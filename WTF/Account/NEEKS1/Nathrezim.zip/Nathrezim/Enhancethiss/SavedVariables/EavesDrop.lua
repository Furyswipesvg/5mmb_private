
EavesDropStatsDB = {
	["profileKeys"] = {
		["Enhancethiss - Nathrezim"] = "Enhancethiss - Nathrezim",
	},
	["profiles"] = {
		["Enhancethiss - Nathrezim"] = {
			[-1] = {
				["hit"] = {
					["Fire"] = {
						[-2] = {
							["time"] = "|cffffffff02/03/13 01:10:13|r\n|Hunit:0x0300000007840FCB:Twinklétoes-Kil'jaeden|hTwinklétoes-Kil'jaeden|h |Hspell:115073:SPELL_DAMAGE|h|cffff1313Spinning Fire Blossom|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000003667F9D:Enhancethiss|hYou|h |cffff13134174|r |cffff1313Fire|r. ",
							["amount"] = 4174,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_explodingjadeblossom",
					},
					["Frost"] = {
						[-2] = {
						},
						[2] = {
							["time"] = "|cffffffff02/07/13 02:25:11|r\n|Hunit:0x010000000022E694:Buid-Dragonmaw|hBuid-Dragonmaw|h |Hspell:116:SPELL_DAMAGE|h|cffff1313Frostbolt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000003667F9D:Enhancethiss|hYou|h |cffff13137767|r |cffff1313Frost|r. (32847 Overkill) (Critical) ",
							["amount"] = 40614,
						},
						["icon"] = "Interface\\Icons\\Spell_Frost_FrostBolt02",
					},
					["Physical"] = {
						[-2] = {
							["time"] = "|cffffffff01/20/13 08:06:27|r\n|Haction:ENVIRONMENTAL_DAMAGE|h|cffffffffFalling|r|h |Haction:ENVIRONMENTAL_DAMAGE|hdamaged|h |Hunit:0x0100000003667F9D:Enhancethiss|hYou|h |cffffffff7997|r |cffffffffPhysical|r. ",
							["amount"] = 7997,
						},
						[2] = {
						},
					},
				},
			},
		},
	},
}
