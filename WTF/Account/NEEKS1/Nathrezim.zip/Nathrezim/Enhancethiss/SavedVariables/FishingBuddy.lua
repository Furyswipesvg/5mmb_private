
FishingBuddy_Player = {
	["MinimapData"] = {
		["hide"] = false,
	},
	["Settings"] = {
		["ResetWatcher"] = 1,
	},
	["WasWearing"] = {
	},
	["Outfit"] = {
	},
}
