
Prat3HighCPUPerCharDB = {
	["time"] = 1360650219,
	["scrollback"] = {
		["ChatFrame1"] = {
			{
				"|cff979797[22:17:44]|r|c00000000|r |Hchannel:channel:1|h[1] |h Joined Channel: |Hchannel:1|h[1. General - Uldum]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				69, -- [5]
			}, -- [1]
			{
				"|cff979797[22:17:44]|r|c00000000|r |Hchannel:channel:2|h[2] |h Joined Channel: |Hchannel:2|h[2. LocalDefense - Uldum]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				70, -- [5]
			}, -- [2]
			{
				"|cff979797[22:17:44]|r|c00000000|r |Hchannel:channel:3|h[3] |h Joined Channel: |Hchannel:3|h[3. WorldDefense]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				71, -- [5]
			}, -- [3]
			{
				"|cff979797[22:17:48]|r|c00000000|r |Hchannel:channel:3|h[3] |h |cffffff00Windshear Crag is under attack!|r", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				71, -- [5]
			}, -- [4]
			{
				"|cff979797[22:17:49]|r|c00000000|r Quest accepted: Grand Master Obalis", -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
				1, -- [5]
			}, -- [5]
			{
				"|cff979797[22:18:06]|r|c00000000|r |Hchannel:channel:3|h[3] |h |cffffff00Trueshot Point is under attack!|r", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				71, -- [5]
			}, -- [6]
			{
				"|cff979797[22:18:19]|r|c00000000|r |Hchannel:channel:3|h[3] |h |cffffff00Talondeep Pass is under attack!|r", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				71, -- [5]
			}, -- [7]
			{
				"|cff979797[22:18:40]|r|c00000000|r |Hchannel:channel:3|h[3] |h |cffffff00Windshear Crag is under attack!|r", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				71, -- [5]
			}, -- [8]
			{
				"|cff979797[22:18:51]|r|c00000000|r |Hchannel:channel:3|h[3] |h |cffffff00Windshear Crag is under attack!|r", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				71, -- [5]
			}, -- [9]
			{
				"|cff979797[22:19:03]|r|c00000000|r |Hchannel:channel:3|h[3] |h |cffffff00Windshear Crag is under attack!|r", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				71, -- [5]
			}, -- [10]
			{
				"|cff979797[22:22:17]|r|c00000000|r |Hchannel:channel:3|h[3] |h |cffffff00Nighthaven is under attack!|r", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				71, -- [5]
			}, -- [11]
			{
				"|cff979797[22:23:14]|r|c00000000|r |Hchannel:channel:3|h[3] |h |cffffff00Refugee Caravan is under attack!|r", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				71, -- [5]
			}, -- [12]
			{
				"|cff979797[22:23:39]|r|c00000000|r Grand Master Obalis completed.", -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
				1, -- [5]
			}, -- [13]
			{
				"|cff979797[22:23:39]|r|c00000000|r Received 90 Silver.", -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
				1, -- [5]
			}, -- [14]
			{
				"|cff979797[22:23:39]|r|c00000000|r Received item: |cffffffff|Hitem:89125:0:0:0:0:0:0:0:60:0:0|h[Sack of Pet Supplies]|h|r.", -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
				1, -- [5]
			}, -- [15]
		},
	},
}
