
TidyPlatesOptions = {
	["FriendlyAutomation"] = "No Automation",
	["_EnableMiniButton"] = false,
	["EnemyAutomation"] = "No Automation",
	["primary"] = "Neon/|cFFFF4400Damage",
	["WelcomeShown"] = true,
	["secondary"] = "Neon/|cFF3782D1Tank",
}
