
EavesDropStatsDB = {
	["profileKeys"] = {
		["Eversmile - Nathrezim"] = "Eversmile - Nathrezim",
	},
	["profiles"] = {
		["Eversmile - Nathrezim"] = {
			{
				["heal"] = {
					["Second Wind"] = {
						[-2] = {
							["time"] = "|cffffffff11/09/12 08:52:53|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:16491:SPELL_PERIODIC_HEAL|h|cffffffffSecond Wind|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cffffffff528|r |cffffffffPhysical|r. ",
							["amount"] = 528,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Hunter_Harass",
					},
					["Drain Life"] = {
						[-2] = {
							["time"] = "|cffffffff06/20/12 05:48:20|r\n|Hunit:0x0100000004D44C01:Eversmile|hEversmile's|h |Hspell:18817:SPELL_HEAL|h|cffffffffDrain Life|r|h heals |Hunit:0x0100000004D44C01:Eversmile|hEversmile|h for |cffffffff55|r.",
							["amount"] = 55,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_LifeDrain02",
					},
					["Victory Rush"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 12:46:26|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:118779:SPELL_HEAL|h|cffffffffVictory Rush|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cffffffff221|r |cffffffffPhysical|r. (2227 Overhealed) ",
							["amount"] = 2448,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\spell_impending_victory",
					},
					["Bloodthirst Heal"] = {
						[-2] = {
							["time"] = "|cffffffff01/12/13 09:49:12|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:117313:SPELL_HEAL|h|cffffffffBloodthirst Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cffffffff0|r |cffffffffPhysical|r. (128 Overhealed) ",
							["amount"] = 128,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_BloodLust",
					},
					["Lifeblood"] = {
						[-2] = {
							["time"] = "|cffffffff06/20/12 05:48:50|r\n|Hunit:0x0100000004D44C01:Eversmile|hEversmile's|h |Hspell:55502:SPELL_HEAL|h|cffffffffLifeblood|r|h heals |Hunit:0x0100000004D44C01:Eversmile|hEversmile|h for |cffffffff134|r.(236 Overhealed)",
							["amount"] = 370,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_WispSplodeGreen",
					},
				},
				["hit"] = {
					["Shield Slam"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 12:47:59|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:23922:SPELL_DAMAGE|h|cffffffffShield Slam|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13043750000429E:Bleeding Hollow Darkcaster|hBleeding Hollow Darkcaster|h |cffffffff5818|r |cffffffffPhysical|r. ",
							["amount"] = 5818,
						},
						[2] = {
							["time"] = "|cffffffff11/30/12 12:49:00|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:23922:SPELL_DAMAGE|h|cffffffffShield Slam|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130439C000042BF:Omor the Unscarred|hOmor the Unscarred|h |cffffffff6410|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 6410,
						},
						["icon"] = "Interface\\Icons\\INV_Shield_05",
					},
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff01/12/13 09:50:35|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF1307F9A00009848:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (380 Overkill) ",
							["amount"] = 381,
						},
						[2] = {
							["time"] = "|cffffffff01/12/13 09:50:16|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF1307F9A00009848:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (761 Overkill) (Critical) ",
							["amount"] = 762,
						},
					},
					["Slam"] = {
						[-2] = {
						},
						[2] = {
							["time"] = "|cffffffff06/20/12 05:49:36|r\n|Hunit:0x0100000004D44C01:Eversmile|hEversmile's|h |Hspell:50782:SPELL_DAMAGE|h|cffffffffSlam|r|h hits |Hunit:0xF3301EAF00012A7E:Southsea Pirate|hSouthsea Pirate|h for |cffffffff1298|r |cffffffffPhysical|r.(Critical)",
							["amount"] = 1298,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_DecisiveStrike",
					},
					["Dragon Roar"] = {
						[-2] = {
						},
						[2] = {
							["time"] = "|cffffffff11/30/12 12:51:10|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:118000:SPELL_DAMAGE|h|cffffffffDragon Roar|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130439B0000428E:Nazan|hNazan|h |cffffffff4440|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 4440,
						},
						["icon"] = "Interface\\Icons\\ability_warrior_dragonroar",
					},
					["Mortal Strike"] = {
						[-2] = {
							["time"] = "|cffffffff06/20/12 05:48:50|r\n|Hunit:0x0100000004D44C01:Eversmile|hEversmile's|h |Hspell:12294:SPELL_DAMAGE|h|cffffffffMortal Strike|r|h hits |Hunit:0xF3301EB200012A03:Southsea Swashbuckler|hSouthsea Swashbuckler|h for |cffffffff529|r |cffffffffPhysical|r.",
							["amount"] = 529,
						},
						[2] = {
							["time"] = "|cffffffff06/20/12 05:49:57|r\n|Hunit:0x0100000004D44C01:Eversmile|hEversmile's|h |Hspell:12294:SPELL_DAMAGE|h|cffffffffMortal Strike|r|h hits |Hunit:0xF3301EB200012A7F:Southsea Swashbuckler|hSouthsea Swashbuckler|h for |cffffffff268|r |cffffffffPhysical|r.(928 Overkill) (Critical)",
							["amount"] = 1196,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_SavageBlow",
					},
					["Thunder Clap"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 12:47:53|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:6343:SPELL_DAMAGE|h|cffffffffThunder Clap|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1304380000042A1:Shattered Hand Warhound|hShattered Hand Warhound|h |cffffffff904|r |cffffffffPhysical|r. ",
							["amount"] = 904,
						},
						[2] = {
							["time"] = "|cffffffff11/30/12 12:47:53|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:6343:SPELL_DAMAGE|h|cffffffffThunder Clap|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130436B000042A0:Bonechewer Hungerer|hBonechewer Hungerer|h |cffffffff1701|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 1701,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_ThunderClap",
					},
					["Raging Blow Off-Hand"] = {
						[-2] = {
							["time"] = "|cffffffff01/12/13 09:49:09|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:85384:SPELL_DAMAGE|h|cffffffffRaging Blow Off-Hand|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1307F9A00009848:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (190 Overkill) ",
							["amount"] = 191,
						},
						[2] = {
							["time"] = "|cffffffff01/12/13 09:50:33|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:85384:SPELL_DAMAGE|h|cffffffffRaging Blow Off-Hand|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1307F9A00009848:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (371 Overkill) (Critical) ",
							["amount"] = 372,
						},
						["icon"] = "Interface\\Icons\\warrior_wild_strike",
					},
					["Raging Blow"] = {
						[-2] = {
							["time"] = "|cffffffff01/12/13 09:49:33|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:96103:SPELL_DAMAGE|h|cffffffffRaging Blow|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1307F9A00009848:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (652 Overkill) ",
							["amount"] = 653,
						},
						[2] = {
							["time"] = "|cffffffff01/12/13 09:50:16|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:96103:SPELL_DAMAGE|h|cffffffffRaging Blow|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1307F9A00009848:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (1313 Overkill) (Critical) ",
							["amount"] = 1314,
						},
						["icon"] = "Interface\\Icons\\warrior_wild_strike",
					},
					["Mithril Shield Spike"] = {
						[-2] = {
							["time"] = "|cffffffff06/20/12 05:48:22|r\n|Hunit:0x0100000004D44C01:Eversmile|hEversmile's|h |Hspell:9782:SPELL_DAMAGE|h|cffffffffMithril Shield Spike|r|h hits |Hunit:0xF3301EB2000129CB:Southsea Swashbuckler|hSouthsea Swashbuckler|h for |cffffffff19|r |cffffffffPhysical|r.",
							["amount"] = 19,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Trade_Engineering",
					},
					["Heroic Strike"] = {
						[-2] = {
							["time"] = "|cffffffff06/20/12 05:48:51|r\n|Hunit:0x0100000004D44C01:Eversmile|hEversmile's|h |Hspell:78:SPELL_DAMAGE|h|cffffffffHeroic Strike|r|h hits |Hunit:0xF3301EB200012A03:Southsea Swashbuckler|hSouthsea Swashbuckler|h for |cffffffff486|r |cffffffffPhysical|r.",
							["amount"] = 486,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Rogue_Ambush",
					},
					["Execute"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 12:49:34|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:5308:SPELL_DAMAGE|h|cffffffffExecute|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130439C000042BF:Omor the Unscarred|hOmor the Unscarred|h |cffffffff4713|r |cffffffffPhysical|r. ",
							["amount"] = 4713,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Sword_48",
					},
					["Drain Life"] = {
						[-2] = {
							["time"] = "|cffffffff06/20/12 05:48:20|r\n|Hunit:0x0100000004D44C01:Eversmile|hEversmile's|h |Hspell:18817:SPELL_DAMAGE|h|cffffffffDrain Life|r|h hits |Hunit:0xF3301EB2000129CB:Southsea Swashbuckler|hSouthsea Swashbuckler|h for |cffffffff55|r |cffffffffShadow|r.",
							["amount"] = 55,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_LifeDrain02",
					},
					["Thunderfury"] = {
						[-2] = {
							["time"] = "|cffffffff06/20/12 05:48:51|r\n|Hunit:0x0100000004D44C01:Eversmile|hEversmile's|h |Hspell:21992:SPELL_DAMAGE|h|cffffffffThunderfury|r|h hits |Hunit:0xF3301EB200012A03:Southsea Swashbuckler|hSouthsea Swashbuckler|h for |cffffffff226|r |cffffffffNature|r.(89 Overkill)",
							["amount"] = 315,
						},
						[2] = {
							["time"] = "|cffffffff11/30/12 12:43:01|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:21992:SPELL_DAMAGE|h|cffffffffThunderfury|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1304377000042B9:Bonechewer Destroyer|hBonechewer Destroyer|h |cffffffff630|r |cffffffffNature|r. (Critical) ",
							["amount"] = 630,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Cyclone",
					},
					["Bloodthirst"] = {
						[-2] = {
							["time"] = "|cffffffff01/12/13 09:49:36|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:23881:SPELL_DAMAGE|h|cffffffffBloodthirst|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1307F9A00009848:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (588 Overkill) ",
							["amount"] = 589,
						},
						[2] = {
							["time"] = "|cffffffff01/12/13 09:50:20|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:23881:SPELL_DAMAGE|h|cffffffffBloodthirst|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1307F9A00009848:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (1201 Overkill) (Critical) ",
							["amount"] = 1202,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_BloodLust",
					},
					["Victory Rush"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 12:47:33|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:34428:SPELL_DAMAGE|h|cffffffffVictory Rush|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1304377000042A8:Bonechewer Destroyer|hBonechewer Destroyer|h |cffffffff808|r |cffffffffPhysical|r. ",
							["amount"] = 808,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_Devastate",
					},
					["Cleave"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 12:45:31|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:845:SPELL_DAMAGE|h|cffffffffCleave|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1304370000042D1:Bonechewer Ravener|hBonechewer Ravener|h |cffffffff368|r |cffffffffPhysical|r. ",
							["amount"] = 368,
						},
						[2] = {
							["time"] = "|cffffffff11/30/12 12:45:37|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:845:SPELL_DAMAGE|h|cffffffffCleave|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130439A00004291:Watchkeeper Gargolmar|hWatchkeeper Gargolmar|h |cffffffff710|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 710,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_Cleave",
					},
					["Revenge"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 12:47:51|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:6572:SPELL_DAMAGE|h|cffffffffRevenge|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13043700000429B:Bonechewer Ravener|hBonechewer Ravener|h |cffffffff667|r |cffffffffPhysical|r. (2615 Overkill) ",
							["amount"] = 3282,
						},
						[2] = {
							["time"] = "|cffffffff11/30/12 12:45:03|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:6572:SPELL_DAMAGE|h|cffffffffRevenge|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130436B000042D4:Bonechewer Hungerer|hBonechewer Hungerer|h |cffffffff536|r |cffffffffPhysical|r. (4422 Overkill) (Critical) ",
							["amount"] = 4958,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_Revenge",
					},
					["Wild Strike"] = {
						[-2] = {
							["time"] = "|cffffffff01/12/13 09:49:28|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:100130:SPELL_DAMAGE|h|cffffffffWild Strike|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1307F9A00009848:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (566 Overkill) ",
							["amount"] = 567,
						},
						[2] = {
							["time"] = "|cffffffff01/12/13 09:50:24|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:100130:SPELL_DAMAGE|h|cffffffffWild Strike|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1307F9A00009848:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (1144 Overkill) (Critical) ",
							["amount"] = 1145,
						},
						["icon"] = "Interface\\Icons\\spell_warrior_wildstrike",
					},
					["Deep Wounds"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 12:47:46|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:115767:SPELL_PERIODIC_DAMAGE|h|cffffffffDeep Wounds|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF1304377000042A7:Bonechewer Destroyer|hBonechewer Destroyer|h |cffffffff377|r |cffffffffPhysical|r. ",
							["amount"] = 377,
						},
						[2] = {
							["time"] = "|cffffffff11/30/12 12:47:49|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:115767:SPELL_PERIODIC_DAMAGE|h|cffffffffDeep Wounds|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130436B0000429A:Bonechewer Hungerer|hBonechewer Hungerer|h |cffffffff754|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 754,
						},
						["icon"] = "Interface\\Icons\\Ability_BackStab",
					},
					["Devastate"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 12:47:58|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:20243:SPELL_DAMAGE|h|cffffffffDevastate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13043750000429E:Bleeding Hollow Darkcaster|hBleeding Hollow Darkcaster|h |cffffffff1796|r |cffffffffPhysical|r. ",
							["amount"] = 1796,
						},
						[2] = {
							["time"] = "|cffffffff11/30/12 12:48:00|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:20243:SPELL_DAMAGE|h|cffffffffDevastate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13043750000429E:Bleeding Hollow Darkcaster|hBleeding Hollow Darkcaster|h |cffffffff9|r |cffffffffPhysical|r. (3713 Overkill) (Critical) ",
							["amount"] = 3722,
						},
						["icon"] = "Interface\\Icons\\INV_Sword_11",
					},
					["Heroic Throw"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 12:45:51|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:57755:SPELL_DAMAGE|h|cffffffffHeroic Throw|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130437700004289:Bonechewer Destroyer|hBonechewer Destroyer|h |cffffffff133|r |cffffffffPhysical|r. ",
							["amount"] = 133,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Axe_66",
					},
					["Shockwave"] = {
						[-2] = {
							["time"] = "|cffffffff01/12/13 09:50:36|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:46968:SPELL_DAMAGE|h|cffffffffShockwave|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1307F9A00009848:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (638 Overkill) ",
							["amount"] = 639,
						},
						[2] = {
							["time"] = "|cffffffff01/12/13 09:49:45|r\n|Hunit:0x0100000004D44C01:Eversmile|hYour|h |Hspell:46968:SPELL_DAMAGE|h|cffffffffShockwave|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1307F9A00009848:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (1161 Overkill) (Critical) ",
							["amount"] = 1162,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_Shockwave",
					},
				},
			}, -- [1]
			[-1] = {
				["heal"] = {
					["Healing Surge"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 12:42:08|r\n|Hunit:0x0300000007617F12:Sorkeknight-Ner'zhul|hSorkeknight-Ner'zhul|h |Hspell:8004:SPELL_HEAL|h|cff82f4ffHealing Surge|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cff82f4ff544|r |cff82f4ffNature|r. (4650 Overhealed) ",
							["amount"] = 5194,
						},
						[2] = {
							["time"] = "|cffffffff11/30/12 12:47:40|r\n|Hunit:0x0300000007617F12:Sorkeknight-Ner'zhul|hSorkeknight-Ner'zhul|h |Hspell:8004:SPELL_HEAL|h|cff82f4ffHealing Surge|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cff82f4ff2556|r |cff82f4ffNature|r. (2669 Overhealed) (Critical) ",
							["amount"] = 5225,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWay",
					},
					["Earthliving"] = {
						[-2] = {
							["time"] = "|cffffffff07/03/12 04:09:45|r\n|Hunit:0x0100000004D44C01:Eversmile|hEversmile|h gains |cff82f4ff0|r Health from |Hunit:0x0100000004877CC9:Jasco|hJasco's|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h.(1438 Overhealed)",
							["amount"] = 1438,
						},
						[2] = {
							["time"] = "|cffffffff11/30/12 12:44:50|r\n|Hunit:0x0300000007617F12:Sorkeknight-Ner'zhul|hSorkeknight-Ner'zhul|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cff82f4ff627|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 627,
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_GiftEarthmother",
					},
					["Earth Shield"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 12:41:57|r\n|Hunit:0x0300000007617F12:Sorkeknight-Ner'zhul|hSorkeknight-Ner'zhul|h |Hspell:379:SPELL_HEAL|h|cff82f4ffEarth Shield|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (702 Overhealed) ",
							["amount"] = 702,
						},
						[2] = {
							["time"] = "|cffffffff11/30/12 12:42:15|r\n|Hunit:0x0300000007617F12:Sorkeknight-Ner'zhul|hSorkeknight-Ner'zhul|h |Hspell:379:SPELL_HEAL|h|cff82f4ffEarth Shield|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cff82f4ff696|r |cff82f4ffNature|r. (708 Overhealed) (Critical) ",
							["amount"] = 1404,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_SkinofEarth",
					},
					["Healing Rain"] = {
						[-2] = {
							["time"] = "|cffffffff07/03/12 04:09:40|r\n|Hunit:0x0100000004877CC9:Jasco|hJasco's|h |Hspell:73921:SPELL_HEAL|h|cff82f4ffHealing Rain|r|h heals |Hunit:0x0100000004D44C01:Eversmile|hEversmile|h for |cff82f4ff0|r.(2432 Overhealed)",
							["amount"] = 2432,
						},
						[2] = {
							["time"] = "|cffffffff11/30/12 12:45:44|r\n|Hunit:0x0300000007617F12:Sorkeknight-Ner'zhul|hSorkeknight-Ner'zhul|h |Hspell:73921:SPELL_HEAL|h|cff82f4ffHealing Rain|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cff82f4ff9|r |cff82f4ffNature|r. (1481 Overhealed) (Critical) ",
							["amount"] = 1490,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_GiftoftheWaterSpirit",
					},
					["Riptide"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 12:42:39|r\n|Hunit:0x0300000007617F12:Sorkeknight-Ner'zhul|hSorkeknight-Ner'zhul|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (1540 Overhealed) ",
							["amount"] = 1540,
						},
						[2] = {
							["time"] = "|cffffffff11/30/12 12:44:03|r\n|Hunit:0x0300000007617F12:Sorkeknight-Ner'zhul|hSorkeknight-Ner'zhul|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (3079 Overhealed) (Critical) ",
							["amount"] = 3079,
						},
						["icon"] = "Interface\\Icons\\spell_nature_riptide",
					},
					["Chi Wave"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 12:45:28|r\n|Hunit:0x038000000591025E:Gorgoroth-Saurfang|hGorgoroth-Saurfang|h |Hspell:132463:SPELL_HEAL|h|cff82f4ffChi Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cff82f4ff752|r |cff82f4ffNature|r. ",
							["amount"] = 752,
						},
						[2] = {
							["time"] = "|cffffffff11/30/12 12:45:28|r\n|Hunit:0x038000000591025E:Gorgoroth-Saurfang|hGorgoroth-Saurfang|h |Hspell:132463:SPELL_HEAL|h|cff82f4ffChi Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cff82f4ff1254|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 1254,
						},
						["icon"] = "Interface\\Icons\\ability_monk_chiwave",
					},
					["Ancestral Awakening"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 12:47:39|r\n|Hunit:0x0300000007617F12:Sorkeknight-Ner'zhul|hSorkeknight-Ner'zhul|h |Hspell:52752:SPELL_HEAL|h|cff82f4ffAncestral Awakening|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cff82f4ff978|r |cff82f4ffNature|r. ",
							["amount"] = 978,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_AncestralAwakening",
					},
					["Chain Heal"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 12:49:35|r\n|Hunit:0x0300000007617F12:Sorkeknight-Ner'zhul|hSorkeknight-Ner'zhul|h |Hspell:1064:SPELL_HEAL|h|cff82f4ffChain Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cff82f4ff617|r |cff82f4ffNature|r. (2804 Overhealed) ",
							["amount"] = 3421,
						},
						[2] = {
							["time"] = "|cffffffff11/30/12 12:47:50|r\n|Hunit:0x0300000007617F12:Sorkeknight-Ner'zhul|hSorkeknight-Ner'zhul|h |Hspell:1064:SPELL_HEAL|h|cff82f4ffChain Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cff82f4ff2131|r |cff82f4ffNature|r. (4711 Overhealed) (Critical) ",
							["amount"] = 6842,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWaveGreater",
					},
					["Healing Stream Totem"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 12:45:36|r\n|Hunit:0x0300000007617F12:Sorkeknight-Ner'zhul|hSorkeknight-Ner'zhul|h |Hspell:52042:SPELL_PERIODIC_HEAL|h|cff82f4ffHealing Stream Totem|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cff82f4ff345|r |cff82f4ffNature|r. ",
							["amount"] = 345,
						},
						[2] = {
							["time"] = "|cffffffff11/30/12 12:45:35|r\n|Hunit:0x0300000007617F12:Sorkeknight-Ner'zhul|hSorkeknight-Ner'zhul|h |Hspell:52042:SPELL_PERIODIC_HEAL|h|cff82f4ffHealing Stream Totem|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cff82f4ff690|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 690,
						},
						["icon"] = "Interface\\Icons\\INV_Spear_04",
					},
					["Greater Healing Wave"] = {
						[-2] = {
						},
						[2] = {
							["time"] = "|cffffffff11/30/12 12:42:29|r\n|Hunit:0x0300000007617F12:Sorkeknight-Ner'zhul|hSorkeknight-Ner'zhul|h |Hspell:77472:SPELL_HEAL|h|cff82f4ffGreater Healing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cff82f4ff6923|r |cff82f4ffNature|r. (5101 Overhealed) (Critical) ",
							["amount"] = 12024,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWaveLesser",
					},
				},
				["hit"] = {
					["Physical"] = {
						[-2] = {
							["time"] = "|cffffffff11/29/12 04:04:26|r\n|Hunit:0x0100000003EC6D55:Thdeath|hThdeath|h |Hspell:55090:SPELL_DAMAGE|h|cffff1313Scourge Strike|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cffff13132607|r |cffff1313Physical|r. (7308 Overkill) ",
							["amount"] = 9915,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_DeathKnight_ScourgeStrike",
					},
					["Shadow"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 12:48:58|r\n|Hunit:0xF130439C000042BF:Omor the Unscarred|hOmor the Unscarred|h |Hspell:30686:SPELL_DAMAGE|h|cffff1313Shadow Bolt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cffff13131472|r |cffff1313Shadow|r. ",
							["amount"] = 1472,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_ShadowBolt",
					},
					["Fire"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 12:51:07|r\n|Hunit:0xF130439B0000428E:Nazan|hNazan|h |Hspell:30926:SPELL_DAMAGE|h|cffff1313Cone of Fire|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004D44C01:Eversmile|hYou|h |cffff1313984|r |cffff1313Fire|r. ",
							["amount"] = 984,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_WindsofWoe",
					},
				},
			},
		},
	},
}
