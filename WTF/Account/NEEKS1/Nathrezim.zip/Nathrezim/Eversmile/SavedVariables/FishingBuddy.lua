
FishingBuddy_Player = {
	["MinimapData"] = {
		["minimapPos"] = 295.1644371962477,
		["hide"] = false,
	},
	["Settings"] = {
		["ResetWatcher"] = 1,
	},
	["WasWearing"] = {
	},
	["Outfit"] = {
	},
}
