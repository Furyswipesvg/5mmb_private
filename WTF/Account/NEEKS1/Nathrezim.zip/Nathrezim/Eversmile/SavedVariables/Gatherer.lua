
Gatherer_SavedSettings_PerCharacter = {
	["SETTINGS_VERSION"] = 2,
}
