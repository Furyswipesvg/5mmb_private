
Prat3HighCPUPerCharDB = {
	["time"] = 1360861127,
	["scrollback"] = {
		["ChatFrame1"] = {
			{
				"|cff979797[23:11:43]|r|c00000000|r |Hchannel:channel:1|h[1] |h Joined Channel: |Hchannel:1|h[1. General - The Veiled Stair]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				69, -- [5]
			}, -- [1]
			{
				"|cff979797[23:11:43]|r|c00000000|r |Hchannel:channel:3|h[3] |h Joined Channel: |Hchannel:3|h[3. LocalDefense - The Veiled Stair]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				71, -- [5]
			}, -- [2]
			{
				"|cff979797[23:11:43]|r|c00000000|r |Hchannel:channel:6|h[6] |h Joined Channel: |Hchannel:6|h[6. world]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				74, -- [5]
			}, -- [3]
			{
				"|cff979797[08:41:04]|r|c00000000|r |Hchannel:channel:1|h[1] |h Joined Channel: |Hchannel:1|h[1. General - The Veiled Stair]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				69, -- [5]
			}, -- [4]
			{
				"|cff979797[08:41:04]|r|c00000000|r |Hchannel:channel:3|h[3] |h Joined Channel: |Hchannel:3|h[3. LocalDefense - The Veiled Stair]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				71, -- [5]
			}, -- [5]
			{
				"|cff979797[08:41:04]|r|c00000000|r |Hchannel:channel:6|h[6] |h Joined Channel: |Hchannel:6|h[6. world]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				74, -- [5]
			}, -- [6]
			{
				"|cff979797[08:41:16]|r|c00000000|r [W From] |cffd8d8d8[|r|HBNplayer:|Kf5|k0000|k:5:5:BN_WHISPER:|Kf5|k0000|k|h|cfffff468|Kf5|k0000|k|r|h|cffd8d8d8]|r: hey :D", -- [1]
				0, -- [2]
				1, -- [3]
				0.9647059440612793, -- [4]
				52, -- [5]
			}, -- [7]
			{
				"|cff979797[08:41:44]|r|c00000000|r [W To] |cffd8d8d8[|r|HBNplayer:|Kf5|k0000|k:5:6:BN_WHISPER:|Kf5|k0000|k|h|cfffff468|Kf5|k0000|k|r|h|cffd8d8d8]|r: heya ", -- [1]
				0, -- [2]
				1, -- [3]
				0.9647059440612793, -- [4]
				53, -- [5]
			}, -- [8]
			{
				"|cff979797[08:58:47]|r|c00000000|r |Hchannel:channel:1|h[1] |h Joined Channel: |Hchannel:1|h[1. General - The Veiled Stair]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				69, -- [5]
			}, -- [9]
			{
				"|cff979797[08:58:47]|r|c00000000|r |Hchannel:channel:3|h[3] |h Joined Channel: |Hchannel:3|h[3. LocalDefense - The Veiled Stair]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				71, -- [5]
			}, -- [10]
			{
				"|cff979797[08:58:47]|r|c00000000|r |Hchannel:channel:6|h[6] |h Joined Channel: |Hchannel:6|h[6. world]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				74, -- [5]
			}, -- [11]
		},
	},
}
