
RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
		["Divinefire"] = {
			["GUID"] = "0x0100000003FE10B9",
			["type"] = "Ungrouped",
			["GuardianReverseGUIDs"] = {
				["Shadowy Apparition"] = {
					["LatestGuardian"] = 3,
					["GUIDs"] = {
						"0xF530F20E002B8A92", -- [1]
						"0xF530F20E002B8A9E", -- [2]
						"0xF530F20E002B8B03", -- [3]
						[0] = "0xF530F20E002B8A89",
					},
				},
			},
			["Owner"] = false,
			["enClass"] = "UNGROUPED",
			["LastFightIn"] = 1,
			["Name"] = "Divinefire",
			["Fights"] = {
			},
			["Pet"] = {
				"Shadowy Apparition <Divinefire>", -- [1]
			},
			["level"] = 1,
			["UnitLockout"] = 1359703613,
			["LastAbility"] = 154482.87,
		},
		["Shadowy Apparition <Divinefire>"] = {
			["GUID"] = "0xF530F20E002B8B03",
			["LastEventHealth"] = {
				"???", -- [1]
				"???", -- [2]
				"???", -- [3]
				"???", -- [4]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
			},
			["TimeWindows"] = {
				["Damage"] = {
					28532, -- [1]
				},
				["TimeDamage"] = {
					10.71, -- [1]
				},
				["ActiveTime"] = {
					10.71, -- [1]
				},
			},
			["enClass"] = "PET",
			["level"] = 1,
			["LastFightIn"] = 1,
			["type"] = "Pet",
			["LastAbility"] = 154482.87,
			["LastEventTimes"] = {
				87427.895, -- [1]
				87429.978, -- [2]
				87431.605, -- [3]
				87439.207, -- [4]
			},
			["Owner"] = "Divinefire",
			["LastFlags"] = 2600,
			["NextEventNum"] = 5,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
			},
			["LastEvents"] = {
				"Shadowy Apparition <Divinefire> Shadowy Apparition Incarnation of Despair Crit -9510 (Shadow)", -- [1]
				"Shadowy Apparition <Divinefire> Shadowy Apparition Incarnation of Despair Hit -4755 (Shadow)", -- [2]
				"Shadowy Apparition <Divinefire> Shadowy Apparition Incarnation of Despair Crit -9511 (Shadow)", -- [3]
				"Shadowy Apparition <Divinefire> Shadowy Apparition Incarnation of Despair Hit -4756 (Shadow)", -- [4]
			},
			["Name"] = "Shadowy Apparition",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
			},
			["TimeLast"] = {
				["Damage"] = 1359703626,
				["OVERALL"] = 1359703626,
				["TimeDamage"] = 1359703626,
				["ActiveTime"] = 1359703626,
			},
			["Fights"] = {
				["CurrentFightData"] = {
					["TimeSpent"] = {
						["Incarnation of Despair"] = {
							["Details"] = {
								["Shadowy Apparition"] = {
									["count"] = 10.71,
								},
							},
							["amount"] = 10.71,
						},
					},
					["ElementDone"] = {
						["Shadow"] = 28532,
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 4,
						},
					},
					["DamagedWho"] = {
						["Incarnation of Despair"] = {
							["Details"] = {
								["Shadowy Apparition"] = {
									["count"] = 28532,
								},
							},
							["amount"] = 28532,
						},
					},
					["TimeDamage"] = 10.71,
					["TimeDamaging"] = {
						["Incarnation of Despair"] = {
							["Details"] = {
								["Shadowy Apparition"] = {
									["count"] = 10.71,
								},
							},
							["amount"] = 10.71,
						},
					},
					["Attacks"] = {
						["Shadowy Apparition"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9511,
									["min"] = 9510,
									["count"] = 2,
									["amount"] = 19021,
								},
								["Hit"] = {
									["max"] = 4756,
									["min"] = 4755,
									["count"] = 2,
									["amount"] = 9511,
								},
							},
							["count"] = 4,
							["amount"] = 28532,
						},
					},
					["ActiveTime"] = 10.71,
					["Damage"] = 28532,
				},
				["OverallData"] = {
					["TimeSpent"] = {
						["Incarnation of Despair"] = {
							["Details"] = {
								["Shadowy Apparition"] = {
									["count"] = 10.71,
								},
							},
							["amount"] = 10.71,
						},
					},
					["ElementDone"] = {
						["Shadow"] = 28532,
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 4,
						},
					},
					["DamagedWho"] = {
						["Incarnation of Despair"] = {
							["Details"] = {
								["Shadowy Apparition"] = {
									["count"] = 28532,
								},
							},
							["amount"] = 28532,
						},
					},
					["TimeDamage"] = 10.71,
					["TimeDamaging"] = {
						["Incarnation of Despair"] = {
							["Details"] = {
								["Shadowy Apparition"] = {
									["count"] = 10.71,
								},
							},
							["amount"] = 10.71,
						},
					},
					["Attacks"] = {
						["Shadowy Apparition"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9511,
									["min"] = 9510,
									["count"] = 2,
									["amount"] = 19021,
								},
								["Hit"] = {
									["max"] = 4756,
									["min"] = 4755,
									["count"] = 2,
									["amount"] = 9511,
								},
							},
							["count"] = 4,
							["amount"] = 28532,
						},
					},
					["ActiveTime"] = 10.71,
					["Damage"] = 28532,
				},
			},
			["UnitLockout"] = 1359703626,
			["LastActive"] = 1359703626,
		},
		["Eversmile"] = {
			["GUID"] = "0x0100000004D44C01",
			["LastEventHealth"] = {
				"10782 (84%)", -- [1]
			},
			["LastAttackedBy"] = "Environment",
			["LastEventType"] = {
				"DAMAGE", -- [1]
			},
			["TimeWindows"] = {
				["DamageTaken"] = {
					1935, -- [1]
				},
			},
			["enClass"] = "WARRIOR",
			["unit"] = "Eversmile",
			["level"] = 60,
			["LastDamageAbility"] = "Falling",
			["LastFightIn"] = 0,
			["LastEventNum"] = {
				15.21585279547063, -- [1]
			},
			["type"] = "Self",
			["FightsSaved"] = 1,
			["LastAbility"] = 154482.87,
			["UnitLockout"] = 1358057673,
			["Owner"] = false,
			["LastDamageTaken"] = 1935,
			["NextEventNum"] = 2,
			["LastEventHealthNum"] = {
				84.78414720452938, -- [1]
			},
			["LastEvents"] = {
				"Environment Falling Eversmile Hit -1935 (Physical)", -- [1]
			},
			["Name"] = "Eversmile",
			["Fights"] = {
				["OverallData"] = {
					["PartialResist"] = {
						["Falling"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Falling"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["Environment"] = {
							["Details"] = {
								["Falling"] = {
									["count"] = 1935,
								},
							},
							["amount"] = 1935,
						},
					},
					["ElementTaken"] = {
						["Physical"] = 1935,
					},
					["DamageTaken"] = 1935,
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
				},
				["LastFightData"] = {
					["PartialResist"] = {
						["Falling"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Falling"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["Environment"] = {
							["Details"] = {
								["Falling"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTaken"] = {
						["Physical"] = 0,
					},
					["DamageTaken"] = 0,
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["FDamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["RageGain"] = 0,
					["ElementDone"] = {
					},
					["ManaGainedFrom"] = {
					},
					["ElementHitsDone"] = {
					},
					["RageGained"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["RunicPowerGained"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
					},
					["ActiveTime"] = 0,
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGainedFrom"] = {
					},
					["CCBroken"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["PartialResist"] = {
						["Falling"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Falling"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["Environment"] = {
							["Details"] = {
								["Falling"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTaken"] = {
						["Physical"] = 0,
					},
					["DamageTaken"] = 0,
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
				},
			},
			["TimeLast"] = {
				["DamageTaken"] = 1358057673,
				["OVERALL"] = 1358057673,
			},
			["LastEventIncoming"] = {
				true, -- [1]
			},
			["LastEventTimes"] = {
				191744.439, -- [1]
			},
			["LastActive"] = 1358057673,
		},
		["Mootalia"] = {
			["GUID"] = "0x0100000000268382",
			["LastEventHealth"] = {
				"391302 (100%)", -- [1]
				"391302 (100%)", -- [2]
				"391302 (100%)", -- [3]
				"391302 (100%)", -- [4]
				"391302 (100%)", -- [5]
				"391302 (100%)", -- [6]
				"391302 (100%)", -- [7]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"HEAL", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
			},
			["TimeWindows"] = {
				["RageGain"] = {
					30, -- [1]
				},
				["Overhealing"] = {
					3913, -- [1]
				},
				["ActiveTime"] = {
					9.67, -- [1]
				},
				["TimeDamage"] = {
					9.67, -- [1]
				},
				["Damage"] = {
					135310, -- [1]
				},
			},
			["enClass"] = "WARRIOR",
			["unit"] = "Mootalia",
			["level"] = 90,
			["LastFightIn"] = 1,
			["LastEventNum"] = {
				[3] = 0.9999948888582221,
			},
			["type"] = "Ungrouped",
			["FightsSaved"] = 1,
			["LastActive"] = 1358057766,
			["Owner"] = false,
			["UnitLockout"] = 1358057756,
			["NextEventNum"] = 8,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				100, -- [6]
				100, -- [7]
			},
			["LastEvents"] = {
				"Mootalia Warbringer Lava Annihilator Immune (Physical)", -- [1]
				"Mootalia Melee Lava Annihilator Hit -13497 (Physical)", -- [2]
				"Mootalia Bloodthirst Heal Mootalia Hit +3913 (3913 overheal)", -- [3]
				"Mootalia Melee Lava Annihilator Crit -49511 (Physical)", -- [4]
				"Mootalia Melee Lava Annihilator Hit -17700 (Physical)", -- [5]
				"Mootalia Melee Lava Surger Crit -41932 (Physical)", -- [6]
				"Mootalia Melee Lava Surger Hit -12670 (Physical)", -- [7]
			},
			["Name"] = "Mootalia",
			["Fights"] = {
				["OverallData"] = {
					["OverHeals"] = {
						["Bloodthirst Heal"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 3913,
									["min"] = 3913,
									["count"] = 1,
									["amount"] = 3913,
								},
							},
							["count"] = 1,
							["amount"] = 3913,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 49511,
									["min"] = 41932,
									["count"] = 2,
									["amount"] = 91443,
								},
								["Hit"] = {
									["max"] = 17700,
									["min"] = 12670,
									["count"] = 3,
									["amount"] = 43867,
								},
							},
							["count"] = 5,
							["amount"] = 135310,
						},
						["Warbringer"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Lava Annihilator"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 80708,
								},
							},
							["amount"] = 80708,
						},
						["Lava Surger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 54602,
								},
							},
							["amount"] = 54602,
						},
					},
					["TimeSpent"] = {
						["Lava Annihilator"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.67,
								},
								["Warbringer"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 6.17,
						},
						["Lava Surger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 5,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["RageGainedFrom"] = {
						["Mootalia"] = {
							["Details"] = {
								["Enrage"] = {
									["count"] = 20,
								},
								["Bloodthirst"] = {
									["count"] = 10,
								},
							},
							["amount"] = 30,
						},
					},
					["ElementDone"] = {
						["Melee"] = 135310,
					},
					["RageGain"] = 30,
					["Overhealing"] = 3913,
					["ActiveTime"] = 9.67,
					["TimeDamaging"] = {
						["Lava Annihilator"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.67,
								},
								["Warbringer"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 6.17,
						},
						["Lava Surger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["TimeDamage"] = 9.67,
					["RageGained"] = {
						["Enrage"] = {
							["Details"] = {
								["Mootalia"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
						["Bloodthirst"] = {
							["Details"] = {
								["Mootalia"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["Damage"] = 135310,
				},
				["LastFightData"] = {
					["OverHeals"] = {
						["Bloodthirst Heal"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 3913,
									["min"] = 3913,
									["count"] = 1,
									["amount"] = 3913,
								},
							},
							["count"] = 1,
							["amount"] = 3913,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 49511,
									["min"] = 49511,
									["count"] = 1,
									["amount"] = 49511,
								},
								["Hit"] = {
									["max"] = 17700,
									["min"] = 13497,
									["count"] = 2,
									["amount"] = 31197,
								},
							},
							["count"] = 3,
							["amount"] = 80708,
						},
						["Warbringer"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Lava Annihilator"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 80708,
								},
							},
							["amount"] = 80708,
						},
					},
					["TimeSpent"] = {
						["Lava Annihilator"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.67,
								},
								["Warbringer"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 6.17,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 3,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["RageGainedFrom"] = {
						["Mootalia"] = {
							["Details"] = {
								["Enrage"] = {
									["count"] = 20,
								},
								["Bloodthirst"] = {
									["count"] = 10,
								},
							},
							["amount"] = 30,
						},
					},
					["ElementDone"] = {
						["Melee"] = 80708,
					},
					["RageGain"] = 30,
					["Overhealing"] = 3913,
					["ActiveTime"] = 6.17,
					["TimeDamaging"] = {
						["Lava Annihilator"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.67,
								},
								["Warbringer"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 6.17,
						},
					},
					["TimeDamage"] = 6.17,
					["RageGained"] = {
						["Enrage"] = {
							["Details"] = {
								["Mootalia"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
						["Bloodthirst"] = {
							["Details"] = {
								["Mootalia"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["Damage"] = 80708,
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["FDamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["RageGain"] = 0,
					["ElementDone"] = {
						["Melee"] = 0,
					},
					["ManaGainedFrom"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RageGained"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["RunicPowerGained"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
					},
					["ActiveTime"] = 0,
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["Lava Surger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGainedFrom"] = {
					},
					["CCBroken"] = {
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["Lava Surger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["Lava Surger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["OverHeals"] = {
						["Bloodthirst Heal"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 3913,
									["min"] = 3913,
									["count"] = 1,
									["amount"] = 3913,
								},
							},
							["count"] = 1,
							["amount"] = 3913,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 49511,
									["min"] = 49511,
									["count"] = 1,
									["amount"] = 49511,
								},
								["Hit"] = {
									["max"] = 17700,
									["min"] = 13497,
									["count"] = 2,
									["amount"] = 31197,
								},
							},
							["count"] = 3,
							["amount"] = 80708,
						},
						["Warbringer"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Lava Annihilator"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 80708,
								},
							},
							["amount"] = 80708,
						},
					},
					["TimeSpent"] = {
						["Lava Annihilator"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.67,
								},
								["Warbringer"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 6.17,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 3,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["RageGainedFrom"] = {
						["Mootalia"] = {
							["Details"] = {
								["Enrage"] = {
									["count"] = 20,
								},
								["Bloodthirst"] = {
									["count"] = 10,
								},
							},
							["amount"] = 30,
						},
					},
					["ElementDone"] = {
						["Melee"] = 80708,
					},
					["RageGain"] = 30,
					["Overhealing"] = 3913,
					["ActiveTime"] = 6.17,
					["TimeDamaging"] = {
						["Lava Annihilator"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.67,
								},
								["Warbringer"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 6.17,
						},
					},
					["TimeDamage"] = 6.17,
					["RageGained"] = {
						["Enrage"] = {
							["Details"] = {
								["Mootalia"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
						["Bloodthirst"] = {
							["Details"] = {
								["Mootalia"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["Damage"] = 80708,
				},
			},
			["TimeLast"] = {
				["RageGain"] = 1358057757,
				["Overhealing"] = 1358057757,
				["ActiveTime"] = 1358057766,
				["OVERALL"] = 1358057766,
				["TimeDamage"] = 1358057766,
				["Damage"] = 1358057766,
			},
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				true, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
			},
			["LastEventTimes"] = {
				191827.831, -- [1]
				191828.338, -- [2]
				191828.532, -- [3]
				191828.584, -- [4]
				191830.492, -- [5]
				191837.781, -- [6]
				191837.781, -- [7]
			},
			["LastAbility"] = 154482.87,
		},
	},
	["FightNum"] = 1,
	["CombatTimes"] = {
		{
			1358057756, -- [1]
			1358057762, -- [2]
			"22:15:56", -- [3]
			"22:16:02", -- [4]
			"Lava Annihilator", -- [5]
		}, -- [1]
	},
	["FoughtWho"] = {
		"Lava Annihilator 22:15:56-22:16:02", -- [1]
	},
}
