
EavesDropStatsDB = {
	["profileKeys"] = {
		["Gato - Nathrezim"] = "Gato - Nathrezim",
	},
	["profiles"] = {
		["Gato - Nathrezim"] = {
			{
				["heal"] = {
					["Mend Pet"] = {
						[-2] = {
							["time"] = "|cffffffff12/13/12 05:52:53|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:136:SPELL_PERIODIC_HEAL|h|cffffffffMend Pet|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0xF540A08EC30035CD:StormWormed|hStormWormed|h |cffffffff5118|r |cffffffffNature|r. (5289 Overhealed) ",
							["amount"] = 10407,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Hunter_MendPet",
					},
					["Cintron-Infused Bandage"] = {
						[-2] = {
							["time"] = "|cffffffff12/13/12 05:36:18|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:120573:SPELL_PERIODIC_HEAL|h|cffffffffCintron-Infused Bandage|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0xF530F0FC001B3E2F:Injured Gao-Ran Blackguard|hInjured Gao-Ran Blackguard|h |cffffffff39395|r |cffffffffPhysical|r. ",
							["amount"] = 39395,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\inv_misc_bandage_frostweave",
					},
				},
				["hit"] = {
					["Mantid Poison"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 09:30:04|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:128386:SPELL_PERIODIC_DAMAGE|h|cffffffffMantid Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF1308DC80001AD2C:Apothecary Hummel|hApothecary Hummel|h |cffffffff4239|r |cffffffffNature|r. ",
							["amount"] = 4239,
						},
						[2] = {
							["time"] = "|cffffffff02/10/13 09:30:01|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:128386:SPELL_PERIODIC_DAMAGE|h|cffffffffMantid Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF1308DC80001AD2C:Apothecary Hummel|hApothecary Hummel|h |cffffffff8477|r |cffffffffNature|r. (Critical) ",
							["amount"] = 8477,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_NullifyPoison",
					},
					["Cobra Shot"] = {
						[-2] = {
							["time"] = "|cffffffff12/13/12 05:52:43|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:77767:SPELL_DAMAGE|h|cffffffffCobra Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530F374001DFCE0:Norvakess|hNorvakess|h |cffffffff17485|r |cffffffffNature|r. ",
							["amount"] = 17485,
						},
						[2] = {
							["time"] = "|cffffffff12/13/12 05:49:45|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:77767:SPELL_DAMAGE|h|cffffffffCobra Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530F374001DFCE0:Norvakess|hNorvakess|h |cffffffff28480|r |cffffffffNature|r. (Critical) ",
							["amount"] = 28480,
						},
						["icon"] = "INTERFACE\\ICONS\\ability_hunter_cobrashot",
					},
					["Auto Shot"] = {
						[-2] = {
							["time"] = "|cffffffff12/13/12 05:52:46|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Haction:RANGE_DAMAGE|h|cffffffffAuto Shot|r|h |Haction:RANGE_DAMAGE|hhit|h |Hunit:0xF530F374001DFCE0:Norvakess|hNorvakess|h |cffffffff18727|r |cffffffffPhysical|r. ",
							["amount"] = 18727,
						},
						[2] = {
							["time"] = "|cffffffff12/13/12 05:53:39|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Haction:RANGE_DAMAGE|h|cffffffffAuto Shot|r|h |Haction:RANGE_DAMAGE|hhit|h |Hunit:0xF530F374001DFCE0:Norvakess|hNorvakess|h |cffffffff33865|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 33865,
						},
					},
					["Serpent Sting"] = {
						[-2] = {
							["time"] = "|cffffffff12/13/12 05:52:46|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:118253:SPELL_PERIODIC_DAMAGE|h|cffffffffSerpent Sting|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF530F374001DFCE0:Norvakess|hNorvakess|h |cffffffff15039|r |cffffffffNature|r. ",
							["amount"] = 15039,
						},
						[2] = {
							["time"] = "|cffffffff12/13/12 05:52:40|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:118253:SPELL_PERIODIC_DAMAGE|h|cffffffffSerpent Sting|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF530F374001DFCE0:Norvakess|hNorvakess|h |cffffffff30979|r |cffffffffNature|r. (Critical) ",
							["amount"] = 30979,
						},
						["icon"] = "Interface\\Icons\\Ability_Hunter_Quickshot",
					},
					["Multi-Shot"] = {
						[-2] = {
							["time"] = "|cffffffff12/13/12 05:53:44|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:2643:SPELL_DAMAGE|h|cffffffffMulti-Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530F374001DFCE0:Norvakess|hNorvakess|h |cffffffff8012|r |cffffffffPhysical|r. ",
							["amount"] = 8012,
						},
						[2] = {
							["time"] = "|cffffffff12/13/12 07:59:26|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:2643:SPELL_DAMAGE|h|cffffffffMulti-Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130B637000054AC:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (10796 Overkill) (Critical) ",
							["amount"] = 10797,
						},
						["icon"] = "Interface\\Icons\\Ability_UpgradeMoonGlaive",
					},
					["Arcane Shot"] = {
						[-2] = {
							["time"] = "|cffffffff12/13/12 05:50:41|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:3044:SPELL_DAMAGE|h|cffffffffArcane Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530F374001DFCE0:Norvakess|hNorvakess|h |cffffffff27135|r |cffffffffArcane|r. ",
							["amount"] = 27135,
						},
						[2] = {
							["time"] = "|cffffffff12/13/12 05:49:57|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:3044:SPELL_DAMAGE|h|cffffffffArcane Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530F374001DFCE0:Norvakess|hNorvakess|h |cffffffff41240|r |cffffffffArcane|r. (Critical) ",
							["amount"] = 41240,
						},
						["icon"] = "Interface\\Icons\\Ability_ImpalingBolt",
					},
					["Explosive Shot"] = {
						[-2] = {
							["time"] = "|cffffffff12/13/12 08:31:16|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:53301:SPELL_PERIODIC_DAMAGE|h|cffffffffExplosive Shot|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF530EFAB001FA582:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff11736|r |cffffffffFire|r. ",
							["amount"] = 11736,
						},
						[2] = {
							["time"] = "|cffffffff12/13/12 08:31:18|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:53301:SPELL_PERIODIC_DAMAGE|h|cffffffffExplosive Shot|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF530EFAB001FA582:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff23472|r |cffffffffFire|r. (Critical) ",
							["amount"] = 23472,
						},
						["icon"] = "Interface\\Icons\\Ability_Hunter_ExplosiveShot",
					},
					["Kill Shot"] = {
						[-2] = {
							["time"] = "|cffffffff12/13/12 05:54:23|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:53351:SPELL_DAMAGE|h|cffffffffKill Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530F374001DFCE0:Norvakess|hNorvakess|h |cffffffff65889|r |cffffffffPhysical|r. ",
							["amount"] = 65889,
						},
						[2] = {
							["time"] = "|cffffffff12/13/12 08:59:10|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:53351:SPELL_DAMAGE|h|cffffffffKill Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB0021DCD0:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff33208|r |cffffffffPhysical|r. (17386 Overkill) (Critical) ",
							["amount"] = 50594,
						},
						["icon"] = "Interface\\Icons\\Ability_Hunter_Assassinate2",
					},
					["Firewall"] = {
						[-2] = {
							["time"] = "|cffffffff12/08/12 01:11:25|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:128517:SPELL_PERIODIC_DAMAGE|h|cffffffffFirewall|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x010000000352EAEF:Gato|hYou|h |cffffffff29790|r |cffffffffFire|r. ",
							["amount"] = 29790,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_Immolation",
					},
					["Speaking of Rage"] = {
						[-2] = {
							["time"] = "|cffffffff12/13/12 05:52:38|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:109856:SPELL_PERIODIC_DAMAGE|h|cffffffffSpeaking of Rage|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF530F374001DFCE0:Norvakess|hNorvakess|h |cffffffff1748|r |cffffffffFire|r. ",
							["amount"] = 1748,
						},
						[2] = {
							["time"] = "|cffffffff12/13/12 05:52:38|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:109856:SPELL_PERIODIC_DAMAGE|h|cffffffffSpeaking of Rage|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF530F374001DFCE0:Norvakess|hNorvakess|h |cffffffff3602|r |cffffffffFire|r. (Critical) ",
							["amount"] = 3602,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_FlameBlades",
					},
					["Explosive Trap"] = {
						[-2] = {
							["time"] = "|cffffffff12/13/12 08:15:22|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:13812:SPELL_PERIODIC_DAMAGE|h|cffffffffExplosive Trap|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130B637000054B0:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffFire|r. (2049 Overkill) ",
							["amount"] = 2050,
						},
						[2] = {
							["time"] = "|cffffffff12/13/12 08:15:34|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:13812:SPELL_PERIODIC_DAMAGE|h|cffffffffExplosive Trap|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130B637000006A1:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffFire|r. (4099 Overkill) (Critical) ",
							["amount"] = 4100,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_SelfDestruct",
					},
					["Improved Serpent Sting"] = {
						[-2] = {
							["time"] = "|cffffffff12/13/12 07:59:26|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:83077:SPELL_DAMAGE|h|cffffffffImproved Serpent Sting|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130B637000054B0:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffNature|r. (8926 Overkill) ",
							["amount"] = 8927,
						},
						[2] = {
							["time"] = "|cffffffff12/13/12 07:59:28|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:83077:SPELL_DAMAGE|h|cffffffffImproved Serpent Sting|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130B637000054B0:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffNature|r. (17853 Overkill) (Critical) ",
							["amount"] = 17854,
						},
						["icon"] = "Interface\\Icons\\Ability_Hunter_Quickshot",
					},
					["Black Arrow"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 09:29:58|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:3674:SPELL_PERIODIC_DAMAGE|h|cffffffffBlack Arrow|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF1308DC80001AD2C:Apothecary Hummel|hApothecary Hummel|h |cffffffff3540|r |cffffffffShadow|r. ",
							["amount"] = 3540,
						},
						[2] = {
							["time"] = "|cffffffff02/10/13 09:30:04|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:3674:SPELL_PERIODIC_DAMAGE|h|cffffffffBlack Arrow|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF1308DC80001AD2C:Apothecary Hummel|hApothecary Hummel|h |cffffffff7079|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 7079,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_PainSpike",
					},
					["Scatter Shot"] = {
						[-2] = {
							["time"] = "|cffffffff12/13/12 08:31:55|r\n|Hunit:0x010000000352EAEF:Gato|hYour|h |Hspell:19503:SPELL_DAMAGE|h|cffffffffScatter Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530EFAB001FA7AE:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff3595|r |cffffffffPhysical|r. ",
							["amount"] = 3595,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_GolemStormBolt",
					},
				},
			}, -- [1]
			[-1] = {
				["hit"] = {
					["Nature"] = {
						[-2] = {
							["time"] = "|cffffffff12/08/12 12:37:47|r\n|Hunit:0xF130E818001CB8B3:Broketooth Tosser|hBroketooth Tosser|h |Hspell:114249:SPELL_DAMAGE|h|cffff1313Sling Derk|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000352EAEF:Gato|hYou|h |cffff13139385|r |cffff1313Nature|r. ",
							["amount"] = 9385,
						},
						[2] = {
							["time"] = "|cffffffff10/23/12 08:18:25|r\n|Hunit:0xF1302DE000031D2D:Dust Stormer|hDust Stormer|h |Haction:SWING_DAMAGE|h|cffff1313Melee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0x010000000352EAEF:Gato|hYou|h |cffff1313502|r |cffff1313Nature|r. (Critical) ",
							["amount"] = 502,
						},
						["icon"] = "Interface\\Icons\\INV_Elemental_Mote_Earth01",
					},
					["Physical"] = {
						[-2] = {
							["time"] = "|cffffffff12/29/12 12:00:29|r\n|Haction:ENVIRONMENTAL_DAMAGE|h|cffffffffFalling|r|h |Haction:ENVIRONMENTAL_DAMAGE|hdamaged|h |Hunit:0x010000000352EAEF:Gato|hYou|h |cffffffff277009|r |cffffffffPhysical|r. ",
							["amount"] = 277009,
						},
						[2] = {
							["time"] = "|cffffffff12/13/12 10:18:10|r\n|Hunit:0xF53024F40015797D:Gadgetzan Bruiser|hGadgetzan Bruiser|h |Haction:SWING_DAMAGE|h|cffff1313Melee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0x010000000352EAEF:Gato|hYou|h |cffff131351315|r |cffff1313Physical|r. (Critical) ",
							["amount"] = 51315,
						},
					},
					["Fire"] = {
						[-2] = {
							["time"] = "|cffffffff12/08/12 12:43:07|r\n|Hunit:0xF130EA44001E1983:Ordo Warrior|hOrdo Warrior|h |Hspell:114890:SPELL_DAMAGE|h|cffff1313Exploding Oil Barrel|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000352EAEF:Gato|hYou|h |cffff13138219|r |cffff1313Fire|r. ",
							["amount"] = 8219,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_vehicle_liquidpyrite",
					},
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff12/08/12 12:43:18|r\n|Hunit:0xF130EA44001E1983:Ordo Warrior|hOrdo Warrior|h |Hspell:94730:SPELL_PERIODIC_DAMAGE|h|cffff1313Flaming Ooze|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x010000000352EAEF:Gato|hYou|h |cffff1313621|r |cffff1313Firestorm|r. ",
							["amount"] = 621,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Ammo_FireTar",
					},
				},
				["heal"] = {
					["Blood Burst"] = {
						[-2] = {
							["time"] = "|cffffffff12/22/12 09:10:53|r\n|Hunit:0xF1306D710021E449:Bloodworm|hBloodworm|h |Hspell:81280:SPELL_HEAL|h|cff82f4ffBlood Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EAEF:Gato|hYou|h |cff82f4ff33782|r |cff82f4ffShadow|r. ",
							["amount"] = 33782,
						},
						[2] = {
							["time"] = "|cffffffff12/17/12 11:58:16|r\n|Hunit:0xF5306D710057676C:Bloodworm|hBloodworm|h |Hspell:81280:SPELL_HEAL|h|cff82f4ffBlood Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EAEF:Gato|hYou|h |cff82f4ff13722|r |cff82f4ffShadow|r. (34440 Overhealed) (Critical) ",
							["amount"] = 48162,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_BloodNova",
					},
					["Prayer of Healing"] = {
						[-2] = {
						},
						[2] = {
							["time"] = "|cffffffff02/10/13 09:29:12|r\n|Hunit:0x0300000006C1BD5C:Kardinalsinn-Barthilas|hKardinalsinn-Barthilas|h |Hspell:596:SPELL_HEAL|h|cff82f4ffPrayer of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EAEF:Gato|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (56814 Overhealed) (Critical) ",
							["amount"] = 56814,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfHealing02",
					},
					["Renewing Mist"] = {
						[-2] = {
							["time"] = "|cffffffff02/06/13 08:40:33|r\n|Hunit:0x01000000050DB98E:Caesfu|hCaesfu|h |Hspell:119611:SPELL_PERIODIC_HEAL|h|cff82f4ffRenewing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000352EAEF:Gato|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (6309 Overhealed) ",
							["amount"] = 6309,
						},
						[2] = {
							["time"] = "|cffffffff02/06/13 08:40:30|r\n|Hunit:0x01000000050DB98E:Caesfu|hCaesfu|h |Hspell:119611:SPELL_PERIODIC_HEAL|h|cff82f4ffRenewing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000352EAEF:Gato|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (12996 Overhealed) (Critical) ",
							["amount"] = 12996,
						},
						["icon"] = "Interface\\Icons\\ability_monk_renewingmists",
					},
				},
			},
		},
	},
}
