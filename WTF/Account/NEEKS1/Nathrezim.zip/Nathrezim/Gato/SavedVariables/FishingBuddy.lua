
FishingBuddy_Player = {
	["MinimapData"] = {
		["minimapPos"] = 341.987437397408,
		["hide"] = false,
	},
	["Settings"] = {
		["ResetWatcher"] = 1,
	},
	["WasWearing"] = {
	},
	["Outfit"] = {
	},
}
