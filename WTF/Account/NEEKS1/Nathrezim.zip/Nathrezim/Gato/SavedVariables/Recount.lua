
RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
		["Underworld <Gato>"] = {
			["GUID"] = "0xF1408C97E9000350",
			["LastEventHealth"] = {
				"215386 (99%)", -- [1]
				"215386 (99%)", -- [2]
				"215764 (100%)", -- [3]
				"215373 (99%)", -- [4]
				"215388 (99%)", -- [5]
				"215388 (99%)", -- [6]
				"215388 (99%)", -- [7]
				"214987 (99%)", -- [8]
				"215764 (100%)", -- [9]
				"215376 (99%)", -- [10]
				"215376 (99%)", -- [11]
				"215764 (100%)", -- [12]
				"215764 (100%)", -- [13]
				"215764 (100%)", -- [14]
				"215764 (100%)", -- [15]
				"215764 (100%)", -- [16]
				"215764 (100%)", -- [17]
				"215764 (100%)", -- [18]
				"215764 (100%)", -- [19]
				"215764 (100%)", -- [20]
				"215764 (100%)", -- [21]
				"214993 (99%)", -- [22]
				"214993 (99%)", -- [23]
				"215764 (100%)", -- [24]
				"215764 (100%)", -- [25]
				"214987 (99%)", -- [26]
				"214987 (99%)", -- [27]
				"215764 (100%)", -- [28]
				"215764 (100%)", -- [29]
				"215764 (100%)", -- [30]
				"215764 (100%)", -- [31]
				"215764 (100%)", -- [32]
				"215764 (100%)", -- [33]
				"215764 (100%)", -- [34]
				"215764 (100%)", -- [35]
				"215764 (100%)", -- [36]
				"196131 (100%)", -- [37]
				"196131 (100%)", -- [38]
				"196131 (100%)", -- [39]
				"196131 (100%)", -- [40]
				"196131 (100%)", -- [41]
				"196131 (100%)", -- [42]
				"215764 (100%)", -- [43]
				"215764 (100%)", -- [44]
				"215398 (99%)", -- [45]
				"215398 (99%)", -- [46]
				"215764 (100%)", -- [47]
				"215764 (100%)", -- [48]
				"214988 (99%)", -- [49]
				"215764 (100%)", -- [50]
			},
			["LastAttackedBy"] = "Apothecary Baxter",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"HEAL", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"HEAL", -- [17]
				"HEAL", -- [18]
				"DAMAGE", -- [19]
				"HEAL", -- [20]
				"HEAL", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"HEAL", -- [24]
				"HEAL", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"HEAL", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"HEAL", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"HEAL", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["HealingTaken"] = {
					11986, -- [1]
				},
				["ActiveTime"] = {
					125.55, -- [1]
				},
				["TimeDamage"] = {
					125.55, -- [1]
				},
				["DamageTaken"] = {
					57876, -- [1]
				},
				["DOT_Time"] = {
					57, -- [1]
				},
				["Damage"] = {
					697218, -- [1]
				},
			},
			["enClass"] = "PET",
			["unit"] = "Underworld",
			["LastActive"] = 1360561112,
			["level"] = 1,
			["LastDamageAbility"] = "Chain Reaction",
			["LastFightIn"] = 6,
			["LastEventNum"] = {
				0.1751914128399548, -- [1]
				nil, -- [2]
				nil, -- [3]
				0.1812165143397416, -- [4]
				0.1742644741476799, -- [5]
				nil, -- [6]
				nil, -- [7]
				0.185851207801116, -- [8]
				nil, -- [9]
				0.1798261063013292, -- [10]
				nil, -- [11]
				18.59948832984187, -- [12]
				[24] = 31.6674700135333,
				[25] = 0.5260377078660018,
				[26] = 0.3601156819487959,
				[28] = 0.5260377078660018,
				[45] = 0.1696297806863054,
				[17] = 18.23983611723921,
				[18] = 0.5260377078660018,
				[49] = 0.3596522126026585,
				[20] = 14.98396396062364,
				[21] = 0.5260377078660018,
				[22] = 0.3573348658719712,
				[44] = 15.27826699542092,
				[47] = 16.37993363118963,
			},
			["type"] = "Pet",
			["FightsSaved"] = 5,
			["UnitLockout"] = 1360560551,
			["Fights"] = {
				["Fight5"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 7,
								},
							},
							["amount"] = 7,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 11971,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 747,
									["min"] = 356,
									["count"] = 7,
									["amount"] = 4343,
								},
							},
							["count"] = 7,
							["amount"] = 4343,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Melee"] = 3520,
						["Physical"] = 8451,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 3.73,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
						["Nature"] = 4343,
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
								["Bite"] = {
									["count"] = 0.23,
								},
							},
							["amount"] = 3.73,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 3520,
									["min"] = 3520,
									["count"] = 1,
									["amount"] = 3520,
								},
							},
							["count"] = 1,
							["amount"] = 3520,
						},
						["Bite"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 8451,
									["min"] = 8451,
									["count"] = 1,
									["amount"] = 8451,
								},
							},
							["count"] = 1,
							["amount"] = 8451,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3520,
								},
								["Bite"] = {
									["count"] = 8451,
								},
							},
							["amount"] = 11971,
						},
					},
					["TimeDamage"] = 3.73,
					["TimeDamaging"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
								["Bite"] = {
									["count"] = 0.23,
								},
							},
							["amount"] = 3.73,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
						["Lynx Rush (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 0,
								},
								["Apothecary Hummel"] = {
									["count"] = 0,
								},
								["Apothecary Baxter"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Lynx Rush (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Lynx Rush (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Lynx Rush (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["PartialResist"] = {
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["ElementTaken"] = {
						["Nature"] = 0,
						["Fire"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["Apothecary Baxter"] = {
							["Details"] = {
								["Irresistible Cologne Spray (DoT)"] = {
									["count"] = 0,
								},
								["Chain Reaction"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["Bite"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Lynx Rush (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Lynx Rush (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Lynx Rush (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Lynx Rush (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Lynx Rush (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Lynx Rush (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Lynx Rush (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
						["Nature"] = 0,
						["Fire"] = 0,
					},
					["ElementHitsTaken"] = {
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Fire"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
				},
				["Fight4"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 15490,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Melee"] = 7040,
						["Physical"] = 8450,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 5.17,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4.93,
								},
								["Bite"] = {
									["count"] = 0.24,
								},
							},
							["amount"] = 5.17,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 3520,
									["min"] = 3520,
									["count"] = 2,
									["amount"] = 7040,
								},
							},
							["count"] = 2,
							["amount"] = 7040,
						},
						["Bite"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 8450,
									["min"] = 8450,
									["count"] = 1,
									["amount"] = 8450,
								},
							},
							["count"] = 1,
							["amount"] = 8450,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 7040,
								},
								["Bite"] = {
									["count"] = 8450,
								},
							},
							["amount"] = 15490,
						},
					},
					["TimeDamage"] = 5.17,
					["TimeDamaging"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4.93,
								},
								["Bite"] = {
									["count"] = 0.24,
								},
							},
							["amount"] = 5.17,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 7041,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Melee"] = 7041,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 3.5,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7041,
									["min"] = 7041,
									["count"] = 1,
									["amount"] = 7041,
								},
							},
							["count"] = 1,
							["amount"] = 7041,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 7041,
								},
							},
							["amount"] = 7041,
						},
					},
					["TimeDamage"] = 3.5,
					["TimeDamaging"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["DOTs"] = {
						["Lynx Rush (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 21,
								},
								["Apothecary Hummel"] = {
									["count"] = 18,
								},
								["Apothecary Baxter"] = {
									["count"] = 18,
								},
							},
							["amount"] = 57,
						},
					},
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 4.879999999999999,
								},
								["Melee"] = {
									["count"] = 36.39999999999999,
								},
								["Lynx Rush (DoT)"] = {
									["count"] = 0.6100000000000001,
								},
							},
							["amount"] = 41.89,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 4.140000000000001,
								},
								["Melee"] = {
									["count"] = 33.48,
								},
								["Lynx Rush (DoT)"] = {
									["count"] = 0.39,
								},
							},
							["amount"] = 38.00999999999998,
						},
						["Crown Technician"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 11.93,
								},
								["Bite"] = {
									["count"] = 0.47,
								},
							},
							["amount"] = 12.4,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 3.71,
								},
								["Melee"] = {
									["count"] = 28.41,
								},
								["Lynx Rush (DoT)"] = {
									["count"] = 1.13,
								},
							},
							["amount"] = 33.25,
						},
					},
					["DamageTaken"] = 57876,
					["PartialResist"] = {
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 67,
									["amount"] = 0,
								},
							},
							["count"] = 67,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 24640,
									["min"] = 24640,
									["count"] = 1,
									["amount"] = 24640,
								},
							},
							["count"] = 1,
							["amount"] = 24640,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 800,
									["min"] = 91,
									["count"] = 67,
									["amount"] = 13870,
								},
							},
							["count"] = 67,
							["amount"] = 13870,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 747,
									["min"] = 356,
									["count"] = 8,
									["amount"] = 4760,
								},
							},
							["count"] = 8,
							["amount"] = 4760,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 9420,
									["min"] = 8658,
									["count"] = 10,
									["amount"] = 90215,
								},
							},
							["count"] = 11,
							["amount"] = 90215,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 125.55,
					["ElementTaken"] = {
						["Nature"] = 49280,
						["Fire"] = 8596,
					},
					["DOT_Time"] = 57,
					["Damage"] = 697218,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 35,
								},
								["Hit"] = {
									["count"] = 102,
								},
								["Dodge"] = {
									["count"] = 2,
								},
								["Miss"] = {
									["count"] = 5,
								},
								["Crit"] = {
									["count"] = 59,
								},
								["Parry"] = {
									["count"] = 2,
								},
							},
							["amount"] = 205,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 37,
								},
								["Crit"] = {
									["count"] = 21,
								},
								["Tick"] = {
									["count"] = 15,
								},
							},
							["amount"] = 73,
						},
					},
					["WhoDamaged"] = {
						["Apothecary Baxter"] = {
							["Details"] = {
								["Irresistible Cologne Spray (DoT)"] = {
									["count"] = 49280,
								},
								["Chain Reaction"] = {
									["count"] = 8596,
								},
							},
							["amount"] = 57876,
						},
					},
					["Attacks"] = {
						["Bite"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7324,
									["min"] = 1808,
									["count"] = 17,
									["amount"] = 67255,
								},
								["Hit"] = {
									["max"] = 8451,
									["min"] = 902,
									["count"] = 37,
									["amount"] = 121502,
								},
							},
							["count"] = 54,
							["amount"] = 188757,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 2700,
									["min"] = 605,
									["count"] = 35,
									["amount"] = 57402,
								},
								["Hit"] = {
									["max"] = 3520,
									["min"] = 751,
									["count"] = 102,
									["amount"] = 170674,
								},
								["Dodge"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 5,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 7041,
									["min"] = 1503,
									["count"] = 59,
									["amount"] = 216011,
								},
								["Parry"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 205,
							["amount"] = 444087,
						},
						["Lynx Rush (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7357,
									["min"] = 3678,
									["count"] = 4,
									["amount"] = 23910,
								},
								["Tick"] = {
									["max"] = 3679,
									["min"] = 1839,
									["count"] = 15,
									["amount"] = 40464,
								},
							},
							["count"] = 19,
							["amount"] = 64374,
						},
					},
					["ElementDone"] = {
						["Melee"] = 444087,
						["Physical"] = 253131,
					},
					["HealingTaken"] = 11986,
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 40081,
								},
								["Melee"] = {
									["count"] = 97486,
								},
								["Lynx Rush (DoT)"] = {
									["count"] = 32187,
								},
							},
							["amount"] = 169754,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 99135,
								},
								["Melee"] = {
									["count"] = 253692,
								},
								["Lynx Rush (DoT)"] = {
									["count"] = 19313,
								},
							},
							["amount"] = 372140,
						},
						["Crown Technician"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 17601,
								},
								["Bite"] = {
									["count"] = 16901,
								},
							},
							["amount"] = 34502,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 32640,
								},
								["Melee"] = {
									["count"] = 75308,
								},
								["Lynx Rush (DoT)"] = {
									["count"] = 12874,
								},
							},
							["amount"] = 120822,
						},
					},
					["TimeDamage"] = 125.55,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 4.879999999999999,
								},
								["Melee"] = {
									["count"] = 36.39999999999999,
								},
								["Lynx Rush (DoT)"] = {
									["count"] = 0.6100000000000001,
								},
							},
							["amount"] = 41.89,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 4.140000000000001,
								},
								["Melee"] = {
									["count"] = 33.48,
								},
								["Lynx Rush (DoT)"] = {
									["count"] = 0.39,
								},
							},
							["amount"] = 38.00999999999998,
						},
						["Crown Technician"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 11.93,
								},
								["Bite"] = {
									["count"] = 0.47,
								},
							},
							["amount"] = 12.4,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Bite"] = {
									["count"] = 3.71,
								},
								["Melee"] = {
									["count"] = 28.41,
								},
								["Lynx Rush (DoT)"] = {
									["count"] = 1.13,
								},
							},
							["amount"] = 33.25,
						},
					},
					["ElementTakenAbsorb"] = {
						["Nature"] = 43270,
						["Fire"] = 90215,
					},
					["ElementHitsTaken"] = {
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 2,
								},
								["Absorb"] = {
									["count"] = 76,
								},
							},
							["amount"] = 78,
						},
						["Fire"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 10,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 11,
						},
					},
					["WhoHealed"] = {
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 11986,
								},
							},
							["amount"] = 11986,
						},
					},
				},
				["Fight1"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 7041,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Melee"] = 7041,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 3.5,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7041,
									["min"] = 7041,
									["count"] = 1,
									["amount"] = 7041,
								},
							},
							["count"] = 1,
							["amount"] = 7041,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 7041,
								},
							},
							["amount"] = 7041,
						},
					},
					["TimeDamage"] = 3.5,
					["TimeDamaging"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
			},
			["Owner"] = "Gato",
			["LastFlags"] = 4648,
			["NextEventNum"] = 43,
			["LastEventHealthNum"] = {
				99.82480858716005, -- [1]
				99.82480858716005, -- [2]
				100, -- [3]
				99.81878348566026, -- [4]
				99.82573552585232, -- [5]
				99.82573552585232, -- [6]
				99.82573552585232, -- [7]
				99.6398843180512, -- [8]
				100, -- [9]
				99.82017389369867, -- [10]
				99.82017389369867, -- [11]
				100, -- [12]
				100, -- [13]
				100, -- [14]
				100, -- [15]
				100, -- [16]
				100, -- [17]
				100, -- [18]
				100, -- [19]
				100, -- [20]
				100, -- [21]
				99.64266513412802, -- [22]
				99.64266513412802, -- [23]
				100, -- [24]
				100, -- [25]
				99.6398843180512, -- [26]
				99.6398843180512, -- [27]
				100, -- [28]
				100, -- [29]
				100, -- [30]
				100, -- [31]
				100, -- [32]
				100, -- [33]
				100, -- [34]
				100, -- [35]
				100, -- [36]
				100, -- [37]
				100, -- [38]
				100, -- [39]
				100, -- [40]
				100, -- [41]
				100, -- [42]
				100, -- [43]
				100, -- [44]
				99.83037021931369, -- [45]
				99.83037021931369, -- [46]
				100, -- [47]
				100, -- [48]
				99.64034778739735, -- [49]
				100, -- [50]
			},
			["LastEvents"] = {
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Hit -378 (Nature)", -- [1]
				"Underworld <Gato> Bite Apothecary Frye Hit -3665 (Physical)", -- [2]
				"Underworld <Gato> Melee Apothecary Frye Crit -6014 (Physical)", -- [3]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Hit -391 (Nature)", -- [4]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Hit -376 (Nature)", -- [5]
				"Underworld <Gato> Melee Apothecary Frye Glancing -2676 (Physical)", -- [6]
				"Underworld <Gato> Bite Apothecary Frye Hit -3663 (Physical)", -- [7]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Hit -401 (Nature)", -- [8]
				"Underworld <Gato> Melee Apothecary Frye Glancing -2695 (Physical)", -- [9]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Hit -388 (Nature)", -- [10]
				"Underworld <Gato> Melee Apothecary Frye Hit -3007 (Physical)", -- [11]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Hit +40131 (40131 overheal)", -- [12]
				"Underworld <Gato> Melee Apothecary Frye Hit -3006 (Physical)", -- [13]
				"Underworld <Gato> Bite Apothecary Frye Hit -3618 (Physical)", -- [14]
				"Underworld <Gato> Melee Apothecary Frye Hit -3006 (Physical)", -- [15]
				"Underworld <Gato> Melee Apothecary Frye Hit -3007 (Physical)", -- [16]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Hit +39355 (39355 overheal)", -- [17]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Hit +1135 (1135 overheal)", -- [18]
				"Underworld <Gato> Melee Apothecary Frye Hit -3007 (Physical)", -- [19]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Hit +32330 (32330 overheal)", -- [20]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Hit +1135 (1135 overheal)", -- [21]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Crit -771 (Nature)", -- [22]
				"Underworld <Gato> Melee Apothecary Frye Miss", -- [23]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Crit +68327 (68327 overheal)", -- [24]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Hit +1135 (1135 overheal)", -- [25]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Crit -777 (Nature)", -- [26]
				"Underworld <Gato> Bite Apothecary Frye Crit -7244 (Physical)", -- [27]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Hit +1135 (358 overheal)", -- [28]
				"Underworld <Gato> Melee Apothecary Frye Crit -6014 (Physical)", -- [29]
				"No One <Gato> Concentrated Alluring Perfume Spill Underworld <Gato> Absorb (747 Absorbed) (Nature)", -- [30]
				"No One <Gato> Concentrated Alluring Perfume Spill Underworld <Gato> Absorb (729 Absorbed) (Nature)", -- [31]
				"No One <Gato> Concentrated Alluring Perfume Spill Underworld <Gato> Absorb (716 Absorbed) (Nature)", -- [32]
				"No One <Gato> Concentrated Alluring Perfume Spill Underworld <Gato> Absorb (694 Absorbed) (Nature)", -- [33]
				"No One <Gato> Concentrated Alluring Perfume Spill Underworld <Gato> Absorb (356 Absorbed) (Nature)", -- [34]
				"No One <Gato> Concentrated Alluring Perfume Spill Underworld <Gato> Absorb (711 Absorbed) (Nature)", -- [35]
				"No One <Gato> Concentrated Alluring Perfume Spill Underworld <Gato> Absorb (390 Absorbed) (Nature)", -- [36]
				"Underworld <Gato> Melee Crown Technician Hit -3520 (Physical)", -- [37]
				"Underworld <Gato> Bite Crown Technician Hit -8451 (Physical)", -- [38]
				"Underworld <Gato> Melee Crown Technician Hit -3520 (Physical)", -- [39]
				"Underworld <Gato> Bite Crown Technician Hit -8450 (Physical)", -- [40]
				"Underworld <Gato> Melee Crown Technician Hit -3520 (Physical)", -- [41]
				"Underworld <Gato> Melee Crown Technician Crit -7041 (Physical)", -- [42]
				"Underworld <Gato> Bite Apothecary Frye Hit -3658 (Physical)", -- [43]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Hit +32965 (32965 overheal)", -- [44]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Hit -366 (Nature)", -- [45]
				"Underworld <Gato> Melee Apothecary Frye Crit -6014 (Physical)", -- [46]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Hit +35342 (35342 overheal)", -- [47]
				"Underworld <Gato> Melee Apothecary Frye Crit -6013 (Physical)", -- [48]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Crit -776 (Nature)", -- [49]
				"Underworld <Gato> Melee Apothecary Frye Crit -6014 (Physical)", -- [50]
			},
			["Name"] = "Underworld",
			["LastEventIncoming"] = {
				true, -- [1]
				false, -- [2]
				false, -- [3]
				true, -- [4]
				true, -- [5]
				false, -- [6]
				false, -- [7]
				true, -- [8]
				false, -- [9]
				true, -- [10]
				false, -- [11]
				true, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				true, -- [17]
				true, -- [18]
				false, -- [19]
				true, -- [20]
				true, -- [21]
				true, -- [22]
				false, -- [23]
				true, -- [24]
				true, -- [25]
				true, -- [26]
				false, -- [27]
				true, -- [28]
				false, -- [29]
				true, -- [30]
				true, -- [31]
				true, -- [32]
				true, -- [33]
				true, -- [34]
				true, -- [35]
				true, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				true, -- [44]
				true, -- [45]
				false, -- [46]
				true, -- [47]
				false, -- [48]
				true, -- [49]
				false, -- [50]
			},
			["LastDamageTaken"] = 8596,
			["TimeLast"] = {
				["HealingTaken"] = 1360560705,
				["TimeDamage"] = 1360561112,
				["ActiveTime"] = 1360561112,
				["DamageTaken"] = 1360560641,
				["OVERALL"] = 1360561112,
				["DOT_Time"] = 1360560626,
				["Damage"] = 1360561112,
			},
			["LastEventTimes"] = {
				20874.406, -- [1]
				20874.406, -- [2]
				20875.914, -- [3]
				20876.428, -- [4]
				20877.217, -- [5]
				20877.48, -- [6]
				20877.638, -- [7]
				20878.438, -- [8]
				20879.06, -- [9]
				20879.248, -- [10]
				20880.6, -- [11]
				20882.048, -- [12]
				20882.148, -- [13]
				20882.454, -- [14]
				20883.726, -- [15]
				20885.274, -- [16]
				20885.665, -- [17]
				20886.473, -- [18]
				20886.83, -- [19]
				20886.869, -- [20]
				20887.282, -- [21]
				20887.693, -- [22]
				20888.399, -- [23]
				20888.508, -- [24]
				20888.508, -- [25]
				20888.508, -- [26]
				20888.922, -- [27]
				20889.304, -- [28]
				20889.971, -- [29]
				20896.142, -- [30]
				20896.935, -- [31]
				20898.155, -- [32]
				20898.961, -- [33]
				20900.171, -- [34]
				20900.987, -- [35]
				20902.181, -- [36]
				21242.217, -- [37]
				21242.443, -- [38]
				21263.186, -- [39]
				21263.421, -- [40]
				21264.852, -- [41]
				21295.387, -- [42]
				20869.58, -- [43]
				20869.977, -- [44]
				20870.391, -- [45]
				20870.725, -- [46]
				20871.991, -- [47]
				20872.291, -- [48]
				20872.381, -- [49]
				20873.869, -- [50]
			},
			["LastAbility"] = 102142.251,
		},
		["Palauradin-Silvermoon"] = {
			["GUID"] = "0x0100000004BA6522",
			["LastEventHealth"] = {
				"491176 (100%)", -- [1]
				"491176 (100%)", -- [2]
				"491176 (100%)", -- [3]
				"491176 (100%)", -- [4]
				"491176 (100%)", -- [5]
				"491176 (100%)", -- [6]
				"491176 (100%)", -- [7]
				"491176 (100%)", -- [8]
				"491176 (100%)", -- [9]
				"491176 (100%)", -- [10]
				"491176 (100%)", -- [11]
				"491176 (100%)", -- [12]
				"491176 (100%)", -- [13]
				"488132 (99%)", -- [14]
				"489323 (99%)", -- [15]
				"491176 (100%)", -- [16]
				"491176 (100%)", -- [17]
				"491176 (100%)", -- [18]
				"491176 (100%)", -- [19]
				"491176 (100%)", -- [20]
				"491176 (100%)", -- [21]
				"491176 (100%)", -- [22]
				"491176 (100%)", -- [23]
				"491176 (100%)", -- [24]
				"491176 (100%)", -- [25]
				"491176 (100%)", -- [26]
				"491176 (100%)", -- [27]
				"491176 (100%)", -- [28]
				"491176 (100%)", -- [29]
				"491176 (100%)", -- [30]
				"491176 (100%)", -- [31]
				"491176 (100%)", -- [32]
				"491176 (100%)", -- [33]
				"491176 (100%)", -- [34]
				"491176 (100%)", -- [35]
				"491176 (100%)", -- [36]
				"491176 (100%)", -- [37]
				"491176 (100%)", -- [38]
				"491176 (100%)", -- [39]
				"491176 (100%)", -- [40]
				"491176 (100%)", -- [41]
				"491176 (100%)", -- [42]
				"491176 (100%)", -- [43]
				"491176 (100%)", -- [44]
				"491176 (100%)", -- [45]
				"491176 (100%)", -- [46]
				"491176 (100%)", -- [47]
				"491176 (100%)", -- [48]
				"491176 (100%)", -- [49]
				"491176 (100%)", -- [50]
			},
			["LastAttackedBy"] = "Apothecary Frye",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"HEAL", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"HEAL", -- [14]
				"HEAL", -- [15]
				"HEAL", -- [16]
				"HEAL", -- [17]
				"HEAL", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"HEAL", -- [23]
				"HEAL", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"HEAL", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"HEAL", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					14.62, -- [1]
				},
				["Healing"] = {
					465257, -- [1]
				},
				["DamageTaken"] = {
					1214002, -- [1]
				},
				["HealingTaken"] = {
					1311647, -- [1]
				},
				["Overhealing"] = {
					168325, -- [1]
				},
				["ActiveTime"] = {
					125.65, -- [1]
				},
				["TimeDamage"] = {
					111.03, -- [1]
				},
				["ManaGain"] = {
					156000, -- [1]
				},
				["DOT_Time"] = {
					153, -- [1]
				},
				["Damage"] = {
					4207557, -- [1]
				},
			},
			["enClass"] = "PALADIN",
			["unit"] = "Palauradin",
			["level"] = 90,
			["LastDamageAbility"] = "Melee",
			["LastFightIn"] = 1,
			["LastEventNum"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				1.28833656367575, -- [4]
				nil, -- [5]
				nil, -- [6]
				nil, -- [7]
				nil, -- [8]
				nil, -- [9]
				nil, -- [10]
				nil, -- [11]
				1.703259116894962, -- [12]
				nil, -- [13]
				1.083521996188739, -- [14]
				0.24247927423164, -- [15]
				6.510904441585094, -- [16]
				1.28854015668518, -- [17]
				13.88911510334381, -- [18]
				nil, -- [19]
				nil, -- [20]
				nil, -- [21]
				nil, -- [22]
				1.28833656367575, -- [23]
				1.28833656367575, -- [24]
				[30] = 1.28833656367575,
				[43] = 1.28833656367575,
			},
			["type"] = "Ungrouped",
			["FightsSaved"] = 5,
			["LastActive"] = 1360560707,
			["UnitLockout"] = 1360560703,
			["Owner"] = false,
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["PartialBlock"] = {
						["Melee"] = {
							["Details"] = {
								["Blocked"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
								["Absorb"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["Overhealing"] = 0,
					["ElementTaken"] = {
						["Fire"] = 0,
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["TimeHeal"] = 0,
					["ElementDone"] = {
						["Physical"] = 0,
						["Fire"] = 0,
						["Melee"] = 0,
						["Holy"] = 0,
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Yaungol Fire (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Judgment"] = {
									["count"] = 0,
								},
								["Hammer of Wrath"] = {
									["count"] = 0,
								},
								["Shield of the Righteous"] = {
									["count"] = 0,
								},
								["Hammer of the Righteous"] = {
									["count"] = 0,
								},
								["Consecration"] = {
									["count"] = 0,
								},
								["Avenger's Shield"] = {
									["count"] = 0,
								},
								["Execution Sentence (DoT)"] = {
									["count"] = 0,
								},
								["Holy Wrath"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Yaungol Fire (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Judgment"] = {
									["count"] = 0,
								},
								["Hammer of Wrath"] = {
									["count"] = 0,
								},
								["Shield of the Righteous"] = {
									["count"] = 0,
								},
								["Execution Sentence (DoT)"] = {
									["count"] = 0,
								},
								["Consecration"] = {
									["count"] = 0,
								},
								["Avenger's Shield"] = {
									["count"] = 0,
								},
								["Hammer of the Righteous"] = {
									["count"] = 0,
								},
								["Holy Wrath"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Black Rat"] = {
							["Details"] = {
								["Consecration"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Yaungol Fire (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Judgment"] = {
									["count"] = 0,
								},
								["Hammer of Wrath"] = {
									["count"] = 0,
								},
								["Shield of the Righteous"] = {
									["count"] = 0,
								},
								["Hammer of the Righteous"] = {
									["count"] = 0,
								},
								["Consecration"] = {
									["count"] = 0,
								},
								["Avenger's Shield"] = {
									["count"] = 0,
								},
								["Crusader Strike"] = {
									["count"] = 0,
								},
								["Holy Wrath"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Alluring Perfume"] = {
									["count"] = 0,
								},
								["Alluring Perfume Spray (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Irresistible Cologne Spray (DoT)"] = {
									["count"] = 0,
								},
								["Irresistible Cologne"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Chain Reaction"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDoneBlock"] = {
						["Melee"] = 0,
					},
					["TimeHealing"] = {
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Seal of Insight"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["Seal of Insight"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Alluring Perfume Spray"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Alluring Perfume"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
						["Seal of Insight"] = {
							["Details"] = {
								["Palauradin-Silvermoon"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Alluring Perfume Spray"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Alluring Perfume"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["Heals"] = {
						["Seal of Insight"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Fire"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Holy"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["HealedWho"] = {
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Seal of Insight"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
						["Fire"] = 0,
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["Healing"] = 0,
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Yaungol Fire (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Judgment"] = {
									["count"] = 0,
								},
								["Hammer of Wrath"] = {
									["count"] = 0,
								},
								["Shield of the Righteous"] = {
									["count"] = 0,
								},
								["Hammer of the Righteous"] = {
									["count"] = 0,
								},
								["Consecration"] = {
									["count"] = 0,
								},
								["Avenger's Shield"] = {
									["count"] = 0,
								},
								["Execution Sentence (DoT)"] = {
									["count"] = 0,
								},
								["Holy Wrath"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Yaungol Fire (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Judgment"] = {
									["count"] = 0,
								},
								["Hammer of Wrath"] = {
									["count"] = 0,
								},
								["Shield of the Righteous"] = {
									["count"] = 0,
								},
								["Execution Sentence (DoT)"] = {
									["count"] = 0,
								},
								["Consecration"] = {
									["count"] = 0,
								},
								["Avenger's Shield"] = {
									["count"] = 0,
								},
								["Hammer of the Righteous"] = {
									["count"] = 0,
								},
								["Holy Wrath"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Seal of Insight"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Black Rat"] = {
							["Details"] = {
								["Consecration"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Yaungol Fire (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Judgment"] = {
									["count"] = 0,
								},
								["Hammer of Wrath"] = {
									["count"] = 0,
								},
								["Shield of the Righteous"] = {
									["count"] = 0,
								},
								["Hammer of the Righteous"] = {
									["count"] = 0,
								},
								["Consecration"] = {
									["count"] = 0,
								},
								["Avenger's Shield"] = {
									["count"] = 0,
								},
								["Crusader Strike"] = {
									["count"] = 0,
								},
								["Holy Wrath"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Seal of Insight"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["Yaungol Fire (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit (Blocked)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Judgment"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Hammer of Wrath"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Shield of the Righteous"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Execution Sentence (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Avenger's Shield"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Consecration"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Crusader Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Hammer of the Righteous"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Holy Wrath"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["ElementTakenBlock"] = {
						["Melee"] = 0,
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Yaungol Fire (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Judgment"] = {
									["count"] = 0,
								},
								["Hammer of Wrath"] = {
									["count"] = 0,
								},
								["Shield of the Righteous"] = {
									["count"] = 0,
								},
								["Hammer of the Righteous"] = {
									["count"] = 0,
								},
								["Consecration"] = {
									["count"] = 0,
								},
								["Avenger's Shield"] = {
									["count"] = 0,
								},
								["Execution Sentence (DoT)"] = {
									["count"] = 0,
								},
								["Holy Wrath"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Yaungol Fire (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Judgment"] = {
									["count"] = 0,
								},
								["Hammer of Wrath"] = {
									["count"] = 0,
								},
								["Shield of the Righteous"] = {
									["count"] = 0,
								},
								["Execution Sentence (DoT)"] = {
									["count"] = 0,
								},
								["Consecration"] = {
									["count"] = 0,
								},
								["Avenger's Shield"] = {
									["count"] = 0,
								},
								["Hammer of the Righteous"] = {
									["count"] = 0,
								},
								["Holy Wrath"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Black Rat"] = {
							["Details"] = {
								["Consecration"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Yaungol Fire (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Judgment"] = {
									["count"] = 0,
								},
								["Hammer of Wrath"] = {
									["count"] = 0,
								},
								["Shield of the Righteous"] = {
									["count"] = 0,
								},
								["Hammer of the Righteous"] = {
									["count"] = 0,
								},
								["Consecration"] = {
									["count"] = 0,
								},
								["Avenger's Shield"] = {
									["count"] = 0,
								},
								["Crusader Strike"] = {
									["count"] = 0,
								},
								["Holy Wrath"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["ManaGainedFrom"] = {
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Seal of Insight"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DOTs"] = {
						["Execution Sentence (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 0,
								},
								["Apothecary Hummel"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Yaungol Fire (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 0,
								},
								["Apothecary Hummel"] = {
									["count"] = 0,
								},
								["Apothecary Baxter"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
				},
				["OverallData"] = {
					["PartialBlock"] = {
						["Melee"] = {
							["Details"] = {
								["Blocked"] = {
									["max"] = 2876,
									["min"] = 1345,
									["count"] = 7,
									["amount"] = 13612,
								},
							},
							["count"] = 7,
							["amount"] = 13612,
						},
					},
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 3,
						},
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
								["Absorb"] = {
									["count"] = 9,
								},
								["Hit"] = {
									["count"] = 18,
								},
								["Parry"] = {
									["count"] = 2,
								},
							},
							["amount"] = 30,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 83,
								},
								["Hit"] = {
									["count"] = 83,
								},
								["Tick"] = {
									["count"] = 48,
								},
							},
							["amount"] = 214,
						},
					},
					["DamageTaken"] = 1214002,
					["Overhealing"] = 168325,
					["ElementTaken"] = {
						["Fire"] = 73177,
						["Melee"] = 107318,
						["Nature"] = 1033507,
					},
					["DOT_Time"] = 153,
					["Damage"] = 4207557,
					["TimeHeal"] = 14.62,
					["ElementDone"] = {
						["Physical"] = 37126,
						["Fire"] = 33756,
						["Melee"] = 458910,
						["Holy"] = 3677765,
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Yaungol Fire (DoT)"] = {
									["count"] = 12362,
								},
								["Melee"] = {
									["count"] = 112050,
								},
								["Judgment"] = {
									["count"] = 211787,
								},
								["Hammer of Wrath"] = {
									["count"] = 25793,
								},
								["Shield of the Righteous"] = {
									["count"] = 69545,
								},
								["Hammer of the Righteous"] = {
									["count"] = 41092,
								},
								["Consecration"] = {
									["count"] = 215660,
								},
								["Avenger's Shield"] = {
									["count"] = 341359,
								},
								["Execution Sentence (DoT)"] = {
									["count"] = 223994,
								},
								["Holy Wrath"] = {
									["count"] = 239924,
								},
							},
							["amount"] = 1493566,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Yaungol Fire (DoT)"] = {
									["count"] = 8752,
								},
								["Melee"] = {
									["count"] = 139931,
								},
								["Judgment"] = {
									["count"] = 93823,
								},
								["Hammer of Wrath"] = {
									["count"] = 100137,
								},
								["Shield of the Righteous"] = {
									["count"] = 131750,
								},
								["Execution Sentence (DoT)"] = {
									["count"] = 107266,
								},
								["Consecration"] = {
									["count"] = 152272,
								},
								["Avenger's Shield"] = {
									["count"] = 229466,
								},
								["Hammer of the Righteous"] = {
									["count"] = 29608,
								},
								["Holy Wrath"] = {
									["count"] = 109364,
								},
							},
							["amount"] = 1102369,
						},
						["Black Rat"] = {
							["Details"] = {
								["Consecration"] = {
									["count"] = 3652,
								},
							},
							["amount"] = 3652,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Yaungol Fire (DoT)"] = {
									["count"] = 12642,
								},
								["Melee"] = {
									["count"] = 206929,
								},
								["Judgment"] = {
									["count"] = 274910,
								},
								["Hammer of Wrath"] = {
									["count"] = 40237,
								},
								["Shield of the Righteous"] = {
									["count"] = 239631,
								},
								["Hammer of the Righteous"] = {
									["count"] = 55186,
								},
								["Consecration"] = {
									["count"] = 311015,
								},
								["Avenger's Shield"] = {
									["count"] = 273406,
								},
								["Crusader Strike"] = {
									["count"] = 13164,
								},
								["Holy Wrath"] = {
									["count"] = 180850,
								},
							},
							["amount"] = 1607970,
						},
					},
					["WhoDamaged"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 23585,
								},
							},
							["amount"] = 23585,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Alluring Perfume"] = {
									["count"] = 39770,
								},
								["Alluring Perfume Spray (DoT)"] = {
									["count"] = 293440,
								},
								["Melee"] = {
									["count"] = 34584,
								},
							},
							["amount"] = 367794,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Irresistible Cologne Spray (DoT)"] = {
									["count"] = 615886,
								},
								["Irresistible Cologne"] = {
									["count"] = 84411,
								},
								["Melee"] = {
									["count"] = 49149,
								},
								["Chain Reaction"] = {
									["count"] = 73177,
								},
							},
							["amount"] = 822623,
						},
					},
					["ElementDoneBlock"] = {
						["Melee"] = 5740,
					},
					["TimeHealing"] = {
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Seal of Insight"] = {
									["count"] = 14.62,
								},
							},
							["amount"] = 14.62,
						},
					},
					["OverHeals"] = {
						["Seal of Insight"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 12915,
									["min"] = 2942,
									["count"] = 23,
									["amount"] = 168325,
								},
							},
							["count"] = 23,
							["amount"] = 168325,
						},
					},
					["PartialResist"] = {
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 13,
									["amount"] = 0,
								},
							},
							["count"] = 13,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 30,
									["amount"] = 0,
								},
							},
							["count"] = 30,
							["amount"] = 0,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 72,
									["amount"] = 0,
								},
							},
							["count"] = 72,
							["amount"] = 0,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 32,
									["amount"] = 0,
								},
							},
							["count"] = 32,
							["amount"] = 0,
						},
						["Alluring Perfume Spray"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 18,
									["amount"] = 0,
								},
							},
							["count"] = 18,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Alluring Perfume"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 48,
									["amount"] = 0,
								},
							},
							["count"] = 48,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
						["Seal of Insight"] = {
							["Details"] = {
								["Palauradin-Silvermoon"] = {
									["count"] = 156000,
								},
							},
							["amount"] = 156000,
						},
					},
					["PartialAbsorb"] = {
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 2336,
									["min"] = 2122,
									["count"] = 13,
									["amount"] = 28872,
								},
							},
							["count"] = 13,
							["amount"] = 28872,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 21,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 9362,
									["min"] = 3339,
									["count"] = 9,
									["amount"] = 47939,
								},
							},
							["count"] = 30,
							["amount"] = 47939,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 78236,
									["min"] = 74065,
									["count"] = 2,
									["amount"] = 152301,
								},
							},
							["count"] = 3,
							["amount"] = 152301,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 55,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1668,
									["min"] = 676,
									["count"] = 17,
									["amount"] = 22968,
								},
							},
							["count"] = 72,
							["amount"] = 22968,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 14,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 17512,
									["min"] = 14930,
									["count"] = 2,
									["amount"] = 32442,
								},
							},
							["count"] = 16,
							["amount"] = 32442,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 30,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 5283,
									["min"] = 4408,
									["count"] = 2,
									["amount"] = 9691,
								},
							},
							["count"] = 32,
							["amount"] = 9691,
						},
						["Alluring Perfume Spray"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 21606,
									["min"] = 14853,
									["count"] = 8,
									["amount"] = 143867,
								},
							},
							["count"] = 8,
							["amount"] = 143867,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 3494,
									["min"] = 1623,
									["count"] = 18,
									["amount"] = 38707,
								},
							},
							["count"] = 18,
							["amount"] = 38707,
						},
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 22197,
									["min"] = 17410,
									["count"] = 7,
									["amount"] = 132767,
								},
							},
							["count"] = 7,
							["amount"] = 132767,
						},
						["Alluring Perfume"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 27,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1668,
									["min"] = 1152,
									["count"] = 21,
									["amount"] = 30924,
								},
							},
							["count"] = 48,
							["amount"] = 30924,
						},
					},
					["ActiveTime"] = 125.65,
					["Heals"] = {
						["Seal of Insight"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 13043,
									["min"] = 3387,
									["count"] = 46,
									["amount"] = 465257,
								},
							},
							["count"] = 46,
							["amount"] = 465257,
						},
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 13,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 16,
						},
						["Fire"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 3,
								},
								["Tick"] = {
									["count"] = 28,
								},
							},
							["amount"] = 31,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 7,
								},
								["Hit"] = {
									["count"] = 38,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Miss"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 3,
								},
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 51,
						},
						["Holy"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 218,
								},
								["Tick"] = {
									["count"] = 18,
								},
								["Crit"] = {
									["count"] = 19,
								},
								["Miss"] = {
									["count"] = 10,
								},
							},
							["amount"] = 265,
						},
					},
					["HealedWho"] = {
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Seal of Insight"] = {
									["count"] = 465257,
								},
							},
							["amount"] = 465257,
						},
					},
					["ElementTakenAbsorb"] = {
						["Fire"] = 152301,
						["Melee"] = 47939,
						["Nature"] = 440238,
					},
					["Healing"] = 465257,
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Yaungol Fire (DoT)"] = {
									["count"] = 4.83,
								},
								["Melee"] = {
									["count"] = 8.73,
								},
								["Judgment"] = {
									["count"] = 3.47,
								},
								["Hammer of Wrath"] = {
									["count"] = 0.75,
								},
								["Shield of the Righteous"] = {
									["count"] = 1.63,
								},
								["Hammer of the Righteous"] = {
									["count"] = 1.08,
								},
								["Consecration"] = {
									["count"] = 17.86,
								},
								["Avenger's Shield"] = {
									["count"] = 2.86,
								},
								["Execution Sentence (DoT)"] = {
									["count"] = 4.75,
								},
								["Holy Wrath"] = {
									["count"] = 3.94,
								},
							},
							["amount"] = 49.90000000000001,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Yaungol Fire (DoT)"] = {
									["count"] = 2.179999999999999,
								},
								["Melee"] = {
									["count"] = 5.959999999999999,
								},
								["Judgment"] = {
									["count"] = 1.66,
								},
								["Hammer of Wrath"] = {
									["count"] = 0.37,
								},
								["Shield of the Righteous"] = {
									["count"] = 2.45,
								},
								["Execution Sentence (DoT)"] = {
									["count"] = 6.270000000000001,
								},
								["Consecration"] = {
									["count"] = 0.98,
								},
								["Avenger's Shield"] = {
									["count"] = 5.04,
								},
								["Hammer of the Righteous"] = {
									["count"] = 0.46,
								},
								["Holy Wrath"] = {
									["count"] = 0.7,
								},
							},
							["amount"] = 26.07000000000001,
						},
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Seal of Insight"] = {
									["count"] = 14.62,
								},
							},
							["amount"] = 14.62,
						},
						["Black Rat"] = {
							["Details"] = {
								["Consecration"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Yaungol Fire (DoT)"] = {
									["count"] = 3.31,
								},
								["Melee"] = {
									["count"] = 10.47,
								},
								["Judgment"] = {
									["count"] = 4.790000000000001,
								},
								["Hammer of Wrath"] = {
									["count"] = 0.15,
								},
								["Shield of the Righteous"] = {
									["count"] = 1.19,
								},
								["Hammer of the Righteous"] = {
									["count"] = 1.17,
								},
								["Consecration"] = {
									["count"] = 9.649999999999999,
								},
								["Avenger's Shield"] = {
									["count"] = 2.24,
								},
								["Crusader Strike"] = {
									["count"] = 0.4,
								},
								["Holy Wrath"] = {
									["count"] = 1.69,
								},
							},
							["amount"] = 35.06,
						},
					},
					["WhoHealed"] = {
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 844711,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 1679,
								},
							},
							["amount"] = 846390,
						},
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Seal of Insight"] = {
									["count"] = 465257,
								},
							},
							["amount"] = 465257,
						},
					},
					["Attacks"] = {
						["Yaungol Fire (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2223,
									["min"] = 1852,
									["count"] = 3,
									["amount"] = 6020,
								},
								["Tick"] = {
									["max"] = 1112,
									["min"] = 926,
									["count"] = 28,
									["amount"] = 27736,
								},
							},
							["count"] = 31,
							["amount"] = 33756,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 9009,
									["min"] = 5585,
									["count"] = 7,
									["amount"] = 54718,
								},
								["Hit"] = {
									["max"] = 11990,
									["min"] = 6217,
									["count"] = 36,
									["amount"] = 336563,
								},
								["Dodge"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Hit (Blocked)"] = {
									["max"] = 6923,
									["min"] = 6470,
									["count"] = 2,
									["amount"] = 13393,
								},
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 21763,
									["min"] = 14802,
									["count"] = 3,
									["amount"] = 54236,
								},
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 51,
							["amount"] = 458910,
						},
						["Judgment"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 64914,
									["min"] = 36872,
									["count"] = 3,
									["amount"] = 138658,
								},
								["Hit"] = {
									["max"] = 42877,
									["min"] = 18436,
									["count"] = 15,
									["amount"] = 441862,
								},
							},
							["count"] = 18,
							["amount"] = 580520,
						},
						["Hammer of Wrath"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 51124,
									["min"] = 25793,
									["count"] = 4,
									["amount"] = 166167,
								},
							},
							["count"] = 4,
							["amount"] = 166167,
						},
						["Shield of the Righteous"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 56351,
									["min"] = 54752,
									["count"] = 2,
									["amount"] = 111103,
								},
								["Hit"] = {
									["max"] = 38053,
									["min"] = 19144,
									["count"] = 11,
									["amount"] = 329823,
								},
							},
							["count"] = 13,
							["amount"] = 440926,
						},
						["Execution Sentence (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 133016,
									["min"] = 19035,
									["count"] = 2,
									["amount"] = 152051,
								},
								["Tick"] = {
									["max"] = 47317,
									["min"] = 4415,
									["count"] = 18,
									["amount"] = 179209,
								},
							},
							["count"] = 20,
							["amount"] = 331260,
						},
						["Avenger's Shield"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 116669,
									["min"] = 116669,
									["count"] = 1,
									["amount"] = 116669,
								},
								["Hit"] = {
									["max"] = 62552,
									["min"] = 29199,
									["count"] = 15,
									["amount"] = 727562,
								},
							},
							["count"] = 16,
							["amount"] = 844231,
						},
						["Consecration"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5592,
									["min"] = 2771,
									["count"] = 136,
									["amount"] = 611874,
								},
								["Crit"] = {
									["max"] = 10900,
									["min"] = 5543,
									["count"] = 8,
									["amount"] = 70725,
								},
								["Miss"] = {
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 153,
							["amount"] = 682599,
						},
						["Crusader Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 13164,
									["min"] = 13164,
									["count"] = 1,
									["amount"] = 13164,
								},
							},
							["count"] = 1,
							["amount"] = 13164,
						},
						["Hammer of the Righteous"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5751,
									["min"] = 1311,
									["count"] = 31,
									["amount"] = 115824,
								},
								["Dodge"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 6628,
									["min"] = 3434,
									["count"] = 2,
									["amount"] = 10062,
								},
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 35,
							["amount"] = 125886,
						},
						["Holy Wrath"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 51984,
									["min"] = 15146,
									["count"] = 18,
									["amount"] = 466669,
								},
								["Crit"] = {
									["max"] = 33178,
									["min"] = 30291,
									["count"] = 2,
									["amount"] = 63469,
								},
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 21,
							["amount"] = 530138,
						},
					},
					["HealingTaken"] = 1311647,
					["ElementTakenBlock"] = {
						["Melee"] = 13612,
					},
					["TimeDamage"] = 111.03,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Yaungol Fire (DoT)"] = {
									["count"] = 4.83,
								},
								["Melee"] = {
									["count"] = 8.73,
								},
								["Judgment"] = {
									["count"] = 3.47,
								},
								["Hammer of Wrath"] = {
									["count"] = 0.75,
								},
								["Shield of the Righteous"] = {
									["count"] = 1.63,
								},
								["Hammer of the Righteous"] = {
									["count"] = 1.08,
								},
								["Consecration"] = {
									["count"] = 17.86,
								},
								["Avenger's Shield"] = {
									["count"] = 2.86,
								},
								["Execution Sentence (DoT)"] = {
									["count"] = 4.75,
								},
								["Holy Wrath"] = {
									["count"] = 3.94,
								},
							},
							["amount"] = 49.90000000000001,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Yaungol Fire (DoT)"] = {
									["count"] = 2.179999999999999,
								},
								["Melee"] = {
									["count"] = 5.959999999999999,
								},
								["Judgment"] = {
									["count"] = 1.66,
								},
								["Hammer of Wrath"] = {
									["count"] = 0.37,
								},
								["Shield of the Righteous"] = {
									["count"] = 2.45,
								},
								["Execution Sentence (DoT)"] = {
									["count"] = 6.270000000000001,
								},
								["Consecration"] = {
									["count"] = 0.98,
								},
								["Avenger's Shield"] = {
									["count"] = 5.04,
								},
								["Hammer of the Righteous"] = {
									["count"] = 0.46,
								},
								["Holy Wrath"] = {
									["count"] = 0.7,
								},
							},
							["amount"] = 26.07000000000001,
						},
						["Black Rat"] = {
							["Details"] = {
								["Consecration"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Yaungol Fire (DoT)"] = {
									["count"] = 3.31,
								},
								["Melee"] = {
									["count"] = 10.47,
								},
								["Judgment"] = {
									["count"] = 4.790000000000001,
								},
								["Hammer of Wrath"] = {
									["count"] = 0.15,
								},
								["Shield of the Righteous"] = {
									["count"] = 1.19,
								},
								["Hammer of the Righteous"] = {
									["count"] = 1.17,
								},
								["Consecration"] = {
									["count"] = 9.649999999999999,
								},
								["Avenger's Shield"] = {
									["count"] = 2.24,
								},
								["Crusader Strike"] = {
									["count"] = 0.4,
								},
								["Holy Wrath"] = {
									["count"] = 1.69,
								},
							},
							["amount"] = 35.06,
						},
					},
					["ManaGain"] = 156000,
					["ManaGainedFrom"] = {
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Seal of Insight"] = {
									["count"] = 156000,
								},
							},
							["amount"] = 156000,
						},
					},
					["DOTs"] = {
						["Execution Sentence (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 30,
								},
								["Apothecary Hummel"] = {
									["count"] = 30,
								},
							},
							["amount"] = 60,
						},
						["Yaungol Fire (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 36,
								},
								["Apothecary Hummel"] = {
									["count"] = 27,
								},
								["Apothecary Baxter"] = {
									["count"] = 30,
								},
							},
							["amount"] = 93,
						},
					},
				},
			},
			["NextEventNum"] = 17,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				100, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				100, -- [11]
				100, -- [12]
				100, -- [13]
				99.38026287929378, -- [14]
				99.62274215352542, -- [15]
				100, -- [16]
				100, -- [17]
				100, -- [18]
				100, -- [19]
				100, -- [20]
				100, -- [21]
				100, -- [22]
				100, -- [23]
				100, -- [24]
				100, -- [25]
				100, -- [26]
				100, -- [27]
				100, -- [28]
				100, -- [29]
				100, -- [30]
				100, -- [31]
				100, -- [32]
				100, -- [33]
				100, -- [34]
				100, -- [35]
				100, -- [36]
				100, -- [37]
				100, -- [38]
				100, -- [39]
				100, -- [40]
				100, -- [41]
				100, -- [42]
				100, -- [43]
				100, -- [44]
				100, -- [45]
				100, -- [46]
				100, -- [47]
				100, -- [48]
				100, -- [49]
				100, -- [50]
			},
			["LastEvents"] = {
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2225 Absorbed) (Nature)", -- [1]
				"Palauradin-Silvermoon Melee Apothecary Frye Hit -6748 (Physical)", -- [2]
				"Palauradin-Silvermoon Yaungol Fire (DoT) Apothecary Frye Tick -972 (Fire)", -- [3]
				"Palauradin-Silvermoon Seal of Insight Palauradin-Silvermoon Hit +6328 (6328 overheal)", -- [4]
				"Palauradin-Silvermoon Hammer of the Righteous Apothecary Frye Hit -1567 (Physical)", -- [5]
				"Palauradin-Silvermoon Hammer of the Righteous Apothecary Frye Hit -4139 (Holy)", -- [6]
				"Palauradin-Silvermoon Consecration Apothecary Frye Hit -2772 (Holy)", -- [7]
				"Palauradin-Silvermoon Judgment Apothecary Frye Hit -18436 (Holy)", -- [8]
				"Palauradin-Silvermoon Yaungol Fire (DoT) Apothecary Frye Tick -972 (Fire)", -- [9]
				"Palauradin-Silvermoon Avenger's Shield Apothecary Frye Hit -36669 (Holy)", -- [10]
				"Palauradin-Silvermoon Melee Apothecary Frye Hit -6217 (Physical)", -- [11]
				"Apothecary Frye Melee Palauradin-Silvermoon Hit -8366 (Physical)", -- [12]
				"Palauradin-Silvermoon Yaungol Fire (DoT) Apothecary Frye Tick -972 (Fire)", -- [13]
				"Palauradin-Silvermoon Seal of Insight Palauradin-Silvermoon Hit +5322", -- [14]
				"Kardinalsinn-Barthilas Atonement Palauradin-Silvermoon Hit +1191", -- [15]
				"Kardinalsinn-Barthilas Atonement Palauradin-Silvermoon Hit +31980 (30127 overheal)", -- [16]
				"Palauradin-Silvermoon Seal of Insight Palauradin-Silvermoon Hit +6329 (2942 overheal)", -- [17]
				"Kardinalsinn-Barthilas Atonement Palauradin-Silvermoon Crit +68220 (68220 overheal)", -- [18]
				"Palauradin-Silvermoon Judgment Apothecary Frye Crit -36872 (Holy)", -- [19]
				"Palauradin-Silvermoon Melee Apothecary Frye Hit -7613 (Physical)", -- [20]
				"Palauradin-Silvermoon Hammer of the Righteous Apothecary Frye Hit -1460 (Physical)", -- [21]
				"Palauradin-Silvermoon Hammer of the Righteous Apothecary Frye Crit -6628 (Holy)", -- [22]
				"Palauradin-Silvermoon Seal of Insight Palauradin-Silvermoon Hit +6328 (6328 overheal)", -- [23]
				"Palauradin-Silvermoon Seal of Insight Palauradin-Silvermoon Hit +6328 (6328 overheal)", -- [24]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2122 Absorbed) (Nature)", -- [25]
				"Palauradin-Silvermoon Avenger's Shield Apothecary Frye Hit -35751 (Holy)", -- [26]
				"Palauradin-Silvermoon Melee Apothecary Frye Hit -7752 (Physical)", -- [27]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2336 Absorbed) (Nature)", -- [28]
				"Palauradin-Silvermoon Yaungol Fire (DoT) Apothecary Frye Tick -973 (Fire)", -- [29]
				"Palauradin-Silvermoon Seal of Insight Palauradin-Silvermoon Hit +6328 (6328 overheal)", -- [30]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2241 Absorbed) (Nature)", -- [31]
				"Palauradin-Silvermoon Consecration Apothecary Frye Hit -2772 (Holy)", -- [32]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2224 Absorbed) (Nature)", -- [33]
				"Palauradin-Silvermoon Yaungol Fire (DoT) Apothecary Frye Tick -972 (Fire)", -- [34]
				"Palauradin-Silvermoon Judgment Apothecary Frye Crit -36872 (Holy)", -- [35]
				"Palauradin-Silvermoon Consecration Apothecary Frye Hit -2772 (Holy)", -- [36]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2183 Absorbed) (Nature)", -- [37]
				"Palauradin-Silvermoon Melee Apothecary Frye Dodge", -- [38]
				"Palauradin-Silvermoon Consecration Apothecary Frye Hit -2771 (Holy)", -- [39]
				"Palauradin-Silvermoon Shield of the Righteous Apothecary Frye Hit -19144 (Holy)", -- [40]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2294 Absorbed) (Nature)", -- [41]
				"Palauradin-Silvermoon Yaungol Fire (DoT) Apothecary Frye Tick -972 (Fire)", -- [42]
				"Palauradin-Silvermoon Seal of Insight Palauradin-Silvermoon Hit +6328 (6328 overheal)", -- [43]
				"Palauradin-Silvermoon Holy Wrath Apothecary Frye Hit -31617 (Holy)", -- [44]
				"Palauradin-Silvermoon Consecration Apothecary Frye Hit -2771 (Holy)", -- [45]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2216 Absorbed) (Nature)", -- [46]
				"Palauradin-Silvermoon Consecration Apothecary Frye Crit -5543 (Holy)", -- [47]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2203 Absorbed) (Nature)", -- [48]
				"Palauradin-Silvermoon Hammer of Wrath Apothecary Frye Hit -25793 (Holy)", -- [49]
				"Palauradin-Silvermoon Yaungol Fire (DoT) Apothecary Frye Tick -973 (Fire)", -- [50]
			},
			["Name"] = "Palauradin-Silvermoon",
			["LastDamageTaken"] = 8366,
			["LastEventIncoming"] = {
				true, -- [1]
				false, -- [2]
				false, -- [3]
				true, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				true, -- [12]
				false, -- [13]
				true, -- [14]
				true, -- [15]
				true, -- [16]
				true, -- [17]
				true, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				true, -- [23]
				true, -- [24]
				true, -- [25]
				false, -- [26]
				false, -- [27]
				true, -- [28]
				false, -- [29]
				true, -- [30]
				true, -- [31]
				false, -- [32]
				true, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				true, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				true, -- [41]
				false, -- [42]
				true, -- [43]
				false, -- [44]
				false, -- [45]
				true, -- [46]
				false, -- [47]
				true, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["TimeLast"] = {
				["TimeHeal"] = 1360560706,
				["OVERALL"] = 1360560707,
				["DamageTaken"] = 1360560706,
				["TimeDamage"] = 1360560706,
				["HealingTaken"] = 1360560707,
				["Overhealing"] = 1360560702,
				["ActiveTime"] = 1360560706,
				["Healing"] = 1360560706,
				["ManaGain"] = 1360560706,
				["DOT_Time"] = 1360560706,
				["Damage"] = 1360560706,
			},
			["LastEventTimes"] = {
				20884.459, -- [1]
				20885.274, -- [2]
				20886.028, -- [3]
				20886.078, -- [4]
				20886.078, -- [5]
				20886.078, -- [6]
				20886.473, -- [7]
				20887.282, -- [8]
				20888.025, -- [9]
				20888.949, -- [10]
				20889.66, -- [11]
				20889.707, -- [12]
				20890.015, -- [13]
				20890.1, -- [14]
				20890.512, -- [15]
				20890.914, -- [16]
				20873.201, -- [17]
				20873.612, -- [18]
				20873.612, -- [19]
				20875.144, -- [20]
				20875.223, -- [21]
				20875.223, -- [22]
				20875.617, -- [23]
				20875.617, -- [24]
				20876.428, -- [25]
				20876.746, -- [26]
				20877.519, -- [27]
				20877.638, -- [28]
				20878.035, -- [29]
				20878.035, -- [30]
				20878.438, -- [31]
				20879.629, -- [32]
				20879.629, -- [33]
				20880.026, -- [34]
				20880.051, -- [35]
				20880.437, -- [36]
				20880.437, -- [37]
				20881.401, -- [38]
				20881.651, -- [39]
				20881.651, -- [40]
				20881.651, -- [41]
				20882.023, -- [42]
				20882.048, -- [43]
				20882.454, -- [44]
				20882.454, -- [45]
				20882.454, -- [46]
				20883.272, -- [47]
				20883.669, -- [48]
				20884.022, -- [49]
				20884.022, -- [50]
			},
			["LastAbility"] = 102142.251,
		},
		["Ghost Iron Dragonling"] = {
			["GUID"] = "0xF130E1B70001B0ED",
			["FightsSaved"] = 5,
			["LastAttackedBy"] = "Apothecary Baxter",
			["Owner"] = false,
			["LastDamageTaken"] = 21661,
			["LastFightIn"] = 1,
			["Name"] = "Ghost Iron Dragonling",
			["UnitLockout"] = 1360560588,
			["Fights"] = {
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
			},
			["LastActive"] = 1360560666,
			["LastDamageAbility"] = "Irresistible Cologne Spray (DoT)",
			["LastAbility"] = 102142.251,
		},
		["Gato"] = {
			["GUID"] = "0x010000000352EAEF",
			["LastEventHealth"] = {
				"280187 (100%)", -- [1]
				"280187 (100%)", -- [2]
				"280187 (100%)", -- [3]
				"280187 (100%)", -- [4]
				"280187 (100%)", -- [5]
				"280187 (100%)", -- [6]
				"280187 (100%)", -- [7]
				"280187 (100%)", -- [8]
				"280187 (100%)", -- [9]
				"280187 (100%)", -- [10]
				"280187 (100%)", -- [11]
				"280187 (100%)", -- [12]
				"280187 (100%)", -- [13]
				"280187 (100%)", -- [14]
				"280187 (100%)", -- [15]
				"280187 (100%)", -- [16]
				"280187 (100%)", -- [17]
				"280187 (100%)", -- [18]
				"280187 (100%)", -- [19]
				"280187 (100%)", -- [20]
				"280187 (100%)", -- [21]
				"280187 (100%)", -- [22]
				"280187 (100%)", -- [23]
				"280187 (100%)", -- [24]
				"280187 (100%)", -- [25]
				"280187 (100%)", -- [26]
				"277123 (98%)", -- [27]
				"277123 (98%)", -- [28]
				"277123 (98%)", -- [29]
				"277123 (98%)", -- [30]
				"277123 (98%)", -- [31]
				"277123 (98%)", -- [32]
				"277123 (98%)", -- [33]
				"277123 (98%)", -- [34]
				"277123 (98%)", -- [35]
				"277123 (98%)", -- [36]
				"280187 (100%)", -- [37]
				"280187 (100%)", -- [38]
				"277422 (99%)", -- [39]
				"280187 (100%)", -- [40]
				"280187 (100%)", -- [41]
				"280187 (100%)", -- [42]
				"280187 (100%)", -- [43]
				"280187 (100%)", -- [44]
				"280187 (100%)", -- [45]
				"280187 (100%)", -- [46]
				"280187 (100%)", -- [47]
				"280187 (100%)", -- [48]
				"280187 (100%)", -- [49]
				"280187 (100%)", -- [50]
			},
			["LastAttackedBy"] = "Crown Technician",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["EnergyGain"] = {
					96, -- [1]
				},
				["ActiveTime"] = {
					146.63, -- [1]
				},
				["TimeDamage"] = {
					146.63, -- [1]
				},
				["DOT_Time"] = {
					657, -- [1]
				},
				["DamageTaken"] = {
					5829, -- [1]
				},
				["Damage"] = {
					2017586, -- [1]
				},
			},
			["enClass"] = "HUNTER",
			["unit"] = "Gato",
			["LastActive"] = 1360561111,
			["UnitLockout"] = 1360560515,
			["level"] = 90,
			["LastDamageAbility"] = "Spray Chemical",
			["LastFightIn"] = 6,
			["LastEventNum"] = {
				[39] = 0.9868409312352108,
			},
			["type"] = "Self",
			["FightsSaved"] = 5,
			["GuardianReverseGUIDs"] = {
				["Underworld"] = {
					["LatestGuardian"] = 3,
					["GUIDs"] = {
						"0xF1408C97E900034E", -- [1]
						"0xF1408C97E900034F", -- [2]
						"0xF1408C97E9000350", -- [3]
						[0] = "0xF1408C97E900034D",
					},
				},
			},
			["Fights"] = {
				["OverallData"] = {
					["DOTs"] = {
						["Explosive Shot (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 6,
								},
								["Apothecary Hummel"] = {
									["count"] = 30,
								},
								["Crown Technician"] = {
									["count"] = 24,
								},
								["Apothecary Baxter"] = {
									["count"] = 36,
								},
							},
							["amount"] = 96,
						},
						["Explosive Trap (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 57,
								},
								["Apothecary Hummel"] = {
									["count"] = 30,
								},
								["Apothecary Baxter"] = {
									["count"] = 51,
								},
							},
							["amount"] = 138,
						},
						["Serpent Sting (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 24,
								},
								["Apothecary Hummel"] = {
									["count"] = 51,
								},
								["Apothecary Baxter"] = {
									["count"] = 24,
								},
							},
							["amount"] = 99,
						},
						["Speaking of Rage (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 90,
								},
								["Apothecary Hummel"] = {
									["count"] = 60,
								},
								["Crown Technician"] = {
									["count"] = 60,
								},
								["Apothecary Baxter"] = {
									["count"] = 30,
								},
							},
							["amount"] = 240,
						},
						["Black Arrow (DoT)"] = {
							["Details"] = {
								["Apothecary Hummel"] = {
									["count"] = 30,
								},
							},
							["amount"] = 30,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 12,
								},
								["Apothecary Hummel"] = {
									["count"] = 24,
								},
								["Crown Technician"] = {
									["count"] = 6,
								},
								["Apothecary Baxter"] = {
									["count"] = 12,
								},
							},
							["amount"] = 54,
						},
					},
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 1.28,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 6.160000000000002,
								},
								["Auto Shot"] = {
									["count"] = 12.18,
								},
								["Entrapment"] = {
									["count"] = 0,
								},
								["Explosive Shot"] = {
									["count"] = 1.29,
								},
								["Explosive Trap (DoT)"] = {
									["count"] = 11.19,
								},
								["Improved Serpent Sting"] = {
									["count"] = 3.88,
								},
								["Explosive Trap"] = {
									["count"] = 1.04,
								},
								["Arcane Shot"] = {
									["count"] = 3.38,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 2.18,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 1.73,
								},
							},
							["amount"] = 44.31000000000003,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 2.16,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 6.39,
								},
								["Auto Shot"] = {
									["count"] = 16.01,
								},
								["Black Arrow (DoT)"] = {
									["count"] = 4.360000000000001,
								},
								["Entrapment"] = {
									["count"] = 0.43,
								},
								["Explosive Shot"] = {
									["count"] = 1.54,
								},
								["Explosive Trap (DoT)"] = {
									["count"] = 0.84,
								},
								["Improved Serpent Sting"] = {
									["count"] = 3.33,
								},
								["Explosive Trap"] = {
									["count"] = 0,
								},
								["Arcane Shot"] = {
									["count"] = 3.07,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 3.33,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 3.66,
								},
							},
							["amount"] = 45.12000000000001,
						},
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot"] = {
									["count"] = 1.88,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 3.92,
								},
								["Auto Shot"] = {
									["count"] = 19,
								},
								["Explosive Shot (DoT)"] = {
									["count"] = 4.220000000000001,
								},
								["Improved Serpent Sting"] = {
									["count"] = 1.64,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.72,
								},
							},
							["amount"] = 31.38000000000001,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 5.79,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 2.1,
								},
								["Auto Shot"] = {
									["count"] = 5.8,
								},
								["Entrapment"] = {
									["count"] = 0.09,
								},
								["Explosive Shot"] = {
									["count"] = 2.55,
								},
								["Explosive Trap (DoT)"] = {
									["count"] = 2.95,
								},
								["Improved Serpent Sting"] = {
									["count"] = 3.04,
								},
								["Explosive Trap"] = {
									["count"] = 1.01,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 1.65,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.8400000000000001,
								},
							},
							["amount"] = 25.82,
						},
					},
					["DamageTaken"] = 5829,
					["PartialResist"] = {
						["Spray Chemical"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Spray Chemical"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 3098,
									["min"] = 2629,
									["count"] = 3,
									["amount"] = 8719,
								},
							},
							["count"] = 3,
							["amount"] = 8719,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 146.63,
					["ElementTaken"] = {
						["Nature"] = 5829,
					},
					["DOT_Time"] = 657,
					["Damage"] = 2017586,
					["EnergyGained"] = {
						["Viper Venom"] = {
							["Details"] = {
								["Gato"] = {
									["count"] = 96,
								},
							},
							["amount"] = 96,
						},
					},
					["ElementDone"] = {
						["Shadow"] = 46014,
						["Arcane"] = 301377,
						["Fire"] = 523728,
						["Physical"] = 379171,
						["Nature"] = 767296,
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 5,
								},
							},
							["amount"] = 5,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 2,
								},
								["Miss"] = {
									["count"] = 3,
								},
							},
							["amount"] = 8,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 13097,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 25832,
								},
								["Auto Shot"] = {
									["count"] = 86059,
								},
								["Arcane Shot"] = {
									["count"] = 158448,
								},
								["Explosive Shot"] = {
									["count"] = 13405,
								},
								["Explosive Trap (DoT)"] = {
									["count"] = 29933,
								},
								["Improved Serpent Sting"] = {
									["count"] = 83751,
								},
								["Explosive Trap"] = {
									["count"] = 3183,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 89323,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 16953,
								},
							},
							["amount"] = 519984,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 73497,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 18618,
								},
								["Auto Shot"] = {
									["count"] = 123883,
								},
								["Black Arrow (DoT)"] = {
									["count"] = 46014,
								},
								["Arcane Shot"] = {
									["count"] = 142929,
								},
								["Explosive Shot"] = {
									["count"] = 39392,
								},
								["Explosive Trap (DoT)"] = {
									["count"] = 17866,
								},
								["Improved Serpent Sting"] = {
									["count"] = 58628,
								},
								["Explosive Trap"] = {
									["count"] = 1607,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 223306,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 42384,
								},
							},
							["amount"] = 788124,
						},
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot"] = {
									["count"] = 40143,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 18421,
								},
								["Auto Shot"] = {
									["count"] = 87853,
								},
								["Explosive Shot (DoT)"] = {
									["count"] = 52033,
								},
								["Improved Serpent Sting"] = {
									["count"] = 44555,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 11533,
								},
							},
							["amount"] = 254538,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 95204,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 103277,
								},
								["Auto Shot"] = {
									["count"] = 81376,
								},
								["Explosive Shot"] = {
									["count"] = 40523,
								},
								["Explosive Trap (DoT)"] = {
									["count"] = 27631,
								},
								["Improved Serpent Sting"] = {
									["count"] = 76633,
								},
								["Explosive Trap"] = {
									["count"] = 3187,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 10156,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 16953,
								},
							},
							["amount"] = 454940,
						},
					},
					["Attacks"] = {
						["Explosive Shot (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 13721,
									["min"] = 11122,
									["count"] = 4,
									["amount"] = 51480,
								},
								["Tick"] = {
									["max"] = 7078,
									["min"] = 5561,
									["count"] = 28,
									["amount"] = 182351,
								},
							},
							["count"] = 32,
							["amount"] = 233831,
						},
						["Serpent Sting (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 23447,
									["min"] = 22330,
									["count"] = 4,
									["amount"] = 90438,
								},
								["Tick"] = {
									["max"] = 11724,
									["min"] = 11165,
									["count"] = 29,
									["amount"] = 325468,
								},
							},
							["count"] = 33,
							["amount"] = 415906,
						},
						["Auto Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 7714,
									["min"] = 5336,
									["count"] = 44,
									["amount"] = 284892,
								},
								["Crit"] = {
									["max"] = 16709,
									["min"] = 11006,
									["count"] = 7,
									["amount"] = 94279,
								},
								["Miss"] = {
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 54,
							["amount"] = 379171,
						},
						["Black Arrow (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7079,
									["min"] = 7079,
									["count"] = 3,
									["amount"] = 21237,
								},
								["Tick"] = {
									["max"] = 3540,
									["min"] = 3539,
									["count"] = 7,
									["amount"] = 24777,
								},
							},
							["count"] = 10,
							["amount"] = 46014,
						},
						["Entrapment"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 12,
									["amount"] = 0,
								},
							},
							["count"] = 12,
							["amount"] = 0,
						},
						["Explosive Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 7041,
									["min"] = 5743,
									["count"] = 15,
									["amount"] = 97866,
								},
								["Crit"] = {
									["max"] = 12875,
									["min"] = 11338,
									["count"] = 3,
									["amount"] = 35597,
								},
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 19,
							["amount"] = 133463,
						},
						["Explosive Trap (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3248,
									["min"] = 3248,
									["count"] = 1,
									["amount"] = 3248,
								},
								["Tick"] = {
									["max"] = 1706,
									["min"] = 1546,
									["count"] = 45,
									["amount"] = 72182,
								},
							},
							["count"] = 46,
							["amount"] = 75430,
						},
						["Improved Serpent Sting"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 16750,
									["min"] = 16750,
									["count"] = 2,
									["amount"] = 33500,
								},
								["Hit"] = {
									["max"] = 8794,
									["min"] = 7425,
									["count"] = 28,
									["amount"] = 230067,
								},
							},
							["count"] = 30,
							["amount"] = 263567,
						},
						["Explosive Trap"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1635,
									["min"] = 1552,
									["count"] = 5,
									["amount"] = 7977,
								},
							},
							["count"] = 5,
							["amount"] = 7977,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 25631,
									["min"] = 23616,
									["count"] = 3,
									["amount"] = 73300,
								},
								["Hit"] = {
									["max"] = 14698,
									["min"] = 12213,
									["count"] = 17,
									["amount"] = 228077,
								},
							},
							["count"] = 20,
							["amount"] = 301377,
						},
						["Speaking of Rage (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1693,
									["min"] = 1535,
									["count"] = 9,
									["amount"] = 14603,
								},
								["Tick"] = {
									["max"] = 847,
									["min"] = 767,
									["count"] = 71,
									["amount"] = 58424,
								},
							},
							["count"] = 80,
							["amount"] = 73027,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 8477,
									["min"] = 7688,
									["count"] = 3,
									["amount"] = 24642,
								},
								["Tick"] = {
									["max"] = 4239,
									["min"] = 3845,
									["count"] = 15,
									["amount"] = 63181,
								},
							},
							["count"] = 18,
							["amount"] = 87823,
						},
					},
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 1.28,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 6.160000000000002,
								},
								["Auto Shot"] = {
									["count"] = 12.18,
								},
								["Entrapment"] = {
									["count"] = 0,
								},
								["Explosive Shot"] = {
									["count"] = 1.29,
								},
								["Explosive Trap (DoT)"] = {
									["count"] = 11.19,
								},
								["Improved Serpent Sting"] = {
									["count"] = 3.88,
								},
								["Explosive Trap"] = {
									["count"] = 1.04,
								},
								["Arcane Shot"] = {
									["count"] = 3.38,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 2.18,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 1.73,
								},
							},
							["amount"] = 44.31000000000003,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 2.16,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 6.39,
								},
								["Auto Shot"] = {
									["count"] = 16.01,
								},
								["Black Arrow (DoT)"] = {
									["count"] = 4.360000000000001,
								},
								["Entrapment"] = {
									["count"] = 0.43,
								},
								["Explosive Shot"] = {
									["count"] = 1.54,
								},
								["Explosive Trap (DoT)"] = {
									["count"] = 0.84,
								},
								["Improved Serpent Sting"] = {
									["count"] = 3.33,
								},
								["Explosive Trap"] = {
									["count"] = 0,
								},
								["Arcane Shot"] = {
									["count"] = 3.07,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 3.33,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 3.66,
								},
							},
							["amount"] = 45.12000000000001,
						},
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot"] = {
									["count"] = 1.88,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 3.92,
								},
								["Auto Shot"] = {
									["count"] = 19,
								},
								["Explosive Shot (DoT)"] = {
									["count"] = 4.220000000000001,
								},
								["Improved Serpent Sting"] = {
									["count"] = 1.64,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.72,
								},
							},
							["amount"] = 31.38000000000001,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 5.79,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 2.1,
								},
								["Auto Shot"] = {
									["count"] = 5.8,
								},
								["Entrapment"] = {
									["count"] = 0.09,
								},
								["Explosive Shot"] = {
									["count"] = 2.55,
								},
								["Explosive Trap (DoT)"] = {
									["count"] = 2.95,
								},
								["Improved Serpent Sting"] = {
									["count"] = 3.04,
								},
								["Explosive Trap"] = {
									["count"] = 1.01,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 1.65,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.8400000000000001,
								},
							},
							["amount"] = 25.82,
						},
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 3,
								},
								["Tick"] = {
									["count"] = 7,
								},
							},
							["amount"] = 10,
						},
						["Arcane"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 17,
								},
							},
							["amount"] = 20,
						},
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 20,
								},
								["Tick"] = {
									["count"] = 144,
								},
								["Crit"] = {
									["count"] = 17,
								},
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 182,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 44,
								},
								["Crit"] = {
									["count"] = 7,
								},
								["Miss"] = {
									["count"] = 3,
								},
							},
							["amount"] = 54,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 28,
								},
								["Immune"] = {
									["count"] = 12,
								},
								["Crit"] = {
									["count"] = 9,
								},
								["Tick"] = {
									["count"] = 44,
								},
							},
							["amount"] = 93,
						},
					},
					["TimeDamage"] = 146.63,
					["WhoDamaged"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Spray Chemical"] = {
									["count"] = 5829,
								},
							},
							["amount"] = 5829,
						},
					},
					["EnergyGainedFrom"] = {
						["Gato"] = {
							["Details"] = {
								["Viper Venom"] = {
									["count"] = 96,
								},
							},
							["amount"] = 96,
						},
					},
					["EnergyGain"] = 96,
					["ElementTakenAbsorb"] = {
						["Nature"] = 8719,
					},
				},
				["Fight5"] = {
					["DOTs"] = {
						["Speaking of Rage (DoT)"] = {
							["Details"] = {
								["Crown Technician"] = {
									["count"] = 30,
								},
							},
							["amount"] = 30,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Crown Technician"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 3064,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Nature"] = 3064,
					},
					["DOT_Time"] = 33,
					["Damage"] = 46811,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["Spray Chemical"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Physical"] = 14991,
						["Fire"] = 20549,
						["Nature"] = 11271,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Fire"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 3,
								},
								["Tick"] = {
									["count"] = 8,
								},
							},
							["amount"] = 11,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
								["Tick"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Spray Chemical"] = {
									["count"] = 3064,
								},
							},
							["amount"] = 3064,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 6.250000000000002,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
						["Spray Chemical"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot"] = {
									["count"] = 0.11,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 2.21,
								},
								["Auto Shot"] = {
									["count"] = 3.78,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0.15,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 6.250000000000002,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["Explosive Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 11338,
									["min"] = 11338,
									["count"] = 1,
									["amount"] = 11338,
								},
							},
							["count"] = 1,
							["amount"] = 11338,
						},
						["Speaking of Rage (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1535,
									["min"] = 1535,
									["count"] = 2,
									["amount"] = 3070,
								},
								["Tick"] = {
									["max"] = 768,
									["min"] = 767,
									["count"] = 8,
									["amount"] = 6141,
								},
							},
							["count"] = 10,
							["amount"] = 9211,
						},
						["Auto Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 7714,
									["min"] = 7277,
									["count"] = 2,
									["amount"] = 14991,
								},
							},
							["count"] = 2,
							["amount"] = 14991,
						},
						["Improved Serpent Sting"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 7426,
									["min"] = 7426,
									["count"] = 1,
									["amount"] = 7426,
								},
							},
							["count"] = 1,
							["amount"] = 7426,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 3845,
									["min"] = 3845,
									["count"] = 1,
									["amount"] = 3845,
								},
							},
							["count"] = 1,
							["amount"] = 3845,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot"] = {
									["count"] = 11338,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 9211,
								},
								["Auto Shot"] = {
									["count"] = 14991,
								},
								["Improved Serpent Sting"] = {
									["count"] = 7426,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 3845,
								},
							},
							["amount"] = 46811,
						},
					},
					["TimeDamage"] = 6.250000000000002,
					["TimeDamaging"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot"] = {
									["count"] = 0.11,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 2.21,
								},
								["Auto Shot"] = {
									["count"] = 3.78,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0.15,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 6.250000000000002,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
						["Explosive Shot (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 0,
								},
								["Apothecary Hummel"] = {
									["count"] = 0,
								},
								["Apothecary Baxter"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Explosive Trap (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 0,
								},
								["Apothecary Hummel"] = {
									["count"] = 0,
								},
								["Apothecary Baxter"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Serpent Sting (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 0,
								},
								["Apothecary Hummel"] = {
									["count"] = 0,
								},
								["Apothecary Baxter"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Speaking of Rage (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 0,
								},
								["Apothecary Hummel"] = {
									["count"] = 0,
								},
								["Apothecary Baxter"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Black Arrow (DoT)"] = {
							["Details"] = {
								["Apothecary Hummel"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 0,
								},
								["Apothecary Hummel"] = {
									["count"] = 0,
								},
								["Apothecary Baxter"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Shadow"] = 0,
						["Arcane"] = 0,
						["Fire"] = 0,
						["Physical"] = 0,
						["Nature"] = 0,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Arcane"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Immune"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
						["Gato"] = {
							["Details"] = {
								["Viper Venom"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
						["Nature"] = 0,
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 0,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 0,
								},
								["Auto Shot"] = {
									["count"] = 0,
								},
								["Entrapment"] = {
									["count"] = 0,
								},
								["Explosive Shot"] = {
									["count"] = 0,
								},
								["Explosive Trap (DoT)"] = {
									["count"] = 0,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0,
								},
								["Explosive Trap"] = {
									["count"] = 0,
								},
								["Arcane Shot"] = {
									["count"] = 0,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 0,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 0,
								},
								["Auto Shot"] = {
									["count"] = 0,
								},
								["Black Arrow (DoT)"] = {
									["count"] = 0,
								},
								["Entrapment"] = {
									["count"] = 0,
								},
								["Explosive Shot"] = {
									["count"] = 0,
								},
								["Explosive Trap (DoT)"] = {
									["count"] = 0,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0,
								},
								["Explosive Trap"] = {
									["count"] = 0,
								},
								["Arcane Shot"] = {
									["count"] = 0,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 0,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 0,
								},
								["Auto Shot"] = {
									["count"] = 0,
								},
								["Entrapment"] = {
									["count"] = 0,
								},
								["Explosive Shot"] = {
									["count"] = 0,
								},
								["Explosive Trap (DoT)"] = {
									["count"] = 0,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0,
								},
								["Explosive Trap"] = {
									["count"] = 0,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
						["Viper Venom"] = {
							["Details"] = {
								["Gato"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["Explosive Shot (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Serpent Sting (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Auto Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Black Arrow (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Entrapment"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Explosive Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Explosive Trap (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Improved Serpent Sting"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Explosive Trap"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Arcane Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Speaking of Rage (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 0,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 0,
								},
								["Auto Shot"] = {
									["count"] = 0,
								},
								["Arcane Shot"] = {
									["count"] = 0,
								},
								["Explosive Shot"] = {
									["count"] = 0,
								},
								["Explosive Trap (DoT)"] = {
									["count"] = 0,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0,
								},
								["Explosive Trap"] = {
									["count"] = 0,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 0,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 0,
								},
								["Auto Shot"] = {
									["count"] = 0,
								},
								["Black Arrow (DoT)"] = {
									["count"] = 0,
								},
								["Arcane Shot"] = {
									["count"] = 0,
								},
								["Explosive Shot"] = {
									["count"] = 0,
								},
								["Explosive Trap (DoT)"] = {
									["count"] = 0,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0,
								},
								["Explosive Trap"] = {
									["count"] = 0,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 0,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 0,
								},
								["Auto Shot"] = {
									["count"] = 0,
								},
								["Explosive Shot"] = {
									["count"] = 0,
								},
								["Explosive Trap (DoT)"] = {
									["count"] = 0,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0,
								},
								["Explosive Trap"] = {
									["count"] = 0,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 0,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 0,
								},
								["Auto Shot"] = {
									["count"] = 0,
								},
								["Entrapment"] = {
									["count"] = 0,
								},
								["Explosive Shot"] = {
									["count"] = 0,
								},
								["Explosive Trap (DoT)"] = {
									["count"] = 0,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0,
								},
								["Explosive Trap"] = {
									["count"] = 0,
								},
								["Arcane Shot"] = {
									["count"] = 0,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 0,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 0,
								},
								["Auto Shot"] = {
									["count"] = 0,
								},
								["Black Arrow (DoT)"] = {
									["count"] = 0,
								},
								["Entrapment"] = {
									["count"] = 0,
								},
								["Explosive Shot"] = {
									["count"] = 0,
								},
								["Explosive Trap (DoT)"] = {
									["count"] = 0,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0,
								},
								["Explosive Trap"] = {
									["count"] = 0,
								},
								["Arcane Shot"] = {
									["count"] = 0,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 0,
								},
								["Serpent Sting (DoT)"] = {
									["count"] = 0,
								},
								["Auto Shot"] = {
									["count"] = 0,
								},
								["Entrapment"] = {
									["count"] = 0,
								},
								["Explosive Shot"] = {
									["count"] = 0,
								},
								["Explosive Trap (DoT)"] = {
									["count"] = 0,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0,
								},
								["Explosive Trap"] = {
									["count"] = 0,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["DOTs"] = {
						["Explosive Shot (DoT)"] = {
							["Details"] = {
								["Crown Technician"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Crown Technician"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["DamagedWho"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 16683,
								},
								["Improved Serpent Sting"] = {
									["count"] = 7426,
								},
								["Auto Shot"] = {
									["count"] = 14589,
								},
								["Explosive Shot"] = {
									["count"] = 5743,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 7688,
								},
							},
							["amount"] = 52129,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Spray Chemical"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["TimeSpent"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 0.98,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0.28,
								},
								["Auto Shot"] = {
									["count"] = 3.91,
								},
								["Explosive Shot"] = {
									["count"] = 0.34,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.72,
								},
							},
							["amount"] = 6.23,
						},
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Spray Chemical"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Physical"] = 14589,
						["Fire"] = 22426,
						["Nature"] = 15114,
					},
					["TimeDamage"] = 6.23,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Tick"] = {
									["count"] = 1,
								},
							},
							["amount"] = 3,
						},
						["Nature"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
					},
					["ActiveTime"] = 6.23,
					["TimeDamaging"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 0.98,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0.28,
								},
								["Auto Shot"] = {
									["count"] = 3.91,
								},
								["Explosive Shot"] = {
									["count"] = 0.34,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.72,
								},
							},
							["amount"] = 6.23,
						},
					},
					["Attacks"] = {
						["Explosive Shot (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 11122,
									["min"] = 11122,
									["count"] = 1,
									["amount"] = 11122,
								},
								["Tick"] = {
									["max"] = 5561,
									["min"] = 5561,
									["count"] = 1,
									["amount"] = 5561,
								},
							},
							["count"] = 2,
							["amount"] = 16683,
						},
						["Improved Serpent Sting"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 7426,
									["min"] = 7426,
									["count"] = 1,
									["amount"] = 7426,
								},
							},
							["count"] = 1,
							["amount"] = 7426,
						},
						["Auto Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 7383,
									["min"] = 7206,
									["count"] = 2,
									["amount"] = 14589,
								},
							},
							["count"] = 2,
							["amount"] = 14589,
						},
						["Explosive Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5743,
									["min"] = 5743,
									["count"] = 1,
									["amount"] = 5743,
								},
							},
							["count"] = 1,
							["amount"] = 5743,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7688,
									["min"] = 7688,
									["count"] = 1,
									["amount"] = 7688,
								},
							},
							["count"] = 1,
							["amount"] = 7688,
						},
					},
					["DOT_Time"] = 9,
					["Damage"] = 52129,
				},
				["Fight4"] = {
					["DOTs"] = {
						["Explosive Shot (DoT)"] = {
							["Details"] = {
								["Crown Technician"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 2765,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Nature"] = 2765,
					},
					["DOT_Time"] = 6,
					["Damage"] = 38638,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["Spray Chemical"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Physical"] = 13459,
						["Fire"] = 17753,
						["Nature"] = 7426,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
								["Tick"] = {
									["count"] = 2,
								},
							},
							["amount"] = 3,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Spray Chemical"] = {
									["count"] = 2765,
								},
							},
							["amount"] = 2765,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 6.35,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
						["Spray Chemical"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot"] = {
									["count"] = 0.33,
								},
								["Auto Shot"] = {
									["count"] = 4.1,
								},
								["Explosive Shot (DoT)"] = {
									["count"] = 1.79,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0.13,
								},
							},
							["amount"] = 6.35,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["Explosive Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5921,
									["min"] = 5921,
									["count"] = 1,
									["amount"] = 5921,
								},
							},
							["count"] = 1,
							["amount"] = 5921,
						},
						["Auto Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 7138,
									["min"] = 6321,
									["count"] = 2,
									["amount"] = 13459,
								},
							},
							["count"] = 2,
							["amount"] = 13459,
						},
						["Explosive Shot (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 5916,
									["min"] = 5916,
									["count"] = 2,
									["amount"] = 11832,
								},
							},
							["count"] = 2,
							["amount"] = 11832,
						},
						["Improved Serpent Sting"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 7426,
									["min"] = 7426,
									["count"] = 1,
									["amount"] = 7426,
								},
							},
							["count"] = 1,
							["amount"] = 7426,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot"] = {
									["count"] = 5921,
								},
								["Auto Shot"] = {
									["count"] = 13459,
								},
								["Explosive Shot (DoT)"] = {
									["count"] = 11832,
								},
								["Improved Serpent Sting"] = {
									["count"] = 7426,
								},
							},
							["amount"] = 38638,
						},
					},
					["TimeDamage"] = 6.35,
					["TimeDamaging"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot"] = {
									["count"] = 0.33,
								},
								["Auto Shot"] = {
									["count"] = 4.1,
								},
								["Explosive Shot (DoT)"] = {
									["count"] = 1.79,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0.13,
								},
							},
							["amount"] = 6.35,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
						["Explosive Shot (DoT)"] = {
							["Details"] = {
								["Crown Technician"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Crown Technician"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["DamagedWho"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 16683,
								},
								["Improved Serpent Sting"] = {
									["count"] = 7426,
								},
								["Auto Shot"] = {
									["count"] = 14589,
								},
								["Explosive Shot"] = {
									["count"] = 5743,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 7688,
								},
							},
							["amount"] = 52129,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Spray Chemical"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["TimeSpent"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 0.98,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0.28,
								},
								["Auto Shot"] = {
									["count"] = 3.91,
								},
								["Explosive Shot"] = {
									["count"] = 0.34,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.72,
								},
							},
							["amount"] = 6.23,
						},
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Spray Chemical"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Physical"] = 14589,
						["Fire"] = 22426,
						["Nature"] = 15114,
					},
					["TimeDamage"] = 6.23,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Tick"] = {
									["count"] = 1,
								},
							},
							["amount"] = 3,
						},
						["Nature"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
					},
					["ActiveTime"] = 6.23,
					["TimeDamaging"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 0.98,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0.28,
								},
								["Auto Shot"] = {
									["count"] = 3.91,
								},
								["Explosive Shot"] = {
									["count"] = 0.34,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.72,
								},
							},
							["amount"] = 6.23,
						},
					},
					["Attacks"] = {
						["Explosive Shot (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 11122,
									["min"] = 11122,
									["count"] = 1,
									["amount"] = 11122,
								},
								["Tick"] = {
									["max"] = 5561,
									["min"] = 5561,
									["count"] = 1,
									["amount"] = 5561,
								},
							},
							["count"] = 2,
							["amount"] = 16683,
						},
						["Improved Serpent Sting"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 7426,
									["min"] = 7426,
									["count"] = 1,
									["amount"] = 7426,
								},
							},
							["count"] = 1,
							["amount"] = 7426,
						},
						["Auto Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 7383,
									["min"] = 7206,
									["count"] = 2,
									["amount"] = 14589,
								},
							},
							["count"] = 2,
							["amount"] = 14589,
						},
						["Explosive Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5743,
									["min"] = 5743,
									["count"] = 1,
									["amount"] = 5743,
								},
							},
							["count"] = 1,
							["amount"] = 5743,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7688,
									["min"] = 7688,
									["count"] = 1,
									["amount"] = 7688,
								},
							},
							["count"] = 1,
							["amount"] = 7688,
						},
					},
					["DOT_Time"] = 9,
					["Damage"] = 52129,
				},
				["Fight2"] = {
					["DOTs"] = {
						["Explosive Shot (DoT)"] = {
							["Details"] = {
								["Crown Technician"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 6,
					["Damage"] = 63261,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Physical"] = 32585,
						["Fire"] = 23250,
						["Nature"] = 7426,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Fire"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Tick"] = {
									["count"] = 2,
								},
							},
							["amount"] = 3,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 6.36,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot"] = {
									["count"] = 0.72,
								},
								["Explosive Shot (DoT)"] = {
									["count"] = 1.15,
								},
								["Auto Shot"] = {
									["count"] = 3.71,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0.78,
								},
							},
							["amount"] = 6.36,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["Explosive Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 11384,
									["min"] = 11384,
									["count"] = 1,
									["amount"] = 11384,
								},
							},
							["count"] = 1,
							["amount"] = 11384,
						},
						["Explosive Shot (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 5933,
									["min"] = 5933,
									["count"] = 2,
									["amount"] = 11866,
								},
							},
							["count"] = 2,
							["amount"] = 11866,
						},
						["Auto Shot"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 16709,
									["min"] = 15876,
									["count"] = 2,
									["amount"] = 32585,
								},
							},
							["count"] = 2,
							["amount"] = 32585,
						},
						["Improved Serpent Sting"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 7426,
									["min"] = 7426,
									["count"] = 1,
									["amount"] = 7426,
								},
							},
							["count"] = 1,
							["amount"] = 7426,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot"] = {
									["count"] = 11384,
								},
								["Explosive Shot (DoT)"] = {
									["count"] = 11866,
								},
								["Auto Shot"] = {
									["count"] = 32585,
								},
								["Improved Serpent Sting"] = {
									["count"] = 7426,
								},
							},
							["amount"] = 63261,
						},
					},
					["TimeDamage"] = 6.36,
					["TimeDamaging"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot"] = {
									["count"] = 0.72,
								},
								["Explosive Shot (DoT)"] = {
									["count"] = 1.15,
								},
								["Auto Shot"] = {
									["count"] = 3.71,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0.78,
								},
							},
							["amount"] = 6.36,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["DOTs"] = {
						["Explosive Shot (DoT)"] = {
							["Details"] = {
								["Crown Technician"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["Speaking of Rage (DoT)"] = {
							["Details"] = {
								["Crown Technician"] = {
									["count"] = 30,
								},
							},
							["amount"] = 30,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Nature"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 36,
					["Damage"] = 53699,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["Spray Chemical"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Physical"] = 12229,
						["Fire"] = 26619,
						["Nature"] = 14851,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Tick"] = {
									["count"] = 10,
								},
							},
							["amount"] = 13,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 6.19,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
						["Spray Chemical"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 0.3,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 1.71,
								},
								["Auto Shot"] = {
									["count"] = 3.5,
								},
								["Explosive Shot"] = {
									["count"] = 0.38,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0.3,
								},
							},
							["amount"] = 6.19,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["Explosive Shot (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 5826,
									["min"] = 5826,
									["count"] = 2,
									["amount"] = 11652,
								},
							},
							["count"] = 2,
							["amount"] = 11652,
						},
						["Speaking of Rage (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1535,
									["min"] = 1535,
									["count"] = 2,
									["amount"] = 3070,
								},
								["Tick"] = {
									["max"] = 768,
									["min"] = 767,
									["count"] = 8,
									["amount"] = 6140,
								},
							},
							["count"] = 10,
							["amount"] = 9210,
						},
						["Auto Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 6234,
									["min"] = 5995,
									["count"] = 2,
									["amount"] = 12229,
								},
							},
							["count"] = 2,
							["amount"] = 12229,
						},
						["Explosive Shot"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5757,
									["min"] = 5757,
									["count"] = 1,
									["amount"] = 5757,
								},
							},
							["count"] = 1,
							["amount"] = 5757,
						},
						["Improved Serpent Sting"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 7426,
									["min"] = 7425,
									["count"] = 2,
									["amount"] = 14851,
								},
							},
							["count"] = 2,
							["amount"] = 14851,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 11652,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 9210,
								},
								["Auto Shot"] = {
									["count"] = 12229,
								},
								["Explosive Shot"] = {
									["count"] = 5757,
								},
								["Improved Serpent Sting"] = {
									["count"] = 14851,
								},
							},
							["amount"] = 53699,
						},
					},
					["TimeDamage"] = 6.19,
					["TimeDamaging"] = {
						["Crown Technician"] = {
							["Details"] = {
								["Explosive Shot (DoT)"] = {
									["count"] = 0.3,
								},
								["Speaking of Rage (DoT)"] = {
									["count"] = 1.71,
								},
								["Auto Shot"] = {
									["count"] = 3.5,
								},
								["Explosive Shot"] = {
									["count"] = 0.38,
								},
								["Improved Serpent Sting"] = {
									["count"] = 0.3,
								},
							},
							["amount"] = 6.19,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
			},
			["Owner"] = false,
			["Pet"] = {
				"Underworld <Gato>", -- [1]
				"Venomous Snake <Gato>", -- [2]
				"Viper <Gato>", -- [3]
				"Ghost Iron Dragonling <Gato>", -- [4]
				"No One <Gato>", -- [5]
			},
			["NextEventNum"] = 27,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				100, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				100, -- [11]
				100, -- [12]
				100, -- [13]
				100, -- [14]
				100, -- [15]
				100, -- [16]
				100, -- [17]
				100, -- [18]
				100, -- [19]
				100, -- [20]
				100, -- [21]
				100, -- [22]
				100, -- [23]
				100, -- [24]
				100, -- [25]
				100, -- [26]
				98.90644462448293, -- [27]
				98.90644462448293, -- [28]
				98.90644462448293, -- [29]
				98.90644462448293, -- [30]
				98.90644462448293, -- [31]
				98.90644462448293, -- [32]
				98.90644462448293, -- [33]
				98.90644462448293, -- [34]
				98.90644462448293, -- [35]
				98.90644462448293, -- [36]
				100, -- [37]
				100, -- [38]
				99.01315906876479, -- [39]
				100, -- [40]
				100, -- [41]
				100, -- [42]
				100, -- [43]
				100, -- [44]
				100, -- [45]
				100, -- [46]
				100, -- [47]
				100, -- [48]
				100, -- [49]
				100, -- [50]
			},
			["LastEvents"] = {
				"Gato Improved Serpent Sting Crown Technician Hit -7426 (Nature)", -- [1]
				"Gato Speaking of Rage (DoT) Crown Technician Tick -768 (Fire)", -- [2]
				"Gato Speaking of Rage (DoT) Crown Technician Tick -768 (Fire)", -- [3]
				"Gato Speaking of Rage (DoT) Crown Technician Tick -767 (Fire)", -- [4]
				"Gato Speaking of Rage (DoT) Crown Technician Tick -767 (Fire)", -- [5]
				"Gato Speaking of Rage (DoT) Crown Technician Tick -768 (Fire)", -- [6]
				"Gato Explosive Shot (DoT) Crown Technician Tick -5826 (Fire)", -- [7]
				"Gato Speaking of Rage (DoT) Crown Technician Crit -1535 (Fire)", -- [8]
				"Gato Improved Serpent Sting Crown Technician Hit -7425 (Nature)", -- [9]
				"Gato Speaking of Rage (DoT) Crown Technician Tick -768 (Fire)", -- [10]
				"Gato Auto Shot Crown Technician Hit -6234 (Physical)", -- [11]
				"Crown Technician Spray Chemical Gato Miss (Nature)", -- [12]
				"Gato Auto Shot Crown Technician Crit -15876 (Physical)", -- [13]
				"Gato Explosive Shot Crown Technician Crit -11384 (Fire)", -- [14]
				"Gato Improved Serpent Sting Crown Technician Hit -7426 (Nature)", -- [15]
				"Gato Explosive Shot (DoT) Crown Technician Tick -5933 (Fire)", -- [16]
				"Gato Explosive Shot (DoT) Crown Technician Tick -5933 (Fire)", -- [17]
				"Gato Auto Shot Crown Technician Crit -16709 (Physical)", -- [18]
				"Gato Auto Shot Crown Technician Hit -7383 (Physical)", -- [19]
				"Gato Explosive Shot Crown Technician Hit -5743 (Fire)", -- [20]
				"Gato Explosive Shot (DoT) Crown Technician Tick -5561 (Fire)", -- [21]
				"Gato Improved Serpent Sting Crown Technician Hit -7426 (Nature)", -- [22]
				"Crown Technician Spray Chemical Gato Miss (Nature)", -- [23]
				"Gato Mantid Poison (DoT) Crown Technician Crit -7688 (Nature)", -- [24]
				"Gato Explosive Shot (DoT) Crown Technician Crit -11122 (Fire)", -- [25]
				"Gato Auto Shot Crown Technician Hit -7206 (Physical)", -- [26]
				"Gato Speaking of Rage (DoT) Crown Technician Crit -1535 (Fire)", -- [27]
				"Gato Speaking of Rage (DoT) Crown Technician Tick -767 (Fire)", -- [28]
				"Gato Speaking of Rage (DoT) Crown Technician Tick -768 (Fire)", -- [29]
				"Gato Speaking of Rage (DoT) Crown Technician Tick -767 (Fire)", -- [30]
				"Gato Mantid Poison (DoT) Crown Technician Tick -3845 (Nature)", -- [31]
				"Gato Explosive Shot Crown Technician Crit -11338 (Fire)", -- [32]
				"Gato Speaking of Rage (DoT) Crown Technician Tick -768 (Fire)", -- [33]
				"Gato Speaking of Rage (DoT) Crown Technician Tick -768 (Fire)", -- [34]
				"Gato Speaking of Rage (DoT) Crown Technician Crit -1535 (Fire)", -- [35]
				"Gato Auto Shot Crown Technician Hit -7714 (Physical)", -- [36]
				"Gato Auto Shot Crown Technician Hit -7138 (Physical)", -- [37]
				"Gato Explosive Shot Crown Technician Hit -5921 (Fire)", -- [38]
				"Crown Technician Spray Chemical Gato Hit -2765 (Nature)", -- [39]
				"Gato Explosive Shot (DoT) Crown Technician Tick -5916 (Fire)", -- [40]
				"Gato Improved Serpent Sting Crown Technician Hit -7426 (Nature)", -- [41]
				"Gato Explosive Shot (DoT) Crown Technician Tick -5916 (Fire)", -- [42]
				"Gato Auto Shot Crown Technician Hit -6321 (Physical)", -- [43]
				"Gato Auto Shot Crown Technician Hit -5995 (Physical)", -- [44]
				"Gato Explosive Shot Crown Technician Hit -5757 (Fire)", -- [45]
				"Gato Speaking of Rage (DoT) Crown Technician Crit -1535 (Fire)", -- [46]
				"Gato Speaking of Rage (DoT) Crown Technician Tick -767 (Fire)", -- [47]
				"Crown Technician Spray Chemical Gato Miss (Nature)", -- [48]
				"Gato Speaking of Rage (DoT) Crown Technician Tick -767 (Fire)", -- [49]
				"Gato Explosive Shot (DoT) Crown Technician Tick -5826 (Fire)", -- [50]
			},
			["Name"] = "Gato",
			["LastDamageTaken"] = 2765,
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				true, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				true, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				true, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				true, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["TimeLast"] = {
				["EnergyGain"] = 1360560704,
				["TimeDamage"] = 1360561111,
				["ActiveTime"] = 1360561111,
				["DOT_Time"] = 1360561111,
				["OVERALL"] = 1360561111,
				["DamageTaken"] = 1360561078,
				["Damage"] = 1360561111,
			},
			["LastEventTimes"] = {
				21271.45, -- [1]
				21271.45, -- [2]
				21271.697, -- [3]
				21271.889, -- [4]
				21272.095, -- [5]
				21272.299, -- [6]
				21272.418, -- [7]
				21272.418, -- [8]
				21272.717, -- [9]
				21272.717, -- [10]
				21272.717, -- [11]
				21273.592, -- [12]
				21280.886, -- [13]
				21281.603, -- [14]
				21282.378, -- [15]
				21282.536, -- [16]
				21283.524, -- [17]
				21283.734, -- [18]
				21292.038, -- [19]
				21292.376, -- [20]
				21293.352, -- [21]
				21293.631, -- [22]
				21294.269, -- [23]
				21294.346, -- [24]
				21294.346, -- [25]
				21294.754, -- [26]
				21240.871, -- [27]
				21241.102, -- [28]
				21241.276, -- [29]
				21241.48, -- [30]
				21241.48, -- [31]
				21241.592, -- [32]
				21241.707, -- [33]
				21241.906, -- [34]
				21242.048, -- [35]
				21242.329, -- [36]
				21261.586, -- [37]
				21261.913, -- [38]
				21261.913, -- [39]
				21262.909, -- [40]
				21263.036, -- [41]
				21263.826, -- [42]
				21264.426, -- [43]
				21270.032, -- [44]
				21270.415, -- [45]
				21270.896, -- [46]
				21271.105, -- [47]
				21271.138, -- [48]
				21271.273, -- [49]
				21271.45, -- [50]
			},
			["LastAbility"] = 102142.251,
		},
		["Darver-Silvermoon"] = {
			["GUID"] = "0x01000000048D8AB2",
			["LastEventHealth"] = {
				"344309 (100%)", -- [1]
				"344309 (100%)", -- [2]
				"344309 (100%)", -- [3]
				"344309 (100%)", -- [4]
				"344309 (100%)", -- [5]
				"344309 (100%)", -- [6]
				"344309 (100%)", -- [7]
				"344309 (100%)", -- [8]
				"344309 (100%)", -- [9]
				"344309 (100%)", -- [10]
				"344309 (100%)", -- [11]
				"344309 (100%)", -- [12]
				"344309 (100%)", -- [13]
				"342230 (99%)", -- [14]
				"343311 (99%)", -- [15]
				"343311 (99%)", -- [16]
				"340687 (98%)", -- [17]
				"340687 (98%)", -- [18]
				"340687 (98%)", -- [19]
				"341768 (99%)", -- [20]
				"341768 (99%)", -- [21]
				"341768 (99%)", -- [22]
				"339148 (98%)", -- [23]
				"340228 (98%)", -- [24]
				"340228 (98%)", -- [25]
				"344309 (100%)", -- [26]
				"344309 (100%)", -- [27]
				"344309 (100%)", -- [28]
				"344309 (100%)", -- [29]
				"344309 (100%)", -- [30]
				"344309 (100%)", -- [31]
				"344309 (100%)", -- [32]
				"344309 (100%)", -- [33]
				"344309 (100%)", -- [34]
				"344309 (100%)", -- [35]
				"344309 (100%)", -- [36]
				"344309 (100%)", -- [37]
				"344309 (100%)", -- [38]
				"344309 (100%)", -- [39]
				"344309 (100%)", -- [40]
				"344309 (100%)", -- [41]
				"344309 (100%)", -- [42]
				"344309 (100%)", -- [43]
				"344309 (100%)", -- [44]
				"344309 (100%)", -- [45]
				"344309 (100%)", -- [46]
				"344309 (100%)", -- [47]
				"344309 (100%)", -- [48]
				"344309 (100%)", -- [49]
				"344309 (100%)", -- [50]
			},
			["LastAttackedBy"] = "Apothecary Baxter",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"HEAL", -- [13]
				"DAMAGE", -- [14]
				"HEAL", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"HEAL", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"HEAL", -- [24]
				"DAMAGE", -- [25]
				"HEAL", -- [26]
				"HEAL", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					0.52, -- [1]
				},
				["Healing"] = {
					21109, -- [1]
				},
				["DamageTaken"] = {
					223189, -- [1]
				},
				["EnergyGain"] = {
					800, -- [1]
				},
				["HealingTaken"] = {
					270551, -- [1]
				},
				["Overhealing"] = {
					106736, -- [1]
				},
				["TimeDamage"] = {
					126.2999999999999, -- [1]
				},
				["ActiveTime"] = {
					126.8199999999999, -- [1]
				},
				["DOT_Time"] = {
					369, -- [1]
				},
				["Damage"] = {
					3662186, -- [1]
				},
			},
			["enClass"] = "ROGUE",
			["unit"] = "Darver",
			["level"] = 90,
			["LastDamageAbility"] = "Irresistible Cologne",
			["LastFightIn"] = 1,
			["LastEventNum"] = {
				[27] = 11.18472070146293,
				[24] = 0.3136717309161248,
				[15] = 0.3139621677040101,
				[17] = 0.762106131411029,
				[20] = 0.3139621677040101,
				[26] = 9.629722139125031,
				[23] = 0.7609443842594879,
				[13] = 4.538946121071479,
			},
			["type"] = "Ungrouped",
			["FightsSaved"] = 5,
			["LastActive"] = 1360560712,
			["UnitLockout"] = 1360560706,
			["Owner"] = false,
			["Fights"] = {
				["LastFightData"] = {
					["DamagedWho"] = {
						["Corpse Eater"] = {
							["Details"] = {
								["Fan of Knives"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["TimeSpent"] = {
						["Corpse Eater"] = {
							["Details"] = {
								["Fan of Knives"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Physical"] = 0,
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["Corpse Eater"] = {
							["Details"] = {
								["Fan of Knives"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["Fan of Knives"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Damage"] = 0,
				},
				["CurrentFightData"] = {
					["DOTs"] = {
						["Deadly Poison (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 0,
								},
								["Apothecary Hummel"] = {
									["count"] = 0,
								},
								["Apothecary Baxter"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Rupture (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 0,
								},
								["Apothecary Hummel"] = {
									["count"] = 0,
								},
								["Apothecary Baxter"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Hemorrhage (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 0,
								},
								["Apothecary Hummel"] = {
									["count"] = 0,
								},
								["Apothecary Baxter"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Fire"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Nature"] = 0,
						["Fire"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["Alluring Perfume"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Physical"] = 0,
						["Shadow"] = 0,
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["Apothecary Hummel"] = {
							["Details"] = {
								["Alluring Perfume"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Irresistible Cologne"] = {
									["count"] = 0,
								},
								["Irresistible Cologne Spray (DoT)"] = {
									["count"] = 0,
								},
								["Chain Reaction"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Relentless Strikes"] = {
									["count"] = 0,
								},
								["Slice and Dice"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
						["Melee"] = 0,
					},
					["TimeHealing"] = {
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Touch of the Grave"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Touch of the Grave"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["Alluring Perfume"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
						["Nature"] = 0,
						["Fire"] = 0,
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Touch of the Grave"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Hemorrhage (DoT)"] = {
									["count"] = 0,
								},
								["Ambush"] = {
									["count"] = 0,
								},
								["Rupture (DoT)"] = {
									["count"] = 0,
								},
								["Deadly Poison"] = {
									["count"] = 0,
								},
								["Hemorrhage"] = {
									["count"] = 0,
								},
								["Eviscerate"] = {
									["count"] = 0,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 0,
								},
								["Touch of the Grave"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Mind-numbing Poison"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Frye"] = {
							["Details"] = {
								["Hemorrhage (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Touch of the Grave"] = {
									["count"] = 0,
								},
								["Shiv"] = {
									["count"] = 0,
								},
								["Hemorrhage"] = {
									["count"] = 0,
								},
								["Eviscerate"] = {
									["count"] = 0,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 0,
								},
								["Deadly Poison"] = {
									["count"] = 0,
								},
								["Rupture (DoT)"] = {
									["count"] = 0,
								},
								["Mind-numbing Poison"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Hemorrhage (DoT)"] = {
									["count"] = 0,
								},
								["Ambush"] = {
									["count"] = 0,
								},
								["Rupture (DoT)"] = {
									["count"] = 0,
								},
								["Deadly Poison"] = {
									["count"] = 0,
								},
								["Shiv"] = {
									["count"] = 0,
								},
								["Hemorrhage"] = {
									["count"] = 0,
								},
								["Eviscerate"] = {
									["count"] = 0,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Touch of the Grave"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Heals"] = {
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
						["Relentless Strikes"] = {
							["Details"] = {
								["Darver-Silvermoon"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Slice and Dice"] = {
							["Details"] = {
								["Darver-Silvermoon"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["HealedWho"] = {
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Touch of the Grave"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["Hemorrhage (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Ambush"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Rupture (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Deadly Poison"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Shiv"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Hemorrhage"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Eviscerate"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Deadly Poison (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit (Blocked)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Mind-numbing Poison"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Hemorrhage (DoT)"] = {
									["count"] = 0,
								},
								["Eviscerate"] = {
									["count"] = 0,
								},
								["Rupture (DoT)"] = {
									["count"] = 0,
								},
								["Touch of the Grave"] = {
									["count"] = 0,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 0,
								},
								["Deadly Poison"] = {
									["count"] = 0,
								},
								["Hemorrhage"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Hemorrhage (DoT)"] = {
									["count"] = 0,
								},
								["Ambush"] = {
									["count"] = 0,
								},
								["Rupture (DoT)"] = {
									["count"] = 0,
								},
								["Deadly Poison"] = {
									["count"] = 0,
								},
								["Hemorrhage"] = {
									["count"] = 0,
								},
								["Eviscerate"] = {
									["count"] = 0,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 0,
								},
								["Touch of the Grave"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Hemorrhage (DoT)"] = {
									["count"] = 0,
								},
								["Ambush"] = {
									["count"] = 0,
								},
								["Rupture (DoT)"] = {
									["count"] = 0,
								},
								["Deadly Poison"] = {
									["count"] = 0,
								},
								["Shiv"] = {
									["count"] = 0,
								},
								["Hemorrhage"] = {
									["count"] = 0,
								},
								["Eviscerate"] = {
									["count"] = 0,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Touch of the Grave"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Hemorrhage (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Touch of the Grave"] = {
									["count"] = 0,
								},
								["Shiv"] = {
									["count"] = 0,
								},
								["Hemorrhage"] = {
									["count"] = 0,
								},
								["Eviscerate"] = {
									["count"] = 0,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 0,
								},
								["Deadly Poison"] = {
									["count"] = 0,
								},
								["Rupture (DoT)"] = {
									["count"] = 0,
								},
								["Mind-numbing Poison"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Hemorrhage (DoT)"] = {
									["count"] = 0,
								},
								["Ambush"] = {
									["count"] = 0,
								},
								["Rupture (DoT)"] = {
									["count"] = 0,
								},
								["Deadly Poison"] = {
									["count"] = 0,
								},
								["Hemorrhage"] = {
									["count"] = 0,
								},
								["Eviscerate"] = {
									["count"] = 0,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 0,
								},
								["Touch of the Grave"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Mind-numbing Poison"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Hemorrhage (DoT)"] = {
									["count"] = 0,
								},
								["Ambush"] = {
									["count"] = 0,
								},
								["Rupture (DoT)"] = {
									["count"] = 0,
								},
								["Deadly Poison"] = {
									["count"] = 0,
								},
								["Shiv"] = {
									["count"] = 0,
								},
								["Hemorrhage"] = {
									["count"] = 0,
								},
								["Eviscerate"] = {
									["count"] = 0,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Touch of the Grave"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["ElementDoneBlock"] = {
						["Melee"] = 3562,
					},
					["TimeHealing"] = {
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Touch of the Grave"] = {
									["count"] = 0.52,
								},
							},
							["amount"] = 0.52,
						},
					},
					["OverHeals"] = {
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16080,
									["min"] = 14077,
									["count"] = 7,
									["amount"] = 106736,
								},
							},
							["count"] = 7,
							["amount"] = 106736,
						},
					},
					["ElementDone"] = {
						["Physical"] = 1731889,
						["Shadow"] = 121762,
						["Melee"] = 1058341,
						["Nature"] = 750194,
					},
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 87,
								},
								["Hit"] = {
									["count"] = 41,
								},
								["Tick"] = {
									["count"] = 3,
								},
							},
							["amount"] = 131,
						},
					},
					["DamageTaken"] = 223189,
					["DamagedWho"] = {
						["Corpse Eater"] = {
							["Details"] = {
								["Fan of Knives"] = {
									["count"] = 5186,
								},
							},
							["amount"] = 5186,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Hemorrhage (DoT)"] = {
									["count"] = 23917,
								},
								["Ambush"] = {
									["count"] = 275763,
								},
								["Rupture (DoT)"] = {
									["count"] = 132044,
								},
								["Deadly Poison"] = {
									["count"] = 148564,
								},
								["Hemorrhage"] = {
									["count"] = 267590,
								},
								["Eviscerate"] = {
									["count"] = 249223,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 192685,
								},
								["Touch of the Grave"] = {
									["count"] = 47698,
								},
								["Melee"] = {
									["count"] = 479411,
								},
							},
							["amount"] = 1816895,
						},
						["Apothecary Frye"] = {
							["Details"] = {
								["Hemorrhage (DoT)"] = {
									["count"] = 9196,
								},
								["Eviscerate"] = {
									["count"] = 33218,
								},
								["Rupture (DoT)"] = {
									["count"] = 43901,
								},
								["Touch of the Grave"] = {
									["count"] = 44599,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 124013,
								},
								["Deadly Poison"] = {
									["count"] = 87925,
								},
								["Hemorrhage"] = {
									["count"] = 183367,
								},
								["Melee"] = {
									["count"] = 238764,
								},
							},
							["amount"] = 764983,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Hemorrhage (DoT)"] = {
									["count"] = 11141,
								},
								["Ambush"] = {
									["count"] = 199709,
								},
								["Rupture (DoT)"] = {
									["count"] = 92433,
								},
								["Deadly Poison"] = {
									["count"] = 91793,
								},
								["Shiv"] = {
									["count"] = 1292,
								},
								["Hemorrhage"] = {
									["count"] = 187992,
								},
								["Eviscerate"] = {
									["count"] = 15917,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 105214,
								},
								["Melee"] = {
									["count"] = 340166,
								},
								["Touch of the Grave"] = {
									["count"] = 29465,
								},
							},
							["amount"] = 1075122,
						},
					},
					["PartialResist"] = {
						["Alluring Perfume"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 46,
									["amount"] = 0,
								},
							},
							["count"] = 46,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 12,
									["amount"] = 0,
								},
							},
							["count"] = 12,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 52,
									["amount"] = 0,
								},
							},
							["count"] = 52,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 18,
									["amount"] = 0,
								},
							},
							["count"] = 18,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Alluring Perfume"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 18,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1972,
									["min"] = 1621,
									["count"] = 28,
									["amount"] = 50182,
								},
							},
							["count"] = 46,
							["amount"] = 50182,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 2756,
									["min"] = 2506,
									["count"] = 12,
									["amount"] = 31733,
								},
							},
							["count"] = 12,
							["amount"] = 31733,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 93383,
									["min"] = 93383,
									["count"] = 1,
									["amount"] = 93383,
								},
							},
							["count"] = 2,
							["amount"] = 93383,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 22,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1974,
									["min"] = 1598,
									["count"] = 30,
									["amount"] = 53891,
								},
							},
							["count"] = 52,
							["amount"] = 53891,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 2877,
									["min"] = 2411,
									["count"] = 18,
									["amount"] = 48336,
								},
							},
							["count"] = 18,
							["amount"] = 48336,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 5566,
									["min"] = 5566,
									["count"] = 1,
									["amount"] = 5566,
								},
							},
							["count"] = 3,
							["amount"] = 5566,
						},
					},
					["ElementTakenAbsorb"] = {
						["Nature"] = 189708,
						["Fire"] = 93383,
					},
					["ActiveTime"] = 126.8199999999999,
					["TimeDamaging"] = {
						["Corpse Eater"] = {
							["Details"] = {
								["Fan of Knives"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Hemorrhage (DoT)"] = {
									["count"] = 3.75,
								},
								["Ambush"] = {
									["count"] = 0.34,
								},
								["Rupture (DoT)"] = {
									["count"] = 5.8,
								},
								["Deadly Poison"] = {
									["count"] = 2.26,
								},
								["Hemorrhage"] = {
									["count"] = 2.66,
								},
								["Eviscerate"] = {
									["count"] = 0.32,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 6.84,
								},
								["Touch of the Grave"] = {
									["count"] = 1.3,
								},
								["Melee"] = {
									["count"] = 28.49000000000001,
								},
								["Mind-numbing Poison"] = {
									["count"] = 0.38,
								},
							},
							["amount"] = 52.13999999999998,
						},
						["Apothecary Frye"] = {
							["Details"] = {
								["Hemorrhage (DoT)"] = {
									["count"] = 4.019999999999999,
								},
								["Melee"] = {
									["count"] = 19.39,
								},
								["Touch of the Grave"] = {
									["count"] = 1.47,
								},
								["Shiv"] = {
									["count"] = 0.44,
								},
								["Hemorrhage"] = {
									["count"] = 3.76,
								},
								["Eviscerate"] = {
									["count"] = 0.04,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 2.540000000000001,
								},
								["Deadly Poison"] = {
									["count"] = 0.7,
								},
								["Rupture (DoT)"] = {
									["count"] = 5.72,
								},
								["Mind-numbing Poison"] = {
									["count"] = 0.38,
								},
							},
							["amount"] = 38.46000000000002,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Hemorrhage (DoT)"] = {
									["count"] = 2.73,
								},
								["Ambush"] = {
									["count"] = 0.6,
								},
								["Rupture (DoT)"] = {
									["count"] = 4.16,
								},
								["Deadly Poison"] = {
									["count"] = 1.01,
								},
								["Shiv"] = {
									["count"] = 0.77,
								},
								["Hemorrhage"] = {
									["count"] = 2.69,
								},
								["Eviscerate"] = {
									["count"] = 0.14,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 3.560000000000001,
								},
								["Melee"] = {
									["count"] = 15.85,
								},
								["Touch of the Grave"] = {
									["count"] = 0.69,
								},
							},
							["amount"] = 32.2,
						},
					},
					["ElementTaken"] = {
						["Nature"] = 133844,
						["Fire"] = 89345,
					},
					["DOT_Time"] = 369,
					["Damage"] = 3662186,
					["EnergyGain"] = 800,
					["TimeHeal"] = 0.52,
					["WhoHealed"] = {
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Touch of the Grave"] = {
									["count"] = 21109,
								},
							},
							["amount"] = 21109,
						},
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 249442,
								},
							},
							["amount"] = 249442,
						},
					},
					["EnergyGained"] = {
						["Relentless Strikes"] = {
							["Details"] = {
								["Darver-Silvermoon"] = {
									["count"] = 425,
								},
							},
							["amount"] = 425,
						},
						["Slice and Dice"] = {
							["Details"] = {
								["Darver-Silvermoon"] = {
									["count"] = 375,
								},
							},
							["amount"] = 375,
						},
					},
					["Overhealing"] = 106736,
					["Healing"] = 21109,
					["HealedWho"] = {
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Touch of the Grave"] = {
									["count"] = 21109,
								},
							},
							["amount"] = 21109,
						},
					},
					["Heals"] = {
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 15725,
									["min"] = 1776,
									["count"] = 3,
									["amount"] = 21109,
								},
							},
							["count"] = 3,
							["amount"] = 21109,
						},
					},
					["Attacks"] = {
						["Hemorrhage (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 2205,
									["min"] = 591,
									["count"] = 43,
									["amount"] = 44254,
								},
							},
							["count"] = 43,
							["amount"] = 44254,
						},
						["Ambush"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 102870,
									["min"] = 73260,
									["count"] = 4,
									["amount"] = 360715,
								},
								["Hit"] = {
									["max"] = 50139,
									["min"] = 30942,
									["count"] = 3,
									["amount"] = 114757,
								},
							},
							["count"] = 7,
							["amount"] = 475472,
						},
						["Fan of Knives"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5186,
									["min"] = 5186,
									["count"] = 1,
									["amount"] = 5186,
								},
							},
							["count"] = 1,
							["amount"] = 5186,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 17549,
									["min"] = 14400,
									["count"] = 8,
									["amount"] = 121762,
								},
							},
							["count"] = 8,
							["amount"] = 121762,
						},
						["Shiv"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1292,
									["min"] = 1292,
									["count"] = 1,
									["amount"] = 1292,
								},
								["Dodge"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 1292,
						},
						["Hemorrhage"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 17212,
									["min"] = 9139,
									["count"] = 32,
									["amount"] = 423581,
								},
								["Crit"] = {
									["max"] = 35267,
									["min"] = 20335,
									["count"] = 8,
									["amount"] = 215368,
								},
								["Dodge"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 42,
							["amount"] = 638949,
						},
						["Eviscerate"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 113617,
									["min"] = 46586,
									["count"] = 2,
									["amount"] = 160203,
								},
								["Hit"] = {
									["max"] = 50454,
									["min"] = 15917,
									["count"] = 4,
									["amount"] = 138155,
								},
							},
							["count"] = 6,
							["amount"] = 298358,
						},
						["Rupture (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 14342,
									["min"] = 6334,
									["count"] = 15,
									["amount"] = 149992,
								},
								["Tick"] = {
									["max"] = 7171,
									["min"] = 3167,
									["count"] = 26,
									["amount"] = 118386,
								},
							},
							["count"] = 41,
							["amount"] = 268378,
						},
						["Deadly Poison (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 22535,
									["min"] = 16719,
									["count"] = 7,
									["amount"] = 139894,
								},
								["Tick"] = {
									["max"] = 11268,
									["min"] = 7206,
									["count"] = 32,
									["amount"] = 282018,
								},
							},
							["count"] = 39,
							["amount"] = 421912,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 13687,
									["min"] = 2194,
									["count"] = 27,
									["amount"] = 173204,
								},
								["Miss"] = {
									["count"] = 49,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 15339,
									["min"] = 2340,
									["count"] = 52,
									["amount"] = 294983,
								},
								["Hit (Blocked)"] = {
									["max"] = 8311,
									["min"] = 8311,
									["count"] = 1,
									["amount"] = 8311,
								},
								["Dodge"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 26275,
									["min"] = 4652,
									["count"] = 46,
									["amount"] = 581843,
								},
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 177,
							["amount"] = 1058341,
						},
						["Deadly Poison"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 11657,
									["min"] = 7376,
									["count"] = 16,
									["amount"] = 153197,
								},
								["Hit"] = {
									["max"] = 5836,
									["min"] = 3658,
									["count"] = 37,
									["amount"] = 175085,
								},
							},
							["count"] = 53,
							["amount"] = 328282,
						},
						["Mind-numbing Poison"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 270551,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 40,
								},
								["Tick"] = {
									["count"] = 69,
								},
								["Crit"] = {
									["count"] = 30,
								},
								["Dodge"] = {
									["count"] = 3,
								},
							},
							["amount"] = 142,
						},
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 8,
								},
							},
							["amount"] = 8,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 27,
								},
								["Miss"] = {
									["count"] = 49,
								},
								["Hit"] = {
									["count"] = 53,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 46,
								},
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 177,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 32,
								},
								["Hit"] = {
									["count"] = 37,
								},
								["Miss"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 23,
								},
								["Dodge"] = {
									["count"] = 2,
								},
							},
							["amount"] = 95,
						},
					},
					["TimeDamage"] = 126.2999999999999,
					["WhoDamaged"] = {
						["Apothecary Hummel"] = {
							["Details"] = {
								["Alluring Perfume"] = {
									["count"] = 32389,
								},
							},
							["amount"] = 32389,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Irresistible Cologne"] = {
									["count"] = 39425,
								},
								["Irresistible Cologne Spray (DoT)"] = {
									["count"] = 62030,
								},
								["Chain Reaction"] = {
									["count"] = 89345,
								},
							},
							["amount"] = 190800,
						},
					},
					["EnergyGainedFrom"] = {
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Relentless Strikes"] = {
									["count"] = 425,
								},
								["Slice and Dice"] = {
									["count"] = 375,
								},
							},
							["amount"] = 800,
						},
					},
					["TimeSpent"] = {
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Touch of the Grave"] = {
									["count"] = 0.52,
								},
							},
							["amount"] = 0.52,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Hemorrhage (DoT)"] = {
									["count"] = 3.75,
								},
								["Ambush"] = {
									["count"] = 0.34,
								},
								["Rupture (DoT)"] = {
									["count"] = 5.8,
								},
								["Deadly Poison"] = {
									["count"] = 2.26,
								},
								["Hemorrhage"] = {
									["count"] = 2.66,
								},
								["Eviscerate"] = {
									["count"] = 0.32,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 6.84,
								},
								["Touch of the Grave"] = {
									["count"] = 1.3,
								},
								["Melee"] = {
									["count"] = 28.49000000000001,
								},
								["Mind-numbing Poison"] = {
									["count"] = 0.38,
								},
							},
							["amount"] = 52.13999999999998,
						},
						["Apothecary Frye"] = {
							["Details"] = {
								["Hemorrhage (DoT)"] = {
									["count"] = 4.019999999999999,
								},
								["Melee"] = {
									["count"] = 19.39,
								},
								["Touch of the Grave"] = {
									["count"] = 1.47,
								},
								["Shiv"] = {
									["count"] = 0.44,
								},
								["Hemorrhage"] = {
									["count"] = 3.76,
								},
								["Eviscerate"] = {
									["count"] = 0.04,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 2.540000000000001,
								},
								["Deadly Poison"] = {
									["count"] = 0.7,
								},
								["Rupture (DoT)"] = {
									["count"] = 5.72,
								},
								["Mind-numbing Poison"] = {
									["count"] = 0.38,
								},
							},
							["amount"] = 38.46000000000002,
						},
						["Corpse Eater"] = {
							["Details"] = {
								["Fan of Knives"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Hemorrhage (DoT)"] = {
									["count"] = 2.73,
								},
								["Ambush"] = {
									["count"] = 0.6,
								},
								["Rupture (DoT)"] = {
									["count"] = 4.16,
								},
								["Deadly Poison"] = {
									["count"] = 1.01,
								},
								["Shiv"] = {
									["count"] = 0.77,
								},
								["Hemorrhage"] = {
									["count"] = 2.69,
								},
								["Eviscerate"] = {
									["count"] = 0.14,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 3.560000000000001,
								},
								["Melee"] = {
									["count"] = 15.85,
								},
								["Touch of the Grave"] = {
									["count"] = 0.69,
								},
							},
							["amount"] = 32.2,
						},
					},
					["DOTs"] = {
						["Deadly Poison (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 30,
								},
								["Apothecary Hummel"] = {
									["count"] = 54,
								},
								["Apothecary Baxter"] = {
									["count"] = 33,
								},
							},
							["amount"] = 117,
						},
						["Rupture (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 24,
								},
								["Apothecary Hummel"] = {
									["count"] = 57,
								},
								["Apothecary Baxter"] = {
									["count"] = 42,
								},
							},
							["amount"] = 123,
						},
						["Hemorrhage (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 33,
								},
								["Apothecary Hummel"] = {
									["count"] = 63,
								},
								["Apothecary Baxter"] = {
									["count"] = 33,
								},
							},
							["amount"] = 129,
						},
					},
				},
			},
			["NextEventNum"] = 14,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				100, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				100, -- [11]
				100, -- [12]
				100, -- [13]
				99.39618191798645, -- [14]
				99.71014408569047, -- [15]
				99.71014408569047, -- [16]
				98.94803795427944, -- [17]
				98.94803795427944, -- [18]
				98.94803795427944, -- [19]
				99.26200012198345, -- [20]
				99.26200012198345, -- [21]
				99.26200012198345, -- [22]
				98.50105573772396, -- [23]
				98.81472746864009, -- [24]
				98.81472746864009, -- [25]
				100, -- [26]
				100, -- [27]
				100, -- [28]
				100, -- [29]
				100, -- [30]
				100, -- [31]
				100, -- [32]
				100, -- [33]
				100, -- [34]
				100, -- [35]
				100, -- [36]
				100, -- [37]
				100, -- [38]
				100, -- [39]
				100, -- [40]
				100, -- [41]
				100, -- [42]
				100, -- [43]
				100, -- [44]
				100, -- [45]
				100, -- [46]
				100, -- [47]
				100, -- [48]
				100, -- [49]
				100, -- [50]
			},
			["LastEvents"] = {
				"Darver-Silvermoon Melee Apothecary Frye Crit -5882 (Physical)", -- [1]
				"Darver-Silvermoon Deadly Poison Apothecary Frye Crit -9987 (Nature)", -- [2]
				"Darver-Silvermoon Deadly Poison (DoT) Apothecary Frye Crit -19426 (Nature)", -- [3]
				"Darver-Silvermoon Hemorrhage (DoT) Apothecary Frye Tick -846 (Physical)", -- [4]
				"Darver-Silvermoon Rupture (DoT) Apothecary Frye Tick -4084 (Physical)", -- [5]
				"Darver-Silvermoon Deadly Poison (DoT) Apothecary Frye Crit -22535 (Nature)", -- [6]
				"Darver-Silvermoon Melee Apothecary Frye Miss", -- [7]
				"Darver-Silvermoon Melee Apothecary Frye Hit -3699 (Physical)", -- [8]
				"Darver-Silvermoon Hemorrhage Apothecary Frye Hit -13565 (Physical)", -- [9]
				"Darver-Silvermoon Hemorrhage (DoT) Apothecary Frye Tick -846 (Physical)", -- [10]
				"Darver-Silvermoon Touch of the Grave Apothecary Frye Hit -14884 (Shadow)", -- [11]
				"Darver-Silvermoon Rupture (DoT) Apothecary Frye Crit -9476 (Physical)", -- [12]
				"Darver-Silvermoon Touch of the Grave Darver-Silvermoon Hit +15628 (15628 overheal)", -- [13]
				"Darver-Silvermoon Deadly Poison (DoT) Apothecary Frye Tick -11267 (Nature)", -- [14]
				"Kardinalsinn-Barthilas Atonement Darver-Silvermoon Hit +1081", -- [15]
				"Darver-Silvermoon Hemorrhage Apothecary Frye Dodge (Physical)", -- [16]
				"No One Concentrated Irresistible Cologne Spill Darver-Silvermoon Hit -2624 (Nature)", -- [17]
				"Darver-Silvermoon Hemorrhage (DoT) Apothecary Frye Tick -968 (Physical)", -- [18]
				"Darver-Silvermoon Melee Apothecary Frye Miss", -- [19]
				"Kardinalsinn-Barthilas Atonement Darver-Silvermoon Hit +1081", -- [20]
				"Darver-Silvermoon Rupture (DoT) Apothecary Frye Tick -3168 (Physical)", -- [21]
				"Darver-Silvermoon Melee Apothecary Frye Miss", -- [22]
				"No One Concentrated Irresistible Cologne Spill Darver-Silvermoon Hit -2620 (Nature)", -- [23]
				"Kardinalsinn-Barthilas Atonement Darver-Silvermoon Hit +1080", -- [24]
				"Darver-Silvermoon Hemorrhage Apothecary Frye Hit -14773 (Physical)", -- [25]
				"Kardinalsinn-Barthilas Atonement Darver-Silvermoon Hit +33156 (29075 overheal)", -- [26]
				"Kardinalsinn-Barthilas Atonement Darver-Silvermoon Hit +38510 (38510 overheal)", -- [27]
				"Darver-Silvermoon Melee Apothecary Frye Miss", -- [28]
				"Darver-Silvermoon Deadly Poison (DoT) Apothecary Frye Tick -11267 (Nature)", -- [29]
				"Darver-Silvermoon Rupture (DoT) Apothecary Frye Crit -6335 (Physical)", -- [30]
				"Darver-Silvermoon Melee Apothecary Frye Hit -8311 (Physical)", -- [31]
				"Darver-Silvermoon Hemorrhage (DoT) Apothecary Frye Tick -923 (Physical)", -- [32]
				"Darver-Silvermoon Deadly Poison Apothecary Frye Hit -5764 (Nature)", -- [33]
				"Darver-Silvermoon Melee Apothecary Frye Miss", -- [34]
				"Darver-Silvermoon Melee Apothecary Frye Crit -6229 (Physical)", -- [35]
				"Darver-Silvermoon Hemorrhage Apothecary Frye Hit -15296 (Physical)", -- [36]
				"Darver-Silvermoon Deadly Poison Apothecary Frye Hit -5779 (Nature)", -- [37]
				"Darver-Silvermoon Deadly Poison Apothecary Frye Crit -11489 (Nature)", -- [38]
				"Darver-Silvermoon Melee Apothecary Frye Glancing -9891 (Physical)", -- [39]
				"Darver-Silvermoon Rupture (DoT) Apothecary Frye Tick -3167 (Physical)", -- [40]
				"Darver-Silvermoon Melee Apothecary Frye Hit -3350 (Physical)", -- [41]
				"Darver-Silvermoon Deadly Poison (DoT) Apothecary Frye Crit -19426 (Nature)", -- [42]
				"Darver-Silvermoon Hemorrhage Apothecary Frye Hit -12545 (Physical)", -- [43]
				"Darver-Silvermoon Deadly Poison Apothecary Frye Hit -4990 (Nature)", -- [44]
				"Darver-Silvermoon Hemorrhage (DoT) Apothecary Frye Tick -784 (Physical)", -- [45]
				"Darver-Silvermoon Melee Apothecary Frye Crit -16546 (Physical)", -- [46]
				"Darver-Silvermoon Melee Apothecary Frye Glancing -2668 (Physical)", -- [47]
				"Darver-Silvermoon Hemorrhage Apothecary Frye Hit -13542 (Physical)", -- [48]
				"Darver-Silvermoon Melee Apothecary Frye Crit -16992 (Physical)", -- [49]
				"Darver-Silvermoon Deadly Poison Apothecary Frye Crit -9860 (Nature)", -- [50]
			},
			["Name"] = "Darver-Silvermoon",
			["TimeLast"] = {
				["TimeHeal"] = 1360560641,
				["OVERALL"] = 1360560712,
				["DamageTaken"] = 1360560668,
				["EnergyGain"] = 1360560712,
				["HealingTaken"] = 1360560695,
				["Overhealing"] = 1360560707,
				["TimeDamage"] = 1360560707,
				["ActiveTime"] = 1360560707,
				["Healing"] = 1360560641,
				["DOT_Time"] = 1360560707,
				["Damage"] = 1360560707,
			},
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				true, -- [13]
				false, -- [14]
				true, -- [15]
				false, -- [16]
				true, -- [17]
				false, -- [18]
				false, -- [19]
				true, -- [20]
				false, -- [21]
				false, -- [22]
				true, -- [23]
				true, -- [24]
				false, -- [25]
				true, -- [26]
				true, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["LastDamageTaken"] = 1700,
			["LastEventTimes"] = {
				20885.642, -- [1]
				20885.665, -- [2]
				20885.71, -- [3]
				20886.306, -- [4]
				20888.486, -- [5]
				20888.71, -- [6]
				20889.146, -- [7]
				20889.17, -- [8]
				20889.304, -- [9]
				20889.304, -- [10]
				20890.1, -- [11]
				20890.486, -- [12]
				20890.512, -- [13]
				20876.706, -- [14]
				20876.827, -- [15]
				20877.047, -- [16]
				20877.217, -- [17]
				20877.309, -- [18]
				20877.577, -- [19]
				20877.638, -- [20]
				20877.986, -- [21]
				20878.008, -- [22]
				20878.035, -- [23]
				20878.438, -- [24]
				20878.438, -- [25]
				20878.847, -- [26]
				20878.847, -- [27]
				20879.182, -- [28]
				20879.716, -- [29]
				20879.983, -- [30]
				20880.291, -- [31]
				20880.321, -- [32]
				20880.437, -- [33]
				20880.577, -- [34]
				20881.604, -- [35]
				20881.651, -- [36]
				20881.651, -- [37]
				20881.651, -- [38]
				20881.747, -- [39]
				20881.972, -- [40]
				20882.613, -- [41]
				20882.711, -- [42]
				20882.883, -- [43]
				20882.883, -- [44]
				20883.327, -- [45]
				20883.726, -- [46]
				20884.636, -- [47]
				20884.859, -- [48]
				20885.18, -- [49]
				20885.274, -- [50]
			},
			["LastAbility"] = 102142.251,
		},
		["Venomous Snake <Gato>"] = {
			["GUID"] = "0xF1304D790001B140",
			["LastEventHealth"] = {
				"???", -- [1]
				"???", -- [2]
				"???", -- [3]
				"???", -- [4]
				"???", -- [5]
				"???", -- [6]
				"???", -- [7]
				"???", -- [8]
				"???", -- [9]
				"???", -- [10]
				"???", -- [11]
				"???", -- [12]
				"???", -- [13]
				"???", -- [14]
				"???", -- [15]
				"???", -- [16]
				"???", -- [17]
				"???", -- [18]
				"???", -- [19]
				"???", -- [20]
				"???", -- [21]
				"???", -- [22]
				"???", -- [23]
				"???", -- [24]
				"???", -- [25]
				"???", -- [26]
				"???", -- [27]
				"???", -- [28]
				"???", -- [29]
				"???", -- [30]
				"???", -- [31]
				"???", -- [32]
				"???", -- [33]
				"???", -- [34]
				"???", -- [35]
				"???", -- [36]
				"???", -- [37]
				"???", -- [38]
				"???", -- [39]
				"???", -- [40]
				"???", -- [41]
				"???", -- [42]
				"???", -- [43]
				"???", -- [44]
				"???", -- [45]
				"???", -- [46]
				"???", -- [47]
				"???", -- [48]
				"???", -- [49]
				"???", -- [50]
			},
			["LastEventType"] = {
				"MISC", -- [1]
				"MISC", -- [2]
				"MISC", -- [3]
				"MISC", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"MISC", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"MISC", -- [37]
				"MISC", -- [38]
				"MISC", -- [39]
				"MISC", -- [40]
				"MISC", -- [41]
				"DAMAGE", -- [42]
				"MISC", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"MISC", -- [50]
			},
			["TimeWindows"] = {
				["DeathCount"] = {
					24, -- [1]
				},
				["ActiveTime"] = {
					63.91000000000001, -- [1]
				},
				["TimeDamage"] = {
					63.91000000000001, -- [1]
				},
				["DOT_Time"] = {
					66, -- [1]
				},
				["Damage"] = {
					11568, -- [1]
				},
			},
			["enClass"] = "PET",
			["level"] = 1,
			["LastFightIn"] = 1,
			["type"] = "Pet",
			["FightsSaved"] = 5,
			["LastActive"] = 1360560690,
			["UnitLockout"] = 1360560690,
			["Owner"] = "Gato",
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["ElementDoneBlock"] = {
						["Melee"] = 0,
					},
					["DOTs"] = {
						["Deadly Poison (DoT)"] = {
							["Details"] = {
								["Apothecary Hummel"] = {
									["count"] = 0,
								},
								["Apothecary Baxter"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Deadly Poison (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Deadly Poison"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["ElementDone"] = {
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["DeathCount"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Deadly Poison (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Deadly Poison"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["Deadly Poison (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit (Blocked)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Deadly Poison"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
				},
				["OverallData"] = {
					["ElementDoneBlock"] = {
						["Melee"] = 20,
					},
					["DOTs"] = {
						["Deadly Poison (DoT)"] = {
							["Details"] = {
								["Apothecary Hummel"] = {
									["count"] = 51,
								},
								["Apothecary Baxter"] = {
									["count"] = 15,
								},
							},
							["amount"] = 66,
						},
					},
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 7.329999999999999,
								},
							},
							["amount"] = 7.329999999999999,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Deadly Poison (DoT)"] = {
									["count"] = 20.68,
								},
								["Melee"] = {
									["count"] = 21.12,
								},
								["Deadly Poison"] = {
									["count"] = 0.49,
								},
							},
							["amount"] = 42.29,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.209999999999999,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 9.08,
								},
							},
							["amount"] = 14.29,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 748,
								},
							},
							["amount"] = 748,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4828,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 3933,
								},
							},
							["amount"] = 8761,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 747,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 1312,
								},
							},
							["amount"] = 2059,
						},
					},
					["TimeDamage"] = 63.91000000000001,
					["ElementDone"] = {
						["Melee"] = 6323,
						["Nature"] = 5245,
					},
					["DeathCount"] = 24,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 19,
								},
								["Hit"] = {
									["count"] = 63,
								},
								["Miss"] = {
									["count"] = 3,
								},
								["Dodge"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 10,
								},
								["Parry"] = {
									["count"] = 3,
								},
							},
							["amount"] = 100,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 20,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 23,
						},
					},
					["ActiveTime"] = 63.91000000000001,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 7.329999999999999,
								},
							},
							["amount"] = 7.329999999999999,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Deadly Poison (DoT)"] = {
									["count"] = 20.68,
								},
								["Melee"] = {
									["count"] = 21.12,
								},
								["Deadly Poison"] = {
									["count"] = 0.49,
								},
							},
							["amount"] = 42.29,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.209999999999999,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 9.08,
								},
							},
							["amount"] = 14.29,
						},
					},
					["Attacks"] = {
						["Deadly Poison (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 437,
									["min"] = 437,
									["count"] = 2,
									["amount"] = 874,
								},
								["Tick"] = {
									["max"] = 219,
									["min"] = 218,
									["count"] = 20,
									["amount"] = 4371,
								},
							},
							["count"] = 22,
							["amount"] = 5245,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 61,
									["min"] = 49,
									["count"] = 19,
									["amount"] = 1041,
								},
								["Hit"] = {
									["max"] = 69,
									["min"] = 59,
									["count"] = 62,
									["amount"] = 3976,
								},
								["Miss"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Hit (Blocked)"] = {
									["max"] = 46,
									["min"] = 46,
									["count"] = 1,
									["amount"] = 46,
								},
								["Dodge"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 135,
									["min"] = 119,
									["count"] = 10,
									["amount"] = 1260,
								},
								["Parry"] = {
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 100,
							["amount"] = 6323,
						},
						["Deadly Poison"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DOT_Time"] = 66,
					["Damage"] = 11568,
				},
			},
			["NextEventNum"] = 42,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
				0, -- [5]
				0, -- [6]
				0, -- [7]
				0, -- [8]
				0, -- [9]
				0, -- [10]
				0, -- [11]
				0, -- [12]
				0, -- [13]
				0, -- [14]
				0, -- [15]
				0, -- [16]
				0, -- [17]
				0, -- [18]
				0, -- [19]
				0, -- [20]
				0, -- [21]
				0, -- [22]
				0, -- [23]
				0, -- [24]
				0, -- [25]
				0, -- [26]
				0, -- [27]
				0, -- [28]
				0, -- [29]
				0, -- [30]
				0, -- [31]
				0, -- [32]
				0, -- [33]
				0, -- [34]
				0, -- [35]
				0, -- [36]
				0, -- [37]
				0, -- [38]
				0, -- [39]
				0, -- [40]
				0, -- [41]
				0, -- [42]
				0, -- [43]
				0, -- [44]
				0, -- [45]
				0, -- [46]
				0, -- [47]
				0, -- [48]
				0, -- [49]
				0, -- [50]
			},
			["LastEvents"] = {
				"Venomous Snake <Gato> dies.", -- [1]
				"Venomous Snake <Gato> dies.", -- [2]
				"Venomous Snake <Gato> dies.", -- [3]
				"Venomous Snake <Gato> dies.", -- [4]
				"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Baxter Tick -218 (Nature)", -- [5]
				"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Baxter Tick -219 (Nature)", -- [6]
				"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Baxter Tick -219 (Nature)", -- [7]
				"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Baxter Tick -219 (Nature)", -- [8]
				"Venomous Snake <Gato> Melee Apothecary Frye Glancing -53 (Physical)", -- [9]
				"Venomous Snake <Gato> Melee Apothecary Frye Crit -121 (Physical)", -- [10]
				"Venomous Snake <Gato> Melee Apothecary Frye Glancing -58 (Physical)", -- [11]
				"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [12]
				"Venomous Snake <Gato> Melee Apothecary Frye Miss", -- [13]
				"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [14]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2376 (Nature)", -- [15]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2544 (Nature)", -- [16]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2594 (Nature)", -- [17]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4894 (Nature)", -- [18]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2599 (Nature)", -- [19]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2412 (Nature)", -- [20]
				"Venomous Snake <Gato> Melee Apothecary Frye Hit -61 (Physical)", -- [21]
				"Venomous Snake <Gato> Melee Apothecary Frye Hit -64 (Physical)", -- [22]
				"Venomous Snake <Gato> Melee Apothecary Frye Hit -46 (Physical)", -- [23]
				"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [24]
				"Venomous Snake <Gato> dies.", -- [25]
				"Venomous Snake <Gato> Melee Apothecary Frye Hit -61 (Physical)", -- [26]
				"Venomous Snake <Gato> Melee Apothecary Frye Crit -123 (Physical)", -- [27]
				"Venomous Snake <Gato> Melee Apothecary Frye Dodge", -- [28]
				"Venomous Snake <Gato> Melee Apothecary Frye Glancing -58 (Physical)", -- [29]
				"Venomous Snake <Gato> Melee Apothecary Frye Glancing -49 (Physical)", -- [30]
				"Venomous Snake <Gato> Melee Apothecary Frye Glancing -54 (Physical)", -- [31]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2543 (Nature)", -- [32]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2466 (Nature)", -- [33]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4946 (Nature)", -- [34]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4948 (Nature)", -- [35]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2465 (Nature)", -- [36]
				"Venomous Snake <Gato> dies.", -- [37]
				"Venomous Snake <Gato> dies.", -- [38]
				"Venomous Snake <Gato> dies.", -- [39]
				"Venomous Snake <Gato> dies.", -- [40]
				"Venomous Snake <Gato> dies.", -- [41]
				"Venomous Snake <Gato> Melee Apothecary Baxter Hit -69 (Physical)", -- [42]
				"Venomous Snake <Gato> dies.", -- [43]
				"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Baxter Crit -437 (Nature)", -- [44]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2617 (Nature)", -- [45]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2565 (Nature)", -- [46]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2410 (Nature)", -- [47]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2500 (Nature)", -- [48]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2430 (Nature)", -- [49]
				"Venomous Snake <Gato> dies.", -- [50]
			},
			["Name"] = "Venomous Snake",
			["TimeLast"] = {
				["DeathCount"] = 1360560690,
				["ActiveTime"] = 1360560690,
				["TimeDamage"] = 1360560690,
				["OVERALL"] = 1360560690,
				["DOT_Time"] = 1360560667,
				["Damage"] = 1360560690,
			},
			["LastEventIncoming"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
				true, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				true, -- [15]
				true, -- [16]
				true, -- [17]
				true, -- [18]
				true, -- [19]
				true, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				true, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				true, -- [32]
				true, -- [33]
				true, -- [34]
				true, -- [35]
				true, -- [36]
				true, -- [37]
				true, -- [38]
				true, -- [39]
				true, -- [40]
				true, -- [41]
				false, -- [42]
				true, -- [43]
				false, -- [44]
				true, -- [45]
				true, -- [46]
				true, -- [47]
				true, -- [48]
				true, -- [49]
				true, -- [50]
			},
			["DeathLogs"] = {
				{
					["MessageTimes"] = {
						-4.327999999997701, -- [1]
						-4.327999999997701, -- [2]
						-4.327999999997701, -- [3]
						-4.327999999997701, -- [4]
						-4.327999999997701, -- [5]
						-4.327999999997701, -- [6]
						-2.414999999997235, -- [7]
						-2.414999999997235, -- [8]
						-2.414999999997235, -- [9]
						-2.414999999997235, -- [10]
						-2.414999999997235, -- [11]
						-2.414999999997235, -- [12]
						-2.385999999998603, -- [13]
						-2.310999999997875, -- [14]
						-2.248999999999796, -- [15]
						-2.151999999998225, -- [16]
						-2.024999999997817, -- [17]
						-1.920999999998458, -- [18]
						-0.9709999999977299, -- [19]
						-0.7699999999967986, -- [20]
						-0.66899999999805, -- [21]
						-0.5370000000002619, -- [22]
						-0.4939999999987776, -- [23]
						-0.3789999999971769, -- [24]
						-0.3789999999971769, -- [25]
						-0.3789999999971769, -- [26]
						-0.3789999999971769, -- [27]
						-0.3789999999971769, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						true, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						false, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
						true, -- [31]
						true, -- [32]
						true, -- [33]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -53 (Physical)", -- [1]
						"Venomous Snake <Gato> Melee Apothecary Frye Crit -121 (Physical)", -- [2]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -58 (Physical)", -- [3]
						"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Frye Miss", -- [5]
						"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [6]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2376 (Nature)", -- [7]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2544 (Nature)", -- [8]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2594 (Nature)", -- [9]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4894 (Nature)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2599 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2412 (Nature)", -- [12]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -61 (Physical)", -- [13]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -64 (Physical)", -- [14]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -46 (Physical)", -- [15]
						"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [16]
						"Venomous Snake <Gato> dies.", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -61 (Physical)", -- [18]
						"Venomous Snake <Gato> Melee Apothecary Frye Crit -123 (Physical)", -- [19]
						"Venomous Snake <Gato> Melee Apothecary Frye Dodge", -- [20]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -58 (Physical)", -- [21]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -49 (Physical)", -- [22]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -54 (Physical)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2543 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2466 (Nature)", -- [25]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4946 (Nature)", -- [26]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4948 (Nature)", -- [27]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2465 (Nature)", -- [28]
						"Venomous Snake <Gato> dies.", -- [29]
						"Venomous Snake <Gato> dies.", -- [30]
						"Venomous Snake <Gato> dies.", -- [31]
						"Venomous Snake <Gato> dies.", -- [32]
						"Venomous Snake <Gato> dies.", -- [33]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
					},
					["DeathAt"] = 1360560692,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"MISC", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
						"MISC", -- [31]
						"MISC", -- [32]
						"MISC", -- [33]
					},
				}, -- [1]
				{
					["MessageTimes"] = {
						-4.327999999997701, -- [1]
						-4.327999999997701, -- [2]
						-4.327999999997701, -- [3]
						-4.327999999997701, -- [4]
						-4.327999999997701, -- [5]
						-4.327999999997701, -- [6]
						-2.414999999997235, -- [7]
						-2.414999999997235, -- [8]
						-2.414999999997235, -- [9]
						-2.414999999997235, -- [10]
						-2.414999999997235, -- [11]
						-2.414999999997235, -- [12]
						-2.385999999998603, -- [13]
						-2.310999999997875, -- [14]
						-2.248999999999796, -- [15]
						-2.151999999998225, -- [16]
						-2.024999999997817, -- [17]
						-1.920999999998458, -- [18]
						-0.9709999999977299, -- [19]
						-0.7699999999967986, -- [20]
						-0.66899999999805, -- [21]
						-0.5370000000002619, -- [22]
						-0.4939999999987776, -- [23]
						-0.3789999999971769, -- [24]
						-0.3789999999971769, -- [25]
						-0.3789999999971769, -- [26]
						-0.3789999999971769, -- [27]
						-0.3789999999971769, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						true, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						false, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
						true, -- [31]
						true, -- [32]
						true, -- [33]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -53 (Physical)", -- [1]
						"Venomous Snake <Gato> Melee Apothecary Frye Crit -121 (Physical)", -- [2]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -58 (Physical)", -- [3]
						"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Frye Miss", -- [5]
						"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [6]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2376 (Nature)", -- [7]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2544 (Nature)", -- [8]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2594 (Nature)", -- [9]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4894 (Nature)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2599 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2412 (Nature)", -- [12]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -61 (Physical)", -- [13]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -64 (Physical)", -- [14]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -46 (Physical)", -- [15]
						"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [16]
						"Venomous Snake <Gato> dies.", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -61 (Physical)", -- [18]
						"Venomous Snake <Gato> Melee Apothecary Frye Crit -123 (Physical)", -- [19]
						"Venomous Snake <Gato> Melee Apothecary Frye Dodge", -- [20]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -58 (Physical)", -- [21]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -49 (Physical)", -- [22]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -54 (Physical)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2543 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2466 (Nature)", -- [25]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4946 (Nature)", -- [26]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4948 (Nature)", -- [27]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2465 (Nature)", -- [28]
						"Venomous Snake <Gato> dies.", -- [29]
						"Venomous Snake <Gato> dies.", -- [30]
						"Venomous Snake <Gato> dies.", -- [31]
						"Venomous Snake <Gato> dies.", -- [32]
						"Venomous Snake <Gato> dies.", -- [33]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
					},
					["DeathAt"] = 1360560692,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"MISC", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
						"MISC", -- [31]
						"MISC", -- [32]
						"MISC", -- [33]
					},
				}, -- [2]
				{
					["MessageTimes"] = {
						-4.327999999997701, -- [1]
						-4.327999999997701, -- [2]
						-4.327999999997701, -- [3]
						-4.327999999997701, -- [4]
						-4.327999999997701, -- [5]
						-4.327999999997701, -- [6]
						-2.414999999997235, -- [7]
						-2.414999999997235, -- [8]
						-2.414999999997235, -- [9]
						-2.414999999997235, -- [10]
						-2.414999999997235, -- [11]
						-2.414999999997235, -- [12]
						-2.385999999998603, -- [13]
						-2.310999999997875, -- [14]
						-2.248999999999796, -- [15]
						-2.151999999998225, -- [16]
						-2.024999999997817, -- [17]
						-1.920999999998458, -- [18]
						-0.9709999999977299, -- [19]
						-0.7699999999967986, -- [20]
						-0.66899999999805, -- [21]
						-0.5370000000002619, -- [22]
						-0.4939999999987776, -- [23]
						-0.3789999999971769, -- [24]
						-0.3789999999971769, -- [25]
						-0.3789999999971769, -- [26]
						-0.3789999999971769, -- [27]
						-0.3789999999971769, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						true, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						false, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
						true, -- [31]
						true, -- [32]
						true, -- [33]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -53 (Physical)", -- [1]
						"Venomous Snake <Gato> Melee Apothecary Frye Crit -121 (Physical)", -- [2]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -58 (Physical)", -- [3]
						"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Frye Miss", -- [5]
						"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [6]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2376 (Nature)", -- [7]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2544 (Nature)", -- [8]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2594 (Nature)", -- [9]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4894 (Nature)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2599 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2412 (Nature)", -- [12]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -61 (Physical)", -- [13]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -64 (Physical)", -- [14]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -46 (Physical)", -- [15]
						"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [16]
						"Venomous Snake <Gato> dies.", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -61 (Physical)", -- [18]
						"Venomous Snake <Gato> Melee Apothecary Frye Crit -123 (Physical)", -- [19]
						"Venomous Snake <Gato> Melee Apothecary Frye Dodge", -- [20]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -58 (Physical)", -- [21]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -49 (Physical)", -- [22]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -54 (Physical)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2543 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2466 (Nature)", -- [25]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4946 (Nature)", -- [26]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4948 (Nature)", -- [27]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2465 (Nature)", -- [28]
						"Venomous Snake <Gato> dies.", -- [29]
						"Venomous Snake <Gato> dies.", -- [30]
						"Venomous Snake <Gato> dies.", -- [31]
						"Venomous Snake <Gato> dies.", -- [32]
						"Venomous Snake <Gato> dies.", -- [33]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
					},
					["DeathAt"] = 1360560692,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"MISC", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
						"MISC", -- [31]
						"MISC", -- [32]
						"MISC", -- [33]
					},
				}, -- [3]
				{
					["MessageTimes"] = {
						-4.327999999997701, -- [1]
						-4.327999999997701, -- [2]
						-4.327999999997701, -- [3]
						-4.327999999997701, -- [4]
						-4.327999999997701, -- [5]
						-4.327999999997701, -- [6]
						-2.414999999997235, -- [7]
						-2.414999999997235, -- [8]
						-2.414999999997235, -- [9]
						-2.414999999997235, -- [10]
						-2.414999999997235, -- [11]
						-2.414999999997235, -- [12]
						-2.385999999998603, -- [13]
						-2.310999999997875, -- [14]
						-2.248999999999796, -- [15]
						-2.151999999998225, -- [16]
						-2.024999999997817, -- [17]
						-1.920999999998458, -- [18]
						-0.9709999999977299, -- [19]
						-0.7699999999967986, -- [20]
						-0.66899999999805, -- [21]
						-0.5370000000002619, -- [22]
						-0.4939999999987776, -- [23]
						-0.3789999999971769, -- [24]
						-0.3789999999971769, -- [25]
						-0.3789999999971769, -- [26]
						-0.3789999999971769, -- [27]
						-0.3789999999971769, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						true, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						false, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
						true, -- [31]
						true, -- [32]
						true, -- [33]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -53 (Physical)", -- [1]
						"Venomous Snake <Gato> Melee Apothecary Frye Crit -121 (Physical)", -- [2]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -58 (Physical)", -- [3]
						"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Frye Miss", -- [5]
						"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [6]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2376 (Nature)", -- [7]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2544 (Nature)", -- [8]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2594 (Nature)", -- [9]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4894 (Nature)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2599 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2412 (Nature)", -- [12]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -61 (Physical)", -- [13]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -64 (Physical)", -- [14]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -46 (Physical)", -- [15]
						"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [16]
						"Venomous Snake <Gato> dies.", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -61 (Physical)", -- [18]
						"Venomous Snake <Gato> Melee Apothecary Frye Crit -123 (Physical)", -- [19]
						"Venomous Snake <Gato> Melee Apothecary Frye Dodge", -- [20]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -58 (Physical)", -- [21]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -49 (Physical)", -- [22]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -54 (Physical)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2543 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2466 (Nature)", -- [25]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4946 (Nature)", -- [26]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4948 (Nature)", -- [27]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2465 (Nature)", -- [28]
						"Venomous Snake <Gato> dies.", -- [29]
						"Venomous Snake <Gato> dies.", -- [30]
						"Venomous Snake <Gato> dies.", -- [31]
						"Venomous Snake <Gato> dies.", -- [32]
						"Venomous Snake <Gato> dies.", -- [33]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
					},
					["DeathAt"] = 1360560692,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"MISC", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
						"MISC", -- [31]
						"MISC", -- [32]
						"MISC", -- [33]
					},
				}, -- [4]
				{
					["MessageTimes"] = {
						-4.327999999997701, -- [1]
						-4.327999999997701, -- [2]
						-4.327999999997701, -- [3]
						-4.327999999997701, -- [4]
						-4.327999999997701, -- [5]
						-4.327999999997701, -- [6]
						-2.414999999997235, -- [7]
						-2.414999999997235, -- [8]
						-2.414999999997235, -- [9]
						-2.414999999997235, -- [10]
						-2.414999999997235, -- [11]
						-2.414999999997235, -- [12]
						-2.385999999998603, -- [13]
						-2.310999999997875, -- [14]
						-2.248999999999796, -- [15]
						-2.151999999998225, -- [16]
						-2.024999999997817, -- [17]
						-1.920999999998458, -- [18]
						-0.9709999999977299, -- [19]
						-0.7699999999967986, -- [20]
						-0.66899999999805, -- [21]
						-0.5370000000002619, -- [22]
						-0.4939999999987776, -- [23]
						-0.3789999999971769, -- [24]
						-0.3789999999971769, -- [25]
						-0.3789999999971769, -- [26]
						-0.3789999999971769, -- [27]
						-0.3789999999971769, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						true, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						false, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
						true, -- [31]
						true, -- [32]
						true, -- [33]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -53 (Physical)", -- [1]
						"Venomous Snake <Gato> Melee Apothecary Frye Crit -121 (Physical)", -- [2]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -58 (Physical)", -- [3]
						"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Frye Miss", -- [5]
						"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [6]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2376 (Nature)", -- [7]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2544 (Nature)", -- [8]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2594 (Nature)", -- [9]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4894 (Nature)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2599 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2412 (Nature)", -- [12]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -61 (Physical)", -- [13]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -64 (Physical)", -- [14]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -46 (Physical)", -- [15]
						"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [16]
						"Venomous Snake <Gato> dies.", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -61 (Physical)", -- [18]
						"Venomous Snake <Gato> Melee Apothecary Frye Crit -123 (Physical)", -- [19]
						"Venomous Snake <Gato> Melee Apothecary Frye Dodge", -- [20]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -58 (Physical)", -- [21]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -49 (Physical)", -- [22]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -54 (Physical)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2543 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2466 (Nature)", -- [25]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4946 (Nature)", -- [26]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4948 (Nature)", -- [27]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2465 (Nature)", -- [28]
						"Venomous Snake <Gato> dies.", -- [29]
						"Venomous Snake <Gato> dies.", -- [30]
						"Venomous Snake <Gato> dies.", -- [31]
						"Venomous Snake <Gato> dies.", -- [32]
						"Venomous Snake <Gato> dies.", -- [33]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
					},
					["DeathAt"] = 1360560692,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"MISC", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
						"MISC", -- [31]
						"MISC", -- [32]
						"MISC", -- [33]
					},
				}, -- [5]
				{
					["MessageTimes"] = {
						-2.302999999999884, -- [1]
						-2.302999999999884, -- [2]
						-2.302999999999884, -- [3]
						-2.302999999999884, -- [4]
						-2.302999999999884, -- [5]
						-2.302999999999884, -- [6]
						-0.3899999999994179, -- [7]
						-0.3899999999994179, -- [8]
						-0.3899999999994179, -- [9]
						-0.3899999999994179, -- [10]
						-0.3899999999994179, -- [11]
						-0.3899999999994179, -- [12]
						-0.3610000000007858, -- [13]
						-0.2860000000000582, -- [14]
						-0.2240000000019791, -- [15]
						-0.1270000000004075, -- [16]
						0, -- [17]
						0.1039999999993597, -- [18]
						1.054000000000087, -- [19]
						1.255000000001019, -- [20]
						1.355999999999767, -- [21]
						1.487999999997555, -- [22]
						1.53099999999904, -- [23]
						1.64600000000064, -- [24]
						1.64600000000064, -- [25]
						1.64600000000064, -- [26]
						1.64600000000064, -- [27]
						1.64600000000064, -- [28]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						true, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						false, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -53 (Physical)", -- [1]
						"Venomous Snake <Gato> Melee Apothecary Frye Crit -121 (Physical)", -- [2]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -58 (Physical)", -- [3]
						"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Frye Miss", -- [5]
						"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [6]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2376 (Nature)", -- [7]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2544 (Nature)", -- [8]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2594 (Nature)", -- [9]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4894 (Nature)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2599 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2412 (Nature)", -- [12]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -61 (Physical)", -- [13]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -64 (Physical)", -- [14]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -46 (Physical)", -- [15]
						"Venomous Snake <Gato> Melee Apothecary Frye Parry", -- [16]
						"Venomous Snake <Gato> dies.", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Frye Hit -61 (Physical)", -- [18]
						"Venomous Snake <Gato> Melee Apothecary Frye Crit -123 (Physical)", -- [19]
						"Venomous Snake <Gato> Melee Apothecary Frye Dodge", -- [20]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -58 (Physical)", -- [21]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -49 (Physical)", -- [22]
						"Venomous Snake <Gato> Melee Apothecary Frye Glancing -54 (Physical)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2543 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2466 (Nature)", -- [25]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4946 (Nature)", -- [26]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4948 (Nature)", -- [27]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2465 (Nature)", -- [28]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
					},
					["DeathAt"] = 1360560690,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"MISC", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
					},
				}, -- [6]
				{
					["MessageTimes"] = {
						-3.212999999999738, -- [1]
						-3.212999999999738, -- [2]
						-3.212999999999738, -- [3]
						-3.212999999999738, -- [4]
						-3.212999999999738, -- [5]
						-3.212999999999738, -- [6]
						-1.817999999999302, -- [7]
						-1.79399999999805, -- [8]
						-1.744999999998981, -- [9]
						-1.690999999998894, -- [10]
						-1.598999999998341, -- [11]
						-1.598999999998341, -- [12]
						-1.598999999998341, -- [13]
						-1.598999999998341, -- [14]
						-1.598999999998341, -- [15]
						-1.598999999998341, -- [16]
						-1.563999999998487, -- [17]
						-1.500999999996566, -- [18]
						-1.202999999997701, -- [19]
						-0.4279999999998836, -- [20]
						-0.3999999999978172, -- [21]
						-0.3999999999978172, -- [22]
						-0.3999999999978172, -- [23]
						-0.3999999999978172, -- [24]
						-0.3999999999978172, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						1.590000000000146, -- [31]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						true, -- [11]
						true, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						true, -- [16]
						false, -- [17]
						false, -- [18]
						true, -- [19]
						false, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
						false, -- [31]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Melee Apothecary Baxter Glancing -52 (Physical)", -- [1]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -69 (Physical)", -- [2]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -61 (Physical)", -- [3]
						"Venomous Snake <Gato> Melee Apothecary Baxter Glancing -55 (Physical)", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -61 (Physical)", -- [5]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -64 (Physical)", -- [6]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -61 (Physical)", -- [7]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -62 (Physical)", -- [8]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -62 (Physical)", -- [9]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -64 (Physical)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2456 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2376 (Nature)", -- [12]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2402 (Nature)", -- [13]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5052 (Nature)", -- [14]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2519 (Nature)", -- [15]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2617 (Nature)", -- [16]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -67 (Physical)", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -69 (Physical)", -- [18]
						"Venomous Snake <Gato> dies.", -- [19]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Baxter Crit -437 (Nature)", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2617 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2565 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2410 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2500 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2430 (Nature)", -- [25]
						"Venomous Snake <Gato> dies.", -- [26]
						"Venomous Snake <Gato> dies.", -- [27]
						"Venomous Snake <Gato> dies.", -- [28]
						"Venomous Snake <Gato> dies.", -- [29]
						"Venomous Snake <Gato> dies.", -- [30]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Baxter Tick -218 (Nature)", -- [31]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
					},
					["DeathAt"] = 1360560661,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"MISC", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
						"DAMAGE", -- [31]
					},
				}, -- [7]
				{
					["MessageTimes"] = {
						-3.212999999999738, -- [1]
						-3.212999999999738, -- [2]
						-3.212999999999738, -- [3]
						-3.212999999999738, -- [4]
						-3.212999999999738, -- [5]
						-3.212999999999738, -- [6]
						-1.817999999999302, -- [7]
						-1.79399999999805, -- [8]
						-1.744999999998981, -- [9]
						-1.690999999998894, -- [10]
						-1.598999999998341, -- [11]
						-1.598999999998341, -- [12]
						-1.598999999998341, -- [13]
						-1.598999999998341, -- [14]
						-1.598999999998341, -- [15]
						-1.598999999998341, -- [16]
						-1.563999999998487, -- [17]
						-1.500999999996566, -- [18]
						-1.202999999997701, -- [19]
						-0.4279999999998836, -- [20]
						-0.3999999999978172, -- [21]
						-0.3999999999978172, -- [22]
						-0.3999999999978172, -- [23]
						-0.3999999999978172, -- [24]
						-0.3999999999978172, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						1.590000000000146, -- [31]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						true, -- [11]
						true, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						true, -- [16]
						false, -- [17]
						false, -- [18]
						true, -- [19]
						false, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
						false, -- [31]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Melee Apothecary Baxter Glancing -52 (Physical)", -- [1]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -69 (Physical)", -- [2]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -61 (Physical)", -- [3]
						"Venomous Snake <Gato> Melee Apothecary Baxter Glancing -55 (Physical)", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -61 (Physical)", -- [5]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -64 (Physical)", -- [6]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -61 (Physical)", -- [7]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -62 (Physical)", -- [8]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -62 (Physical)", -- [9]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -64 (Physical)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2456 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2376 (Nature)", -- [12]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2402 (Nature)", -- [13]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5052 (Nature)", -- [14]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2519 (Nature)", -- [15]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2617 (Nature)", -- [16]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -67 (Physical)", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -69 (Physical)", -- [18]
						"Venomous Snake <Gato> dies.", -- [19]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Baxter Crit -437 (Nature)", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2617 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2565 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2410 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2500 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2430 (Nature)", -- [25]
						"Venomous Snake <Gato> dies.", -- [26]
						"Venomous Snake <Gato> dies.", -- [27]
						"Venomous Snake <Gato> dies.", -- [28]
						"Venomous Snake <Gato> dies.", -- [29]
						"Venomous Snake <Gato> dies.", -- [30]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Baxter Tick -218 (Nature)", -- [31]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
					},
					["DeathAt"] = 1360560661,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"MISC", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
						"DAMAGE", -- [31]
					},
				}, -- [8]
				{
					["MessageTimes"] = {
						-3.212999999999738, -- [1]
						-3.212999999999738, -- [2]
						-3.212999999999738, -- [3]
						-3.212999999999738, -- [4]
						-3.212999999999738, -- [5]
						-3.212999999999738, -- [6]
						-1.817999999999302, -- [7]
						-1.79399999999805, -- [8]
						-1.744999999998981, -- [9]
						-1.690999999998894, -- [10]
						-1.598999999998341, -- [11]
						-1.598999999998341, -- [12]
						-1.598999999998341, -- [13]
						-1.598999999998341, -- [14]
						-1.598999999998341, -- [15]
						-1.598999999998341, -- [16]
						-1.563999999998487, -- [17]
						-1.500999999996566, -- [18]
						-1.202999999997701, -- [19]
						-0.4279999999998836, -- [20]
						-0.3999999999978172, -- [21]
						-0.3999999999978172, -- [22]
						-0.3999999999978172, -- [23]
						-0.3999999999978172, -- [24]
						-0.3999999999978172, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						1.590000000000146, -- [31]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						true, -- [11]
						true, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						true, -- [16]
						false, -- [17]
						false, -- [18]
						true, -- [19]
						false, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
						false, -- [31]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Melee Apothecary Baxter Glancing -52 (Physical)", -- [1]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -69 (Physical)", -- [2]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -61 (Physical)", -- [3]
						"Venomous Snake <Gato> Melee Apothecary Baxter Glancing -55 (Physical)", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -61 (Physical)", -- [5]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -64 (Physical)", -- [6]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -61 (Physical)", -- [7]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -62 (Physical)", -- [8]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -62 (Physical)", -- [9]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -64 (Physical)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2456 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2376 (Nature)", -- [12]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2402 (Nature)", -- [13]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5052 (Nature)", -- [14]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2519 (Nature)", -- [15]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2617 (Nature)", -- [16]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -67 (Physical)", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -69 (Physical)", -- [18]
						"Venomous Snake <Gato> dies.", -- [19]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Baxter Crit -437 (Nature)", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2617 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2565 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2410 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2500 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2430 (Nature)", -- [25]
						"Venomous Snake <Gato> dies.", -- [26]
						"Venomous Snake <Gato> dies.", -- [27]
						"Venomous Snake <Gato> dies.", -- [28]
						"Venomous Snake <Gato> dies.", -- [29]
						"Venomous Snake <Gato> dies.", -- [30]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Baxter Tick -218 (Nature)", -- [31]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
					},
					["DeathAt"] = 1360560661,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"MISC", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
						"DAMAGE", -- [31]
					},
				}, -- [9]
				{
					["MessageTimes"] = {
						-3.212999999999738, -- [1]
						-3.212999999999738, -- [2]
						-3.212999999999738, -- [3]
						-3.212999999999738, -- [4]
						-3.212999999999738, -- [5]
						-3.212999999999738, -- [6]
						-1.817999999999302, -- [7]
						-1.79399999999805, -- [8]
						-1.744999999998981, -- [9]
						-1.690999999998894, -- [10]
						-1.598999999998341, -- [11]
						-1.598999999998341, -- [12]
						-1.598999999998341, -- [13]
						-1.598999999998341, -- [14]
						-1.598999999998341, -- [15]
						-1.598999999998341, -- [16]
						-1.563999999998487, -- [17]
						-1.500999999996566, -- [18]
						-1.202999999997701, -- [19]
						-0.4279999999998836, -- [20]
						-0.3999999999978172, -- [21]
						-0.3999999999978172, -- [22]
						-0.3999999999978172, -- [23]
						-0.3999999999978172, -- [24]
						-0.3999999999978172, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						1.590000000000146, -- [31]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						true, -- [11]
						true, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						true, -- [16]
						false, -- [17]
						false, -- [18]
						true, -- [19]
						false, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
						false, -- [31]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Melee Apothecary Baxter Glancing -52 (Physical)", -- [1]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -69 (Physical)", -- [2]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -61 (Physical)", -- [3]
						"Venomous Snake <Gato> Melee Apothecary Baxter Glancing -55 (Physical)", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -61 (Physical)", -- [5]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -64 (Physical)", -- [6]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -61 (Physical)", -- [7]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -62 (Physical)", -- [8]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -62 (Physical)", -- [9]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -64 (Physical)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2456 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2376 (Nature)", -- [12]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2402 (Nature)", -- [13]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5052 (Nature)", -- [14]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2519 (Nature)", -- [15]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2617 (Nature)", -- [16]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -67 (Physical)", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -69 (Physical)", -- [18]
						"Venomous Snake <Gato> dies.", -- [19]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Baxter Crit -437 (Nature)", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2617 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2565 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2410 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2500 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2430 (Nature)", -- [25]
						"Venomous Snake <Gato> dies.", -- [26]
						"Venomous Snake <Gato> dies.", -- [27]
						"Venomous Snake <Gato> dies.", -- [28]
						"Venomous Snake <Gato> dies.", -- [29]
						"Venomous Snake <Gato> dies.", -- [30]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Baxter Tick -218 (Nature)", -- [31]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
					},
					["DeathAt"] = 1360560661,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"MISC", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
						"DAMAGE", -- [31]
					},
				}, -- [10]
				{
					["MessageTimes"] = {
						-3.212999999999738, -- [1]
						-3.212999999999738, -- [2]
						-3.212999999999738, -- [3]
						-3.212999999999738, -- [4]
						-3.212999999999738, -- [5]
						-3.212999999999738, -- [6]
						-1.817999999999302, -- [7]
						-1.79399999999805, -- [8]
						-1.744999999998981, -- [9]
						-1.690999999998894, -- [10]
						-1.598999999998341, -- [11]
						-1.598999999998341, -- [12]
						-1.598999999998341, -- [13]
						-1.598999999998341, -- [14]
						-1.598999999998341, -- [15]
						-1.598999999998341, -- [16]
						-1.563999999998487, -- [17]
						-1.500999999996566, -- [18]
						-1.202999999997701, -- [19]
						-0.4279999999998836, -- [20]
						-0.3999999999978172, -- [21]
						-0.3999999999978172, -- [22]
						-0.3999999999978172, -- [23]
						-0.3999999999978172, -- [24]
						-0.3999999999978172, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						1.590000000000146, -- [31]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						true, -- [11]
						true, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						true, -- [16]
						false, -- [17]
						false, -- [18]
						true, -- [19]
						false, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
						false, -- [31]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Melee Apothecary Baxter Glancing -52 (Physical)", -- [1]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -69 (Physical)", -- [2]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -61 (Physical)", -- [3]
						"Venomous Snake <Gato> Melee Apothecary Baxter Glancing -55 (Physical)", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -61 (Physical)", -- [5]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -64 (Physical)", -- [6]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -61 (Physical)", -- [7]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -62 (Physical)", -- [8]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -62 (Physical)", -- [9]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -64 (Physical)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2456 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2376 (Nature)", -- [12]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2402 (Nature)", -- [13]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5052 (Nature)", -- [14]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2519 (Nature)", -- [15]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2617 (Nature)", -- [16]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -67 (Physical)", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -69 (Physical)", -- [18]
						"Venomous Snake <Gato> dies.", -- [19]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Baxter Crit -437 (Nature)", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2617 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2565 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2410 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2500 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2430 (Nature)", -- [25]
						"Venomous Snake <Gato> dies.", -- [26]
						"Venomous Snake <Gato> dies.", -- [27]
						"Venomous Snake <Gato> dies.", -- [28]
						"Venomous Snake <Gato> dies.", -- [29]
						"Venomous Snake <Gato> dies.", -- [30]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Baxter Tick -218 (Nature)", -- [31]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
					},
					["DeathAt"] = 1360560661,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"MISC", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
						"DAMAGE", -- [31]
					},
				}, -- [11]
				{
					["MessageTimes"] = {
						-2.010000000002037, -- [1]
						-2.010000000002037, -- [2]
						-2.010000000002037, -- [3]
						-2.010000000002037, -- [4]
						-2.010000000002037, -- [5]
						-2.010000000002037, -- [6]
						-0.6150000000016007, -- [7]
						-0.5910000000003493, -- [8]
						-0.5420000000012806, -- [9]
						-0.4880000000011933, -- [10]
						-0.3960000000006403, -- [11]
						-0.3960000000006403, -- [12]
						-0.3960000000006403, -- [13]
						-0.3960000000006403, -- [14]
						-0.3960000000006403, -- [15]
						-0.3960000000006403, -- [16]
						-0.3610000000007858, -- [17]
						-0.297999999998865, -- [18]
						0, -- [19]
						0.7749999999978172, -- [20]
						0.8029999999998836, -- [21]
						0.8029999999998836, -- [22]
						0.8029999999998836, -- [23]
						0.8029999999998836, -- [24]
						0.8029999999998836, -- [25]
						1.202999999997701, -- [26]
						1.202999999997701, -- [27]
						1.202999999997701, -- [28]
						1.202999999997701, -- [29]
						1.202999999997701, -- [30]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						true, -- [11]
						true, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						true, -- [16]
						false, -- [17]
						false, -- [18]
						true, -- [19]
						false, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Melee Apothecary Baxter Glancing -52 (Physical)", -- [1]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -69 (Physical)", -- [2]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -61 (Physical)", -- [3]
						"Venomous Snake <Gato> Melee Apothecary Baxter Glancing -55 (Physical)", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -61 (Physical)", -- [5]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -64 (Physical)", -- [6]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -61 (Physical)", -- [7]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -62 (Physical)", -- [8]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -62 (Physical)", -- [9]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -64 (Physical)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2456 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2376 (Nature)", -- [12]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2402 (Nature)", -- [13]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5052 (Nature)", -- [14]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2519 (Nature)", -- [15]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2617 (Nature)", -- [16]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -67 (Physical)", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Baxter Hit -69 (Physical)", -- [18]
						"Venomous Snake <Gato> dies.", -- [19]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Baxter Crit -437 (Nature)", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2617 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2565 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2410 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2500 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2430 (Nature)", -- [25]
						"Venomous Snake <Gato> dies.", -- [26]
						"Venomous Snake <Gato> dies.", -- [27]
						"Venomous Snake <Gato> dies.", -- [28]
						"Venomous Snake <Gato> dies.", -- [29]
						"Venomous Snake <Gato> dies.", -- [30]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["DeathAt"] = 1360560660,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"MISC", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
					},
				}, -- [12]
				{
					["MessageTimes"] = {
						-13.8060000000005, -- [1]
						-11.80500000000029, -- [2]
						-9.811000000001513, -- [3]
						-7.820999999999913, -- [4]
						-4.022000000000844, -- [5]
						-4.022000000000844, -- [6]
						-4.022000000000844, -- [7]
						-4.022000000000844, -- [8]
						-4.022000000000844, -- [9]
						-4.022000000000844, -- [10]
						-2.983000000000175, -- [11]
						-2.947000000000116, -- [12]
						-2.877000000000408, -- [13]
						-2.877000000000408, -- [14]
						-2.735000000000582, -- [15]
						-2.707000000002154, -- [16]
						-1.950000000000728, -- [17]
						-1.865000000001601, -- [18]
						-1.740000000001601, -- [19]
						-1.709000000002561, -- [20]
						-1.615000000001601, -- [21]
						-1.615000000001601, -- [22]
						-1.615000000001601, -- [23]
						-1.574000000000524, -- [24]
						-1.574000000000524, -- [25]
						-1.574000000000524, -- [26]
						-1.42699999999968, -- [27]
						-1.39600000000064, -- [28]
						-1.39600000000064, -- [29]
						-1.201000000000931, -- [30]
						-0.8369999999995343, -- [31]
						-0.805000000000291, -- [32]
						-0.5669999999990978, -- [33]
						-0.3899999999994179, -- [34]
						-0.3899999999994179, -- [35]
						-0.3899999999994179, -- [36]
						-0.3899999999994179, -- [37]
						-0.3899999999994179, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0.7839999999996508, -- [44]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						false, -- [27]
						false, -- [28]
						true, -- [29]
						false, -- [30]
						false, -- [31]
						false, -- [32]
						false, -- [33]
						true, -- [34]
						true, -- [35]
						true, -- [36]
						true, -- [37]
						true, -- [38]
						true, -- [39]
						true, -- [40]
						true, -- [41]
						true, -- [42]
						true, -- [43]
						false, -- [44]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [1]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [2]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Crit -437 (Nature)", -- [3]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -59 (Physical)", -- [5]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -68 (Physical)", -- [6]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [7]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -61 (Physical)", -- [8]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [9]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -126 (Physical)", -- [10]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -119 (Physical)", -- [11]
						"Venomous Snake <Gato> Melee Apothecary Hummel Miss", -- [12]
						"Venomous Snake <Gato> Melee Apothecary Hummel Miss", -- [13]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -55 (Physical)", -- [14]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -68 (Physical)", -- [15]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [16]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -61 (Physical)", -- [18]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [19]
						"Venomous Snake <Gato> Melee Apothecary Hummel Dodge", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2545 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2575 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2551 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5056 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2464 (Nature)", -- [25]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2465 (Nature)", -- [26]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -135 (Physical)", -- [27]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [28]
						"Venomous Snake <Gato> dies.", -- [29]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [30]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -59 (Physical)", -- [31]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -55 (Physical)", -- [32]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [33]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2411 (Nature)", -- [34]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2556 (Nature)", -- [35]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2406 (Nature)", -- [36]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2599 (Nature)", -- [37]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5216 (Nature)", -- [38]
						"Venomous Snake <Gato> dies.", -- [39]
						"Venomous Snake <Gato> dies.", -- [40]
						"Venomous Snake <Gato> dies.", -- [41]
						"Venomous Snake <Gato> dies.", -- [42]
						"Venomous Snake <Gato> dies.", -- [43]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [44]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
					},
					["DeathAt"] = 1360560626,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"MISC", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"DAMAGE", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"MISC", -- [39]
						"MISC", -- [40]
						"MISC", -- [41]
						"MISC", -- [42]
						"MISC", -- [43]
						"DAMAGE", -- [44]
					},
				}, -- [13]
				{
					["MessageTimes"] = {
						-13.8060000000005, -- [1]
						-11.80500000000029, -- [2]
						-9.811000000001513, -- [3]
						-7.820999999999913, -- [4]
						-4.022000000000844, -- [5]
						-4.022000000000844, -- [6]
						-4.022000000000844, -- [7]
						-4.022000000000844, -- [8]
						-4.022000000000844, -- [9]
						-4.022000000000844, -- [10]
						-2.983000000000175, -- [11]
						-2.947000000000116, -- [12]
						-2.877000000000408, -- [13]
						-2.877000000000408, -- [14]
						-2.735000000000582, -- [15]
						-2.707000000002154, -- [16]
						-1.950000000000728, -- [17]
						-1.865000000001601, -- [18]
						-1.740000000001601, -- [19]
						-1.709000000002561, -- [20]
						-1.615000000001601, -- [21]
						-1.615000000001601, -- [22]
						-1.615000000001601, -- [23]
						-1.574000000000524, -- [24]
						-1.574000000000524, -- [25]
						-1.574000000000524, -- [26]
						-1.42699999999968, -- [27]
						-1.39600000000064, -- [28]
						-1.39600000000064, -- [29]
						-1.201000000000931, -- [30]
						-0.8369999999995343, -- [31]
						-0.805000000000291, -- [32]
						-0.5669999999990978, -- [33]
						-0.3899999999994179, -- [34]
						-0.3899999999994179, -- [35]
						-0.3899999999994179, -- [36]
						-0.3899999999994179, -- [37]
						-0.3899999999994179, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0.7839999999996508, -- [44]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						false, -- [27]
						false, -- [28]
						true, -- [29]
						false, -- [30]
						false, -- [31]
						false, -- [32]
						false, -- [33]
						true, -- [34]
						true, -- [35]
						true, -- [36]
						true, -- [37]
						true, -- [38]
						true, -- [39]
						true, -- [40]
						true, -- [41]
						true, -- [42]
						true, -- [43]
						false, -- [44]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [1]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [2]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Crit -437 (Nature)", -- [3]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -59 (Physical)", -- [5]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -68 (Physical)", -- [6]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [7]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -61 (Physical)", -- [8]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [9]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -126 (Physical)", -- [10]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -119 (Physical)", -- [11]
						"Venomous Snake <Gato> Melee Apothecary Hummel Miss", -- [12]
						"Venomous Snake <Gato> Melee Apothecary Hummel Miss", -- [13]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -55 (Physical)", -- [14]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -68 (Physical)", -- [15]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [16]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -61 (Physical)", -- [18]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [19]
						"Venomous Snake <Gato> Melee Apothecary Hummel Dodge", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2545 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2575 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2551 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5056 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2464 (Nature)", -- [25]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2465 (Nature)", -- [26]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -135 (Physical)", -- [27]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [28]
						"Venomous Snake <Gato> dies.", -- [29]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [30]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -59 (Physical)", -- [31]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -55 (Physical)", -- [32]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [33]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2411 (Nature)", -- [34]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2556 (Nature)", -- [35]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2406 (Nature)", -- [36]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2599 (Nature)", -- [37]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5216 (Nature)", -- [38]
						"Venomous Snake <Gato> dies.", -- [39]
						"Venomous Snake <Gato> dies.", -- [40]
						"Venomous Snake <Gato> dies.", -- [41]
						"Venomous Snake <Gato> dies.", -- [42]
						"Venomous Snake <Gato> dies.", -- [43]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [44]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
					},
					["DeathAt"] = 1360560626,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"MISC", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"DAMAGE", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"MISC", -- [39]
						"MISC", -- [40]
						"MISC", -- [41]
						"MISC", -- [42]
						"MISC", -- [43]
						"DAMAGE", -- [44]
					},
				}, -- [14]
				{
					["MessageTimes"] = {
						-13.8060000000005, -- [1]
						-11.80500000000029, -- [2]
						-9.811000000001513, -- [3]
						-7.820999999999913, -- [4]
						-4.022000000000844, -- [5]
						-4.022000000000844, -- [6]
						-4.022000000000844, -- [7]
						-4.022000000000844, -- [8]
						-4.022000000000844, -- [9]
						-4.022000000000844, -- [10]
						-2.983000000000175, -- [11]
						-2.947000000000116, -- [12]
						-2.877000000000408, -- [13]
						-2.877000000000408, -- [14]
						-2.735000000000582, -- [15]
						-2.707000000002154, -- [16]
						-1.950000000000728, -- [17]
						-1.865000000001601, -- [18]
						-1.740000000001601, -- [19]
						-1.709000000002561, -- [20]
						-1.615000000001601, -- [21]
						-1.615000000001601, -- [22]
						-1.615000000001601, -- [23]
						-1.574000000000524, -- [24]
						-1.574000000000524, -- [25]
						-1.574000000000524, -- [26]
						-1.42699999999968, -- [27]
						-1.39600000000064, -- [28]
						-1.39600000000064, -- [29]
						-1.201000000000931, -- [30]
						-0.8369999999995343, -- [31]
						-0.805000000000291, -- [32]
						-0.5669999999990978, -- [33]
						-0.3899999999994179, -- [34]
						-0.3899999999994179, -- [35]
						-0.3899999999994179, -- [36]
						-0.3899999999994179, -- [37]
						-0.3899999999994179, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0.7839999999996508, -- [44]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						false, -- [27]
						false, -- [28]
						true, -- [29]
						false, -- [30]
						false, -- [31]
						false, -- [32]
						false, -- [33]
						true, -- [34]
						true, -- [35]
						true, -- [36]
						true, -- [37]
						true, -- [38]
						true, -- [39]
						true, -- [40]
						true, -- [41]
						true, -- [42]
						true, -- [43]
						false, -- [44]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [1]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [2]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Crit -437 (Nature)", -- [3]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -59 (Physical)", -- [5]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -68 (Physical)", -- [6]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [7]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -61 (Physical)", -- [8]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [9]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -126 (Physical)", -- [10]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -119 (Physical)", -- [11]
						"Venomous Snake <Gato> Melee Apothecary Hummel Miss", -- [12]
						"Venomous Snake <Gato> Melee Apothecary Hummel Miss", -- [13]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -55 (Physical)", -- [14]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -68 (Physical)", -- [15]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [16]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -61 (Physical)", -- [18]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [19]
						"Venomous Snake <Gato> Melee Apothecary Hummel Dodge", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2545 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2575 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2551 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5056 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2464 (Nature)", -- [25]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2465 (Nature)", -- [26]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -135 (Physical)", -- [27]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [28]
						"Venomous Snake <Gato> dies.", -- [29]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [30]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -59 (Physical)", -- [31]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -55 (Physical)", -- [32]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [33]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2411 (Nature)", -- [34]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2556 (Nature)", -- [35]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2406 (Nature)", -- [36]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2599 (Nature)", -- [37]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5216 (Nature)", -- [38]
						"Venomous Snake <Gato> dies.", -- [39]
						"Venomous Snake <Gato> dies.", -- [40]
						"Venomous Snake <Gato> dies.", -- [41]
						"Venomous Snake <Gato> dies.", -- [42]
						"Venomous Snake <Gato> dies.", -- [43]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [44]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
					},
					["DeathAt"] = 1360560626,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"MISC", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"DAMAGE", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"MISC", -- [39]
						"MISC", -- [40]
						"MISC", -- [41]
						"MISC", -- [42]
						"MISC", -- [43]
						"DAMAGE", -- [44]
					},
				}, -- [15]
				{
					["MessageTimes"] = {
						-13.8060000000005, -- [1]
						-11.80500000000029, -- [2]
						-9.811000000001513, -- [3]
						-7.820999999999913, -- [4]
						-4.022000000000844, -- [5]
						-4.022000000000844, -- [6]
						-4.022000000000844, -- [7]
						-4.022000000000844, -- [8]
						-4.022000000000844, -- [9]
						-4.022000000000844, -- [10]
						-2.983000000000175, -- [11]
						-2.947000000000116, -- [12]
						-2.877000000000408, -- [13]
						-2.877000000000408, -- [14]
						-2.735000000000582, -- [15]
						-2.707000000002154, -- [16]
						-1.950000000000728, -- [17]
						-1.865000000001601, -- [18]
						-1.740000000001601, -- [19]
						-1.709000000002561, -- [20]
						-1.615000000001601, -- [21]
						-1.615000000001601, -- [22]
						-1.615000000001601, -- [23]
						-1.574000000000524, -- [24]
						-1.574000000000524, -- [25]
						-1.574000000000524, -- [26]
						-1.42699999999968, -- [27]
						-1.39600000000064, -- [28]
						-1.39600000000064, -- [29]
						-1.201000000000931, -- [30]
						-0.8369999999995343, -- [31]
						-0.805000000000291, -- [32]
						-0.5669999999990978, -- [33]
						-0.3899999999994179, -- [34]
						-0.3899999999994179, -- [35]
						-0.3899999999994179, -- [36]
						-0.3899999999994179, -- [37]
						-0.3899999999994179, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0.7839999999996508, -- [44]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						false, -- [27]
						false, -- [28]
						true, -- [29]
						false, -- [30]
						false, -- [31]
						false, -- [32]
						false, -- [33]
						true, -- [34]
						true, -- [35]
						true, -- [36]
						true, -- [37]
						true, -- [38]
						true, -- [39]
						true, -- [40]
						true, -- [41]
						true, -- [42]
						true, -- [43]
						false, -- [44]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [1]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [2]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Crit -437 (Nature)", -- [3]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -59 (Physical)", -- [5]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -68 (Physical)", -- [6]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [7]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -61 (Physical)", -- [8]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [9]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -126 (Physical)", -- [10]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -119 (Physical)", -- [11]
						"Venomous Snake <Gato> Melee Apothecary Hummel Miss", -- [12]
						"Venomous Snake <Gato> Melee Apothecary Hummel Miss", -- [13]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -55 (Physical)", -- [14]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -68 (Physical)", -- [15]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [16]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -61 (Physical)", -- [18]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [19]
						"Venomous Snake <Gato> Melee Apothecary Hummel Dodge", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2545 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2575 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2551 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5056 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2464 (Nature)", -- [25]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2465 (Nature)", -- [26]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -135 (Physical)", -- [27]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [28]
						"Venomous Snake <Gato> dies.", -- [29]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [30]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -59 (Physical)", -- [31]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -55 (Physical)", -- [32]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [33]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2411 (Nature)", -- [34]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2556 (Nature)", -- [35]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2406 (Nature)", -- [36]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2599 (Nature)", -- [37]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5216 (Nature)", -- [38]
						"Venomous Snake <Gato> dies.", -- [39]
						"Venomous Snake <Gato> dies.", -- [40]
						"Venomous Snake <Gato> dies.", -- [41]
						"Venomous Snake <Gato> dies.", -- [42]
						"Venomous Snake <Gato> dies.", -- [43]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [44]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
					},
					["DeathAt"] = 1360560626,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"MISC", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"DAMAGE", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"MISC", -- [39]
						"MISC", -- [40]
						"MISC", -- [41]
						"MISC", -- [42]
						"MISC", -- [43]
						"DAMAGE", -- [44]
					},
				}, -- [16]
				{
					["MessageTimes"] = {
						-13.8060000000005, -- [1]
						-11.80500000000029, -- [2]
						-9.811000000001513, -- [3]
						-7.820999999999913, -- [4]
						-4.022000000000844, -- [5]
						-4.022000000000844, -- [6]
						-4.022000000000844, -- [7]
						-4.022000000000844, -- [8]
						-4.022000000000844, -- [9]
						-4.022000000000844, -- [10]
						-2.983000000000175, -- [11]
						-2.947000000000116, -- [12]
						-2.877000000000408, -- [13]
						-2.877000000000408, -- [14]
						-2.735000000000582, -- [15]
						-2.707000000002154, -- [16]
						-1.950000000000728, -- [17]
						-1.865000000001601, -- [18]
						-1.740000000001601, -- [19]
						-1.709000000002561, -- [20]
						-1.615000000001601, -- [21]
						-1.615000000001601, -- [22]
						-1.615000000001601, -- [23]
						-1.574000000000524, -- [24]
						-1.574000000000524, -- [25]
						-1.574000000000524, -- [26]
						-1.42699999999968, -- [27]
						-1.39600000000064, -- [28]
						-1.39600000000064, -- [29]
						-1.201000000000931, -- [30]
						-0.8369999999995343, -- [31]
						-0.805000000000291, -- [32]
						-0.5669999999990978, -- [33]
						-0.3899999999994179, -- [34]
						-0.3899999999994179, -- [35]
						-0.3899999999994179, -- [36]
						-0.3899999999994179, -- [37]
						-0.3899999999994179, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0.7839999999996508, -- [44]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						false, -- [27]
						false, -- [28]
						true, -- [29]
						false, -- [30]
						false, -- [31]
						false, -- [32]
						false, -- [33]
						true, -- [34]
						true, -- [35]
						true, -- [36]
						true, -- [37]
						true, -- [38]
						true, -- [39]
						true, -- [40]
						true, -- [41]
						true, -- [42]
						true, -- [43]
						false, -- [44]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [1]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [2]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Crit -437 (Nature)", -- [3]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -59 (Physical)", -- [5]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -68 (Physical)", -- [6]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [7]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -61 (Physical)", -- [8]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [9]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -126 (Physical)", -- [10]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -119 (Physical)", -- [11]
						"Venomous Snake <Gato> Melee Apothecary Hummel Miss", -- [12]
						"Venomous Snake <Gato> Melee Apothecary Hummel Miss", -- [13]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -55 (Physical)", -- [14]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -68 (Physical)", -- [15]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [16]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -61 (Physical)", -- [18]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [19]
						"Venomous Snake <Gato> Melee Apothecary Hummel Dodge", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2545 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2575 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2551 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5056 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2464 (Nature)", -- [25]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2465 (Nature)", -- [26]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -135 (Physical)", -- [27]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [28]
						"Venomous Snake <Gato> dies.", -- [29]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [30]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -59 (Physical)", -- [31]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -55 (Physical)", -- [32]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [33]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2411 (Nature)", -- [34]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2556 (Nature)", -- [35]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2406 (Nature)", -- [36]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2599 (Nature)", -- [37]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5216 (Nature)", -- [38]
						"Venomous Snake <Gato> dies.", -- [39]
						"Venomous Snake <Gato> dies.", -- [40]
						"Venomous Snake <Gato> dies.", -- [41]
						"Venomous Snake <Gato> dies.", -- [42]
						"Venomous Snake <Gato> dies.", -- [43]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [44]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
					},
					["DeathAt"] = 1360560626,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"MISC", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"DAMAGE", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"MISC", -- [39]
						"MISC", -- [40]
						"MISC", -- [41]
						"MISC", -- [42]
						"MISC", -- [43]
						"DAMAGE", -- [44]
					},
				}, -- [17]
				{
					["MessageTimes"] = {
						-14.41700000000128, -- [1]
						-12.40999999999985, -- [2]
						-10.40899999999965, -- [3]
						-8.415000000000873, -- [4]
						-6.424999999999272, -- [5]
						-2.626000000000204, -- [6]
						-2.626000000000204, -- [7]
						-2.626000000000204, -- [8]
						-2.626000000000204, -- [9]
						-2.626000000000204, -- [10]
						-2.626000000000204, -- [11]
						-1.586999999999534, -- [12]
						-1.550999999999476, -- [13]
						-1.480999999999767, -- [14]
						-1.480999999999767, -- [15]
						-1.338999999999942, -- [16]
						-1.311000000001513, -- [17]
						-0.5540000000000873, -- [18]
						-0.4690000000009604, -- [19]
						-0.3440000000009604, -- [20]
						-0.3130000000019209, -- [21]
						-0.2190000000009604, -- [22]
						-0.2190000000009604, -- [23]
						-0.2190000000009604, -- [24]
						-0.1779999999998836, -- [25]
						-0.1779999999998836, -- [26]
						-0.1779999999998836, -- [27]
						-0.03099999999903957, -- [28]
						0, -- [29]
						0, -- [30]
						0.194999999999709, -- [31]
						0.559000000001106, -- [32]
						0.5910000000003493, -- [33]
						0.8290000000015425, -- [34]
						1.006000000001222, -- [35]
						1.006000000001222, -- [36]
						1.006000000001222, -- [37]
						1.006000000001222, -- [38]
						1.006000000001222, -- [39]
						1.39600000000064, -- [40]
						1.39600000000064, -- [41]
						1.39600000000064, -- [42]
						1.39600000000064, -- [43]
						1.39600000000064, -- [44]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						false, -- [28]
						false, -- [29]
						true, -- [30]
						false, -- [31]
						false, -- [32]
						false, -- [33]
						false, -- [34]
						true, -- [35]
						true, -- [36]
						true, -- [37]
						true, -- [38]
						true, -- [39]
						true, -- [40]
						true, -- [41]
						true, -- [42]
						true, -- [43]
						true, -- [44]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [1]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [2]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [3]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Crit -437 (Nature)", -- [4]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [5]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -59 (Physical)", -- [6]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -68 (Physical)", -- [7]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [8]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -61 (Physical)", -- [9]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [10]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -126 (Physical)", -- [11]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -119 (Physical)", -- [12]
						"Venomous Snake <Gato> Melee Apothecary Hummel Miss", -- [13]
						"Venomous Snake <Gato> Melee Apothecary Hummel Miss", -- [14]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -55 (Physical)", -- [15]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -68 (Physical)", -- [16]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [18]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -61 (Physical)", -- [19]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [20]
						"Venomous Snake <Gato> Melee Apothecary Hummel Dodge", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2545 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2575 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2551 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5056 (Nature)", -- [25]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2464 (Nature)", -- [26]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2465 (Nature)", -- [27]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -135 (Physical)", -- [28]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [29]
						"Venomous Snake <Gato> dies.", -- [30]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [31]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -59 (Physical)", -- [32]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -55 (Physical)", -- [33]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [34]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2411 (Nature)", -- [35]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2556 (Nature)", -- [36]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2406 (Nature)", -- [37]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2599 (Nature)", -- [38]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5216 (Nature)", -- [39]
						"Venomous Snake <Gato> dies.", -- [40]
						"Venomous Snake <Gato> dies.", -- [41]
						"Venomous Snake <Gato> dies.", -- [42]
						"Venomous Snake <Gato> dies.", -- [43]
						"Venomous Snake <Gato> dies.", -- [44]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
					},
					["DeathAt"] = 1360560625,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"MISC", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"DAMAGE", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"DAMAGE", -- [39]
						"MISC", -- [40]
						"MISC", -- [41]
						"MISC", -- [42]
						"MISC", -- [43]
						"MISC", -- [44]
					},
				}, -- [18]
				{
					["MessageTimes"] = {
						-7.350999999998749, -- [1]
						-6.965000000000146, -- [2]
						-6.802999999999884, -- [3]
						-6.766999999999825, -- [4]
						-6.297999999998865, -- [5]
						-6.110000000000582, -- [6]
						-6.040000000000873, -- [7]
						-5.96900000000096, -- [8]
						-5.493999999998778, -- [9]
						-5.294999999998254, -- [10]
						-5.225999999998749, -- [11]
						-4.632999999997992, -- [12]
						-4.583999999998923, -- [13]
						-4.312999999998283, -- [14]
						-4.09400000000096, -- [15]
						-4.020000000000437, -- [16]
						-3.798999999999069, -- [17]
						-3.701999999997497, -- [18]
						-3.211999999999534, -- [19]
						-3.211999999999534, -- [20]
						-2.980999999999767, -- [21]
						-2.600999999998749, -- [22]
						-2.54399999999805, -- [23]
						-2.40599999999904, -- [24]
						-2.40599999999904, -- [25]
						-2.40599999999904, -- [26]
						-2.40599999999904, -- [27]
						-2.40599999999904, -- [28]
						-2.40599999999904, -- [29]
						-2.257999999997992, -- [30]
						-2.080999999998312, -- [31]
						-1.99199999999837, -- [32]
						-1.81499999999869, -- [33]
						-1.338999999999942, -- [34]
						-1.046999999998661, -- [35]
						-0.8669999999983702, -- [36]
						-0.7459999999991851, -- [37]
						-0.4179999999978463, -- [38]
						-0.3879999999990105, -- [39]
						-0.3879999999990105, -- [40]
						-0.3879999999990105, -- [41]
						-0.3879999999990105, -- [42]
						-0.3879999999990105, -- [43]
						-0.09000000000014552, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						1.908999999999651, -- [50]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						false, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						false, -- [30]
						false, -- [31]
						true, -- [32]
						false, -- [33]
						false, -- [34]
						false, -- [35]
						false, -- [36]
						false, -- [37]
						false, -- [38]
						true, -- [39]
						true, -- [40]
						true, -- [41]
						true, -- [42]
						true, -- [43]
						false, -- [44]
						true, -- [45]
						true, -- [46]
						true, -- [47]
						true, -- [48]
						true, -- [49]
						false, -- [50]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -54 (Physical)", -- [1]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -51 (Physical)", -- [2]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [3]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -60 (Physical)", -- [5]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [6]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [7]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [8]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [9]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [10]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [11]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -59 (Physical)", -- [12]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [13]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [14]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [15]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [16]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [18]
						"Venomous Snake <Gato> Deadly Poison Apothecary Hummel Miss (Nature)", -- [19]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -121 (Physical)", -- [20]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -67 (Physical)", -- [21]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [22]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5240 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2482 (Nature)", -- [25]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2418 (Nature)", -- [26]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2460 (Nature)", -- [27]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2597 (Nature)", -- [28]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2506 (Nature)", -- [29]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -127 (Physical)", -- [30]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [31]
						"Venomous Snake <Gato> dies.", -- [32]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [33]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -134 (Physical)", -- [34]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -54 (Physical)", -- [35]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -68 (Physical)", -- [36]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [37]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -49 (Physical)", -- [38]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4922 (Nature)", -- [39]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4768 (Nature)", -- [40]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5164 (Nature)", -- [41]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2525 (Nature)", -- [42]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4804 (Nature)", -- [43]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [44]
						"Venomous Snake <Gato> dies.", -- [45]
						"Venomous Snake <Gato> dies.", -- [46]
						"Venomous Snake <Gato> dies.", -- [47]
						"Venomous Snake <Gato> dies.", -- [48]
						"Venomous Snake <Gato> dies.", -- [49]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [50]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["DeathAt"] = 1360560609,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
						"???", -- [45]
						"???", -- [46]
						"???", -- [47]
						"???", -- [48]
						"???", -- [49]
						"???", -- [50]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"MISC", -- [32]
						"DAMAGE", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"DAMAGE", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"MISC", -- [45]
						"MISC", -- [46]
						"MISC", -- [47]
						"MISC", -- [48]
						"MISC", -- [49]
						"DAMAGE", -- [50]
					},
				}, -- [19]
				{
					["MessageTimes"] = {
						-7.350999999998749, -- [1]
						-6.965000000000146, -- [2]
						-6.802999999999884, -- [3]
						-6.766999999999825, -- [4]
						-6.297999999998865, -- [5]
						-6.110000000000582, -- [6]
						-6.040000000000873, -- [7]
						-5.96900000000096, -- [8]
						-5.493999999998778, -- [9]
						-5.294999999998254, -- [10]
						-5.225999999998749, -- [11]
						-4.632999999997992, -- [12]
						-4.583999999998923, -- [13]
						-4.312999999998283, -- [14]
						-4.09400000000096, -- [15]
						-4.020000000000437, -- [16]
						-3.798999999999069, -- [17]
						-3.701999999997497, -- [18]
						-3.211999999999534, -- [19]
						-3.211999999999534, -- [20]
						-2.980999999999767, -- [21]
						-2.600999999998749, -- [22]
						-2.54399999999805, -- [23]
						-2.40599999999904, -- [24]
						-2.40599999999904, -- [25]
						-2.40599999999904, -- [26]
						-2.40599999999904, -- [27]
						-2.40599999999904, -- [28]
						-2.40599999999904, -- [29]
						-2.257999999997992, -- [30]
						-2.080999999998312, -- [31]
						-1.99199999999837, -- [32]
						-1.81499999999869, -- [33]
						-1.338999999999942, -- [34]
						-1.046999999998661, -- [35]
						-0.8669999999983702, -- [36]
						-0.7459999999991851, -- [37]
						-0.4179999999978463, -- [38]
						-0.3879999999990105, -- [39]
						-0.3879999999990105, -- [40]
						-0.3879999999990105, -- [41]
						-0.3879999999990105, -- [42]
						-0.3879999999990105, -- [43]
						-0.09000000000014552, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						1.908999999999651, -- [50]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						false, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						false, -- [30]
						false, -- [31]
						true, -- [32]
						false, -- [33]
						false, -- [34]
						false, -- [35]
						false, -- [36]
						false, -- [37]
						false, -- [38]
						true, -- [39]
						true, -- [40]
						true, -- [41]
						true, -- [42]
						true, -- [43]
						false, -- [44]
						true, -- [45]
						true, -- [46]
						true, -- [47]
						true, -- [48]
						true, -- [49]
						false, -- [50]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -54 (Physical)", -- [1]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -51 (Physical)", -- [2]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [3]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -60 (Physical)", -- [5]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [6]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [7]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [8]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [9]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [10]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [11]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -59 (Physical)", -- [12]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [13]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [14]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [15]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [16]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [18]
						"Venomous Snake <Gato> Deadly Poison Apothecary Hummel Miss (Nature)", -- [19]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -121 (Physical)", -- [20]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -67 (Physical)", -- [21]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [22]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5240 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2482 (Nature)", -- [25]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2418 (Nature)", -- [26]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2460 (Nature)", -- [27]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2597 (Nature)", -- [28]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2506 (Nature)", -- [29]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -127 (Physical)", -- [30]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [31]
						"Venomous Snake <Gato> dies.", -- [32]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [33]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -134 (Physical)", -- [34]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -54 (Physical)", -- [35]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -68 (Physical)", -- [36]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [37]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -49 (Physical)", -- [38]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4922 (Nature)", -- [39]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4768 (Nature)", -- [40]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5164 (Nature)", -- [41]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2525 (Nature)", -- [42]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4804 (Nature)", -- [43]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [44]
						"Venomous Snake <Gato> dies.", -- [45]
						"Venomous Snake <Gato> dies.", -- [46]
						"Venomous Snake <Gato> dies.", -- [47]
						"Venomous Snake <Gato> dies.", -- [48]
						"Venomous Snake <Gato> dies.", -- [49]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [50]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["DeathAt"] = 1360560609,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
						"???", -- [45]
						"???", -- [46]
						"???", -- [47]
						"???", -- [48]
						"???", -- [49]
						"???", -- [50]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"MISC", -- [32]
						"DAMAGE", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"DAMAGE", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"MISC", -- [45]
						"MISC", -- [46]
						"MISC", -- [47]
						"MISC", -- [48]
						"MISC", -- [49]
						"DAMAGE", -- [50]
					},
				}, -- [20]
				{
					["MessageTimes"] = {
						-7.350999999998749, -- [1]
						-6.965000000000146, -- [2]
						-6.802999999999884, -- [3]
						-6.766999999999825, -- [4]
						-6.297999999998865, -- [5]
						-6.110000000000582, -- [6]
						-6.040000000000873, -- [7]
						-5.96900000000096, -- [8]
						-5.493999999998778, -- [9]
						-5.294999999998254, -- [10]
						-5.225999999998749, -- [11]
						-4.632999999997992, -- [12]
						-4.583999999998923, -- [13]
						-4.312999999998283, -- [14]
						-4.09400000000096, -- [15]
						-4.020000000000437, -- [16]
						-3.798999999999069, -- [17]
						-3.701999999997497, -- [18]
						-3.211999999999534, -- [19]
						-3.211999999999534, -- [20]
						-2.980999999999767, -- [21]
						-2.600999999998749, -- [22]
						-2.54399999999805, -- [23]
						-2.40599999999904, -- [24]
						-2.40599999999904, -- [25]
						-2.40599999999904, -- [26]
						-2.40599999999904, -- [27]
						-2.40599999999904, -- [28]
						-2.40599999999904, -- [29]
						-2.257999999997992, -- [30]
						-2.080999999998312, -- [31]
						-1.99199999999837, -- [32]
						-1.81499999999869, -- [33]
						-1.338999999999942, -- [34]
						-1.046999999998661, -- [35]
						-0.8669999999983702, -- [36]
						-0.7459999999991851, -- [37]
						-0.4179999999978463, -- [38]
						-0.3879999999990105, -- [39]
						-0.3879999999990105, -- [40]
						-0.3879999999990105, -- [41]
						-0.3879999999990105, -- [42]
						-0.3879999999990105, -- [43]
						-0.09000000000014552, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						1.908999999999651, -- [50]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						false, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						false, -- [30]
						false, -- [31]
						true, -- [32]
						false, -- [33]
						false, -- [34]
						false, -- [35]
						false, -- [36]
						false, -- [37]
						false, -- [38]
						true, -- [39]
						true, -- [40]
						true, -- [41]
						true, -- [42]
						true, -- [43]
						false, -- [44]
						true, -- [45]
						true, -- [46]
						true, -- [47]
						true, -- [48]
						true, -- [49]
						false, -- [50]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -54 (Physical)", -- [1]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -51 (Physical)", -- [2]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [3]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -60 (Physical)", -- [5]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [6]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [7]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [8]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [9]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [10]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [11]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -59 (Physical)", -- [12]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [13]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [14]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [15]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [16]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [18]
						"Venomous Snake <Gato> Deadly Poison Apothecary Hummel Miss (Nature)", -- [19]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -121 (Physical)", -- [20]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -67 (Physical)", -- [21]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [22]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5240 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2482 (Nature)", -- [25]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2418 (Nature)", -- [26]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2460 (Nature)", -- [27]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2597 (Nature)", -- [28]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2506 (Nature)", -- [29]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -127 (Physical)", -- [30]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [31]
						"Venomous Snake <Gato> dies.", -- [32]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [33]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -134 (Physical)", -- [34]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -54 (Physical)", -- [35]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -68 (Physical)", -- [36]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [37]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -49 (Physical)", -- [38]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4922 (Nature)", -- [39]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4768 (Nature)", -- [40]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5164 (Nature)", -- [41]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2525 (Nature)", -- [42]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4804 (Nature)", -- [43]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [44]
						"Venomous Snake <Gato> dies.", -- [45]
						"Venomous Snake <Gato> dies.", -- [46]
						"Venomous Snake <Gato> dies.", -- [47]
						"Venomous Snake <Gato> dies.", -- [48]
						"Venomous Snake <Gato> dies.", -- [49]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [50]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["DeathAt"] = 1360560609,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
						"???", -- [45]
						"???", -- [46]
						"???", -- [47]
						"???", -- [48]
						"???", -- [49]
						"???", -- [50]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"MISC", -- [32]
						"DAMAGE", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"DAMAGE", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"MISC", -- [45]
						"MISC", -- [46]
						"MISC", -- [47]
						"MISC", -- [48]
						"MISC", -- [49]
						"DAMAGE", -- [50]
					},
				}, -- [21]
				{
					["MessageTimes"] = {
						-7.350999999998749, -- [1]
						-6.965000000000146, -- [2]
						-6.802999999999884, -- [3]
						-6.766999999999825, -- [4]
						-6.297999999998865, -- [5]
						-6.110000000000582, -- [6]
						-6.040000000000873, -- [7]
						-5.96900000000096, -- [8]
						-5.493999999998778, -- [9]
						-5.294999999998254, -- [10]
						-5.225999999998749, -- [11]
						-4.632999999997992, -- [12]
						-4.583999999998923, -- [13]
						-4.312999999998283, -- [14]
						-4.09400000000096, -- [15]
						-4.020000000000437, -- [16]
						-3.798999999999069, -- [17]
						-3.701999999997497, -- [18]
						-3.211999999999534, -- [19]
						-3.211999999999534, -- [20]
						-2.980999999999767, -- [21]
						-2.600999999998749, -- [22]
						-2.54399999999805, -- [23]
						-2.40599999999904, -- [24]
						-2.40599999999904, -- [25]
						-2.40599999999904, -- [26]
						-2.40599999999904, -- [27]
						-2.40599999999904, -- [28]
						-2.40599999999904, -- [29]
						-2.257999999997992, -- [30]
						-2.080999999998312, -- [31]
						-1.99199999999837, -- [32]
						-1.81499999999869, -- [33]
						-1.338999999999942, -- [34]
						-1.046999999998661, -- [35]
						-0.8669999999983702, -- [36]
						-0.7459999999991851, -- [37]
						-0.4179999999978463, -- [38]
						-0.3879999999990105, -- [39]
						-0.3879999999990105, -- [40]
						-0.3879999999990105, -- [41]
						-0.3879999999990105, -- [42]
						-0.3879999999990105, -- [43]
						-0.09000000000014552, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						1.908999999999651, -- [50]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						false, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						false, -- [30]
						false, -- [31]
						true, -- [32]
						false, -- [33]
						false, -- [34]
						false, -- [35]
						false, -- [36]
						false, -- [37]
						false, -- [38]
						true, -- [39]
						true, -- [40]
						true, -- [41]
						true, -- [42]
						true, -- [43]
						false, -- [44]
						true, -- [45]
						true, -- [46]
						true, -- [47]
						true, -- [48]
						true, -- [49]
						false, -- [50]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -54 (Physical)", -- [1]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -51 (Physical)", -- [2]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [3]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -60 (Physical)", -- [5]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [6]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [7]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [8]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [9]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [10]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [11]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -59 (Physical)", -- [12]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [13]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [14]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [15]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [16]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [18]
						"Venomous Snake <Gato> Deadly Poison Apothecary Hummel Miss (Nature)", -- [19]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -121 (Physical)", -- [20]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -67 (Physical)", -- [21]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [22]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5240 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2482 (Nature)", -- [25]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2418 (Nature)", -- [26]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2460 (Nature)", -- [27]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2597 (Nature)", -- [28]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2506 (Nature)", -- [29]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -127 (Physical)", -- [30]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [31]
						"Venomous Snake <Gato> dies.", -- [32]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [33]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -134 (Physical)", -- [34]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -54 (Physical)", -- [35]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -68 (Physical)", -- [36]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [37]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -49 (Physical)", -- [38]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4922 (Nature)", -- [39]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4768 (Nature)", -- [40]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5164 (Nature)", -- [41]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2525 (Nature)", -- [42]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4804 (Nature)", -- [43]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [44]
						"Venomous Snake <Gato> dies.", -- [45]
						"Venomous Snake <Gato> dies.", -- [46]
						"Venomous Snake <Gato> dies.", -- [47]
						"Venomous Snake <Gato> dies.", -- [48]
						"Venomous Snake <Gato> dies.", -- [49]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [50]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["DeathAt"] = 1360560609,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
						"???", -- [45]
						"???", -- [46]
						"???", -- [47]
						"???", -- [48]
						"???", -- [49]
						"???", -- [50]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"MISC", -- [32]
						"DAMAGE", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"DAMAGE", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"MISC", -- [45]
						"MISC", -- [46]
						"MISC", -- [47]
						"MISC", -- [48]
						"MISC", -- [49]
						"DAMAGE", -- [50]
					},
				}, -- [22]
				{
					["MessageTimes"] = {
						-7.350999999998749, -- [1]
						-6.965000000000146, -- [2]
						-6.802999999999884, -- [3]
						-6.766999999999825, -- [4]
						-6.297999999998865, -- [5]
						-6.110000000000582, -- [6]
						-6.040000000000873, -- [7]
						-5.96900000000096, -- [8]
						-5.493999999998778, -- [9]
						-5.294999999998254, -- [10]
						-5.225999999998749, -- [11]
						-4.632999999997992, -- [12]
						-4.583999999998923, -- [13]
						-4.312999999998283, -- [14]
						-4.09400000000096, -- [15]
						-4.020000000000437, -- [16]
						-3.798999999999069, -- [17]
						-3.701999999997497, -- [18]
						-3.211999999999534, -- [19]
						-3.211999999999534, -- [20]
						-2.980999999999767, -- [21]
						-2.600999999998749, -- [22]
						-2.54399999999805, -- [23]
						-2.40599999999904, -- [24]
						-2.40599999999904, -- [25]
						-2.40599999999904, -- [26]
						-2.40599999999904, -- [27]
						-2.40599999999904, -- [28]
						-2.40599999999904, -- [29]
						-2.257999999997992, -- [30]
						-2.080999999998312, -- [31]
						-1.99199999999837, -- [32]
						-1.81499999999869, -- [33]
						-1.338999999999942, -- [34]
						-1.046999999998661, -- [35]
						-0.8669999999983702, -- [36]
						-0.7459999999991851, -- [37]
						-0.4179999999978463, -- [38]
						-0.3879999999990105, -- [39]
						-0.3879999999990105, -- [40]
						-0.3879999999990105, -- [41]
						-0.3879999999990105, -- [42]
						-0.3879999999990105, -- [43]
						-0.09000000000014552, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						1.908999999999651, -- [50]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						false, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						false, -- [30]
						false, -- [31]
						true, -- [32]
						false, -- [33]
						false, -- [34]
						false, -- [35]
						false, -- [36]
						false, -- [37]
						false, -- [38]
						true, -- [39]
						true, -- [40]
						true, -- [41]
						true, -- [42]
						true, -- [43]
						false, -- [44]
						true, -- [45]
						true, -- [46]
						true, -- [47]
						true, -- [48]
						true, -- [49]
						false, -- [50]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -54 (Physical)", -- [1]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -51 (Physical)", -- [2]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [3]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -60 (Physical)", -- [5]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [6]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [7]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [8]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [9]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [10]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [11]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -59 (Physical)", -- [12]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [13]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [14]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [15]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [16]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [18]
						"Venomous Snake <Gato> Deadly Poison Apothecary Hummel Miss (Nature)", -- [19]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -121 (Physical)", -- [20]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -67 (Physical)", -- [21]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [22]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5240 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2482 (Nature)", -- [25]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2418 (Nature)", -- [26]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2460 (Nature)", -- [27]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2597 (Nature)", -- [28]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2506 (Nature)", -- [29]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -127 (Physical)", -- [30]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [31]
						"Venomous Snake <Gato> dies.", -- [32]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [33]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -134 (Physical)", -- [34]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -54 (Physical)", -- [35]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -68 (Physical)", -- [36]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [37]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -49 (Physical)", -- [38]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4922 (Nature)", -- [39]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4768 (Nature)", -- [40]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5164 (Nature)", -- [41]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2525 (Nature)", -- [42]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4804 (Nature)", -- [43]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [44]
						"Venomous Snake <Gato> dies.", -- [45]
						"Venomous Snake <Gato> dies.", -- [46]
						"Venomous Snake <Gato> dies.", -- [47]
						"Venomous Snake <Gato> dies.", -- [48]
						"Venomous Snake <Gato> dies.", -- [49]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [50]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["DeathAt"] = 1360560609,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
						"???", -- [45]
						"???", -- [46]
						"???", -- [47]
						"???", -- [48]
						"???", -- [49]
						"???", -- [50]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"MISC", -- [32]
						"DAMAGE", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"DAMAGE", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"MISC", -- [45]
						"MISC", -- [46]
						"MISC", -- [47]
						"MISC", -- [48]
						"MISC", -- [49]
						"DAMAGE", -- [50]
					},
				}, -- [23]
				{
					["MessageTimes"] = {
						-5.760000000002037, -- [1]
						-5.359000000000378, -- [2]
						-4.973000000001775, -- [3]
						-4.811000000001513, -- [4]
						-4.775000000001455, -- [5]
						-4.306000000000495, -- [6]
						-4.118000000002212, -- [7]
						-4.048000000002503, -- [8]
						-3.97700000000259, -- [9]
						-3.502000000000408, -- [10]
						-3.302999999999884, -- [11]
						-3.234000000000378, -- [12]
						-2.640999999999622, -- [13]
						-2.592000000000553, -- [14]
						-2.320999999999913, -- [15]
						-2.10200000000259, -- [16]
						-2.028000000002066, -- [17]
						-1.807000000000699, -- [18]
						-1.709999999999127, -- [19]
						-1.220000000001164, -- [20]
						-1.220000000001164, -- [21]
						-0.989000000001397, -- [22]
						-0.6090000000003784, -- [23]
						-0.5519999999996799, -- [24]
						-0.4140000000006694, -- [25]
						-0.4140000000006694, -- [26]
						-0.4140000000006694, -- [27]
						-0.4140000000006694, -- [28]
						-0.4140000000006694, -- [29]
						-0.4140000000006694, -- [30]
						-0.2659999999996217, -- [31]
						-0.08899999999994179, -- [32]
						0, -- [33]
						0.1769999999996799, -- [34]
						0.6529999999984284, -- [35]
						0.944999999999709, -- [36]
						1.125, -- [37]
						1.245999999999185, -- [38]
						1.574000000000524, -- [39]
						1.60399999999936, -- [40]
						1.60399999999936, -- [41]
						1.60399999999936, -- [42]
						1.60399999999936, -- [43]
						1.60399999999936, -- [44]
						1.901999999998225, -- [45]
						1.99199999999837, -- [46]
						1.99199999999837, -- [47]
						1.99199999999837, -- [48]
						1.99199999999837, -- [49]
						1.99199999999837, -- [50]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						false, -- [23]
						false, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
						false, -- [31]
						false, -- [32]
						true, -- [33]
						false, -- [34]
						false, -- [35]
						false, -- [36]
						false, -- [37]
						false, -- [38]
						false, -- [39]
						true, -- [40]
						true, -- [41]
						true, -- [42]
						true, -- [43]
						true, -- [44]
						false, -- [45]
						true, -- [46]
						true, -- [47]
						true, -- [48]
						true, -- [49]
						true, -- [50]
					},
					["Messages"] = {
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -61 (Physical)", -- [1]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -54 (Physical)", -- [2]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -51 (Physical)", -- [3]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [4]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [5]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -60 (Physical)", -- [6]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [7]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [8]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [9]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [10]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [11]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [12]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -59 (Physical)", -- [13]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [14]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [15]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [16]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [17]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [18]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [19]
						"Venomous Snake <Gato> Deadly Poison Apothecary Hummel Miss (Nature)", -- [20]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -121 (Physical)", -- [21]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -67 (Physical)", -- [22]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -69 (Physical)", -- [23]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -63 (Physical)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5240 (Nature)", -- [25]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2482 (Nature)", -- [26]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2418 (Nature)", -- [27]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2460 (Nature)", -- [28]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2597 (Nature)", -- [29]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2506 (Nature)", -- [30]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -127 (Physical)", -- [31]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -219 (Nature)", -- [32]
						"Venomous Snake <Gato> dies.", -- [33]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -60 (Physical)", -- [34]
						"Venomous Snake <Gato> Melee Apothecary Hummel Crit -134 (Physical)", -- [35]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -54 (Physical)", -- [36]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -68 (Physical)", -- [37]
						"Venomous Snake <Gato> Melee Apothecary Hummel Hit -64 (Physical)", -- [38]
						"Venomous Snake <Gato> Melee Apothecary Hummel Glancing -49 (Physical)", -- [39]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4922 (Nature)", -- [40]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4768 (Nature)", -- [41]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -5164 (Nature)", -- [42]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2525 (Nature)", -- [43]
						"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4804 (Nature)", -- [44]
						"Venomous Snake <Gato> Deadly Poison (DoT) Apothecary Hummel Tick -218 (Nature)", -- [45]
						"Venomous Snake <Gato> dies.", -- [46]
						"Venomous Snake <Gato> dies.", -- [47]
						"Venomous Snake <Gato> dies.", -- [48]
						"Venomous Snake <Gato> dies.", -- [49]
						"Venomous Snake <Gato> dies.", -- [50]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["DeathAt"] = 1360560607,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
						"???", -- [45]
						"???", -- [46]
						"???", -- [47]
						"???", -- [48]
						"???", -- [49]
						"???", -- [50]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"MISC", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"DAMAGE", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"DAMAGE", -- [45]
						"MISC", -- [46]
						"MISC", -- [47]
						"MISC", -- [48]
						"MISC", -- [49]
						"MISC", -- [50]
					},
				}, -- [24]
			},
			["LastEventTimes"] = {
				20843.029, -- [1]
				20843.029, -- [2]
				20843.029, -- [3]
				20843.029, -- [4]
				20844.619, -- [5]
				20846.605, -- [6]
				20848.622, -- [7]
				20850.604, -- [8]
				20870.078, -- [9]
				20870.078, -- [10]
				20870.078, -- [11]
				20870.078, -- [12]
				20870.078, -- [13]
				20870.078, -- [14]
				20871.991, -- [15]
				20871.991, -- [16]
				20871.991, -- [17]
				20871.991, -- [18]
				20871.991, -- [19]
				20871.991, -- [20]
				20872.02, -- [21]
				20872.095, -- [22]
				20872.157, -- [23]
				20872.254, -- [24]
				20872.381, -- [25]
				20872.485, -- [26]
				20873.435, -- [27]
				20873.636, -- [28]
				20873.737, -- [29]
				20873.869, -- [30]
				20873.912, -- [31]
				20874.027, -- [32]
				20874.027, -- [33]
				20874.027, -- [34]
				20874.027, -- [35]
				20874.027, -- [36]
				20874.406, -- [37]
				20874.406, -- [38]
				20874.406, -- [39]
				20874.406, -- [40]
				20874.406, -- [41]
				20841.528, -- [42]
				20841.826, -- [43]
				20842.601, -- [44]
				20842.629, -- [45]
				20842.629, -- [46]
				20842.629, -- [47]
				20842.629, -- [48]
				20842.629, -- [49]
				20843.029, -- [50]
			},
			["LastAbility"] = 102142.251,
		},
		["Kardinalsinn-Barthilas"] = {
			["GUID"] = "0x0300000006C1BD5C",
			["LastEventHealth"] = {
				"397199 (100%)", -- [1]
				"397199 (100%)", -- [2]
				"397199 (100%)", -- [3]
				"397199 (100%)", -- [4]
				"397199 (100%)", -- [5]
				"397199 (100%)", -- [6]
				"397199 (100%)", -- [7]
				"397199 (100%)", -- [8]
				"397199 (100%)", -- [9]
				"397199 (100%)", -- [10]
				"397199 (100%)", -- [11]
				"397199 (100%)", -- [12]
				"397199 (100%)", -- [13]
				"397199 (100%)", -- [14]
				"397199 (100%)", -- [15]
				"397199 (100%)", -- [16]
				"397199 (100%)", -- [17]
				"397199 (100%)", -- [18]
				"397199 (100%)", -- [19]
				"397199 (100%)", -- [20]
				"397199 (100%)", -- [21]
				"397199 (100%)", -- [22]
				"397199 (100%)", -- [23]
				"397199 (100%)", -- [24]
				"397199 (100%)", -- [25]
				"397199 (100%)", -- [26]
				"397199 (100%)", -- [27]
				"397199 (100%)", -- [28]
				"397199 (100%)", -- [29]
				"397199 (100%)", -- [30]
				"397199 (100%)", -- [31]
				"397199 (100%)", -- [32]
				"397199 (100%)", -- [33]
				"397199 (100%)", -- [34]
				"397199 (100%)", -- [35]
				"397199 (100%)", -- [36]
				"397199 (100%)", -- [37]
				"397199 (100%)", -- [38]
				"397199 (100%)", -- [39]
				"397199 (100%)", -- [40]
				"397199 (100%)", -- [41]
				"397199 (100%)", -- [42]
				"397199 (100%)", -- [43]
				"397199 (100%)", -- [44]
				"397199 (100%)", -- [45]
				"397199 (100%)", -- [46]
				"397199 (100%)", -- [47]
				"397199 (100%)", -- [48]
				"397199 (100%)", -- [49]
				"397199 (100%)", -- [50]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"HEAL", -- [3]
				"HEAL", -- [4]
				"HEAL", -- [5]
				"DAMAGE", -- [6]
				"HEAL", -- [7]
				"DAMAGE", -- [8]
				"HEAL", -- [9]
				"DAMAGE", -- [10]
				"HEAL", -- [11]
				"DAMAGE", -- [12]
				"HEAL", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"HEAL", -- [16]
				"DAMAGE", -- [17]
				"HEAL", -- [18]
				"HEAL", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"HEAL", -- [22]
				"HEAL", -- [23]
				"DAMAGE", -- [24]
				"HEAL", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"HEAL", -- [28]
				"HEAL", -- [29]
				"HEAL", -- [30]
				"DAMAGE", -- [31]
				"HEAL", -- [32]
				"DAMAGE", -- [33]
				"HEAL", -- [34]
				"DAMAGE", -- [35]
				"HEAL", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"HEAL", -- [39]
				"HEAL", -- [40]
				"DAMAGE", -- [41]
				"HEAL", -- [42]
				"DAMAGE", -- [43]
				"HEAL", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"HEAL", -- [47]
				"DAMAGE", -- [48]
				"HEAL", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					38.51999999999999, -- [1]
				},
				["Healing"] = {
					1152699, -- [1]
				},
				["Absorbs"] = {
					762238, -- [1]
				},
				["HealingTaken"] = {
					18205, -- [1]
				},
				["Overhealing"] = {
					1654240, -- [1]
				},
				["TimeDamage"] = {
					76.20999999999999, -- [1]
				},
				["ActiveTime"] = {
					114.73, -- [1]
				},
				["ManaGain"] = {
					119307, -- [1]
				},
				["DOT_Time"] = {
					159, -- [1]
				},
				["Damage"] = {
					2544124, -- [1]
				},
			},
			["enClass"] = "PRIEST",
			["unit"] = "Kardinalsinn",
			["level"] = 90,
			["LastActive"] = 1360560707,
			["LastFightIn"] = 1,
			["LastEventNum"] = {
			},
			["type"] = "Ungrouped",
			["FightsSaved"] = 5,
			["GuardianReverseGUIDs"] = {
				["Mindbender"] = {
					["LatestGuardian"] = 1,
					["GUIDs"] = {
						"0xF130F6060001B542", -- [1]
						[0] = "0xF130F6060001B244",
					},
				},
			},
			["UnitLockout"] = 1360560705,
			["Owner"] = false,
			["Pet"] = {
				"Mindbender <Kardinalsinn-Barthilas>", -- [1]
			},
			["NextEventNum"] = 30,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				100, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				100, -- [11]
				100, -- [12]
				100, -- [13]
				100, -- [14]
				100, -- [15]
				100, -- [16]
				100, -- [17]
				100, -- [18]
				100, -- [19]
				100, -- [20]
				100, -- [21]
				100, -- [22]
				100, -- [23]
				100, -- [24]
				100, -- [25]
				100, -- [26]
				100, -- [27]
				100, -- [28]
				100, -- [29]
				100, -- [30]
				100, -- [31]
				100, -- [32]
				100, -- [33]
				100, -- [34]
				100, -- [35]
				100, -- [36]
				100, -- [37]
				100, -- [38]
				100, -- [39]
				100, -- [40]
				100, -- [41]
				100, -- [42]
				100, -- [43]
				100, -- [44]
				100, -- [45]
				100, -- [46]
				100, -- [47]
				100, -- [48]
				100, -- [49]
				100, -- [50]
			},
			["LastEvents"] = {
				"Kardinalsinn-Barthilas Smite Apothecary Frye Hit -25262 (Holy)", -- [1]
				"Kardinalsinn-Barthilas Penance Apothecary Frye Hit -29341 (Holy)", -- [2]
				"Kardinalsinn-Barthilas Atonement Darver-Silvermoon Hit +1080", -- [3]
				"Kardinalsinn-Barthilas Atonement Darver-Silvermoon Hit +33156 (29075 overheal)", -- [4]
				"Kardinalsinn-Barthilas Atonement Darver-Silvermoon Hit +38510 (38510 overheal)", -- [5]
				"Kardinalsinn-Barthilas Penance Apothecary Frye Hit -36592 (Holy)", -- [6]
				"Kardinalsinn-Barthilas Atonement Mindbender <Kardinalsinn-Barthilas> Hit +45740 (44611 overheal)", -- [7]
				"Kardinalsinn-Barthilas Smite Apothecary Frye Hit -32105 (Holy)", -- [8]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Hit +40131 (40131 overheal)", -- [9]
				"Kardinalsinn-Barthilas Smite Apothecary Frye Crit -65975 (Holy)", -- [10]
				"Kardinalsinn-Barthilas Atonement Mindbender <Kardinalsinn-Barthilas> Crit +84943 (84657 overheal)", -- [11]
				"Kardinalsinn-Barthilas Holy Fire Apothecary Frye Hit -39355 (Holy)", -- [12]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Hit +39355 (39355 overheal)", -- [13]
				"Kardinalsinn-Barthilas Holy Fire (DoT) Apothecary Frye Tick -1135 (Holy)", -- [14]
				"Kardinalsinn-Barthilas Smite Apothecary Frye Hit -32330 (Holy)", -- [15]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Hit +1135 (1135 overheal)", -- [16]
				"Kardinalsinn-Barthilas Holy Fire (DoT) Apothecary Frye Tick -1135 (Holy)", -- [17]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Hit +32330 (32330 overheal)", -- [18]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Hit +1135 (1135 overheal)", -- [19]
				"Kardinalsinn-Barthilas Smite Apothecary Frye Crit -66337 (Holy)", -- [20]
				"Kardinalsinn-Barthilas Holy Fire (DoT) Apothecary Frye Tick -1135 (Holy)", -- [21]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Crit +68327 (68327 overheal)", -- [22]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Hit +1135 (1135 overheal)", -- [23]
				"Kardinalsinn-Barthilas Holy Fire (DoT) Apothecary Frye Tick -1135 (Holy)", -- [24]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Hit +1135 (358 overheal)", -- [25]
				"Kardinalsinn-Barthilas Holy Fire (DoT) Apothecary Frye Tick -1134 (Holy)", -- [26]
				"Kardinalsinn-Barthilas Penance Apothecary Frye Hit -30457 (Holy)", -- [27]
				"Kardinalsinn-Barthilas Atonement Palauradin-Silvermoon Hit +1191", -- [28]
				"Kardinalsinn-Barthilas Atonement Palauradin-Silvermoon Hit +31980 (30127 overheal)", -- [29]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Hit +32926 (32926 overheal)", -- [30]
				"Kardinalsinn-Barthilas Penance Apothecary Frye Hit -26372 (Holy)", -- [31]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Hit +32965 (32965 overheal)", -- [32]
				"Kardinalsinn-Barthilas Holy Fire Apothecary Frye Hit -28273 (Holy)", -- [33]
				"Kardinalsinn-Barthilas Atonement Underworld <Gato> Hit +35342 (35342 overheal)", -- [34]
				"Kardinalsinn-Barthilas Holy Fire (DoT) Apothecary Frye Tick -824 (Holy)", -- [35]
				"Kardinalsinn-Barthilas Atonement Palauradin-Silvermoon Hit +1081", -- [36]
				"Kardinalsinn-Barthilas Smite Apothecary Frye Crit -50463 (Holy)", -- [37]
				"Kardinalsinn-Barthilas Holy Fire (DoT) Apothecary Frye Tick -823 (Holy)", -- [38]
				"Kardinalsinn-Barthilas Atonement Palauradin-Silvermoon Crit +68220 (68220 overheal)", -- [39]
				"Kardinalsinn-Barthilas Atonement Darver-Silvermoon Hit +1080", -- [40]
				"Kardinalsinn-Barthilas Holy Fire (DoT) Apothecary Frye Tick -823 (Holy)", -- [41]
				"Kardinalsinn-Barthilas Atonement Darver-Silvermoon Hit +1080", -- [42]
				"Kardinalsinn-Barthilas Holy Fire (DoT) Apothecary Frye Tick -823 (Holy)", -- [43]
				"Kardinalsinn-Barthilas Atonement Darver-Silvermoon Hit +1080", -- [44]
				"Kardinalsinn-Barthilas Cascade Apothecary Frye Hit -30436 (Holy)", -- [45]
				"Kardinalsinn-Barthilas Holy Fire (DoT) Apothecary Frye Tick -823 (Holy)", -- [46]
				"Kardinalsinn-Barthilas Atonement Darver-Silvermoon Hit +1081", -- [47]
				"Kardinalsinn-Barthilas Holy Fire (DoT) Apothecary Frye Tick -824 (Holy)", -- [48]
				"Kardinalsinn-Barthilas Atonement Darver-Silvermoon Hit +1081", -- [49]
				"Kardinalsinn-Barthilas Holy Fire (DoT) Apothecary Frye Tick -823 (Holy)", -- [50]
			},
			["Name"] = "Kardinalsinn-Barthilas",
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["TimeHealing"] = {
						["Underworld <Gato>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mirror Image <Uboblorick-Nagrand>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Uboblorick-Nagrand"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mindbender <Kardinalsinn-Barthilas>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["Atonement"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Glyph of Power Word: Shield"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealedWho"] = {
						["Underworld <Gato>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Spirit Shell"] = {
									["count"] = 0,
								},
								["Power Word: Shield"] = {
									["count"] = 0,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 0,
								},
								["Atonement"] = {
									["count"] = 0,
								},
								["Divine Aegis"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Gato"] = {
							["Details"] = {
								["Spirit Shell"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mindbender <Kardinalsinn-Barthilas>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Underworld"] = {
							["Details"] = {
								["Spirit Shell"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mirror Image <Uboblorick-Nagrand>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Uboblorick-Nagrand"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Spirit Shell"] = {
									["count"] = 0,
								},
								["Divine Aegis"] = {
									["count"] = 0,
								},
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 0,
								},
								["Penance"] = {
									["count"] = 0,
								},
								["Smite"] = {
									["count"] = 0,
								},
								["Cascade"] = {
									["count"] = 0,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Smite"] = {
									["count"] = 0,
								},
								["Holy Fire"] = {
									["count"] = 0,
								},
								["Penance"] = {
									["count"] = 0,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mindbender <Kardinalsinn-Barthilas>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Underworld <Gato>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Baron Ashbury"] = {
							["Details"] = {
								["Penance"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mirror Image <Uboblorick-Nagrand>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Uboblorick-Nagrand"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Smite"] = {
									["count"] = 0,
								},
								["Holy Fire"] = {
									["count"] = 0,
								},
								["Penance"] = {
									["count"] = 0,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
						["Arcane Torrent"] = {
							["Details"] = {
								["Kardinalsinn-Barthilas"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mana Leech"] = {
							["Details"] = {
								["Mindbender <Kardinalsinn-Barthilas>"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Rapture"] = {
							["Details"] = {
								["Kardinalsinn-Barthilas"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["DOTs"] = {
						["Holy Fire (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 0,
								},
								["Apothecary Hummel"] = {
									["count"] = 0,
								},
								["Apothecary Baxter"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeHeal"] = 0,
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["Absorbs"] = 0,
					["Heals"] = {
						["Spirit Shell"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Power Word: Shield"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Glyph of Power Word: Shield"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Atonement"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Divine Aegis"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ShieldedWho"] = {
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 0,
								},
								["Spirit Shell"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Spirit Shell"] = {
									["count"] = 0,
								},
								["Power Word: Shield"] = {
									["count"] = 0,
								},
								["Divine Aegis"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Underworld"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 0,
								},
								["Spirit Shell"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Gato"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 0,
								},
								["Spirit Shell"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Uboblorick-Nagrand"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 0,
								},
								["Spirit Shell"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 0,
								},
								["Spirit Shell"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mindbender"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 0,
								},
								["Penance"] = {
									["count"] = 0,
								},
								["Smite"] = {
									["count"] = 0,
								},
								["Cascade"] = {
									["count"] = 0,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Smite"] = {
									["count"] = 0,
								},
								["Holy Fire"] = {
									["count"] = 0,
								},
								["Penance"] = {
									["count"] = 0,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Baron Ashbury"] = {
							["Details"] = {
								["Penance"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Smite"] = {
									["count"] = 0,
								},
								["Holy Fire"] = {
									["count"] = 0,
								},
								["Penance"] = {
									["count"] = 0,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Holy"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["Attacks"] = {
						["Holy Fire"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Penance"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Smite"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Cascade"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Holy Fire (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Overhealing"] = 0,
					["ElementDone"] = {
						["Holy"] = 0,
					},
					["HealingTaken"] = 0,
					["ManaGainedFrom"] = {
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Rapture"] = {
									["count"] = 0,
								},
								["Arcane Torrent"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mindbender <Kardinalsinn-Barthilas>"] = {
							["Details"] = {
								["Mana Leech"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 0,
								},
								["Penance"] = {
									["count"] = 0,
								},
								["Smite"] = {
									["count"] = 0,
								},
								["Cascade"] = {
									["count"] = 0,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Smite"] = {
									["count"] = 0,
								},
								["Holy Fire"] = {
									["count"] = 0,
								},
								["Penance"] = {
									["count"] = 0,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Baron Ashbury"] = {
							["Details"] = {
								["Penance"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Smite"] = {
									["count"] = 0,
								},
								["Holy Fire"] = {
									["count"] = 0,
								},
								["Penance"] = {
									["count"] = 0,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["ElementTakenAbsorb"] = {
						["Nature"] = 0,
					},
					["Absorbed"] = {
						["Spirit Shell"] = {
							["Details"] = {
								["Darver-Silvermoon"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Palauradin-Silvermoon"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Underworld"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Gato"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Divine Aegis"] = {
							["Details"] = {
								["Darver-Silvermoon"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Palauradin-Silvermoon"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Power Word: Shield"] = {
							["Details"] = {
								["Palauradin-Silvermoon"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
				},
				["OverallData"] = {
					["TimeHealing"] = {
						["Underworld <Gato>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 1.65,
								},
							},
							["amount"] = 1.65,
						},
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 20.05,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 0.42,
								},
							},
							["amount"] = 20.47000000000001,
						},
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 12.23,
								},
							},
							["amount"] = 12.23,
						},
						["Mirror Image <Uboblorick-Nagrand>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 1.29,
								},
							},
							["amount"] = 1.29,
						},
						["Uboblorick-Nagrand"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0.8,
								},
							},
							["amount"] = 0.8,
						},
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0.79,
								},
							},
							["amount"] = 0.79,
						},
						["Mindbender <Kardinalsinn-Barthilas>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 1.29,
								},
							},
							["amount"] = 1.29,
						},
					},
					["OverHeals"] = {
						["Atonement"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 84657,
									["min"] = 12385,
									["count"] = 7,
									["amount"] = 413812,
								},
								["Hit"] = {
									["max"] = 44611,
									["min"] = 121,
									["count"] = 64,
									["amount"] = 1224104,
								},
							},
							["count"] = 71,
							["amount"] = 1637916,
						},
						["Glyph of Power Word: Shield"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16324,
									["min"] = 16324,
									["count"] = 1,
									["amount"] = 16324,
								},
							},
							["count"] = 1,
							["amount"] = 16324,
						},
					},
					["HealedWho"] = {
						["Underworld <Gato>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 11986,
								},
							},
							["amount"] = 11986,
						},
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Spirit Shell"] = {
									["count"] = 279434,
								},
								["Power Word: Shield"] = {
									["count"] = 68583,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 1679,
								},
								["Atonement"] = {
									["count"] = 844711,
								},
								["Divine Aegis"] = {
									["count"] = 165587,
								},
							},
							["amount"] = 1359994,
						},
						["Gato"] = {
							["Details"] = {
								["Spirit Shell"] = {
									["count"] = 8719,
								},
							},
							["amount"] = 8719,
						},
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 18205,
								},
							},
							["amount"] = 18205,
						},
						["Mindbender <Kardinalsinn-Barthilas>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 1415,
								},
							},
							["amount"] = 1415,
						},
						["Underworld"] = {
							["Details"] = {
								["Spirit Shell"] = {
									["count"] = 31889,
								},
							},
							["amount"] = 31889,
						},
						["Mirror Image <Uboblorick-Nagrand>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 14456,
								},
							},
							["amount"] = 14456,
						},
						["Uboblorick-Nagrand"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 10805,
								},
							},
							["amount"] = 10805,
						},
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Spirit Shell"] = {
									["count"] = 106559,
								},
								["Divine Aegis"] = {
									["count"] = 101467,
								},
								["Atonement"] = {
									["count"] = 249442,
								},
							},
							["amount"] = 457468,
						},
					},
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 5.209999999999999,
								},
								["Penance"] = {
									["count"] = 5.54,
								},
								["Smite"] = {
									["count"] = 19,
								},
								["Cascade"] = {
									["count"] = 0.13,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 11.24,
								},
							},
							["amount"] = 41.12,
						},
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 20.05,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 0.42,
								},
							},
							["amount"] = 20.47000000000001,
						},
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0.79,
								},
							},
							["amount"] = 0.79,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Smite"] = {
									["count"] = 7.580000000000001,
								},
								["Holy Fire"] = {
									["count"] = 2.42,
								},
								["Penance"] = {
									["count"] = 2.62,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 2.02,
								},
							},
							["amount"] = 14.64,
						},
						["Mindbender <Kardinalsinn-Barthilas>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 1.29,
								},
							},
							["amount"] = 1.29,
						},
						["Underworld <Gato>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 1.65,
								},
							},
							["amount"] = 1.65,
						},
						["Baron Ashbury"] = {
							["Details"] = {
								["Penance"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Mirror Image <Uboblorick-Nagrand>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 1.29,
								},
							},
							["amount"] = 1.29,
						},
						["Uboblorick-Nagrand"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0.8,
								},
							},
							["amount"] = 0.8,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Smite"] = {
									["count"] = 6.63,
								},
								["Holy Fire"] = {
									["count"] = 4.72,
								},
								["Penance"] = {
									["count"] = 0.5,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 5.100000000000001,
								},
							},
							["amount"] = 16.95,
						},
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 12.23,
								},
							},
							["amount"] = 12.23,
						},
					},
					["WhoHealed"] = {
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 18205,
								},
							},
							["amount"] = 18205,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 7,
								},
							},
							["amount"] = 7,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
						["Arcane Torrent"] = {
							["Details"] = {
								["Kardinalsinn-Barthilas"] = {
									["count"] = 6000,
								},
							},
							["amount"] = 6000,
						},
						["Mana Leech"] = {
							["Details"] = {
								["Mindbender <Kardinalsinn-Barthilas>"] = {
									["count"] = 96421,
								},
							},
							["amount"] = 96421,
						},
						["Rapture"] = {
							["Details"] = {
								["Kardinalsinn-Barthilas"] = {
									["count"] = 16886,
								},
							},
							["amount"] = 16886,
						},
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 2751,
									["min"] = 2505,
									["count"] = 7,
									["amount"] = 18290,
								},
							},
							["count"] = 7,
							["amount"] = 18290,
						},
					},
					["ActiveTime"] = 114.73,
					["DOTs"] = {
						["Holy Fire (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 78,
								},
								["Apothecary Hummel"] = {
									["count"] = 60,
								},
								["Apothecary Baxter"] = {
									["count"] = 21,
								},
							},
							["amount"] = 159,
						},
					},
					["TimeHeal"] = 38.51999999999999,
					["DOT_Time"] = 159,
					["Damage"] = 2544124,
					["Absorbs"] = 762238,
					["Heals"] = {
						["Spirit Shell"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 186720,
									["min"] = 4,
									["count"] = 9,
									["amount"] = 426601,
								},
							},
							["count"] = 9,
							["amount"] = 426601,
						},
						["Power Word: Shield"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 68583,
									["min"] = 68583,
									["count"] = 1,
									["amount"] = 68583,
								},
							},
							["count"] = 1,
							["amount"] = 68583,
						},
						["Glyph of Power Word: Shield"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1679,
									["min"] = 1679,
									["count"] = 1,
									["amount"] = 1679,
								},
							},
							["count"] = 1,
							["amount"] = 1679,
						},
						["Atonement"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 60130,
									["min"] = 286,
									["count"] = 9,
									["amount"] = 201988,
								},
								["Hit"] = {
									["max"] = 45616,
									["min"] = 374,
									["count"] = 86,
									["amount"] = 949032,
								},
							},
							["count"] = 95,
							["amount"] = 1151020,
						},
						["Divine Aegis"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 56234,
									["min"] = 1382,
									["count"] = 9,
									["amount"] = 267054,
								},
							},
							["count"] = 9,
							["amount"] = 267054,
						},
					},
					["ShieldedWho"] = {
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 4,
								},
								["Spirit Shell"] = {
									["count"] = 1,
								},
							},
							["amount"] = 5,
						},
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Spirit Shell"] = {
									["count"] = 1,
								},
								["Power Word: Shield"] = {
									["count"] = 1,
								},
								["Divine Aegis"] = {
									["count"] = 7,
								},
							},
							["amount"] = 9,
						},
						["Underworld"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 2,
								},
								["Spirit Shell"] = {
									["count"] = 5,
								},
							},
							["amount"] = 7,
						},
						["Gato"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 1,
								},
								["Spirit Shell"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
						["Uboblorick-Nagrand"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 1,
								},
								["Spirit Shell"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 1,
								},
								["Spirit Shell"] = {
									["count"] = 2,
								},
							},
							["amount"] = 3,
						},
						["Mindbender"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 175215,
								},
								["Penance"] = {
									["count"] = 339660,
								},
								["Smite"] = {
									["count"] = 698293,
								},
								["Cascade"] = {
									["count"] = 30436,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 25603,
								},
							},
							["amount"] = 1269207,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Smite"] = {
									["count"] = 160132,
								},
								["Holy Fire"] = {
									["count"] = 57682,
								},
								["Penance"] = {
									["count"] = 84019,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 17722,
								},
							},
							["amount"] = 319555,
						},
						["Baron Ashbury"] = {
							["Details"] = {
								["Penance"] = {
									["count"] = 21534,
								},
							},
							["amount"] = 21534,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Smite"] = {
									["count"] = 512843,
								},
								["Holy Fire"] = {
									["count"] = 27267,
								},
								["Penance"] = {
									["count"] = 387336,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 6382,
								},
							},
							["amount"] = 933828,
						},
					},
					["ElementHitsDone"] = {
						["Holy"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 67,
								},
								["Crit"] = {
									["count"] = 11,
								},
								["Tick"] = {
									["count"] = 51,
								},
							},
							["amount"] = 129,
						},
					},
					["Healing"] = 1152699,
					["Attacks"] = {
						["Holy Fire"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 76651,
									["min"] = 76651,
									["count"] = 1,
									["amount"] = 76651,
								},
								["Hit"] = {
									["max"] = 39355,
									["min"] = 27267,
									["count"] = 6,
									["amount"] = 183513,
								},
							},
							["count"] = 7,
							["amount"] = 260164,
						},
						["Penance"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 71653,
									["min"] = 71653,
									["count"] = 1,
									["amount"] = 71653,
								},
								["Hit"] = {
									["max"] = 36592,
									["min"] = 21534,
									["count"] = 25,
									["amount"] = 760896,
								},
							},
							["count"] = 26,
							["amount"] = 832549,
						},
						["Smite"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 66337,
									["min"] = 49362,
									["count"] = 7,
									["amount"] = 395268,
								},
								["Hit"] = {
									["max"] = 32342,
									["min"] = 21440,
									["count"] = 35,
									["amount"] = 976000,
								},
							},
							["count"] = 42,
							["amount"] = 1371268,
						},
						["Cascade"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 30436,
									["min"] = 30436,
									["count"] = 1,
									["amount"] = 30436,
								},
							},
							["count"] = 1,
							["amount"] = 30436,
						},
						["Holy Fire (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1761,
									["min"] = 1630,
									["count"] = 2,
									["amount"] = 3391,
								},
								["Tick"] = {
									["max"] = 1135,
									["min"] = 792,
									["count"] = 51,
									["amount"] = 46316,
								},
							},
							["count"] = 53,
							["amount"] = 49707,
						},
					},
					["Overhealing"] = 1654240,
					["ElementDone"] = {
						["Holy"] = 2544124,
					},
					["HealingTaken"] = 18205,
					["ManaGainedFrom"] = {
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Rapture"] = {
									["count"] = 16886,
								},
								["Arcane Torrent"] = {
									["count"] = 6000,
								},
							},
							["amount"] = 22886,
						},
						["Mindbender <Kardinalsinn-Barthilas>"] = {
							["Details"] = {
								["Mana Leech"] = {
									["count"] = 96421,
								},
							},
							["amount"] = 96421,
						},
					},
					["TimeDamage"] = 76.20999999999999,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 5.209999999999999,
								},
								["Penance"] = {
									["count"] = 5.54,
								},
								["Smite"] = {
									["count"] = 19,
								},
								["Cascade"] = {
									["count"] = 0.13,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 11.24,
								},
							},
							["amount"] = 41.12,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Smite"] = {
									["count"] = 6.63,
								},
								["Holy Fire"] = {
									["count"] = 4.72,
								},
								["Penance"] = {
									["count"] = 0.5,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 5.100000000000001,
								},
							},
							["amount"] = 16.95,
						},
						["Baron Ashbury"] = {
							["Details"] = {
								["Penance"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Smite"] = {
									["count"] = 7.580000000000001,
								},
								["Holy Fire"] = {
									["count"] = 2.42,
								},
								["Penance"] = {
									["count"] = 2.62,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 2.02,
								},
							},
							["amount"] = 14.64,
						},
					},
					["ManaGain"] = 119307,
					["ElementTakenAbsorb"] = {
						["Nature"] = 18290,
					},
					["Absorbed"] = {
						["Spirit Shell"] = {
							["Details"] = {
								["Darver-Silvermoon"] = {
									["max"] = 92116,
									["min"] = 14443,
									["count"] = 2,
									["amount"] = 106559,
								},
								["Palauradin-Silvermoon"] = {
									["max"] = 186720,
									["min"] = 92714,
									["count"] = 2,
									["amount"] = 279434,
								},
								["Underworld"] = {
									["max"] = 24866,
									["min"] = 4,
									["count"] = 4,
									["amount"] = 31889,
								},
								["Gato"] = {
									["max"] = 8719,
									["min"] = 8719,
									["count"] = 1,
									["amount"] = 8719,
								},
							},
							["count"] = 9,
							["amount"] = 426601,
						},
						["Divine Aegis"] = {
							["Details"] = {
								["Darver-Silvermoon"] = {
									["max"] = 56234,
									["min"] = 1599,
									["count"] = 3,
									["amount"] = 101467,
								},
								["Palauradin-Silvermoon"] = {
									["max"] = 44416,
									["min"] = 1382,
									["count"] = 6,
									["amount"] = 165587,
								},
							},
							["count"] = 9,
							["amount"] = 267054,
						},
						["Power Word: Shield"] = {
							["Details"] = {
								["Palauradin-Silvermoon"] = {
									["max"] = 68583,
									["min"] = 68583,
									["count"] = 1,
									["amount"] = 68583,
								},
							},
							["count"] = 1,
							["amount"] = 68583,
						},
					},
				},
			},
			["TimeLast"] = {
				["TimeHeal"] = 1360560707,
				["OVERALL"] = 1360560707,
				["Healing"] = 1360560707,
				["Absorbs"] = 1360560705,
				["HealingTaken"] = 1360560673,
				["Overhealing"] = 1360560707,
				["TimeDamage"] = 1360560707,
				["ActiveTime"] = 1360560707,
				["ManaGain"] = 1360560704,
				["DOT_Time"] = 1360560706,
				["Damage"] = 1360560707,
			},
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				20878.035, -- [1]
				20878.324, -- [2]
				20878.438, -- [3]
				20878.847, -- [4]
				20878.847, -- [5]
				20879.132, -- [6]
				20879.629, -- [7]
				20881.237, -- [8]
				20882.048, -- [9]
				20882.883, -- [10]
				20883.669, -- [11]
				20884.859, -- [12]
				20885.665, -- [13]
				20885.823, -- [14]
				20886.078, -- [15]
				20886.473, -- [16]
				20886.81, -- [17]
				20886.869, -- [18]
				20887.282, -- [19]
				20887.693, -- [20]
				20887.773, -- [21]
				20888.508, -- [22]
				20888.508, -- [23]
				20888.745, -- [24]
				20889.304, -- [25]
				20889.707, -- [26]
				20890.486, -- [27]
				20890.512, -- [28]
				20890.914, -- [29]
				20869.168, -- [30]
				20869.58, -- [31]
				20869.977, -- [32]
				20871.199, -- [33]
				20871.991, -- [34]
				20872.157, -- [35]
				20872.801, -- [36]
				20872.801, -- [37]
				20873.149, -- [38]
				20873.612, -- [39]
				20873.612, -- [40]
				20874.105, -- [41]
				20874.815, -- [42]
				20875.071, -- [43]
				20875.617, -- [44]
				20875.746, -- [45]
				20876.031, -- [46]
				20876.827, -- [47]
				20877.003, -- [48]
				20877.638, -- [49]
				20877.986, -- [50]
			},
			["LastAbility"] = 102142.251,
		},
		["Intoxica-Kil'jaeden"] = {
			["GUID"] = "0x03000000077EE399",
			["type"] = "Hostile",
			["GuardianReverseGUIDs"] = {
				["Shadowy Apparition"] = {
					["LatestGuardian"] = 0,
					["GUIDs"] = {
						[0] = "0xF530F20E000C9BDF",
					},
				},
			},
			["Owner"] = false,
			["enClass"] = "HOSTILE",
			["LastAbility"] = 102142.251,
			["Name"] = "Intoxica-Kil'jaeden",
			["Pet"] = {
				"Shadowy Apparition <Intoxica-Kil'jaeden>", -- [1]
			},
			["UnitLockout"] = 1360561129,
			["level"] = 1,
			["Fights"] = {
			},
			["LastFightIn"] = 7,
		},
		["No One"] = {
			["GUID"] = "0x0000000000000000",
			["LastEventHealth"] = {
				"???", -- [1]
				"???", -- [2]
				"???", -- [3]
				"???", -- [4]
				"???", -- [5]
				"???", -- [6]
				"???", -- [7]
				"???", -- [8]
				"???", -- [9]
				"???", -- [10]
				"???", -- [11]
				"???", -- [12]
				"???", -- [13]
				"???", -- [14]
				"???", -- [15]
				"???", -- [16]
				"???", -- [17]
				"???", -- [18]
				"???", -- [19]
				"???", -- [20]
				"???", -- [21]
				"???", -- [22]
				"???", -- [23]
				"???", -- [24]
				"???", -- [25]
				"???", -- [26]
				"???", -- [27]
				"???", -- [28]
				"???", -- [29]
				"???", -- [30]
				"???", -- [31]
				"???", -- [32]
				"???", -- [33]
				"???", -- [34]
				"???", -- [35]
				"???", -- [36]
				"???", -- [37]
				"???", -- [38]
				"???", -- [39]
				"???", -- [40]
				"???", -- [41]
				"???", -- [42]
				"???", -- [43]
				"???", -- [44]
				"???", -- [45]
				"???", -- [46]
				"???", -- [47]
				"???", -- [48]
				"???", -- [49]
				"???", -- [50]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["ActiveTime"] = {
					88.5, -- [1]
				},
				["FDamage"] = {
					224149, -- [1]
				},
				["TimeDamage"] = {
					88.5, -- [1]
				},
			},
			["level"] = 0,
			["LastFightIn"] = 1,
			["type"] = "Ungrouped",
			["FightsSaved"] = 5,
			["LastActive"] = 1360560705,
			["Owner"] = false,
			["UnitLockout"] = 1360560705,
			["NextEventNum"] = 23,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
				0, -- [5]
				0, -- [6]
				0, -- [7]
				0, -- [8]
				0, -- [9]
				0, -- [10]
				0, -- [11]
				0, -- [12]
				0, -- [13]
				0, -- [14]
				0, -- [15]
				0, -- [16]
				0, -- [17]
				0, -- [18]
				0, -- [19]
				0, -- [20]
				0, -- [21]
				0, -- [22]
				0, -- [23]
				0, -- [24]
				0, -- [25]
				0, -- [26]
				0, -- [27]
				0, -- [28]
				0, -- [29]
				0, -- [30]
				0, -- [31]
				0, -- [32]
				0, -- [33]
				0, -- [34]
				0, -- [35]
				0, -- [36]
				0, -- [37]
				0, -- [38]
				0, -- [39]
				0, -- [40]
				0, -- [41]
				0, -- [42]
				0, -- [43]
				0, -- [44]
				0, -- [45]
				0, -- [46]
				0, -- [47]
				0, -- [48]
				0, -- [49]
				0, -- [50]
			},
			["LastEvents"] = {
				"No One Concentrated Irresistible Cologne Spill Darver-Silvermoon Hit -2665 (Nature)", -- [1]
				"No One Concentrated Irresistible Cologne Spill Darver-Silvermoon Hit -2654 (Nature)", -- [2]
				"No One Concentrated Irresistible Cologne Spill Mindbender <Kardinalsinn-Barthilas> Hit -281 (Nature)", -- [3]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2122 Absorbed) (Nature)", -- [4]
				"No One Concentrated Irresistible Cologne Spill Darver-Silvermoon Hit -2624 (Nature)", -- [5]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2336 Absorbed) (Nature)", -- [6]
				"No One Concentrated Irresistible Cologne Spill Mindbender <Kardinalsinn-Barthilas> Hit -297 (Nature)", -- [7]
				"No One Concentrated Irresistible Cologne Spill Darver-Silvermoon Hit -2620 (Nature)", -- [8]
				"No One Concentrated Irresistible Cologne Spill Mindbender <Kardinalsinn-Barthilas> Crit -551 (Nature)", -- [9]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2241 Absorbed) (Nature)", -- [10]
				"No One Concentrated Alluring Perfume Spill Uboblorick-Nagrand Absorb (2803 Absorbed) (Nature)", -- [11]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2224 Absorbed) (Nature)", -- [12]
				"No One Concentrated Alluring Perfume Spill Uboblorick-Nagrand Absorb (2591 Absorbed) (Nature)", -- [13]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2183 Absorbed) (Nature)", -- [14]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2294 Absorbed) (Nature)", -- [15]
				"No One Concentrated Irresistible Cologne Spill Mindbender <Kardinalsinn-Barthilas> Hit -286 (Nature)", -- [16]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2216 Absorbed) (Nature)", -- [17]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2203 Absorbed) (Nature)", -- [18]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2225 Absorbed) (Nature)", -- [19]
				"No One Concentrated Alluring Perfume Spill Mindbender <Kardinalsinn-Barthilas> Absorb (231 Absorbed) (Nature)", -- [20]
				"No One Concentrated Alluring Perfume Spill Mindbender <Kardinalsinn-Barthilas> Absorb (248 Absorbed) (Nature)", -- [21]
				"No One Concentrated Irresistible Cologne Spill Mindbender <Kardinalsinn-Barthilas> Absorb (297 Absorbed) (Nature)", -- [22]
				"No One Concentrated Irresistible Cologne Spill Ghost Iron Dragonling Hit -2418 (Nature)", -- [23]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Hit -2229 (Nature)", -- [24]
				"No One Concentrated Irresistible Cologne Spill Darver-Silvermoon Hit -2628 (Nature)", -- [25]
				"No One Concentrated Alluring Perfume Spill Kardinalsinn-Barthilas Hit -2502 (Nature)", -- [26]
				"No One Concentrated Irresistible Cologne Spill Ghost Iron Dragonling Hit -2498 (Nature)", -- [27]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Hit -2280 (Nature)", -- [28]
				"No One Concentrated Irresistible Cologne Spill Darver-Silvermoon Hit -2531 (Nature)", -- [29]
				"No One Concentrated Alluring Perfume Spill Kardinalsinn-Barthilas Hit -2778 (Nature)", -- [30]
				"No One Concentrated Irresistible Cologne Spill Ghost Iron Dragonling Hit -2465 (Nature)", -- [31]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Hit -2222 (Nature)", -- [32]
				"No One Concentrated Irresistible Cologne Spill Darver-Silvermoon Hit -2687 (Nature)", -- [33]
				"No One Concentrated Alluring Perfume Spill Kardinalsinn-Barthilas Hit -2777 (Nature)", -- [34]
				"No One Concentrated Irresistible Cologne Spill Ghost Iron Dragonling Hit -2576 (Nature)", -- [35]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Hit -2329 (Nature)", -- [36]
				"No One Concentrated Irresistible Cologne Spill Darver-Silvermoon Hit -2624 (Nature)", -- [37]
				"No One Concentrated Irresistible Cologne Spill Ghost Iron Dragonling Hit -2624 (Nature)", -- [38]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Hit -2301 (Nature)", -- [39]
				"No One Concentrated Irresistible Cologne Spill Darver-Silvermoon Hit -2531 (Nature)", -- [40]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Hit -2316 (Nature)", -- [41]
				"No One Concentrated Irresistible Cologne Spill Darver-Silvermoon Hit -2702 (Nature)", -- [42]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Hit -2198 (Nature)", -- [43]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Hit -2314 (Nature)", -- [44]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2241 Absorbed) (Nature)", -- [45]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2177 Absorbed) (Nature)", -- [46]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2155 Absorbed) (Nature)", -- [47]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Absorb (2255 Absorbed) (Nature)", -- [48]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Hit -2240 (Nature)", -- [49]
				"No One Concentrated Irresistible Cologne Spill Palauradin-Silvermoon Hit -2228 (Nature)", -- [50]
			},
			["Name"] = "No One",
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["TimeSpent"] = {
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Gato"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mirror Image <Uboblorick-Nagrand>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Uboblorick-Nagrand"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ghost Iron Dragonling"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mindbender <Kardinalsinn-Barthilas>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["FAttacks"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementDoneAbsorb"] = {
						["Nature"] = 0,
					},
					["Attacks"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["FDamage"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Gato"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mirror Image <Uboblorick-Nagrand>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Uboblorick-Nagrand"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ghost Iron Dragonling"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mindbender <Kardinalsinn-Barthilas>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["FDamagedWho"] = {
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Gato"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mirror Image <Uboblorick-Nagrand>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ghost Iron Dragonling"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mindbender <Kardinalsinn-Barthilas>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
				},
				["OverallData"] = {
					["TimeSpent"] = {
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 8.25,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 3.68,
								},
							},
							["amount"] = 11.93,
						},
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 8.800000000000001,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 29.93,
								},
							},
							["amount"] = 38.73,
						},
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 1.64,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 1.97,
								},
							},
							["amount"] = 3.610000000000001,
						},
						["Gato"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 3.5,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 4.310000000000001,
								},
							},
							["amount"] = 7.810000000000001,
						},
						["Mirror Image <Uboblorick-Nagrand>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 5.07,
								},
							},
							["amount"] = 5.07,
						},
						["Uboblorick-Nagrand"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0.41,
								},
							},
							["amount"] = 0.41,
						},
						["Ghost Iron Dragonling"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 14.1,
								},
							},
							["amount"] = 14.1,
						},
						["Mindbender <Kardinalsinn-Barthilas>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 2.02,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 4.82,
								},
							},
							["amount"] = 6.84,
						},
					},
					["FAttacks"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 548,
									["min"] = 465,
									["count"] = 11,
									["amount"] = 5655,
								},
								["Hit"] = {
									["max"] = 2778,
									["min"] = 232,
									["count"] = 42,
									["amount"] = 41405,
								},
							},
							["count"] = 53,
							["amount"] = 47060,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4552,
									["min"] = 481,
									["count"] = 6,
									["amount"] = 7097,
								},
								["Hit"] = {
									["max"] = 2921,
									["min"] = 241,
									["count"] = 84,
									["amount"] = 169992,
								},
							},
							["count"] = 90,
							["amount"] = 177089,
						},
					},
					["ElementDoneAbsorb"] = {
						["Nature"] = 190025,
					},
					["Attacks"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 46,
									["amount"] = 0,
								},
							},
							["count"] = 46,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 33,
									["amount"] = 0,
								},
							},
							["count"] = 33,
							["amount"] = 0,
						},
					},
					["FDamage"] = 224149,
					["TimeDamage"] = 88.5,
					["TimeDamaging"] = {
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 8.25,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 3.68,
								},
							},
							["amount"] = 11.93,
						},
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 8.800000000000001,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 29.93,
								},
							},
							["amount"] = 38.73,
						},
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 1.64,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 1.97,
								},
							},
							["amount"] = 3.610000000000001,
						},
						["Gato"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 3.5,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 4.310000000000001,
								},
							},
							["amount"] = 7.810000000000001,
						},
						["Mirror Image <Uboblorick-Nagrand>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 5.07,
								},
							},
							["amount"] = 5.07,
						},
						["Uboblorick-Nagrand"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0.41,
								},
							},
							["amount"] = 0.41,
						},
						["Ghost Iron Dragonling"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 14.1,
								},
							},
							["amount"] = 14.1,
						},
						["Mindbender <Kardinalsinn-Barthilas>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 2.02,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 4.82,
								},
							},
							["amount"] = 6.84,
						},
					},
					["ActiveTime"] = 88.5,
					["FDamagedWho"] = {
						["Darver-Silvermoon"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 5099,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 42263,
								},
							},
							["amount"] = 47362,
						},
						["Palauradin-Silvermoon"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 13697,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 62720,
								},
							},
							["amount"] = 76417,
						},
						["Gato"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 2606,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 5736,
								},
							},
							["amount"] = 8342,
						},
						["Mirror Image <Uboblorick-Nagrand>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 12543,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 5239,
								},
							},
							["amount"] = 17782,
						},
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 13115,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 5090,
								},
							},
							["amount"] = 18205,
						},
						["Ghost Iron Dragonling"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 54626,
								},
							},
							["amount"] = 54626,
						},
						["Mindbender <Kardinalsinn-Barthilas>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 1415,
								},
							},
							["amount"] = 1415,
						},
					},
					["ElementHitsDone"] = {
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 79,
								},
							},
							["amount"] = 79,
						},
					},
				},
			},
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["TimeLast"] = {
				["ActiveTime"] = 1360560705,
				["OVERALL"] = 1360560705,
				["FDamage"] = 1360560698,
				["TimeDamage"] = 1360560705,
			},
			["LastEventTimes"] = {
				20873.201, -- [1]
				20874.027, -- [2]
				20875.617, -- [3]
				20876.428, -- [4]
				20877.217, -- [5]
				20877.638, -- [6]
				20877.638, -- [7]
				20878.035, -- [8]
				20878.438, -- [9]
				20878.438, -- [10]
				20878.847, -- [11]
				20879.629, -- [12]
				20879.629, -- [13]
				20880.437, -- [14]
				20881.651, -- [15]
				20882.454, -- [16]
				20882.454, -- [17]
				20883.669, -- [18]
				20884.459, -- [19]
				20885.665, -- [20]
				20886.473, -- [21]
				20888.508, -- [22]
				20847.85, -- [23]
				20847.85, -- [24]
				20847.85, -- [25]
				20848.263, -- [26]
				20848.672, -- [27]
				20849.074, -- [28]
				20849.074, -- [29]
				20849.074, -- [30]
				20849.859, -- [31]
				20849.859, -- [32]
				20849.859, -- [33]
				20850.287, -- [34]
				20850.677, -- [35]
				20851.071, -- [36]
				20851.071, -- [37]
				20851.885, -- [38]
				20851.885, -- [39]
				20851.885, -- [40]
				20853.106, -- [41]
				20853.106, -- [42]
				20853.895, -- [43]
				20855.11, -- [44]
				20867.556, -- [45]
				20868.392, -- [46]
				20869.58, -- [47]
				20870.391, -- [48]
				20871.588, -- [49]
				20872.381, -- [50]
			},
			["LastAbility"] = 102142.251,
		},
		["Mindbender <Kardinalsinn-Barthilas>"] = {
			["GUID"] = "0xF130F6060001B542",
			["LastEventHealth"] = {
				"119160 (100%)", -- [1]
				"119160 (100%)", -- [2]
				"119160 (100%)", -- [3]
				"119160 (100%)", -- [4]
				"119160 (100%)", -- [5]
				"119160 (100%)", -- [6]
				"119160 (100%)", -- [7]
				"119160 (100%)", -- [8]
				"119160 (100%)", -- [9]
				"119160 (100%)", -- [10]
				"119160 (100%)", -- [11]
				"119160 (100%)", -- [12]
				"119160 (100%)", -- [13]
				"119160 (100%)", -- [14]
				"119160 (100%)", -- [15]
				"118879 (99%)", -- [16]
				"118879 (99%)", -- [17]
				"118879 (99%)", -- [18]
				"118582 (99%)", -- [19]
				"118031 (99%)", -- [20]
				"118031 (99%)", -- [21]
				"119160 (100%)", -- [22]
				"119160 (100%)", -- [23]
				"119160 (100%)", -- [24]
				"118874 (99%)", -- [25]
				"118874 (99%)", -- [26]
				"119160 (100%)", -- [27]
				"119160 (100%)", -- [28]
				"119160 (100%)", -- [29]
				"119160 (100%)", -- [30]
				"119160 (100%)", -- [31]
				"119160 (100%)", -- [32]
				"119160 (100%)", -- [33]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"HEAL", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"HEAL", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
			},
			["TimeWindows"] = {
				["ActiveTime"] = {
					35.88, -- [1]
				},
				["HealingTaken"] = {
					1415, -- [1]
				},
				["TimeDamage"] = {
					35.88, -- [1]
				},
				["Damage"] = {
					649238, -- [1]
				},
			},
			["enClass"] = "PET",
			["unit"] = "Mindbender",
			["level"] = 1,
			["LastFightIn"] = 1,
			["LastEventNum"] = {
				[20] = 0.4624034911043974,
				[25] = 0.2400134273246056,
				[22] = 38.38536421617992,
				[19] = 0.2492447129909366,
				[16] = 0.2358173883853642,
				[27] = 71.2848271231957,
			},
			["type"] = "Pet",
			["FightsSaved"] = 5,
			["LastActive"] = 1360560705,
			["UnitLockout"] = 1360560628,
			["Owner"] = "Kardinalsinn-Barthilas",
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["ElementDoneBlock"] = {
						["Melee"] = 0,
					},
					["ElementTakenAbsorb"] = {
						["Nature"] = 0,
					},
					["ActiveTime"] = 0,
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit (Blocked)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Melee"] = 0,
					},
					["ElementHitsTaken"] = {
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["PartialAbsorb"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Damage"] = 0,
				},
				["OverallData"] = {
					["ElementDoneBlock"] = {
						["Melee"] = 6749,
					},
					["ElementTakenAbsorb"] = {
						["Nature"] = 776,
					},
					["ActiveTime"] = 35.88,
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 20991,
									["min"] = 17871,
									["count"] = 2,
									["amount"] = 38862,
								},
								["Hit (Blocked)"] = {
									["max"] = 15746,
									["min"] = 15746,
									["count"] = 1,
									["amount"] = 15746,
								},
								["Crit"] = {
									["max"] = 53642,
									["min"] = 37258,
									["count"] = 4,
									["amount"] = 195629,
								},
								["Hit"] = {
									["max"] = 26821,
									["min"] = 19560,
									["count"] = 17,
									["amount"] = 399001,
								},
							},
							["count"] = 24,
							["amount"] = 649238,
						},
					},
					["ElementDone"] = {
						["Melee"] = 649238,
					},
					["ElementHitsTaken"] = {
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["WhoHealed"] = {
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 1415,
								},
							},
							["amount"] = 1415,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 317037,
								},
							},
							["amount"] = 317037,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 332201,
								},
							},
							["amount"] = 332201,
						},
					},
					["PartialResist"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 1415,
					["PartialAbsorb"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 248,
									["min"] = 231,
									["count"] = 2,
									["amount"] = 479,
								},
							},
							["count"] = 2,
							["amount"] = 479,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 297,
									["min"] = 297,
									["count"] = 1,
									["amount"] = 297,
								},
							},
							["count"] = 1,
							["amount"] = 297,
						},
					},
					["TimeDamage"] = 35.88,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 22.13,
								},
							},
							["amount"] = 22.13,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13.75,
								},
							},
							["amount"] = 13.75,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 18,
								},
							},
							["amount"] = 24,
						},
					},
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 22.13,
								},
							},
							["amount"] = 22.13,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13.75,
								},
							},
							["amount"] = 13.75,
						},
					},
					["Damage"] = 649238,
				},
			},
			["NextEventNum"] = 34,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				100, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				100, -- [11]
				100, -- [12]
				100, -- [13]
				100, -- [14]
				100, -- [15]
				99.76418261161463, -- [16]
				99.76418261161463, -- [17]
				99.76418261161463, -- [18]
				99.5149378986237, -- [19]
				99.0525344075193, -- [20]
				99.0525344075193, -- [21]
				100, -- [22]
				100, -- [23]
				100, -- [24]
				99.75998657267539, -- [25]
				99.75998657267539, -- [26]
				100, -- [27]
				100, -- [28]
				100, -- [29]
				100, -- [30]
				100, -- [31]
				100, -- [32]
				100, -- [33]
			},
			["LastEvents"] = {
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Baxter Crit -37258 (Physical)", -- [1]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Baxter Glancing -17871 (Physical)", -- [2]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Baxter Hit -21423 (Physical)", -- [3]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Baxter Hit -21424 (Physical)", -- [4]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Baxter Crit -51087 (Physical)", -- [5]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Baxter Hit -22212 (Physical)", -- [6]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Baxter Hit -26821 (Physical)", -- [7]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Baxter Hit -26821 (Physical)", -- [8]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Baxter Crit -53642 (Physical)", -- [9]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Baxter Hit -26821 (Physical)", -- [10]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Baxter Hit -26821 (Physical)", -- [11]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Frye Glancing -20991 (Physical)", -- [12]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Frye Hit -21423 (Physical)", -- [13]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Frye Hit -19560 (Physical)", -- [14]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Frye Hit -22494 (Physical)", -- [15]
				"No One Concentrated Irresistible Cologne Spill Mindbender <Kardinalsinn-Barthilas> Hit -281 (Nature)", -- [16]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Frye Hit -15746 (Physical)", -- [17]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Frye Hit -22494 (Physical)", -- [18]
				"No One Concentrated Irresistible Cologne Spill Mindbender <Kardinalsinn-Barthilas> Hit -297 (Nature)", -- [19]
				"No One Concentrated Irresistible Cologne Spill Mindbender <Kardinalsinn-Barthilas> Crit -551 (Nature)", -- [20]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Frye Hit -19560 (Physical)", -- [21]
				"Kardinalsinn-Barthilas Atonement Mindbender <Kardinalsinn-Barthilas> Hit +45740 (44611 overheal)", -- [22]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Frye Hit -22495 (Physical)", -- [23]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Frye Hit -22495 (Physical)", -- [24]
				"No One Concentrated Irresistible Cologne Spill Mindbender <Kardinalsinn-Barthilas> Hit -286 (Nature)", -- [25]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Frye Hit -22495 (Physical)", -- [26]
				"Kardinalsinn-Barthilas Atonement Mindbender <Kardinalsinn-Barthilas> Crit +84943 (84657 overheal)", -- [27]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Frye Crit -53642 (Physical)", -- [28]
				"No One Concentrated Alluring Perfume Spill Mindbender <Kardinalsinn-Barthilas> Absorb (231 Absorbed) (Nature)", -- [29]
				"No One Concentrated Alluring Perfume Spill Mindbender <Kardinalsinn-Barthilas> Absorb (248 Absorbed) (Nature)", -- [30]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Frye Hit -26821 (Physical)", -- [31]
				"Mindbender <Kardinalsinn-Barthilas> Melee Apothecary Frye Hit -26821 (Physical)", -- [32]
				"No One Concentrated Irresistible Cologne Spill Mindbender <Kardinalsinn-Barthilas> Absorb (297 Absorbed) (Nature)", -- [33]
			},
			["Name"] = "Mindbender",
			["TimeLast"] = {
				["HealingTaken"] = 1360560700,
				["ActiveTime"] = 1360560704,
				["OVERALL"] = 1360560704,
				["TimeDamage"] = 1360560704,
				["Damage"] = 1360560704,
			},
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				true, -- [16]
				false, -- [17]
				false, -- [18]
				true, -- [19]
				true, -- [20]
				false, -- [21]
				true, -- [22]
				false, -- [23]
				false, -- [24]
				true, -- [25]
				false, -- [26]
				true, -- [27]
				false, -- [28]
				true, -- [29]
				true, -- [30]
				false, -- [31]
				false, -- [32]
				true, -- [33]
			},
			["LastFlags"] = 2600,
			["LastEventTimes"] = {
				20812.022, -- [1]
				20813.046, -- [2]
				20814.071, -- [3]
				20815.097, -- [4]
				20816.103, -- [5]
				20817.142, -- [6]
				20818.148, -- [7]
				20819.175, -- [8]
				20820.182, -- [9]
				20821.21, -- [10]
				20822.256, -- [11]
				20825.302, -- [12]
				20826.623, -- [13]
				20873.612, -- [14]
				20874.923, -- [15]
				20875.617, -- [16]
				20876.252, -- [17]
				20877.577, -- [18]
				20877.638, -- [19]
				20878.438, -- [20]
				20878.904, -- [21]
				20879.629, -- [22]
				20880.219, -- [23]
				20881.535, -- [24]
				20882.454, -- [25]
				20882.883, -- [26]
				20883.669, -- [27]
				20884.201, -- [28]
				20885.665, -- [29]
				20886.473, -- [30]
				20886.531, -- [31]
				20887.849, -- [32]
				20888.508, -- [33]
			},
			["LastAbility"] = 102142.251,
		},
		["Viper <Gato>"] = {
			["GUID"] = "0xF1304DD10001B13A",
			["LastEventHealth"] = {
				"???", -- [1]
				"???", -- [2]
				"???", -- [3]
				"???", -- [4]
				"???", -- [5]
				"???", -- [6]
				"???", -- [7]
				"???", -- [8]
				"???", -- [9]
				"???", -- [10]
				"???", -- [11]
				"???", -- [12]
				"???", -- [13]
				"???", -- [14]
				"???", -- [15]
				"???", -- [16]
				"???", -- [17]
				"???", -- [18]
				"???", -- [19]
				"???", -- [20]
				"???", -- [21]
				"???", -- [22]
				"???", -- [23]
				"???", -- [24]
				"???", -- [25]
				"???", -- [26]
				"???", -- [27]
				"???", -- [28]
				"???", -- [29]
				"???", -- [30]
				"???", -- [31]
				"???", -- [32]
				"???", -- [33]
				"???", -- [34]
				"???", -- [35]
				"???", -- [36]
				"???", -- [37]
				"???", -- [38]
				"???", -- [39]
				"???", -- [40]
				"???", -- [41]
				"???", -- [42]
				"???", -- [43]
				"???", -- [44]
				"???", -- [45]
				"???", -- [46]
				"???", -- [47]
				"???", -- [48]
				"???", -- [49]
				"???", -- [50]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"MISC", -- [7]
				"MISC", -- [8]
				"MISC", -- [9]
				"MISC", -- [10]
				"MISC", -- [11]
				"MISC", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"MISC", -- [38]
				"MISC", -- [39]
				"MISC", -- [40]
				"MISC", -- [41]
				"MISC", -- [42]
				"MISC", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["DeathCount"] = {
					24, -- [1]
				},
				["ActiveTime"] = {
					44.78, -- [1]
				},
				["TimeDamage"] = {
					44.78, -- [1]
				},
				["DOT_Time"] = {
					18, -- [1]
				},
				["Damage"] = {
					7923, -- [1]
				},
			},
			["enClass"] = "PET",
			["level"] = 1,
			["LastFightIn"] = 1,
			["type"] = "Pet",
			["FightsSaved"] = 5,
			["LastActive"] = 1360560699,
			["UnitLockout"] = 1360560699,
			["Owner"] = "Gato",
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
						["Deadly Poison (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["ElementDone"] = {
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["DeathCount"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Deadly Poison (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
				},
				["OverallData"] = {
					["DOTs"] = {
						["Deadly Poison (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
					},
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.96,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 10.67,
								},
							},
							["amount"] = 16.63,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 22.1,
								},
							},
							["amount"] = 22.1,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 6.050000000000001,
								},
							},
							["amount"] = 6.050000000000001,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1149,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 1442,
								},
							},
							["amount"] = 2591,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4357,
								},
							},
							["amount"] = 4357,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 975,
								},
							},
							["amount"] = 975,
						},
					},
					["TimeDamage"] = 44.78,
					["ElementDone"] = {
						["Melee"] = 6481,
						["Nature"] = 1442,
					},
					["DeathCount"] = 24,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 12,
								},
								["Parry"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 9,
								},
								["Hit"] = {
									["count"] = 51,
								},
							},
							["amount"] = 74,
						},
						["Nature"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Tick"] = {
									["count"] = 5,
								},
							},
							["amount"] = 6,
						},
					},
					["ActiveTime"] = 44.78,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.96,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 10.67,
								},
							},
							["amount"] = 16.63,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 22.1,
								},
							},
							["amount"] = 22.1,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 6.050000000000001,
								},
							},
							["amount"] = 6.050000000000001,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 74,
									["min"] = 61,
									["count"] = 12,
									["amount"] = 827,
								},
								["Parry"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 181,
									["min"] = 151,
									["count"] = 9,
									["amount"] = 1479,
								},
								["Hit"] = {
									["max"] = 91,
									["min"] = 75,
									["count"] = 51,
									["amount"] = 4175,
								},
							},
							["count"] = 74,
							["amount"] = 6481,
						},
						["Deadly Poison (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 437,
									["min"] = 437,
									["count"] = 1,
									["amount"] = 437,
								},
								["Tick"] = {
									["max"] = 219,
									["min"] = 132,
									["count"] = 5,
									["amount"] = 1005,
								},
							},
							["count"] = 6,
							["amount"] = 1442,
						},
					},
					["DOT_Time"] = 18,
					["Damage"] = 7923,
				},
			},
			["NextEventNum"] = 49,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
				0, -- [5]
				0, -- [6]
				0, -- [7]
				0, -- [8]
				0, -- [9]
				0, -- [10]
				0, -- [11]
				0, -- [12]
				0, -- [13]
				0, -- [14]
				0, -- [15]
				0, -- [16]
				0, -- [17]
				0, -- [18]
				0, -- [19]
				0, -- [20]
				0, -- [21]
				0, -- [22]
				0, -- [23]
				0, -- [24]
				0, -- [25]
				0, -- [26]
				0, -- [27]
				0, -- [28]
				0, -- [29]
				0, -- [30]
				0, -- [31]
				0, -- [32]
				0, -- [33]
				0, -- [34]
				0, -- [35]
				0, -- [36]
				0, -- [37]
				0, -- [38]
				0, -- [39]
				0, -- [40]
				0, -- [41]
				0, -- [42]
				0, -- [43]
				0, -- [44]
				0, -- [45]
				0, -- [46]
				0, -- [47]
				0, -- [48]
				0, -- [49]
				0, -- [50]
			},
			["LastEvents"] = {
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2450 (Nature)", -- [1]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -5154 (Nature)", -- [2]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2426 (Nature)", -- [3]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2492 (Nature)", -- [4]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2580 (Nature)", -- [5]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2449 (Nature)", -- [6]
				"Viper <Gato> dies.", -- [7]
				"Viper <Gato> dies.", -- [8]
				"Viper <Gato> dies.", -- [9]
				"Viper <Gato> dies.", -- [10]
				"Viper <Gato> dies.", -- [11]
				"Viper <Gato> dies.", -- [12]
				"Viper <Gato> Melee Apothecary Frye Glancing -71 (Physical)", -- [13]
				"Viper <Gato> Melee Apothecary Frye Hit -87 (Physical)", -- [14]
				"Viper <Gato> Melee Apothecary Frye Crit -154 (Physical)", -- [15]
				"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [16]
				"Viper <Gato> Melee Apothecary Frye Hit -88 (Physical)", -- [17]
				"Viper <Gato> Melee Apothecary Frye Crit -173 (Physical)", -- [18]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2557 (Nature)", -- [19]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2473 (Nature)", -- [20]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2589 (Nature)", -- [21]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2536 (Nature)", -- [22]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2380 (Nature)", -- [23]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2448 (Nature)", -- [24]
				"Viper <Gato> Melee Apothecary Frye Hit -77 (Physical)", -- [25]
				"Viper <Gato> Melee Apothecary Frye Hit -82 (Physical)", -- [26]
				"Viper <Gato> Melee Apothecary Frye Glancing -71 (Physical)", -- [27]
				"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [28]
				"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [29]
				"Viper <Gato> Melee Apothecary Frye Hit -88 (Physical)", -- [30]
				"Viper <Gato> Deadly Poison (DoT) Apothecary Frye Tick -132 (Nature)", -- [31]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2444 (Nature)", -- [32]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2574 (Nature)", -- [33]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2607 (Nature)", -- [34]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2400 (Nature)", -- [35]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2487 (Nature)", -- [36]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2460 (Nature)", -- [37]
				"Viper <Gato> dies.", -- [38]
				"Viper <Gato> dies.", -- [39]
				"Viper <Gato> dies.", -- [40]
				"Viper <Gato> dies.", -- [41]
				"Viper <Gato> dies.", -- [42]
				"Viper <Gato> dies.", -- [43]
				"Viper <Gato> Deadly Poison (DoT) Apothecary Frye Tick -218 (Nature)", -- [44]
				"Viper <Gato> Deadly Poison (DoT) Apothecary Frye Crit -437 (Nature)", -- [45]
				"Viper <Gato> Deadly Poison (DoT) Apothecary Frye Tick -219 (Nature)", -- [46]
				"Viper <Gato> Deadly Poison (DoT) Apothecary Frye Tick -218 (Nature)", -- [47]
				"Viper <Gato> Deadly Poison (DoT) Apothecary Frye Tick -218 (Nature)", -- [48]
				"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [49]
				"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [50]
			},
			["Name"] = "Viper",
			["TimeLast"] = {
				["DeathCount"] = 1360560690,
				["ActiveTime"] = 1360560699,
				["TimeDamage"] = 1360560699,
				["OVERALL"] = 1360560699,
				["DOT_Time"] = 1360560699,
				["Damage"] = 1360560699,
			},
			["LastEventIncoming"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
				true, -- [4]
				true, -- [5]
				true, -- [6]
				true, -- [7]
				true, -- [8]
				true, -- [9]
				true, -- [10]
				true, -- [11]
				true, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				true, -- [19]
				true, -- [20]
				true, -- [21]
				true, -- [22]
				true, -- [23]
				true, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				true, -- [32]
				true, -- [33]
				true, -- [34]
				true, -- [35]
				true, -- [36]
				true, -- [37]
				true, -- [38]
				true, -- [39]
				true, -- [40]
				true, -- [41]
				true, -- [42]
				true, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["DeathLogs"] = {
				{
					["MessageTimes"] = {
						-4.327999999997701, -- [1]
						-4.327999999997701, -- [2]
						-4.327999999997701, -- [3]
						-4.327999999997701, -- [4]
						-4.327999999997701, -- [5]
						-4.327999999997701, -- [6]
						-2.414999999997235, -- [7]
						-2.414999999997235, -- [8]
						-2.414999999997235, -- [9]
						-2.414999999997235, -- [10]
						-2.414999999997235, -- [11]
						-2.414999999997235, -- [12]
						-2.289999999997235, -- [13]
						-2.098999999998341, -- [14]
						-1.942999999999302, -- [15]
						-1.920999999998458, -- [16]
						-1.920999999998458, -- [17]
						-1.875, -- [18]
						-1.204999999998108, -- [19]
						-0.407999999999447, -- [20]
						-0.3789999999971769, -- [21]
						-0.3789999999971769, -- [22]
						-0.3789999999971769, -- [23]
						-0.3789999999971769, -- [24]
						-0.3789999999971769, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0.7770000000018627, -- [32]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						true, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
						true, -- [31]
						false, -- [32]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Frye Glancing -71 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Frye Hit -87 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Frye Crit -154 (Physical)", -- [3]
						"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Frye Hit -88 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Frye Crit -173 (Physical)", -- [6]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2557 (Nature)", -- [7]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2473 (Nature)", -- [8]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2589 (Nature)", -- [9]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2536 (Nature)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2380 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2448 (Nature)", -- [12]
						"Viper <Gato> Melee Apothecary Frye Hit -77 (Physical)", -- [13]
						"Viper <Gato> Melee Apothecary Frye Hit -82 (Physical)", -- [14]
						"Viper <Gato> Melee Apothecary Frye Glancing -71 (Physical)", -- [15]
						"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [16]
						"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [17]
						"Viper <Gato> Melee Apothecary Frye Hit -88 (Physical)", -- [18]
						"Viper <Gato> Deadly Poison (DoT) Apothecary Frye Tick -132 (Nature)", -- [19]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2444 (Nature)", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2574 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2607 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2400 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2487 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2460 (Nature)", -- [25]
						"Viper <Gato> dies.", -- [26]
						"Viper <Gato> dies.", -- [27]
						"Viper <Gato> dies.", -- [28]
						"Viper <Gato> dies.", -- [29]
						"Viper <Gato> dies.", -- [30]
						"Viper <Gato> dies.", -- [31]
						"Viper <Gato> Deadly Poison (DoT) Apothecary Frye Tick -218 (Nature)", -- [32]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
					},
					["DeathAt"] = 1360560692,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
						"MISC", -- [31]
						"DAMAGE", -- [32]
					},
				}, -- [1]
				{
					["MessageTimes"] = {
						-4.327999999997701, -- [1]
						-4.327999999997701, -- [2]
						-4.327999999997701, -- [3]
						-4.327999999997701, -- [4]
						-4.327999999997701, -- [5]
						-4.327999999997701, -- [6]
						-2.414999999997235, -- [7]
						-2.414999999997235, -- [8]
						-2.414999999997235, -- [9]
						-2.414999999997235, -- [10]
						-2.414999999997235, -- [11]
						-2.414999999997235, -- [12]
						-2.289999999997235, -- [13]
						-2.098999999998341, -- [14]
						-1.942999999999302, -- [15]
						-1.920999999998458, -- [16]
						-1.920999999998458, -- [17]
						-1.875, -- [18]
						-1.204999999998108, -- [19]
						-0.407999999999447, -- [20]
						-0.3789999999971769, -- [21]
						-0.3789999999971769, -- [22]
						-0.3789999999971769, -- [23]
						-0.3789999999971769, -- [24]
						-0.3789999999971769, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0.7770000000018627, -- [32]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						true, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
						true, -- [31]
						false, -- [32]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Frye Glancing -71 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Frye Hit -87 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Frye Crit -154 (Physical)", -- [3]
						"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Frye Hit -88 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Frye Crit -173 (Physical)", -- [6]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2557 (Nature)", -- [7]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2473 (Nature)", -- [8]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2589 (Nature)", -- [9]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2536 (Nature)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2380 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2448 (Nature)", -- [12]
						"Viper <Gato> Melee Apothecary Frye Hit -77 (Physical)", -- [13]
						"Viper <Gato> Melee Apothecary Frye Hit -82 (Physical)", -- [14]
						"Viper <Gato> Melee Apothecary Frye Glancing -71 (Physical)", -- [15]
						"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [16]
						"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [17]
						"Viper <Gato> Melee Apothecary Frye Hit -88 (Physical)", -- [18]
						"Viper <Gato> Deadly Poison (DoT) Apothecary Frye Tick -132 (Nature)", -- [19]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2444 (Nature)", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2574 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2607 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2400 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2487 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2460 (Nature)", -- [25]
						"Viper <Gato> dies.", -- [26]
						"Viper <Gato> dies.", -- [27]
						"Viper <Gato> dies.", -- [28]
						"Viper <Gato> dies.", -- [29]
						"Viper <Gato> dies.", -- [30]
						"Viper <Gato> dies.", -- [31]
						"Viper <Gato> Deadly Poison (DoT) Apothecary Frye Tick -218 (Nature)", -- [32]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
					},
					["DeathAt"] = 1360560692,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
						"MISC", -- [31]
						"DAMAGE", -- [32]
					},
				}, -- [2]
				{
					["MessageTimes"] = {
						-4.327999999997701, -- [1]
						-4.327999999997701, -- [2]
						-4.327999999997701, -- [3]
						-4.327999999997701, -- [4]
						-4.327999999997701, -- [5]
						-4.327999999997701, -- [6]
						-2.414999999997235, -- [7]
						-2.414999999997235, -- [8]
						-2.414999999997235, -- [9]
						-2.414999999997235, -- [10]
						-2.414999999997235, -- [11]
						-2.414999999997235, -- [12]
						-2.289999999997235, -- [13]
						-2.098999999998341, -- [14]
						-1.942999999999302, -- [15]
						-1.920999999998458, -- [16]
						-1.920999999998458, -- [17]
						-1.875, -- [18]
						-1.204999999998108, -- [19]
						-0.407999999999447, -- [20]
						-0.3789999999971769, -- [21]
						-0.3789999999971769, -- [22]
						-0.3789999999971769, -- [23]
						-0.3789999999971769, -- [24]
						-0.3789999999971769, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0.7770000000018627, -- [32]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						true, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
						true, -- [31]
						false, -- [32]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Frye Glancing -71 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Frye Hit -87 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Frye Crit -154 (Physical)", -- [3]
						"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Frye Hit -88 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Frye Crit -173 (Physical)", -- [6]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2557 (Nature)", -- [7]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2473 (Nature)", -- [8]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2589 (Nature)", -- [9]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2536 (Nature)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2380 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2448 (Nature)", -- [12]
						"Viper <Gato> Melee Apothecary Frye Hit -77 (Physical)", -- [13]
						"Viper <Gato> Melee Apothecary Frye Hit -82 (Physical)", -- [14]
						"Viper <Gato> Melee Apothecary Frye Glancing -71 (Physical)", -- [15]
						"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [16]
						"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [17]
						"Viper <Gato> Melee Apothecary Frye Hit -88 (Physical)", -- [18]
						"Viper <Gato> Deadly Poison (DoT) Apothecary Frye Tick -132 (Nature)", -- [19]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2444 (Nature)", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2574 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2607 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2400 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2487 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2460 (Nature)", -- [25]
						"Viper <Gato> dies.", -- [26]
						"Viper <Gato> dies.", -- [27]
						"Viper <Gato> dies.", -- [28]
						"Viper <Gato> dies.", -- [29]
						"Viper <Gato> dies.", -- [30]
						"Viper <Gato> dies.", -- [31]
						"Viper <Gato> Deadly Poison (DoT) Apothecary Frye Tick -218 (Nature)", -- [32]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
					},
					["DeathAt"] = 1360560692,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
						"MISC", -- [31]
						"DAMAGE", -- [32]
					},
				}, -- [3]
				{
					["MessageTimes"] = {
						-4.327999999997701, -- [1]
						-4.327999999997701, -- [2]
						-4.327999999997701, -- [3]
						-4.327999999997701, -- [4]
						-4.327999999997701, -- [5]
						-4.327999999997701, -- [6]
						-2.414999999997235, -- [7]
						-2.414999999997235, -- [8]
						-2.414999999997235, -- [9]
						-2.414999999997235, -- [10]
						-2.414999999997235, -- [11]
						-2.414999999997235, -- [12]
						-2.289999999997235, -- [13]
						-2.098999999998341, -- [14]
						-1.942999999999302, -- [15]
						-1.920999999998458, -- [16]
						-1.920999999998458, -- [17]
						-1.875, -- [18]
						-1.204999999998108, -- [19]
						-0.407999999999447, -- [20]
						-0.3789999999971769, -- [21]
						-0.3789999999971769, -- [22]
						-0.3789999999971769, -- [23]
						-0.3789999999971769, -- [24]
						-0.3789999999971769, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0.7770000000018627, -- [32]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						true, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
						true, -- [31]
						false, -- [32]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Frye Glancing -71 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Frye Hit -87 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Frye Crit -154 (Physical)", -- [3]
						"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Frye Hit -88 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Frye Crit -173 (Physical)", -- [6]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2557 (Nature)", -- [7]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2473 (Nature)", -- [8]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2589 (Nature)", -- [9]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2536 (Nature)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2380 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2448 (Nature)", -- [12]
						"Viper <Gato> Melee Apothecary Frye Hit -77 (Physical)", -- [13]
						"Viper <Gato> Melee Apothecary Frye Hit -82 (Physical)", -- [14]
						"Viper <Gato> Melee Apothecary Frye Glancing -71 (Physical)", -- [15]
						"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [16]
						"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [17]
						"Viper <Gato> Melee Apothecary Frye Hit -88 (Physical)", -- [18]
						"Viper <Gato> Deadly Poison (DoT) Apothecary Frye Tick -132 (Nature)", -- [19]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2444 (Nature)", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2574 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2607 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2400 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2487 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2460 (Nature)", -- [25]
						"Viper <Gato> dies.", -- [26]
						"Viper <Gato> dies.", -- [27]
						"Viper <Gato> dies.", -- [28]
						"Viper <Gato> dies.", -- [29]
						"Viper <Gato> dies.", -- [30]
						"Viper <Gato> dies.", -- [31]
						"Viper <Gato> Deadly Poison (DoT) Apothecary Frye Tick -218 (Nature)", -- [32]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
					},
					["DeathAt"] = 1360560692,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
						"MISC", -- [31]
						"DAMAGE", -- [32]
					},
				}, -- [4]
				{
					["MessageTimes"] = {
						-4.327999999997701, -- [1]
						-4.327999999997701, -- [2]
						-4.327999999997701, -- [3]
						-4.327999999997701, -- [4]
						-4.327999999997701, -- [5]
						-4.327999999997701, -- [6]
						-2.414999999997235, -- [7]
						-2.414999999997235, -- [8]
						-2.414999999997235, -- [9]
						-2.414999999997235, -- [10]
						-2.414999999997235, -- [11]
						-2.414999999997235, -- [12]
						-2.289999999997235, -- [13]
						-2.098999999998341, -- [14]
						-1.942999999999302, -- [15]
						-1.920999999998458, -- [16]
						-1.920999999998458, -- [17]
						-1.875, -- [18]
						-1.204999999998108, -- [19]
						-0.407999999999447, -- [20]
						-0.3789999999971769, -- [21]
						-0.3789999999971769, -- [22]
						-0.3789999999971769, -- [23]
						-0.3789999999971769, -- [24]
						-0.3789999999971769, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0.7770000000018627, -- [32]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						true, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
						true, -- [31]
						false, -- [32]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Frye Glancing -71 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Frye Hit -87 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Frye Crit -154 (Physical)", -- [3]
						"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Frye Hit -88 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Frye Crit -173 (Physical)", -- [6]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2557 (Nature)", -- [7]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2473 (Nature)", -- [8]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2589 (Nature)", -- [9]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2536 (Nature)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2380 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2448 (Nature)", -- [12]
						"Viper <Gato> Melee Apothecary Frye Hit -77 (Physical)", -- [13]
						"Viper <Gato> Melee Apothecary Frye Hit -82 (Physical)", -- [14]
						"Viper <Gato> Melee Apothecary Frye Glancing -71 (Physical)", -- [15]
						"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [16]
						"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [17]
						"Viper <Gato> Melee Apothecary Frye Hit -88 (Physical)", -- [18]
						"Viper <Gato> Deadly Poison (DoT) Apothecary Frye Tick -132 (Nature)", -- [19]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2444 (Nature)", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2574 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2607 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2400 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2487 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2460 (Nature)", -- [25]
						"Viper <Gato> dies.", -- [26]
						"Viper <Gato> dies.", -- [27]
						"Viper <Gato> dies.", -- [28]
						"Viper <Gato> dies.", -- [29]
						"Viper <Gato> dies.", -- [30]
						"Viper <Gato> dies.", -- [31]
						"Viper <Gato> Deadly Poison (DoT) Apothecary Frye Tick -218 (Nature)", -- [32]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
					},
					["DeathAt"] = 1360560692,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
						"MISC", -- [31]
						"DAMAGE", -- [32]
					},
				}, -- [5]
				{
					["MessageTimes"] = {
						-4.327999999997701, -- [1]
						-4.327999999997701, -- [2]
						-4.327999999997701, -- [3]
						-4.327999999997701, -- [4]
						-4.327999999997701, -- [5]
						-4.327999999997701, -- [6]
						-2.414999999997235, -- [7]
						-2.414999999997235, -- [8]
						-2.414999999997235, -- [9]
						-2.414999999997235, -- [10]
						-2.414999999997235, -- [11]
						-2.414999999997235, -- [12]
						-2.289999999997235, -- [13]
						-2.098999999998341, -- [14]
						-1.942999999999302, -- [15]
						-1.920999999998458, -- [16]
						-1.920999999998458, -- [17]
						-1.875, -- [18]
						-1.204999999998108, -- [19]
						-0.407999999999447, -- [20]
						-0.3789999999971769, -- [21]
						-0.3789999999971769, -- [22]
						-0.3789999999971769, -- [23]
						-0.3789999999971769, -- [24]
						-0.3789999999971769, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0.7770000000018627, -- [32]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						true, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
						true, -- [31]
						false, -- [32]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Frye Glancing -71 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Frye Hit -87 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Frye Crit -154 (Physical)", -- [3]
						"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Frye Hit -88 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Frye Crit -173 (Physical)", -- [6]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2557 (Nature)", -- [7]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2473 (Nature)", -- [8]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2589 (Nature)", -- [9]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2536 (Nature)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2380 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2448 (Nature)", -- [12]
						"Viper <Gato> Melee Apothecary Frye Hit -77 (Physical)", -- [13]
						"Viper <Gato> Melee Apothecary Frye Hit -82 (Physical)", -- [14]
						"Viper <Gato> Melee Apothecary Frye Glancing -71 (Physical)", -- [15]
						"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [16]
						"Viper <Gato> Melee Apothecary Frye Hit -86 (Physical)", -- [17]
						"Viper <Gato> Melee Apothecary Frye Hit -88 (Physical)", -- [18]
						"Viper <Gato> Deadly Poison (DoT) Apothecary Frye Tick -132 (Nature)", -- [19]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2444 (Nature)", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2574 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2607 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2400 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2487 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2460 (Nature)", -- [25]
						"Viper <Gato> dies.", -- [26]
						"Viper <Gato> dies.", -- [27]
						"Viper <Gato> dies.", -- [28]
						"Viper <Gato> dies.", -- [29]
						"Viper <Gato> dies.", -- [30]
						"Viper <Gato> dies.", -- [31]
						"Viper <Gato> Deadly Poison (DoT) Apothecary Frye Tick -218 (Nature)", -- [32]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
					},
					["DeathAt"] = 1360560692,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
						"MISC", -- [31]
						"DAMAGE", -- [32]
					},
				}, -- [6]
				{
					["MessageTimes"] = {
						-3.212999999999738, -- [1]
						-3.212999999999738, -- [2]
						-3.212999999999738, -- [3]
						-3.212999999999738, -- [4]
						-3.212999999999738, -- [5]
						-3.212999999999738, -- [6]
						-1.598999999998341, -- [7]
						-1.598999999998341, -- [8]
						-1.598999999998341, -- [9]
						-1.598999999998341, -- [10]
						-1.598999999998341, -- [11]
						-1.598999999998341, -- [12]
						-1.169999999998254, -- [13]
						-1.102999999999156, -- [14]
						-1.077999999997701, -- [15]
						-0.9209999999984575, -- [16]
						-0.6699999999982538, -- [17]
						-0.6699999999982538, -- [18]
						-0.3999999999978172, -- [19]
						-0.3999999999978172, -- [20]
						-0.3999999999978172, -- [21]
						-0.3999999999978172, -- [22]
						-0.3999999999978172, -- [23]
						-0.3999999999978172, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						true, -- [19]
						true, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Baxter Glancing -69 (Physical)", -- [3]
						"Viper <Gato> Melee Apothecary Baxter Hit -77 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Baxter Hit -78 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Baxter Hit -84 (Physical)", -- [6]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2425 (Nature)", -- [7]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2528 (Nature)", -- [8]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2576 (Nature)", -- [9]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2573 (Nature)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2533 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2422 (Nature)", -- [12]
						"Viper <Gato> Melee Apothecary Baxter Hit -76 (Physical)", -- [13]
						"Viper <Gato> Melee Apothecary Baxter Hit -78 (Physical)", -- [14]
						"Viper <Gato> Melee Apothecary Baxter Hit -79 (Physical)", -- [15]
						"Viper <Gato> Melee Apothecary Baxter Glancing -74 (Physical)", -- [16]
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [17]
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [18]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2450 (Nature)", -- [19]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -5154 (Nature)", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2426 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2492 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2580 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2449 (Nature)", -- [24]
						"Viper <Gato> dies.", -- [25]
						"Viper <Gato> dies.", -- [26]
						"Viper <Gato> dies.", -- [27]
						"Viper <Gato> dies.", -- [28]
						"Viper <Gato> dies.", -- [29]
						"Viper <Gato> dies.", -- [30]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["DeathAt"] = 1360560661,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"MISC", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
					},
				}, -- [7]
				{
					["MessageTimes"] = {
						-3.212999999999738, -- [1]
						-3.212999999999738, -- [2]
						-3.212999999999738, -- [3]
						-3.212999999999738, -- [4]
						-3.212999999999738, -- [5]
						-3.212999999999738, -- [6]
						-1.598999999998341, -- [7]
						-1.598999999998341, -- [8]
						-1.598999999998341, -- [9]
						-1.598999999998341, -- [10]
						-1.598999999998341, -- [11]
						-1.598999999998341, -- [12]
						-1.169999999998254, -- [13]
						-1.102999999999156, -- [14]
						-1.077999999997701, -- [15]
						-0.9209999999984575, -- [16]
						-0.6699999999982538, -- [17]
						-0.6699999999982538, -- [18]
						-0.3999999999978172, -- [19]
						-0.3999999999978172, -- [20]
						-0.3999999999978172, -- [21]
						-0.3999999999978172, -- [22]
						-0.3999999999978172, -- [23]
						-0.3999999999978172, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						true, -- [19]
						true, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Baxter Glancing -69 (Physical)", -- [3]
						"Viper <Gato> Melee Apothecary Baxter Hit -77 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Baxter Hit -78 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Baxter Hit -84 (Physical)", -- [6]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2425 (Nature)", -- [7]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2528 (Nature)", -- [8]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2576 (Nature)", -- [9]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2573 (Nature)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2533 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2422 (Nature)", -- [12]
						"Viper <Gato> Melee Apothecary Baxter Hit -76 (Physical)", -- [13]
						"Viper <Gato> Melee Apothecary Baxter Hit -78 (Physical)", -- [14]
						"Viper <Gato> Melee Apothecary Baxter Hit -79 (Physical)", -- [15]
						"Viper <Gato> Melee Apothecary Baxter Glancing -74 (Physical)", -- [16]
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [17]
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [18]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2450 (Nature)", -- [19]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -5154 (Nature)", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2426 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2492 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2580 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2449 (Nature)", -- [24]
						"Viper <Gato> dies.", -- [25]
						"Viper <Gato> dies.", -- [26]
						"Viper <Gato> dies.", -- [27]
						"Viper <Gato> dies.", -- [28]
						"Viper <Gato> dies.", -- [29]
						"Viper <Gato> dies.", -- [30]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["DeathAt"] = 1360560661,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"MISC", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
					},
				}, -- [8]
				{
					["MessageTimes"] = {
						-3.212999999999738, -- [1]
						-3.212999999999738, -- [2]
						-3.212999999999738, -- [3]
						-3.212999999999738, -- [4]
						-3.212999999999738, -- [5]
						-3.212999999999738, -- [6]
						-1.598999999998341, -- [7]
						-1.598999999998341, -- [8]
						-1.598999999998341, -- [9]
						-1.598999999998341, -- [10]
						-1.598999999998341, -- [11]
						-1.598999999998341, -- [12]
						-1.169999999998254, -- [13]
						-1.102999999999156, -- [14]
						-1.077999999997701, -- [15]
						-0.9209999999984575, -- [16]
						-0.6699999999982538, -- [17]
						-0.6699999999982538, -- [18]
						-0.3999999999978172, -- [19]
						-0.3999999999978172, -- [20]
						-0.3999999999978172, -- [21]
						-0.3999999999978172, -- [22]
						-0.3999999999978172, -- [23]
						-0.3999999999978172, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						true, -- [19]
						true, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Baxter Glancing -69 (Physical)", -- [3]
						"Viper <Gato> Melee Apothecary Baxter Hit -77 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Baxter Hit -78 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Baxter Hit -84 (Physical)", -- [6]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2425 (Nature)", -- [7]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2528 (Nature)", -- [8]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2576 (Nature)", -- [9]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2573 (Nature)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2533 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2422 (Nature)", -- [12]
						"Viper <Gato> Melee Apothecary Baxter Hit -76 (Physical)", -- [13]
						"Viper <Gato> Melee Apothecary Baxter Hit -78 (Physical)", -- [14]
						"Viper <Gato> Melee Apothecary Baxter Hit -79 (Physical)", -- [15]
						"Viper <Gato> Melee Apothecary Baxter Glancing -74 (Physical)", -- [16]
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [17]
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [18]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2450 (Nature)", -- [19]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -5154 (Nature)", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2426 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2492 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2580 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2449 (Nature)", -- [24]
						"Viper <Gato> dies.", -- [25]
						"Viper <Gato> dies.", -- [26]
						"Viper <Gato> dies.", -- [27]
						"Viper <Gato> dies.", -- [28]
						"Viper <Gato> dies.", -- [29]
						"Viper <Gato> dies.", -- [30]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["DeathAt"] = 1360560661,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"MISC", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
					},
				}, -- [9]
				{
					["MessageTimes"] = {
						-3.212999999999738, -- [1]
						-3.212999999999738, -- [2]
						-3.212999999999738, -- [3]
						-3.212999999999738, -- [4]
						-3.212999999999738, -- [5]
						-3.212999999999738, -- [6]
						-1.598999999998341, -- [7]
						-1.598999999998341, -- [8]
						-1.598999999998341, -- [9]
						-1.598999999998341, -- [10]
						-1.598999999998341, -- [11]
						-1.598999999998341, -- [12]
						-1.169999999998254, -- [13]
						-1.102999999999156, -- [14]
						-1.077999999997701, -- [15]
						-0.9209999999984575, -- [16]
						-0.6699999999982538, -- [17]
						-0.6699999999982538, -- [18]
						-0.3999999999978172, -- [19]
						-0.3999999999978172, -- [20]
						-0.3999999999978172, -- [21]
						-0.3999999999978172, -- [22]
						-0.3999999999978172, -- [23]
						-0.3999999999978172, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						true, -- [19]
						true, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Baxter Glancing -69 (Physical)", -- [3]
						"Viper <Gato> Melee Apothecary Baxter Hit -77 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Baxter Hit -78 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Baxter Hit -84 (Physical)", -- [6]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2425 (Nature)", -- [7]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2528 (Nature)", -- [8]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2576 (Nature)", -- [9]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2573 (Nature)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2533 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2422 (Nature)", -- [12]
						"Viper <Gato> Melee Apothecary Baxter Hit -76 (Physical)", -- [13]
						"Viper <Gato> Melee Apothecary Baxter Hit -78 (Physical)", -- [14]
						"Viper <Gato> Melee Apothecary Baxter Hit -79 (Physical)", -- [15]
						"Viper <Gato> Melee Apothecary Baxter Glancing -74 (Physical)", -- [16]
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [17]
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [18]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2450 (Nature)", -- [19]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -5154 (Nature)", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2426 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2492 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2580 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2449 (Nature)", -- [24]
						"Viper <Gato> dies.", -- [25]
						"Viper <Gato> dies.", -- [26]
						"Viper <Gato> dies.", -- [27]
						"Viper <Gato> dies.", -- [28]
						"Viper <Gato> dies.", -- [29]
						"Viper <Gato> dies.", -- [30]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["DeathAt"] = 1360560661,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"MISC", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
					},
				}, -- [10]
				{
					["MessageTimes"] = {
						-3.212999999999738, -- [1]
						-3.212999999999738, -- [2]
						-3.212999999999738, -- [3]
						-3.212999999999738, -- [4]
						-3.212999999999738, -- [5]
						-3.212999999999738, -- [6]
						-1.598999999998341, -- [7]
						-1.598999999998341, -- [8]
						-1.598999999998341, -- [9]
						-1.598999999998341, -- [10]
						-1.598999999998341, -- [11]
						-1.598999999998341, -- [12]
						-1.169999999998254, -- [13]
						-1.102999999999156, -- [14]
						-1.077999999997701, -- [15]
						-0.9209999999984575, -- [16]
						-0.6699999999982538, -- [17]
						-0.6699999999982538, -- [18]
						-0.3999999999978172, -- [19]
						-0.3999999999978172, -- [20]
						-0.3999999999978172, -- [21]
						-0.3999999999978172, -- [22]
						-0.3999999999978172, -- [23]
						-0.3999999999978172, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						true, -- [19]
						true, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Baxter Glancing -69 (Physical)", -- [3]
						"Viper <Gato> Melee Apothecary Baxter Hit -77 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Baxter Hit -78 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Baxter Hit -84 (Physical)", -- [6]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2425 (Nature)", -- [7]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2528 (Nature)", -- [8]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2576 (Nature)", -- [9]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2573 (Nature)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2533 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2422 (Nature)", -- [12]
						"Viper <Gato> Melee Apothecary Baxter Hit -76 (Physical)", -- [13]
						"Viper <Gato> Melee Apothecary Baxter Hit -78 (Physical)", -- [14]
						"Viper <Gato> Melee Apothecary Baxter Hit -79 (Physical)", -- [15]
						"Viper <Gato> Melee Apothecary Baxter Glancing -74 (Physical)", -- [16]
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [17]
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [18]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2450 (Nature)", -- [19]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -5154 (Nature)", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2426 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2492 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2580 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2449 (Nature)", -- [24]
						"Viper <Gato> dies.", -- [25]
						"Viper <Gato> dies.", -- [26]
						"Viper <Gato> dies.", -- [27]
						"Viper <Gato> dies.", -- [28]
						"Viper <Gato> dies.", -- [29]
						"Viper <Gato> dies.", -- [30]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["DeathAt"] = 1360560661,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"MISC", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
					},
				}, -- [11]
				{
					["MessageTimes"] = {
						-3.212999999999738, -- [1]
						-3.212999999999738, -- [2]
						-3.212999999999738, -- [3]
						-3.212999999999738, -- [4]
						-3.212999999999738, -- [5]
						-3.212999999999738, -- [6]
						-1.598999999998341, -- [7]
						-1.598999999998341, -- [8]
						-1.598999999998341, -- [9]
						-1.598999999998341, -- [10]
						-1.598999999998341, -- [11]
						-1.598999999998341, -- [12]
						-1.169999999998254, -- [13]
						-1.102999999999156, -- [14]
						-1.077999999997701, -- [15]
						-0.9209999999984575, -- [16]
						-0.6699999999982538, -- [17]
						-0.6699999999982538, -- [18]
						-0.3999999999978172, -- [19]
						-0.3999999999978172, -- [20]
						-0.3999999999978172, -- [21]
						-0.3999999999978172, -- [22]
						-0.3999999999978172, -- [23]
						-0.3999999999978172, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						true, -- [19]
						true, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Baxter Glancing -69 (Physical)", -- [3]
						"Viper <Gato> Melee Apothecary Baxter Hit -77 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Baxter Hit -78 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Baxter Hit -84 (Physical)", -- [6]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2425 (Nature)", -- [7]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2528 (Nature)", -- [8]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2576 (Nature)", -- [9]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2573 (Nature)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2533 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2422 (Nature)", -- [12]
						"Viper <Gato> Melee Apothecary Baxter Hit -76 (Physical)", -- [13]
						"Viper <Gato> Melee Apothecary Baxter Hit -78 (Physical)", -- [14]
						"Viper <Gato> Melee Apothecary Baxter Hit -79 (Physical)", -- [15]
						"Viper <Gato> Melee Apothecary Baxter Glancing -74 (Physical)", -- [16]
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [17]
						"Viper <Gato> Melee Apothecary Baxter Hit -90 (Physical)", -- [18]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2450 (Nature)", -- [19]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -5154 (Nature)", -- [20]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2426 (Nature)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2492 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2580 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2449 (Nature)", -- [24]
						"Viper <Gato> dies.", -- [25]
						"Viper <Gato> dies.", -- [26]
						"Viper <Gato> dies.", -- [27]
						"Viper <Gato> dies.", -- [28]
						"Viper <Gato> dies.", -- [29]
						"Viper <Gato> dies.", -- [30]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["DeathAt"] = 1360560661,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"MISC", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
						"MISC", -- [30]
					},
				}, -- [12]
				{
					["MessageTimes"] = {
						-4.022000000000844, -- [1]
						-4.022000000000844, -- [2]
						-4.022000000000844, -- [3]
						-4.022000000000844, -- [4]
						-4.022000000000844, -- [5]
						-4.022000000000844, -- [6]
						-2.494000000002416, -- [7]
						-2.360000000000582, -- [8]
						-2.207000000002154, -- [9]
						-2.145000000000437, -- [10]
						-2.116000000001804, -- [11]
						-2.022000000000844, -- [12]
						-1.615000000001601, -- [13]
						-1.574000000000524, -- [14]
						-1.574000000000524, -- [15]
						-1.574000000000524, -- [16]
						-1.574000000000524, -- [17]
						-1.574000000000524, -- [18]
						-1.39600000000064, -- [19]
						-1.39600000000064, -- [20]
						-0.8369999999995343, -- [21]
						-0.3899999999994179, -- [22]
						-0.3899999999994179, -- [23]
						-0.3899999999994179, -- [24]
						-0.3899999999994179, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						true, -- [16]
						true, -- [17]
						true, -- [18]
						true, -- [19]
						true, -- [20]
						false, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Hummel Hit -88 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [3]
						"Viper <Gato> Melee Apothecary Hummel Hit -80 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Hummel Glancing -71 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Hummel Crit -181 (Physical)", -- [6]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [7]
						"Viper <Gato> Melee Apothecary Hummel Hit -80 (Physical)", -- [8]
						"Viper <Gato> Melee Apothecary Hummel Glancing -68 (Physical)", -- [9]
						"Viper <Gato> Melee Apothecary Hummel Hit -87 (Physical)", -- [10]
						"Viper <Gato> Melee Apothecary Hummel Glancing -71 (Physical)", -- [11]
						"Viper <Gato> Melee Apothecary Hummel Hit -91 (Physical)", -- [12]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -5092 (Nature)", -- [13]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2447 (Nature)", -- [14]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2591 (Nature)", -- [15]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2380 (Nature)", -- [16]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -5140 (Nature)", -- [17]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2518 (Nature)", -- [18]
						"Viper <Gato> dies.", -- [19]
						"Viper <Gato> dies.", -- [20]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2413 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2555 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2533 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2465 (Nature)", -- [25]
						"Viper <Gato> dies.", -- [26]
						"Viper <Gato> dies.", -- [27]
						"Viper <Gato> dies.", -- [28]
						"Viper <Gato> dies.", -- [29]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
					},
					["DeathAt"] = 1360560626,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"MISC", -- [19]
						"MISC", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
					},
				}, -- [13]
				{
					["MessageTimes"] = {
						-4.022000000000844, -- [1]
						-4.022000000000844, -- [2]
						-4.022000000000844, -- [3]
						-4.022000000000844, -- [4]
						-4.022000000000844, -- [5]
						-4.022000000000844, -- [6]
						-2.494000000002416, -- [7]
						-2.360000000000582, -- [8]
						-2.207000000002154, -- [9]
						-2.145000000000437, -- [10]
						-2.116000000001804, -- [11]
						-2.022000000000844, -- [12]
						-1.615000000001601, -- [13]
						-1.574000000000524, -- [14]
						-1.574000000000524, -- [15]
						-1.574000000000524, -- [16]
						-1.574000000000524, -- [17]
						-1.574000000000524, -- [18]
						-1.39600000000064, -- [19]
						-1.39600000000064, -- [20]
						-0.8369999999995343, -- [21]
						-0.3899999999994179, -- [22]
						-0.3899999999994179, -- [23]
						-0.3899999999994179, -- [24]
						-0.3899999999994179, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						true, -- [16]
						true, -- [17]
						true, -- [18]
						true, -- [19]
						true, -- [20]
						false, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Hummel Hit -88 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [3]
						"Viper <Gato> Melee Apothecary Hummel Hit -80 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Hummel Glancing -71 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Hummel Crit -181 (Physical)", -- [6]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [7]
						"Viper <Gato> Melee Apothecary Hummel Hit -80 (Physical)", -- [8]
						"Viper <Gato> Melee Apothecary Hummel Glancing -68 (Physical)", -- [9]
						"Viper <Gato> Melee Apothecary Hummel Hit -87 (Physical)", -- [10]
						"Viper <Gato> Melee Apothecary Hummel Glancing -71 (Physical)", -- [11]
						"Viper <Gato> Melee Apothecary Hummel Hit -91 (Physical)", -- [12]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -5092 (Nature)", -- [13]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2447 (Nature)", -- [14]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2591 (Nature)", -- [15]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2380 (Nature)", -- [16]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -5140 (Nature)", -- [17]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2518 (Nature)", -- [18]
						"Viper <Gato> dies.", -- [19]
						"Viper <Gato> dies.", -- [20]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2413 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2555 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2533 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2465 (Nature)", -- [25]
						"Viper <Gato> dies.", -- [26]
						"Viper <Gato> dies.", -- [27]
						"Viper <Gato> dies.", -- [28]
						"Viper <Gato> dies.", -- [29]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
					},
					["DeathAt"] = 1360560626,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"MISC", -- [19]
						"MISC", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
					},
				}, -- [14]
				{
					["MessageTimes"] = {
						-4.022000000000844, -- [1]
						-4.022000000000844, -- [2]
						-4.022000000000844, -- [3]
						-4.022000000000844, -- [4]
						-4.022000000000844, -- [5]
						-4.022000000000844, -- [6]
						-2.494000000002416, -- [7]
						-2.360000000000582, -- [8]
						-2.207000000002154, -- [9]
						-2.145000000000437, -- [10]
						-2.116000000001804, -- [11]
						-2.022000000000844, -- [12]
						-1.615000000001601, -- [13]
						-1.574000000000524, -- [14]
						-1.574000000000524, -- [15]
						-1.574000000000524, -- [16]
						-1.574000000000524, -- [17]
						-1.574000000000524, -- [18]
						-1.39600000000064, -- [19]
						-1.39600000000064, -- [20]
						-0.8369999999995343, -- [21]
						-0.3899999999994179, -- [22]
						-0.3899999999994179, -- [23]
						-0.3899999999994179, -- [24]
						-0.3899999999994179, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						true, -- [16]
						true, -- [17]
						true, -- [18]
						true, -- [19]
						true, -- [20]
						false, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Hummel Hit -88 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [3]
						"Viper <Gato> Melee Apothecary Hummel Hit -80 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Hummel Glancing -71 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Hummel Crit -181 (Physical)", -- [6]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [7]
						"Viper <Gato> Melee Apothecary Hummel Hit -80 (Physical)", -- [8]
						"Viper <Gato> Melee Apothecary Hummel Glancing -68 (Physical)", -- [9]
						"Viper <Gato> Melee Apothecary Hummel Hit -87 (Physical)", -- [10]
						"Viper <Gato> Melee Apothecary Hummel Glancing -71 (Physical)", -- [11]
						"Viper <Gato> Melee Apothecary Hummel Hit -91 (Physical)", -- [12]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -5092 (Nature)", -- [13]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2447 (Nature)", -- [14]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2591 (Nature)", -- [15]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2380 (Nature)", -- [16]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -5140 (Nature)", -- [17]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2518 (Nature)", -- [18]
						"Viper <Gato> dies.", -- [19]
						"Viper <Gato> dies.", -- [20]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2413 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2555 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2533 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2465 (Nature)", -- [25]
						"Viper <Gato> dies.", -- [26]
						"Viper <Gato> dies.", -- [27]
						"Viper <Gato> dies.", -- [28]
						"Viper <Gato> dies.", -- [29]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
					},
					["DeathAt"] = 1360560626,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"MISC", -- [19]
						"MISC", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
					},
				}, -- [15]
				{
					["MessageTimes"] = {
						-4.022000000000844, -- [1]
						-4.022000000000844, -- [2]
						-4.022000000000844, -- [3]
						-4.022000000000844, -- [4]
						-4.022000000000844, -- [5]
						-4.022000000000844, -- [6]
						-2.494000000002416, -- [7]
						-2.360000000000582, -- [8]
						-2.207000000002154, -- [9]
						-2.145000000000437, -- [10]
						-2.116000000001804, -- [11]
						-2.022000000000844, -- [12]
						-1.615000000001601, -- [13]
						-1.574000000000524, -- [14]
						-1.574000000000524, -- [15]
						-1.574000000000524, -- [16]
						-1.574000000000524, -- [17]
						-1.574000000000524, -- [18]
						-1.39600000000064, -- [19]
						-1.39600000000064, -- [20]
						-0.8369999999995343, -- [21]
						-0.3899999999994179, -- [22]
						-0.3899999999994179, -- [23]
						-0.3899999999994179, -- [24]
						-0.3899999999994179, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						true, -- [16]
						true, -- [17]
						true, -- [18]
						true, -- [19]
						true, -- [20]
						false, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Hummel Hit -88 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [3]
						"Viper <Gato> Melee Apothecary Hummel Hit -80 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Hummel Glancing -71 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Hummel Crit -181 (Physical)", -- [6]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [7]
						"Viper <Gato> Melee Apothecary Hummel Hit -80 (Physical)", -- [8]
						"Viper <Gato> Melee Apothecary Hummel Glancing -68 (Physical)", -- [9]
						"Viper <Gato> Melee Apothecary Hummel Hit -87 (Physical)", -- [10]
						"Viper <Gato> Melee Apothecary Hummel Glancing -71 (Physical)", -- [11]
						"Viper <Gato> Melee Apothecary Hummel Hit -91 (Physical)", -- [12]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -5092 (Nature)", -- [13]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2447 (Nature)", -- [14]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2591 (Nature)", -- [15]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2380 (Nature)", -- [16]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -5140 (Nature)", -- [17]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2518 (Nature)", -- [18]
						"Viper <Gato> dies.", -- [19]
						"Viper <Gato> dies.", -- [20]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2413 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2555 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2533 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2465 (Nature)", -- [25]
						"Viper <Gato> dies.", -- [26]
						"Viper <Gato> dies.", -- [27]
						"Viper <Gato> dies.", -- [28]
						"Viper <Gato> dies.", -- [29]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
					},
					["DeathAt"] = 1360560626,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"MISC", -- [19]
						"MISC", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
					},
				}, -- [16]
				{
					["MessageTimes"] = {
						-2.626000000000204, -- [1]
						-2.626000000000204, -- [2]
						-2.626000000000204, -- [3]
						-2.626000000000204, -- [4]
						-2.626000000000204, -- [5]
						-2.626000000000204, -- [6]
						-1.098000000001775, -- [7]
						-0.9639999999999418, -- [8]
						-0.8110000000015134, -- [9]
						-0.7489999999997963, -- [10]
						-0.7200000000011642, -- [11]
						-0.6260000000002037, -- [12]
						-0.2190000000009604, -- [13]
						-0.1779999999998836, -- [14]
						-0.1779999999998836, -- [15]
						-0.1779999999998836, -- [16]
						-0.1779999999998836, -- [17]
						-0.1779999999998836, -- [18]
						0, -- [19]
						0, -- [20]
						0.559000000001106, -- [21]
						1.006000000001222, -- [22]
						1.006000000001222, -- [23]
						1.006000000001222, -- [24]
						1.006000000001222, -- [25]
						1.39600000000064, -- [26]
						1.39600000000064, -- [27]
						1.39600000000064, -- [28]
						1.39600000000064, -- [29]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						true, -- [16]
						true, -- [17]
						true, -- [18]
						true, -- [19]
						true, -- [20]
						false, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Hummel Hit -88 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [3]
						"Viper <Gato> Melee Apothecary Hummel Hit -80 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Hummel Glancing -71 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Hummel Crit -181 (Physical)", -- [6]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [7]
						"Viper <Gato> Melee Apothecary Hummel Hit -80 (Physical)", -- [8]
						"Viper <Gato> Melee Apothecary Hummel Glancing -68 (Physical)", -- [9]
						"Viper <Gato> Melee Apothecary Hummel Hit -87 (Physical)", -- [10]
						"Viper <Gato> Melee Apothecary Hummel Glancing -71 (Physical)", -- [11]
						"Viper <Gato> Melee Apothecary Hummel Hit -91 (Physical)", -- [12]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -5092 (Nature)", -- [13]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2447 (Nature)", -- [14]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2591 (Nature)", -- [15]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2380 (Nature)", -- [16]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -5140 (Nature)", -- [17]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2518 (Nature)", -- [18]
						"Viper <Gato> dies.", -- [19]
						"Viper <Gato> dies.", -- [20]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2413 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2555 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2533 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2465 (Nature)", -- [25]
						"Viper <Gato> dies.", -- [26]
						"Viper <Gato> dies.", -- [27]
						"Viper <Gato> dies.", -- [28]
						"Viper <Gato> dies.", -- [29]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
					},
					["DeathAt"] = 1360560625,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"MISC", -- [19]
						"MISC", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
					},
				}, -- [17]
				{
					["MessageTimes"] = {
						-2.626000000000204, -- [1]
						-2.626000000000204, -- [2]
						-2.626000000000204, -- [3]
						-2.626000000000204, -- [4]
						-2.626000000000204, -- [5]
						-2.626000000000204, -- [6]
						-1.098000000001775, -- [7]
						-0.9639999999999418, -- [8]
						-0.8110000000015134, -- [9]
						-0.7489999999997963, -- [10]
						-0.7200000000011642, -- [11]
						-0.6260000000002037, -- [12]
						-0.2190000000009604, -- [13]
						-0.1779999999998836, -- [14]
						-0.1779999999998836, -- [15]
						-0.1779999999998836, -- [16]
						-0.1779999999998836, -- [17]
						-0.1779999999998836, -- [18]
						0, -- [19]
						0, -- [20]
						0.559000000001106, -- [21]
						1.006000000001222, -- [22]
						1.006000000001222, -- [23]
						1.006000000001222, -- [24]
						1.006000000001222, -- [25]
						1.39600000000064, -- [26]
						1.39600000000064, -- [27]
						1.39600000000064, -- [28]
						1.39600000000064, -- [29]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						true, -- [16]
						true, -- [17]
						true, -- [18]
						true, -- [19]
						true, -- [20]
						false, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Hummel Hit -88 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [3]
						"Viper <Gato> Melee Apothecary Hummel Hit -80 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Hummel Glancing -71 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Hummel Crit -181 (Physical)", -- [6]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [7]
						"Viper <Gato> Melee Apothecary Hummel Hit -80 (Physical)", -- [8]
						"Viper <Gato> Melee Apothecary Hummel Glancing -68 (Physical)", -- [9]
						"Viper <Gato> Melee Apothecary Hummel Hit -87 (Physical)", -- [10]
						"Viper <Gato> Melee Apothecary Hummel Glancing -71 (Physical)", -- [11]
						"Viper <Gato> Melee Apothecary Hummel Hit -91 (Physical)", -- [12]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -5092 (Nature)", -- [13]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2447 (Nature)", -- [14]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2591 (Nature)", -- [15]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2380 (Nature)", -- [16]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -5140 (Nature)", -- [17]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2518 (Nature)", -- [18]
						"Viper <Gato> dies.", -- [19]
						"Viper <Gato> dies.", -- [20]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [21]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2413 (Nature)", -- [22]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2555 (Nature)", -- [23]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2533 (Nature)", -- [24]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2465 (Nature)", -- [25]
						"Viper <Gato> dies.", -- [26]
						"Viper <Gato> dies.", -- [27]
						"Viper <Gato> dies.", -- [28]
						"Viper <Gato> dies.", -- [29]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
					},
					["DeathAt"] = 1360560625,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"MISC", -- [19]
						"MISC", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"MISC", -- [26]
						"MISC", -- [27]
						"MISC", -- [28]
						"MISC", -- [29]
					},
				}, -- [18]
				{
					["MessageTimes"] = {
						-12.56199999999808, -- [1]
						-12.56199999999808, -- [2]
						-12.56199999999808, -- [3]
						-10.91799999999785, -- [4]
						-10.8839999999982, -- [5]
						-10.85499999999956, -- [6]
						-10.62299999999959, -- [7]
						-10.54000000000087, -- [8]
						-10.44700000000012, -- [9]
						-8.920999999998458, -- [10]
						-8.872999999999593, -- [11]
						-8.841000000000349, -- [12]
						-8.338999999999942, -- [13]
						-8.206999999998516, -- [14]
						-7.992999999998574, -- [15]
						-6.965000000000146, -- [16]
						-6.860000000000582, -- [17]
						-6.802999999999884, -- [18]
						-6.063999999998487, -- [19]
						-5.86699999999837, -- [20]
						-5.541999999997643, -- [21]
						-4.97899999999936, -- [22]
						-4.854999999999563, -- [23]
						-4.789000000000669, -- [24]
						-3.770000000000437, -- [25]
						-3.53099999999904, -- [26]
						-3.087999999999738, -- [27]
						-2.980999999999767, -- [28]
						-2.824000000000524, -- [29]
						-2.761999999998807, -- [30]
						-2.40599999999904, -- [31]
						-2.40599999999904, -- [32]
						-2.40599999999904, -- [33]
						-2.40599999999904, -- [34]
						-2.40599999999904, -- [35]
						-2.40599999999904, -- [36]
						-1.99199999999837, -- [37]
						-1.99199999999837, -- [38]
						-1.195999999999913, -- [39]
						-1.011999999998807, -- [40]
						-0.8369999999995343, -- [41]
						-0.6270000000004075, -- [42]
						-0.3879999999990105, -- [43]
						-0.3879999999990105, -- [44]
						-0.3879999999990105, -- [45]
						-0.3879999999990105, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						false, -- [23]
						false, -- [24]
						false, -- [25]
						false, -- [26]
						false, -- [27]
						false, -- [28]
						false, -- [29]
						false, -- [30]
						true, -- [31]
						true, -- [32]
						true, -- [33]
						true, -- [34]
						true, -- [35]
						true, -- [36]
						true, -- [37]
						true, -- [38]
						false, -- [39]
						false, -- [40]
						false, -- [41]
						false, -- [42]
						true, -- [43]
						true, -- [44]
						true, -- [45]
						true, -- [46]
						true, -- [47]
						true, -- [48]
						true, -- [49]
						true, -- [50]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Hummel Parry", -- [3]
						"Viper <Gato> Melee Apothecary Hummel Glancing -61 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Hummel Crit -153 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [6]
						"Viper <Gato> Melee Apothecary Hummel Hit -84 (Physical)", -- [7]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [8]
						"Viper <Gato> Melee Apothecary Hummel Hit -87 (Physical)", -- [9]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [10]
						"Viper <Gato> Melee Apothecary Hummel Glancing -64 (Physical)", -- [11]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [12]
						"Viper <Gato> Melee Apothecary Hummel Hit -83 (Physical)", -- [13]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [14]
						"Viper <Gato> Melee Apothecary Hummel Glancing -74 (Physical)", -- [15]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [16]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [17]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [18]
						"Viper <Gato> Melee Apothecary Hummel Hit -83 (Physical)", -- [19]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [20]
						"Viper <Gato> Melee Apothecary Hummel Crit -175 (Physical)", -- [21]
						"Viper <Gato> Melee Apothecary Hummel Crit -151 (Physical)", -- [22]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [23]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [24]
						"Viper <Gato> Melee Apothecary Hummel Hit -83 (Physical)", -- [25]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [26]
						"Viper <Gato> Melee Apothecary Hummel Crit -175 (Physical)", -- [27]
						"Viper <Gato> Melee Apothecary Hummel Crit -151 (Physical)", -- [28]
						"Viper <Gato> Melee Apothecary Hummel Glancing -62 (Physical)", -- [29]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [30]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2604 (Nature)", -- [31]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2397 (Nature)", -- [32]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2525 (Nature)", -- [33]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -4958 (Nature)", -- [34]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -4782 (Nature)", -- [35]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2381 (Nature)", -- [36]
						"Viper <Gato> dies.", -- [37]
						"Viper <Gato> dies.", -- [38]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [39]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [40]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [41]
						"Viper <Gato> Melee Apothecary Hummel Hit -88 (Physical)", -- [42]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2526 (Nature)", -- [43]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2565 (Nature)", -- [44]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2581 (Nature)", -- [45]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2425 (Nature)", -- [46]
						"Viper <Gato> dies.", -- [47]
						"Viper <Gato> dies.", -- [48]
						"Viper <Gato> dies.", -- [49]
						"Viper <Gato> dies.", -- [50]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["DeathAt"] = 1360560609,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
						"???", -- [45]
						"???", -- [46]
						"???", -- [47]
						"???", -- [48]
						"???", -- [49]
						"???", -- [50]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"DAMAGE", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"MISC", -- [37]
						"MISC", -- [38]
						"DAMAGE", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"DAMAGE", -- [45]
						"DAMAGE", -- [46]
						"MISC", -- [47]
						"MISC", -- [48]
						"MISC", -- [49]
						"MISC", -- [50]
					},
				}, -- [19]
				{
					["MessageTimes"] = {
						-12.56199999999808, -- [1]
						-12.56199999999808, -- [2]
						-12.56199999999808, -- [3]
						-10.91799999999785, -- [4]
						-10.8839999999982, -- [5]
						-10.85499999999956, -- [6]
						-10.62299999999959, -- [7]
						-10.54000000000087, -- [8]
						-10.44700000000012, -- [9]
						-8.920999999998458, -- [10]
						-8.872999999999593, -- [11]
						-8.841000000000349, -- [12]
						-8.338999999999942, -- [13]
						-8.206999999998516, -- [14]
						-7.992999999998574, -- [15]
						-6.965000000000146, -- [16]
						-6.860000000000582, -- [17]
						-6.802999999999884, -- [18]
						-6.063999999998487, -- [19]
						-5.86699999999837, -- [20]
						-5.541999999997643, -- [21]
						-4.97899999999936, -- [22]
						-4.854999999999563, -- [23]
						-4.789000000000669, -- [24]
						-3.770000000000437, -- [25]
						-3.53099999999904, -- [26]
						-3.087999999999738, -- [27]
						-2.980999999999767, -- [28]
						-2.824000000000524, -- [29]
						-2.761999999998807, -- [30]
						-2.40599999999904, -- [31]
						-2.40599999999904, -- [32]
						-2.40599999999904, -- [33]
						-2.40599999999904, -- [34]
						-2.40599999999904, -- [35]
						-2.40599999999904, -- [36]
						-1.99199999999837, -- [37]
						-1.99199999999837, -- [38]
						-1.195999999999913, -- [39]
						-1.011999999998807, -- [40]
						-0.8369999999995343, -- [41]
						-0.6270000000004075, -- [42]
						-0.3879999999990105, -- [43]
						-0.3879999999990105, -- [44]
						-0.3879999999990105, -- [45]
						-0.3879999999990105, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						false, -- [23]
						false, -- [24]
						false, -- [25]
						false, -- [26]
						false, -- [27]
						false, -- [28]
						false, -- [29]
						false, -- [30]
						true, -- [31]
						true, -- [32]
						true, -- [33]
						true, -- [34]
						true, -- [35]
						true, -- [36]
						true, -- [37]
						true, -- [38]
						false, -- [39]
						false, -- [40]
						false, -- [41]
						false, -- [42]
						true, -- [43]
						true, -- [44]
						true, -- [45]
						true, -- [46]
						true, -- [47]
						true, -- [48]
						true, -- [49]
						true, -- [50]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Hummel Parry", -- [3]
						"Viper <Gato> Melee Apothecary Hummel Glancing -61 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Hummel Crit -153 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [6]
						"Viper <Gato> Melee Apothecary Hummel Hit -84 (Physical)", -- [7]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [8]
						"Viper <Gato> Melee Apothecary Hummel Hit -87 (Physical)", -- [9]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [10]
						"Viper <Gato> Melee Apothecary Hummel Glancing -64 (Physical)", -- [11]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [12]
						"Viper <Gato> Melee Apothecary Hummel Hit -83 (Physical)", -- [13]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [14]
						"Viper <Gato> Melee Apothecary Hummel Glancing -74 (Physical)", -- [15]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [16]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [17]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [18]
						"Viper <Gato> Melee Apothecary Hummel Hit -83 (Physical)", -- [19]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [20]
						"Viper <Gato> Melee Apothecary Hummel Crit -175 (Physical)", -- [21]
						"Viper <Gato> Melee Apothecary Hummel Crit -151 (Physical)", -- [22]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [23]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [24]
						"Viper <Gato> Melee Apothecary Hummel Hit -83 (Physical)", -- [25]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [26]
						"Viper <Gato> Melee Apothecary Hummel Crit -175 (Physical)", -- [27]
						"Viper <Gato> Melee Apothecary Hummel Crit -151 (Physical)", -- [28]
						"Viper <Gato> Melee Apothecary Hummel Glancing -62 (Physical)", -- [29]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [30]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2604 (Nature)", -- [31]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2397 (Nature)", -- [32]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2525 (Nature)", -- [33]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -4958 (Nature)", -- [34]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -4782 (Nature)", -- [35]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2381 (Nature)", -- [36]
						"Viper <Gato> dies.", -- [37]
						"Viper <Gato> dies.", -- [38]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [39]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [40]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [41]
						"Viper <Gato> Melee Apothecary Hummel Hit -88 (Physical)", -- [42]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2526 (Nature)", -- [43]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2565 (Nature)", -- [44]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2581 (Nature)", -- [45]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2425 (Nature)", -- [46]
						"Viper <Gato> dies.", -- [47]
						"Viper <Gato> dies.", -- [48]
						"Viper <Gato> dies.", -- [49]
						"Viper <Gato> dies.", -- [50]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["DeathAt"] = 1360560609,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
						"???", -- [45]
						"???", -- [46]
						"???", -- [47]
						"???", -- [48]
						"???", -- [49]
						"???", -- [50]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"DAMAGE", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"MISC", -- [37]
						"MISC", -- [38]
						"DAMAGE", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"DAMAGE", -- [45]
						"DAMAGE", -- [46]
						"MISC", -- [47]
						"MISC", -- [48]
						"MISC", -- [49]
						"MISC", -- [50]
					},
				}, -- [20]
				{
					["MessageTimes"] = {
						-12.56199999999808, -- [1]
						-12.56199999999808, -- [2]
						-12.56199999999808, -- [3]
						-10.91799999999785, -- [4]
						-10.8839999999982, -- [5]
						-10.85499999999956, -- [6]
						-10.62299999999959, -- [7]
						-10.54000000000087, -- [8]
						-10.44700000000012, -- [9]
						-8.920999999998458, -- [10]
						-8.872999999999593, -- [11]
						-8.841000000000349, -- [12]
						-8.338999999999942, -- [13]
						-8.206999999998516, -- [14]
						-7.992999999998574, -- [15]
						-6.965000000000146, -- [16]
						-6.860000000000582, -- [17]
						-6.802999999999884, -- [18]
						-6.063999999998487, -- [19]
						-5.86699999999837, -- [20]
						-5.541999999997643, -- [21]
						-4.97899999999936, -- [22]
						-4.854999999999563, -- [23]
						-4.789000000000669, -- [24]
						-3.770000000000437, -- [25]
						-3.53099999999904, -- [26]
						-3.087999999999738, -- [27]
						-2.980999999999767, -- [28]
						-2.824000000000524, -- [29]
						-2.761999999998807, -- [30]
						-2.40599999999904, -- [31]
						-2.40599999999904, -- [32]
						-2.40599999999904, -- [33]
						-2.40599999999904, -- [34]
						-2.40599999999904, -- [35]
						-2.40599999999904, -- [36]
						-1.99199999999837, -- [37]
						-1.99199999999837, -- [38]
						-1.195999999999913, -- [39]
						-1.011999999998807, -- [40]
						-0.8369999999995343, -- [41]
						-0.6270000000004075, -- [42]
						-0.3879999999990105, -- [43]
						-0.3879999999990105, -- [44]
						-0.3879999999990105, -- [45]
						-0.3879999999990105, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						false, -- [23]
						false, -- [24]
						false, -- [25]
						false, -- [26]
						false, -- [27]
						false, -- [28]
						false, -- [29]
						false, -- [30]
						true, -- [31]
						true, -- [32]
						true, -- [33]
						true, -- [34]
						true, -- [35]
						true, -- [36]
						true, -- [37]
						true, -- [38]
						false, -- [39]
						false, -- [40]
						false, -- [41]
						false, -- [42]
						true, -- [43]
						true, -- [44]
						true, -- [45]
						true, -- [46]
						true, -- [47]
						true, -- [48]
						true, -- [49]
						true, -- [50]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Hummel Parry", -- [3]
						"Viper <Gato> Melee Apothecary Hummel Glancing -61 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Hummel Crit -153 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [6]
						"Viper <Gato> Melee Apothecary Hummel Hit -84 (Physical)", -- [7]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [8]
						"Viper <Gato> Melee Apothecary Hummel Hit -87 (Physical)", -- [9]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [10]
						"Viper <Gato> Melee Apothecary Hummel Glancing -64 (Physical)", -- [11]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [12]
						"Viper <Gato> Melee Apothecary Hummel Hit -83 (Physical)", -- [13]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [14]
						"Viper <Gato> Melee Apothecary Hummel Glancing -74 (Physical)", -- [15]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [16]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [17]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [18]
						"Viper <Gato> Melee Apothecary Hummel Hit -83 (Physical)", -- [19]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [20]
						"Viper <Gato> Melee Apothecary Hummel Crit -175 (Physical)", -- [21]
						"Viper <Gato> Melee Apothecary Hummel Crit -151 (Physical)", -- [22]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [23]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [24]
						"Viper <Gato> Melee Apothecary Hummel Hit -83 (Physical)", -- [25]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [26]
						"Viper <Gato> Melee Apothecary Hummel Crit -175 (Physical)", -- [27]
						"Viper <Gato> Melee Apothecary Hummel Crit -151 (Physical)", -- [28]
						"Viper <Gato> Melee Apothecary Hummel Glancing -62 (Physical)", -- [29]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [30]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2604 (Nature)", -- [31]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2397 (Nature)", -- [32]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2525 (Nature)", -- [33]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -4958 (Nature)", -- [34]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -4782 (Nature)", -- [35]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2381 (Nature)", -- [36]
						"Viper <Gato> dies.", -- [37]
						"Viper <Gato> dies.", -- [38]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [39]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [40]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [41]
						"Viper <Gato> Melee Apothecary Hummel Hit -88 (Physical)", -- [42]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2526 (Nature)", -- [43]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2565 (Nature)", -- [44]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2581 (Nature)", -- [45]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2425 (Nature)", -- [46]
						"Viper <Gato> dies.", -- [47]
						"Viper <Gato> dies.", -- [48]
						"Viper <Gato> dies.", -- [49]
						"Viper <Gato> dies.", -- [50]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["DeathAt"] = 1360560609,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
						"???", -- [45]
						"???", -- [46]
						"???", -- [47]
						"???", -- [48]
						"???", -- [49]
						"???", -- [50]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"DAMAGE", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"MISC", -- [37]
						"MISC", -- [38]
						"DAMAGE", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"DAMAGE", -- [45]
						"DAMAGE", -- [46]
						"MISC", -- [47]
						"MISC", -- [48]
						"MISC", -- [49]
						"MISC", -- [50]
					},
				}, -- [21]
				{
					["MessageTimes"] = {
						-12.56199999999808, -- [1]
						-12.56199999999808, -- [2]
						-12.56199999999808, -- [3]
						-10.91799999999785, -- [4]
						-10.8839999999982, -- [5]
						-10.85499999999956, -- [6]
						-10.62299999999959, -- [7]
						-10.54000000000087, -- [8]
						-10.44700000000012, -- [9]
						-8.920999999998458, -- [10]
						-8.872999999999593, -- [11]
						-8.841000000000349, -- [12]
						-8.338999999999942, -- [13]
						-8.206999999998516, -- [14]
						-7.992999999998574, -- [15]
						-6.965000000000146, -- [16]
						-6.860000000000582, -- [17]
						-6.802999999999884, -- [18]
						-6.063999999998487, -- [19]
						-5.86699999999837, -- [20]
						-5.541999999997643, -- [21]
						-4.97899999999936, -- [22]
						-4.854999999999563, -- [23]
						-4.789000000000669, -- [24]
						-3.770000000000437, -- [25]
						-3.53099999999904, -- [26]
						-3.087999999999738, -- [27]
						-2.980999999999767, -- [28]
						-2.824000000000524, -- [29]
						-2.761999999998807, -- [30]
						-2.40599999999904, -- [31]
						-2.40599999999904, -- [32]
						-2.40599999999904, -- [33]
						-2.40599999999904, -- [34]
						-2.40599999999904, -- [35]
						-2.40599999999904, -- [36]
						-1.99199999999837, -- [37]
						-1.99199999999837, -- [38]
						-1.195999999999913, -- [39]
						-1.011999999998807, -- [40]
						-0.8369999999995343, -- [41]
						-0.6270000000004075, -- [42]
						-0.3879999999990105, -- [43]
						-0.3879999999990105, -- [44]
						-0.3879999999990105, -- [45]
						-0.3879999999990105, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						false, -- [23]
						false, -- [24]
						false, -- [25]
						false, -- [26]
						false, -- [27]
						false, -- [28]
						false, -- [29]
						false, -- [30]
						true, -- [31]
						true, -- [32]
						true, -- [33]
						true, -- [34]
						true, -- [35]
						true, -- [36]
						true, -- [37]
						true, -- [38]
						false, -- [39]
						false, -- [40]
						false, -- [41]
						false, -- [42]
						true, -- [43]
						true, -- [44]
						true, -- [45]
						true, -- [46]
						true, -- [47]
						true, -- [48]
						true, -- [49]
						true, -- [50]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Hummel Parry", -- [3]
						"Viper <Gato> Melee Apothecary Hummel Glancing -61 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Hummel Crit -153 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [6]
						"Viper <Gato> Melee Apothecary Hummel Hit -84 (Physical)", -- [7]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [8]
						"Viper <Gato> Melee Apothecary Hummel Hit -87 (Physical)", -- [9]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [10]
						"Viper <Gato> Melee Apothecary Hummel Glancing -64 (Physical)", -- [11]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [12]
						"Viper <Gato> Melee Apothecary Hummel Hit -83 (Physical)", -- [13]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [14]
						"Viper <Gato> Melee Apothecary Hummel Glancing -74 (Physical)", -- [15]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [16]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [17]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [18]
						"Viper <Gato> Melee Apothecary Hummel Hit -83 (Physical)", -- [19]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [20]
						"Viper <Gato> Melee Apothecary Hummel Crit -175 (Physical)", -- [21]
						"Viper <Gato> Melee Apothecary Hummel Crit -151 (Physical)", -- [22]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [23]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [24]
						"Viper <Gato> Melee Apothecary Hummel Hit -83 (Physical)", -- [25]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [26]
						"Viper <Gato> Melee Apothecary Hummel Crit -175 (Physical)", -- [27]
						"Viper <Gato> Melee Apothecary Hummel Crit -151 (Physical)", -- [28]
						"Viper <Gato> Melee Apothecary Hummel Glancing -62 (Physical)", -- [29]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [30]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2604 (Nature)", -- [31]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2397 (Nature)", -- [32]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2525 (Nature)", -- [33]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -4958 (Nature)", -- [34]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -4782 (Nature)", -- [35]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2381 (Nature)", -- [36]
						"Viper <Gato> dies.", -- [37]
						"Viper <Gato> dies.", -- [38]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [39]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [40]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [41]
						"Viper <Gato> Melee Apothecary Hummel Hit -88 (Physical)", -- [42]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2526 (Nature)", -- [43]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2565 (Nature)", -- [44]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2581 (Nature)", -- [45]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2425 (Nature)", -- [46]
						"Viper <Gato> dies.", -- [47]
						"Viper <Gato> dies.", -- [48]
						"Viper <Gato> dies.", -- [49]
						"Viper <Gato> dies.", -- [50]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["DeathAt"] = 1360560609,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
						"???", -- [45]
						"???", -- [46]
						"???", -- [47]
						"???", -- [48]
						"???", -- [49]
						"???", -- [50]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"DAMAGE", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"MISC", -- [37]
						"MISC", -- [38]
						"DAMAGE", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"DAMAGE", -- [45]
						"DAMAGE", -- [46]
						"MISC", -- [47]
						"MISC", -- [48]
						"MISC", -- [49]
						"MISC", -- [50]
					},
				}, -- [22]
				{
					["MessageTimes"] = {
						-10.56999999999971, -- [1]
						-10.56999999999971, -- [2]
						-10.56999999999971, -- [3]
						-8.925999999999476, -- [4]
						-8.891999999999825, -- [5]
						-8.863000000001193, -- [6]
						-8.631000000001222, -- [7]
						-8.548000000002503, -- [8]
						-8.455000000001746, -- [9]
						-6.929000000000087, -- [10]
						-6.881000000001222, -- [11]
						-6.849000000001979, -- [12]
						-6.347000000001572, -- [13]
						-6.215000000000146, -- [14]
						-6.001000000000204, -- [15]
						-4.973000000001775, -- [16]
						-4.868000000002212, -- [17]
						-4.811000000001513, -- [18]
						-4.072000000000116, -- [19]
						-3.875, -- [20]
						-3.549999999999272, -- [21]
						-2.98700000000099, -- [22]
						-2.863000000001193, -- [23]
						-2.797000000002299, -- [24]
						-1.778000000002066, -- [25]
						-1.539000000000669, -- [26]
						-1.096000000001368, -- [27]
						-0.989000000001397, -- [28]
						-0.8320000000021537, -- [29]
						-0.7700000000004366, -- [30]
						-0.4140000000006694, -- [31]
						-0.4140000000006694, -- [32]
						-0.4140000000006694, -- [33]
						-0.4140000000006694, -- [34]
						-0.4140000000006694, -- [35]
						-0.4140000000006694, -- [36]
						0, -- [37]
						0, -- [38]
						0.7959999999984575, -- [39]
						0.9799999999995634, -- [40]
						1.154999999998836, -- [41]
						1.364999999997963, -- [42]
						1.60399999999936, -- [43]
						1.60399999999936, -- [44]
						1.60399999999936, -- [45]
						1.60399999999936, -- [46]
						1.99199999999837, -- [47]
						1.99199999999837, -- [48]
						1.99199999999837, -- [49]
						1.99199999999837, -- [50]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						false, -- [23]
						false, -- [24]
						false, -- [25]
						false, -- [26]
						false, -- [27]
						false, -- [28]
						false, -- [29]
						false, -- [30]
						true, -- [31]
						true, -- [32]
						true, -- [33]
						true, -- [34]
						true, -- [35]
						true, -- [36]
						true, -- [37]
						true, -- [38]
						false, -- [39]
						false, -- [40]
						false, -- [41]
						false, -- [42]
						true, -- [43]
						true, -- [44]
						true, -- [45]
						true, -- [46]
						true, -- [47]
						true, -- [48]
						true, -- [49]
						true, -- [50]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Hummel Parry", -- [3]
						"Viper <Gato> Melee Apothecary Hummel Glancing -61 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Hummel Crit -153 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [6]
						"Viper <Gato> Melee Apothecary Hummel Hit -84 (Physical)", -- [7]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [8]
						"Viper <Gato> Melee Apothecary Hummel Hit -87 (Physical)", -- [9]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [10]
						"Viper <Gato> Melee Apothecary Hummel Glancing -64 (Physical)", -- [11]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [12]
						"Viper <Gato> Melee Apothecary Hummel Hit -83 (Physical)", -- [13]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [14]
						"Viper <Gato> Melee Apothecary Hummel Glancing -74 (Physical)", -- [15]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [16]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [17]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [18]
						"Viper <Gato> Melee Apothecary Hummel Hit -83 (Physical)", -- [19]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [20]
						"Viper <Gato> Melee Apothecary Hummel Crit -175 (Physical)", -- [21]
						"Viper <Gato> Melee Apothecary Hummel Crit -151 (Physical)", -- [22]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [23]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [24]
						"Viper <Gato> Melee Apothecary Hummel Hit -83 (Physical)", -- [25]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [26]
						"Viper <Gato> Melee Apothecary Hummel Crit -175 (Physical)", -- [27]
						"Viper <Gato> Melee Apothecary Hummel Crit -151 (Physical)", -- [28]
						"Viper <Gato> Melee Apothecary Hummel Glancing -62 (Physical)", -- [29]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [30]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2604 (Nature)", -- [31]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2397 (Nature)", -- [32]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2525 (Nature)", -- [33]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -4958 (Nature)", -- [34]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -4782 (Nature)", -- [35]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2381 (Nature)", -- [36]
						"Viper <Gato> dies.", -- [37]
						"Viper <Gato> dies.", -- [38]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [39]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [40]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [41]
						"Viper <Gato> Melee Apothecary Hummel Hit -88 (Physical)", -- [42]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2526 (Nature)", -- [43]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2565 (Nature)", -- [44]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2581 (Nature)", -- [45]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2425 (Nature)", -- [46]
						"Viper <Gato> dies.", -- [47]
						"Viper <Gato> dies.", -- [48]
						"Viper <Gato> dies.", -- [49]
						"Viper <Gato> dies.", -- [50]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["DeathAt"] = 1360560607,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
						"???", -- [45]
						"???", -- [46]
						"???", -- [47]
						"???", -- [48]
						"???", -- [49]
						"???", -- [50]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"DAMAGE", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"MISC", -- [37]
						"MISC", -- [38]
						"DAMAGE", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"DAMAGE", -- [45]
						"DAMAGE", -- [46]
						"MISC", -- [47]
						"MISC", -- [48]
						"MISC", -- [49]
						"MISC", -- [50]
					},
				}, -- [23]
				{
					["MessageTimes"] = {
						-10.56999999999971, -- [1]
						-10.56999999999971, -- [2]
						-10.56999999999971, -- [3]
						-8.925999999999476, -- [4]
						-8.891999999999825, -- [5]
						-8.863000000001193, -- [6]
						-8.631000000001222, -- [7]
						-8.548000000002503, -- [8]
						-8.455000000001746, -- [9]
						-6.929000000000087, -- [10]
						-6.881000000001222, -- [11]
						-6.849000000001979, -- [12]
						-6.347000000001572, -- [13]
						-6.215000000000146, -- [14]
						-6.001000000000204, -- [15]
						-4.973000000001775, -- [16]
						-4.868000000002212, -- [17]
						-4.811000000001513, -- [18]
						-4.072000000000116, -- [19]
						-3.875, -- [20]
						-3.549999999999272, -- [21]
						-2.98700000000099, -- [22]
						-2.863000000001193, -- [23]
						-2.797000000002299, -- [24]
						-1.778000000002066, -- [25]
						-1.539000000000669, -- [26]
						-1.096000000001368, -- [27]
						-0.989000000001397, -- [28]
						-0.8320000000021537, -- [29]
						-0.7700000000004366, -- [30]
						-0.4140000000006694, -- [31]
						-0.4140000000006694, -- [32]
						-0.4140000000006694, -- [33]
						-0.4140000000006694, -- [34]
						-0.4140000000006694, -- [35]
						-0.4140000000006694, -- [36]
						0, -- [37]
						0, -- [38]
						0.7959999999984575, -- [39]
						0.9799999999995634, -- [40]
						1.154999999998836, -- [41]
						1.364999999997963, -- [42]
						1.60399999999936, -- [43]
						1.60399999999936, -- [44]
						1.60399999999936, -- [45]
						1.60399999999936, -- [46]
						1.99199999999837, -- [47]
						1.99199999999837, -- [48]
						1.99199999999837, -- [49]
						1.99199999999837, -- [50]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						false, -- [11]
						false, -- [12]
						false, -- [13]
						false, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						false, -- [23]
						false, -- [24]
						false, -- [25]
						false, -- [26]
						false, -- [27]
						false, -- [28]
						false, -- [29]
						false, -- [30]
						true, -- [31]
						true, -- [32]
						true, -- [33]
						true, -- [34]
						true, -- [35]
						true, -- [36]
						true, -- [37]
						true, -- [38]
						false, -- [39]
						false, -- [40]
						false, -- [41]
						false, -- [42]
						true, -- [43]
						true, -- [44]
						true, -- [45]
						true, -- [46]
						true, -- [47]
						true, -- [48]
						true, -- [49]
						true, -- [50]
					},
					["Messages"] = {
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [1]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [2]
						"Viper <Gato> Melee Apothecary Hummel Parry", -- [3]
						"Viper <Gato> Melee Apothecary Hummel Glancing -61 (Physical)", -- [4]
						"Viper <Gato> Melee Apothecary Hummel Crit -153 (Physical)", -- [5]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [6]
						"Viper <Gato> Melee Apothecary Hummel Hit -84 (Physical)", -- [7]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [8]
						"Viper <Gato> Melee Apothecary Hummel Hit -87 (Physical)", -- [9]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [10]
						"Viper <Gato> Melee Apothecary Hummel Glancing -64 (Physical)", -- [11]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [12]
						"Viper <Gato> Melee Apothecary Hummel Hit -83 (Physical)", -- [13]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [14]
						"Viper <Gato> Melee Apothecary Hummel Glancing -74 (Physical)", -- [15]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [16]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [17]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [18]
						"Viper <Gato> Melee Apothecary Hummel Hit -83 (Physical)", -- [19]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [20]
						"Viper <Gato> Melee Apothecary Hummel Crit -175 (Physical)", -- [21]
						"Viper <Gato> Melee Apothecary Hummel Crit -151 (Physical)", -- [22]
						"Viper <Gato> Melee Apothecary Hummel Hit -76 (Physical)", -- [23]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [24]
						"Viper <Gato> Melee Apothecary Hummel Hit -83 (Physical)", -- [25]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [26]
						"Viper <Gato> Melee Apothecary Hummel Crit -175 (Physical)", -- [27]
						"Viper <Gato> Melee Apothecary Hummel Crit -151 (Physical)", -- [28]
						"Viper <Gato> Melee Apothecary Hummel Glancing -62 (Physical)", -- [29]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [30]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2604 (Nature)", -- [31]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2397 (Nature)", -- [32]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2525 (Nature)", -- [33]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -4958 (Nature)", -- [34]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Crit -4782 (Nature)", -- [35]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2381 (Nature)", -- [36]
						"Viper <Gato> dies.", -- [37]
						"Viper <Gato> dies.", -- [38]
						"Viper <Gato> Melee Apothecary Hummel Hit -85 (Physical)", -- [39]
						"Viper <Gato> Melee Apothecary Hummel Hit -75 (Physical)", -- [40]
						"Viper <Gato> Melee Apothecary Hummel Hit -77 (Physical)", -- [41]
						"Viper <Gato> Melee Apothecary Hummel Hit -88 (Physical)", -- [42]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2526 (Nature)", -- [43]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2565 (Nature)", -- [44]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2581 (Nature)", -- [45]
						"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2425 (Nature)", -- [46]
						"Viper <Gato> dies.", -- [47]
						"Viper <Gato> dies.", -- [48]
						"Viper <Gato> dies.", -- [49]
						"Viper <Gato> dies.", -- [50]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["DeathAt"] = 1360560607,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
						"???", -- [45]
						"???", -- [46]
						"???", -- [47]
						"???", -- [48]
						"???", -- [49]
						"???", -- [50]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"DAMAGE", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"MISC", -- [37]
						"MISC", -- [38]
						"DAMAGE", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"DAMAGE", -- [45]
						"DAMAGE", -- [46]
						"MISC", -- [47]
						"MISC", -- [48]
						"MISC", -- [49]
						"MISC", -- [50]
					},
				}, -- [24]
			},
			["LastEventTimes"] = {
				20842.629, -- [1]
				20842.629, -- [2]
				20842.629, -- [3]
				20842.629, -- [4]
				20842.629, -- [5]
				20842.629, -- [6]
				20843.029, -- [7]
				20843.029, -- [8]
				20843.029, -- [9]
				20843.029, -- [10]
				20843.029, -- [11]
				20843.029, -- [12]
				20870.078, -- [13]
				20870.078, -- [14]
				20870.078, -- [15]
				20870.078, -- [16]
				20870.078, -- [17]
				20870.078, -- [18]
				20871.991, -- [19]
				20871.991, -- [20]
				20871.991, -- [21]
				20871.991, -- [22]
				20871.991, -- [23]
				20871.991, -- [24]
				20872.116, -- [25]
				20872.307, -- [26]
				20872.463, -- [27]
				20872.485, -- [28]
				20872.485, -- [29]
				20872.531, -- [30]
				20873.201, -- [31]
				20873.998, -- [32]
				20874.027, -- [33]
				20874.027, -- [34]
				20874.027, -- [35]
				20874.027, -- [36]
				20874.027, -- [37]
				20874.406, -- [38]
				20874.406, -- [39]
				20874.406, -- [40]
				20874.406, -- [41]
				20874.406, -- [42]
				20874.406, -- [43]
				20875.183, -- [44]
				20877.191, -- [45]
				20879.182, -- [46]
				20881.182, -- [47]
				20883.199, -- [48]
				20842.359, -- [49]
				20842.359, -- [50]
			},
			["LastAbility"] = 102142.251,
		},
		["Baron Ashbury"] = {
			["GUID"] = "0xF150B7720001ACEC",
			["type"] = "Trivial",
			["FightsSaved"] = 5,
			["LastAttackedBy"] = "Kardinalsinn-Barthilas",
			["Owner"] = false,
			["enClass"] = "MOB",
			["LastDamageTaken"] = 21534,
			["LastAbility"] = 102142.251,
			["LastFightIn"] = 1,
			["Name"] = "Baron Ashbury",
			["UnitLockout"] = 1360560531,
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["WhoDamaged"] = {
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Penance"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
				},
				["OverallData"] = {
					["WhoDamaged"] = {
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Penance"] = {
									["count"] = 21534,
								},
							},
							["amount"] = 21534,
						},
					},
				},
			},
			["level"] = 21,
			["LastDamageAbility"] = "Penance",
			["LastActive"] = 1360560531,
		},
		["Mirror Image <Uboblorick-Nagrand>"] = {
			["GUID"] = "0xF130B88C0001B131",
			["LastEventHealth"] = {
				"???", -- [1]
				"???", -- [2]
				"???", -- [3]
				"???", -- [4]
				"???", -- [5]
				"???", -- [6]
				"???", -- [7]
				"???", -- [8]
				"???", -- [9]
				"???", -- [10]
				"???", -- [11]
				"???", -- [12]
				"???", -- [13]
				"???", -- [14]
				"???", -- [15]
				"???", -- [16]
				"???", -- [17]
				"???", -- [18]
				"???", -- [19]
				"???", -- [20]
				"???", -- [21]
				"???", -- [22]
				"???", -- [23]
				"???", -- [24]
				"???", -- [25]
				"???", -- [26]
				"???", -- [27]
				"???", -- [28]
				"???", -- [29]
				"???", -- [30]
				"???", -- [31]
				"???", -- [32]
				"???", -- [33]
				"???", -- [34]
				"???", -- [35]
				"???", -- [36]
				"???", -- [37]
				"???", -- [38]
				"???", -- [39]
				"???", -- [40]
				"???", -- [41]
				"???", -- [42]
				"???", -- [43]
				"???", -- [44]
				"???", -- [45]
				"???", -- [46]
				"???", -- [47]
				"???", -- [48]
				"???", -- [49]
				"???", -- [50]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"HEAL", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"HEAL", -- [32]
				"HEAL", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"HEAL", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"HEAL", -- [46]
				"MISC", -- [47]
				"MISC", -- [48]
				"MISC", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["HealingTaken"] = {
					14456, -- [1]
				},
				["ActiveTime"] = {
					29.43000000000001, -- [1]
				},
				["DeathCount"] = {
					3, -- [1]
				},
				["TimeDamage"] = {
					29.43000000000001, -- [1]
				},
				["Damage"] = {
					147143, -- [1]
				},
			},
			["enClass"] = "PET",
			["level"] = 1,
			["LastFightIn"] = 1,
			["type"] = "Pet",
			["FightsSaved"] = 5,
			["LastActive"] = 1360560623,
			["UnitLockout"] = 1360560624,
			["Owner"] = "Uboblorick-Nagrand",
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["HealingTaken"] = 0,
					["TimeSpent"] = {
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["ElementDone"] = {
						["Fire"] = 0,
					},
					["DeathCount"] = 0,
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["Fireball"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Damage"] = 0,
				},
				["OverallData"] = {
					["HealingTaken"] = 14456,
					["TimeSpent"] = {
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 29.43000000000001,
								},
							},
							["amount"] = 29.43000000000001,
						},
					},
					["WhoHealed"] = {
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 14456,
								},
							},
							["amount"] = 14456,
						},
					},
					["ActiveTime"] = 29.43000000000001,
					["ElementDone"] = {
						["Fire"] = 147143,
					},
					["DeathCount"] = 3,
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 7,
								},
								["Hit"] = {
									["count"] = 29,
								},
							},
							["amount"] = 36,
						},
					},
					["TimeDamage"] = 29.43000000000001,
					["TimeDamaging"] = {
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 29.43000000000001,
								},
							},
							["amount"] = 29.43000000000001,
						},
					},
					["Attacks"] = {
						["Fireball"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7146,
									["min"] = 6791,
									["count"] = 7,
									["amount"] = 48516,
								},
								["Hit"] = {
									["max"] = 3638,
									["min"] = 3162,
									["count"] = 29,
									["amount"] = 98627,
								},
							},
							["count"] = 36,
							["amount"] = 147143,
						},
					},
					["DamagedWho"] = {
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 147143,
								},
							},
							["amount"] = 147143,
						},
					},
					["Damage"] = 147143,
				},
			},
			["NextEventNum"] = 50,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
				0, -- [5]
				0, -- [6]
				0, -- [7]
				0, -- [8]
				0, -- [9]
				0, -- [10]
				0, -- [11]
				0, -- [12]
				0, -- [13]
				0, -- [14]
				0, -- [15]
				0, -- [16]
				0, -- [17]
				0, -- [18]
				0, -- [19]
				0, -- [20]
				0, -- [21]
				0, -- [22]
				0, -- [23]
				0, -- [24]
				0, -- [25]
				0, -- [26]
				0, -- [27]
				0, -- [28]
				0, -- [29]
				0, -- [30]
				0, -- [31]
				0, -- [32]
				0, -- [33]
				0, -- [34]
				0, -- [35]
				0, -- [36]
				0, -- [37]
				0, -- [38]
				0, -- [39]
				0, -- [40]
				0, -- [41]
				0, -- [42]
				0, -- [43]
				0, -- [44]
				0, -- [45]
				0, -- [46]
				0, -- [47]
				0, -- [48]
				0, -- [49]
				0, -- [50]
			},
			["LastEvents"] = {
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -542 (Nature)", -- [1]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -249 (Nature)", -- [2]
				"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Crit -6938 (Fire)", -- [3]
				"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3207 (Fire)", -- [4]
				"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3334 (Fire)", -- [5]
				"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -250 (Nature)", -- [6]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -484 (Nature)", -- [7]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -235 (Nature)", -- [8]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -546 (Nature)", -- [9]
				"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -249 (Nature)", -- [10]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -273 (Nature)", -- [11]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -268 (Nature)", -- [12]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -236 (Nature)", -- [13]
				"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3537 (Fire)", -- [14]
				"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3339 (Fire)", -- [15]
				"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3231 (Fire)", -- [16]
				"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -251 (Nature)", -- [17]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -270 (Nature)", -- [18]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -232 (Nature)", -- [19]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -548 (Nature)", -- [20]
				"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +26800 (19923 overheal)", -- [21]
				"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -258 (Nature)", -- [22]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -270 (Nature)", -- [23]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -270 (Nature)", -- [24]
				"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3638 (Fire)", -- [25]
				"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3606 (Fire)", -- [26]
				"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3465 (Fire)", -- [27]
				"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -251 (Nature)", -- [28]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -482 (Nature)", -- [29]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -255 (Nature)", -- [30]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -245 (Nature)", -- [31]
				"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +35343 (31729 overheal)", -- [32]
				"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +34108 (34108 overheal)", -- [33]
				"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -244 (Nature)", -- [34]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -238 (Nature)", -- [35]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -239 (Nature)", -- [36]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -548 (Nature)", -- [37]
				"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +1030", -- [38]
				"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Crit -490 (Nature)", -- [39]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -272 (Nature)", -- [40]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -232 (Nature)", -- [41]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -539 (Nature)", -- [42]
				"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Crit -6924 (Fire)", -- [43]
				"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3221 (Fire)", -- [44]
				"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3254 (Fire)", -- [45]
				"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +35394 (32459 overheal)", -- [46]
				"Mirror Image <Uboblorick-Nagrand> dies.", -- [47]
				"Mirror Image <Uboblorick-Nagrand> dies.", -- [48]
				"Mirror Image <Uboblorick-Nagrand> dies.", -- [49]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -272 (Nature)", -- [50]
			},
			["Name"] = "Mirror Image",
			["TimeLast"] = {
				["HealingTaken"] = 1360560623,
				["ActiveTime"] = 1360560623,
				["DeathCount"] = 1360560624,
				["OVERALL"] = 1360560624,
				["TimeDamage"] = 1360560623,
				["Damage"] = 1360560623,
			},
			["LastEventIncoming"] = {
				true, -- [1]
				true, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				true, -- [6]
				true, -- [7]
				true, -- [8]
				true, -- [9]
				true, -- [10]
				true, -- [11]
				true, -- [12]
				true, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				true, -- [17]
				true, -- [18]
				true, -- [19]
				true, -- [20]
				true, -- [21]
				true, -- [22]
				true, -- [23]
				true, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				true, -- [28]
				true, -- [29]
				true, -- [30]
				true, -- [31]
				true, -- [32]
				true, -- [33]
				true, -- [34]
				true, -- [35]
				true, -- [36]
				true, -- [37]
				true, -- [38]
				true, -- [39]
				true, -- [40]
				true, -- [41]
				true, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				true, -- [46]
				true, -- [47]
				true, -- [48]
				true, -- [49]
				true, -- [50]
			},
			["DeathLogs"] = {
				{
					["MessageTimes"] = {
						-8.052999999999884, -- [1]
						-8.052999999999884, -- [2]
						-8.052999999999884, -- [3]
						-7.913000000000466, -- [4]
						-7.769000000000233, -- [5]
						-7.741000000001804, -- [6]
						-6.848000000001775, -- [7]
						-6.848000000001775, -- [8]
						-6.848000000001775, -- [9]
						-6.848000000001775, -- [10]
						-6.046000000002096, -- [11]
						-6.046000000002096, -- [12]
						-6.046000000002096, -- [13]
						-6.046000000002096, -- [14]
						-5.481999999999971, -- [15]
						-5.347000000001572, -- [16]
						-5.347000000001572, -- [17]
						-4.807000000000699, -- [18]
						-4.807000000000699, -- [19]
						-4.807000000000699, -- [20]
						-4.807000000000699, -- [21]
						-4.039000000000669, -- [22]
						-4.039000000000669, -- [23]
						-4.039000000000669, -- [24]
						-4.039000000000669, -- [25]
						-3.076000000000931, -- [26]
						-2.933000000000902, -- [27]
						-2.933000000000902, -- [28]
						-2.816999999999098, -- [29]
						-2.816999999999098, -- [30]
						-2.816999999999098, -- [31]
						-2.816999999999098, -- [32]
						-1.98700000000099, -- [33]
						-1.98700000000099, -- [34]
						-1.98700000000099, -- [35]
						-1.98700000000099, -- [36]
						-1.98700000000099, -- [37]
						-1.98700000000099, -- [38]
						-0.8100000000013097, -- [39]
						-0.8100000000013097, -- [40]
						-0.8100000000013097, -- [41]
						-0.8100000000013097, -- [42]
						-0.8100000000013097, -- [43]
						-0.6530000000020664, -- [44]
						-0.4989999999997963, -- [45]
						-0.4989999999997963, -- [46]
						-0.3960000000006403, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["MessageIncoming"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						true, -- [13]
						true, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						true, -- [18]
						true, -- [19]
						true, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						false, -- [26]
						false, -- [27]
						false, -- [28]
						true, -- [29]
						true, -- [30]
						true, -- [31]
						true, -- [32]
						true, -- [33]
						true, -- [34]
						true, -- [35]
						true, -- [36]
						true, -- [37]
						true, -- [38]
						true, -- [39]
						true, -- [40]
						true, -- [41]
						true, -- [42]
						true, -- [43]
						false, -- [44]
						false, -- [45]
						false, -- [46]
						true, -- [47]
						true, -- [48]
						true, -- [49]
						true, -- [50]
					},
					["Messages"] = {
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -272 (Nature)", -- [1]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -542 (Nature)", -- [2]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -249 (Nature)", -- [3]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Crit -6938 (Fire)", -- [4]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3207 (Fire)", -- [5]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3334 (Fire)", -- [6]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -250 (Nature)", -- [7]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -484 (Nature)", -- [8]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -235 (Nature)", -- [9]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -546 (Nature)", -- [10]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -249 (Nature)", -- [11]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -273 (Nature)", -- [12]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -268 (Nature)", -- [13]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -236 (Nature)", -- [14]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3537 (Fire)", -- [15]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3339 (Fire)", -- [16]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3231 (Fire)", -- [17]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -251 (Nature)", -- [18]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -270 (Nature)", -- [19]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -232 (Nature)", -- [20]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -548 (Nature)", -- [21]
						"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +26800 (19923 overheal)", -- [22]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -258 (Nature)", -- [23]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -270 (Nature)", -- [24]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -270 (Nature)", -- [25]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3638 (Fire)", -- [26]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3606 (Fire)", -- [27]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3465 (Fire)", -- [28]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -251 (Nature)", -- [29]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -482 (Nature)", -- [30]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -255 (Nature)", -- [31]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -245 (Nature)", -- [32]
						"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +35343 (31729 overheal)", -- [33]
						"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +34108 (34108 overheal)", -- [34]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -244 (Nature)", -- [35]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -238 (Nature)", -- [36]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -239 (Nature)", -- [37]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -548 (Nature)", -- [38]
						"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +1030", -- [39]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Crit -490 (Nature)", -- [40]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -272 (Nature)", -- [41]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -232 (Nature)", -- [42]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -539 (Nature)", -- [43]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Crit -6924 (Fire)", -- [44]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3221 (Fire)", -- [45]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3254 (Fire)", -- [46]
						"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +35394 (32459 overheal)", -- [47]
						"Mirror Image <Uboblorick-Nagrand> dies.", -- [48]
						"Mirror Image <Uboblorick-Nagrand> dies.", -- [49]
						"Mirror Image <Uboblorick-Nagrand> dies.", -- [50]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["DeathAt"] = 1360560626,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
						"???", -- [45]
						"???", -- [46]
						"???", -- [47]
						"???", -- [48]
						"???", -- [49]
						"???", -- [50]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"HEAL", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"HEAL", -- [33]
						"HEAL", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"HEAL", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"DAMAGE", -- [45]
						"DAMAGE", -- [46]
						"HEAL", -- [47]
						"MISC", -- [48]
						"MISC", -- [49]
						"MISC", -- [50]
					},
				}, -- [1]
				{
					["MessageTimes"] = {
						-8.052999999999884, -- [1]
						-8.052999999999884, -- [2]
						-8.052999999999884, -- [3]
						-7.913000000000466, -- [4]
						-7.769000000000233, -- [5]
						-7.741000000001804, -- [6]
						-6.848000000001775, -- [7]
						-6.848000000001775, -- [8]
						-6.848000000001775, -- [9]
						-6.848000000001775, -- [10]
						-6.046000000002096, -- [11]
						-6.046000000002096, -- [12]
						-6.046000000002096, -- [13]
						-6.046000000002096, -- [14]
						-5.481999999999971, -- [15]
						-5.347000000001572, -- [16]
						-5.347000000001572, -- [17]
						-4.807000000000699, -- [18]
						-4.807000000000699, -- [19]
						-4.807000000000699, -- [20]
						-4.807000000000699, -- [21]
						-4.039000000000669, -- [22]
						-4.039000000000669, -- [23]
						-4.039000000000669, -- [24]
						-4.039000000000669, -- [25]
						-3.076000000000931, -- [26]
						-2.933000000000902, -- [27]
						-2.933000000000902, -- [28]
						-2.816999999999098, -- [29]
						-2.816999999999098, -- [30]
						-2.816999999999098, -- [31]
						-2.816999999999098, -- [32]
						-1.98700000000099, -- [33]
						-1.98700000000099, -- [34]
						-1.98700000000099, -- [35]
						-1.98700000000099, -- [36]
						-1.98700000000099, -- [37]
						-1.98700000000099, -- [38]
						-0.8100000000013097, -- [39]
						-0.8100000000013097, -- [40]
						-0.8100000000013097, -- [41]
						-0.8100000000013097, -- [42]
						-0.8100000000013097, -- [43]
						-0.6530000000020664, -- [44]
						-0.4989999999997963, -- [45]
						-0.4989999999997963, -- [46]
						-0.3960000000006403, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["MessageIncoming"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						true, -- [13]
						true, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						true, -- [18]
						true, -- [19]
						true, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						false, -- [26]
						false, -- [27]
						false, -- [28]
						true, -- [29]
						true, -- [30]
						true, -- [31]
						true, -- [32]
						true, -- [33]
						true, -- [34]
						true, -- [35]
						true, -- [36]
						true, -- [37]
						true, -- [38]
						true, -- [39]
						true, -- [40]
						true, -- [41]
						true, -- [42]
						true, -- [43]
						false, -- [44]
						false, -- [45]
						false, -- [46]
						true, -- [47]
						true, -- [48]
						true, -- [49]
						true, -- [50]
					},
					["Messages"] = {
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -272 (Nature)", -- [1]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -542 (Nature)", -- [2]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -249 (Nature)", -- [3]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Crit -6938 (Fire)", -- [4]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3207 (Fire)", -- [5]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3334 (Fire)", -- [6]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -250 (Nature)", -- [7]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -484 (Nature)", -- [8]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -235 (Nature)", -- [9]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -546 (Nature)", -- [10]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -249 (Nature)", -- [11]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -273 (Nature)", -- [12]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -268 (Nature)", -- [13]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -236 (Nature)", -- [14]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3537 (Fire)", -- [15]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3339 (Fire)", -- [16]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3231 (Fire)", -- [17]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -251 (Nature)", -- [18]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -270 (Nature)", -- [19]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -232 (Nature)", -- [20]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -548 (Nature)", -- [21]
						"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +26800 (19923 overheal)", -- [22]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -258 (Nature)", -- [23]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -270 (Nature)", -- [24]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -270 (Nature)", -- [25]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3638 (Fire)", -- [26]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3606 (Fire)", -- [27]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3465 (Fire)", -- [28]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -251 (Nature)", -- [29]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -482 (Nature)", -- [30]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -255 (Nature)", -- [31]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -245 (Nature)", -- [32]
						"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +35343 (31729 overheal)", -- [33]
						"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +34108 (34108 overheal)", -- [34]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -244 (Nature)", -- [35]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -238 (Nature)", -- [36]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -239 (Nature)", -- [37]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -548 (Nature)", -- [38]
						"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +1030", -- [39]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Crit -490 (Nature)", -- [40]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -272 (Nature)", -- [41]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -232 (Nature)", -- [42]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -539 (Nature)", -- [43]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Crit -6924 (Fire)", -- [44]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3221 (Fire)", -- [45]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3254 (Fire)", -- [46]
						"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +35394 (32459 overheal)", -- [47]
						"Mirror Image <Uboblorick-Nagrand> dies.", -- [48]
						"Mirror Image <Uboblorick-Nagrand> dies.", -- [49]
						"Mirror Image <Uboblorick-Nagrand> dies.", -- [50]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["DeathAt"] = 1360560626,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
						"???", -- [45]
						"???", -- [46]
						"???", -- [47]
						"???", -- [48]
						"???", -- [49]
						"???", -- [50]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"HEAL", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"HEAL", -- [33]
						"HEAL", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"HEAL", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"DAMAGE", -- [45]
						"DAMAGE", -- [46]
						"HEAL", -- [47]
						"MISC", -- [48]
						"MISC", -- [49]
						"MISC", -- [50]
					},
				}, -- [2]
				{
					["MessageTimes"] = {
						-8.052999999999884, -- [1]
						-8.052999999999884, -- [2]
						-8.052999999999884, -- [3]
						-7.913000000000466, -- [4]
						-7.769000000000233, -- [5]
						-7.741000000001804, -- [6]
						-6.848000000001775, -- [7]
						-6.848000000001775, -- [8]
						-6.848000000001775, -- [9]
						-6.848000000001775, -- [10]
						-6.046000000002096, -- [11]
						-6.046000000002096, -- [12]
						-6.046000000002096, -- [13]
						-6.046000000002096, -- [14]
						-5.481999999999971, -- [15]
						-5.347000000001572, -- [16]
						-5.347000000001572, -- [17]
						-4.807000000000699, -- [18]
						-4.807000000000699, -- [19]
						-4.807000000000699, -- [20]
						-4.807000000000699, -- [21]
						-4.039000000000669, -- [22]
						-4.039000000000669, -- [23]
						-4.039000000000669, -- [24]
						-4.039000000000669, -- [25]
						-3.076000000000931, -- [26]
						-2.933000000000902, -- [27]
						-2.933000000000902, -- [28]
						-2.816999999999098, -- [29]
						-2.816999999999098, -- [30]
						-2.816999999999098, -- [31]
						-2.816999999999098, -- [32]
						-1.98700000000099, -- [33]
						-1.98700000000099, -- [34]
						-1.98700000000099, -- [35]
						-1.98700000000099, -- [36]
						-1.98700000000099, -- [37]
						-1.98700000000099, -- [38]
						-0.8100000000013097, -- [39]
						-0.8100000000013097, -- [40]
						-0.8100000000013097, -- [41]
						-0.8100000000013097, -- [42]
						-0.8100000000013097, -- [43]
						-0.6530000000020664, -- [44]
						-0.4989999999997963, -- [45]
						-0.4989999999997963, -- [46]
						-0.3960000000006403, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["MessageIncoming"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						true, -- [13]
						true, -- [14]
						false, -- [15]
						false, -- [16]
						false, -- [17]
						true, -- [18]
						true, -- [19]
						true, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						false, -- [26]
						false, -- [27]
						false, -- [28]
						true, -- [29]
						true, -- [30]
						true, -- [31]
						true, -- [32]
						true, -- [33]
						true, -- [34]
						true, -- [35]
						true, -- [36]
						true, -- [37]
						true, -- [38]
						true, -- [39]
						true, -- [40]
						true, -- [41]
						true, -- [42]
						true, -- [43]
						false, -- [44]
						false, -- [45]
						false, -- [46]
						true, -- [47]
						true, -- [48]
						true, -- [49]
						true, -- [50]
					},
					["Messages"] = {
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -272 (Nature)", -- [1]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -542 (Nature)", -- [2]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -249 (Nature)", -- [3]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Crit -6938 (Fire)", -- [4]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3207 (Fire)", -- [5]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3334 (Fire)", -- [6]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -250 (Nature)", -- [7]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -484 (Nature)", -- [8]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -235 (Nature)", -- [9]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -546 (Nature)", -- [10]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -249 (Nature)", -- [11]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -273 (Nature)", -- [12]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -268 (Nature)", -- [13]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -236 (Nature)", -- [14]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3537 (Fire)", -- [15]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3339 (Fire)", -- [16]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3231 (Fire)", -- [17]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -251 (Nature)", -- [18]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -270 (Nature)", -- [19]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -232 (Nature)", -- [20]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -548 (Nature)", -- [21]
						"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +26800 (19923 overheal)", -- [22]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -258 (Nature)", -- [23]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -270 (Nature)", -- [24]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -270 (Nature)", -- [25]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3638 (Fire)", -- [26]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3606 (Fire)", -- [27]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3465 (Fire)", -- [28]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -251 (Nature)", -- [29]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -482 (Nature)", -- [30]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -255 (Nature)", -- [31]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -245 (Nature)", -- [32]
						"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +35343 (31729 overheal)", -- [33]
						"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +34108 (34108 overheal)", -- [34]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Hit -244 (Nature)", -- [35]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -238 (Nature)", -- [36]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -239 (Nature)", -- [37]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -548 (Nature)", -- [38]
						"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +1030", -- [39]
						"No One Concentrated Irresistible Cologne Spill Mirror Image <Uboblorick-Nagrand> Crit -490 (Nature)", -- [40]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -272 (Nature)", -- [41]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Hit -232 (Nature)", -- [42]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Uboblorick-Nagrand> Crit -539 (Nature)", -- [43]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Crit -6924 (Fire)", -- [44]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3221 (Fire)", -- [45]
						"Mirror Image <Uboblorick-Nagrand> Fireball Apothecary Hummel Hit -3254 (Fire)", -- [46]
						"Kardinalsinn-Barthilas Atonement Mirror Image <Uboblorick-Nagrand> Hit +35394 (32459 overheal)", -- [47]
						"Mirror Image <Uboblorick-Nagrand> dies.", -- [48]
						"Mirror Image <Uboblorick-Nagrand> dies.", -- [49]
						"Mirror Image <Uboblorick-Nagrand> dies.", -- [50]
					},
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["DeathAt"] = 1360560626,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
						"???", -- [45]
						"???", -- [46]
						"???", -- [47]
						"???", -- [48]
						"???", -- [49]
						"???", -- [50]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"HEAL", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"HEAL", -- [33]
						"HEAL", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"HEAL", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"DAMAGE", -- [45]
						"DAMAGE", -- [46]
						"HEAL", -- [47]
						"MISC", -- [48]
						"MISC", -- [49]
						"MISC", -- [50]
					},
				}, -- [3]
			},
			["LastEventTimes"] = {
				20799.541, -- [1]
				20799.541, -- [2]
				20799.681, -- [3]
				20799.825, -- [4]
				20799.853, -- [5]
				20800.746, -- [6]
				20800.746, -- [7]
				20800.746, -- [8]
				20800.746, -- [9]
				20801.548, -- [10]
				20801.548, -- [11]
				20801.548, -- [12]
				20801.548, -- [13]
				20802.112, -- [14]
				20802.247, -- [15]
				20802.247, -- [16]
				20802.787, -- [17]
				20802.787, -- [18]
				20802.787, -- [19]
				20802.787, -- [20]
				20803.555, -- [21]
				20803.555, -- [22]
				20803.555, -- [23]
				20803.555, -- [24]
				20804.518, -- [25]
				20804.661, -- [26]
				20804.661, -- [27]
				20804.777, -- [28]
				20804.777, -- [29]
				20804.777, -- [30]
				20804.777, -- [31]
				20805.607, -- [32]
				20805.607, -- [33]
				20805.607, -- [34]
				20805.607, -- [35]
				20805.607, -- [36]
				20805.607, -- [37]
				20806.784, -- [38]
				20806.784, -- [39]
				20806.784, -- [40]
				20806.784, -- [41]
				20806.784, -- [42]
				20806.941, -- [43]
				20807.095, -- [44]
				20807.095, -- [45]
				20807.198, -- [46]
				20807.594, -- [47]
				20807.594, -- [48]
				20807.594, -- [49]
				20799.541, -- [50]
			},
			["LastAbility"] = 102142.251,
		},
		["Uboblorick-Nagrand"] = {
			["GUID"] = "0x0300000005FC3DD7",
			["LastEventHealth"] = {
				"347925 (100%)", -- [1]
				"347925 (100%)", -- [2]
				"347925 (100%)", -- [3]
				"347925 (100%)", -- [4]
				"347925 (100%)", -- [5]
				"347925 (100%)", -- [6]
				"347925 (100%)", -- [7]
				"347925 (100%)", -- [8]
				"347925 (100%)", -- [9]
				"347925 (100%)", -- [10]
				"347925 (100%)", -- [11]
				"347925 (100%)", -- [12]
				"347925 (100%)", -- [13]
				"347925 (100%)", -- [14]
				"347925 (100%)", -- [15]
				"347925 (100%)", -- [16]
				"347925 (100%)", -- [17]
				"347925 (100%)", -- [18]
				"347925 (100%)", -- [19]
				"347925 (100%)", -- [20]
				"347925 (100%)", -- [21]
				"347925 (100%)", -- [22]
				"347925 (100%)", -- [23]
				"347925 (100%)", -- [24]
				"347925 (100%)", -- [25]
				"347925 (100%)", -- [26]
				"347925 (100%)", -- [27]
				"347925 (100%)", -- [28]
				"347925 (100%)", -- [29]
				"347925 (100%)", -- [30]
				"347925 (100%)", -- [31]
				"347925 (100%)", -- [32]
				"347925 (100%)", -- [33]
				"347925 (100%)", -- [34]
				"347925 (100%)", -- [35]
				"347925 (100%)", -- [36]
				"347925 (100%)", -- [37]
				"347925 (100%)", -- [38]
				"347925 (100%)", -- [39]
				"347925 (100%)", -- [40]
				"347925 (100%)", -- [41]
				"347925 (100%)", -- [42]
				"347925 (100%)", -- [43]
				"347925 (100%)", -- [44]
				"347925 (100%)", -- [45]
				"347925 (100%)", -- [46]
				"347925 (100%)", -- [47]
				"347925 (100%)", -- [48]
				"347925 (100%)", -- [49]
				"347925 (100%)", -- [50]
			},
			["LastAttackedBy"] = "Apothecary Frye",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["Absorbs"] = {
					69852, -- [1]
				},
				["HealingTaken"] = {
					10805, -- [1]
				},
				["ActiveTime"] = {
					126.7599999999999, -- [1]
				},
				["TimeDamage"] = {
					126.7599999999999, -- [1]
				},
				["DOT_Time"] = {
					696, -- [1]
				},
				["DamageTaken"] = {
					10805, -- [1]
				},
				["Damage"] = {
					4403382, -- [1]
				},
			},
			["enClass"] = "MAGE",
			["unit"] = "Uboblorick",
			["LastActive"] = 1360560706,
			["UnitLockout"] = 1360560706,
			["level"] = 90,
			["LastDamageAbility"] = "Melee",
			["LastFightIn"] = 1,
			["LastEventNum"] = {
			},
			["type"] = "Ungrouped",
			["FightsSaved"] = 5,
			["GuardianReverseGUIDs"] = {
				["Mirror Image"] = {
					["LatestGuardian"] = 2,
					["GUIDs"] = {
						"0xF130B88C0001B131", -- [1]
						"0xF130B88C0001B132", -- [2]
						[0] = "0xF130B88C0001B130",
					},
				},
				["Rune of Power"] = {
					["LatestGuardian"] = 1,
					["GUIDs"] = {
						"0xF130EB270001AFF4", -- [1]
						[0] = "0xF130EB270001AFF0",
					},
				},
			},
			["Fights"] = {
				["LastFightData"] = {
					["DamagedWho"] = {
						["Frantic Geist"] = {
							["Details"] = {
								["Arcane Explosion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Corpse Eater"] = {
							["Details"] = {
								["Arcane Explosion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["TimeSpent"] = {
						["Frantic Geist"] = {
							["Details"] = {
								["Arcane Explosion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Corpse Eater"] = {
							["Details"] = {
								["Arcane Explosion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Arcane"] = 0,
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Slashing Claws"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Arcane"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["Frantic Geist"] = {
							["Details"] = {
								["Arcane Explosion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Corpse Eater"] = {
							["Details"] = {
								["Arcane Explosion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["Arcane Explosion"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Slashing Claws"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Damage"] = 0,
				},
				["CurrentFightData"] = {
					["Ressed"] = 0,
					["HOTs"] = {
					},
					["DOTs"] = {
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 0,
								},
								["Apothecary Hummel"] = {
									["count"] = 0,
								},
								["Apothecary Baxter"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 0,
								},
								["Apothecary Hummel"] = {
									["count"] = 0,
								},
								["Apothecary Baxter"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 0,
								},
								["Apothecary Hummel"] = {
									["count"] = 0,
								},
								["Apothecary Baxter"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Combustion (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["ElementDoneResist"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 0,
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["ElementTaken"] = {
						["Melee"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["RageGain"] = 0,
					["TimeHeal"] = 0,
					["ShieldedWho"] = {
						["Uboblorick-Nagrand"] = {
							["Details"] = {
								["Ice Barrier"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["Irresistible Cologne"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 0,
								},
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 0,
								},
								["Combustion (DoT)"] = {
									["count"] = 0,
								},
								["Combustion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
								["Pyroblast"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Rocket Barrage"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 0,
								},
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Combustion"] = {
									["count"] = 0,
								},
								["Pyroblast"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 0,
								},
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Pyroblast"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["FAttacks"] = {
					},
					["Dispelled"] = 0,
					["ElementDone"] = {
						["Fire"] = 0,
					},
					["FDamagedWho"] = {
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGainedFrom"] = {
					},
					["WhoDamaged"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["ActiveTime"] = 0,
					["Absorbed"] = {
						["Ice Barrier"] = {
							["Details"] = {
								["Uboblorick-Nagrand"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["WhoHealed"] = {
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["RessedWho"] = {
					},
					["PartialResist"] = {
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["Interrupts"] = 0,
					["InterruptData"] = {
					},
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 0,
								},
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 0,
								},
								["Combustion (DoT)"] = {
									["count"] = 0,
								},
								["Combustion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
								["Pyroblast"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Rocket Barrage"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 0,
								},
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Combustion"] = {
									["count"] = 0,
								},
								["Pyroblast"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 0,
								},
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Pyroblast"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["FDamage"] = 0,
					["Heals"] = {
						["Ice Barrier"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealedWho"] = {
						["Uboblorick-Nagrand"] = {
							["Details"] = {
								["Ice Barrier"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGained"] = {
					},
					["RunicPowerGained"] = {
					},
					["Healing"] = 0,
					["CCBroken"] = {
					},
					["PartialBlock"] = {
					},
					["Attacks"] = {
						["Fireball"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Inferno Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Combustion (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Combustion"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Living Bomb"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Pyroblast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Rocket Barrage"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["RunicPowerGainedFrom"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 0,
								},
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 0,
								},
								["Combustion (DoT)"] = {
									["count"] = 0,
								},
								["Combustion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
								["Pyroblast"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Rocket Barrage"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 0,
								},
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Combustion"] = {
									["count"] = 0,
								},
								["Pyroblast"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 0,
								},
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Pyroblast"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["DOTs"] = {
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 81,
								},
								["Apothecary Hummel"] = {
									["count"] = 78,
								},
								["Apothecary Baxter"] = {
									["count"] = 69,
								},
							},
							["amount"] = 228,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 75,
								},
								["Apothecary Hummel"] = {
									["count"] = 69,
								},
								["Apothecary Baxter"] = {
									["count"] = 66,
								},
							},
							["amount"] = 210,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 60,
								},
								["Apothecary Hummel"] = {
									["count"] = 60,
								},
								["Apothecary Baxter"] = {
									["count"] = 75,
								},
							},
							["amount"] = 195,
						},
						["Combustion (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 63,
								},
							},
							["amount"] = 63,
						},
					},
					["TimeSpent"] = {
						["Corpse Eater"] = {
							["Details"] = {
								["Arcane Explosion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 3.06,
								},
								["Inferno Blast"] = {
									["count"] = 3.61,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 9.770000000000001,
								},
								["Ignite (DoT)"] = {
									["count"] = 9.689999999999998,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 9.279999999999999,
								},
								["Combustion"] = {
									["count"] = 3.5,
								},
								["Pyroblast"] = {
									["count"] = 1.78,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 40.69000000000003,
						},
						["Apothecary Frye"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 4.69,
								},
								["Inferno Blast"] = {
									["count"] = 1.62,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 2.31,
								},
								["Combustion (DoT)"] = {
									["count"] = 11.42,
								},
								["Combustion"] = {
									["count"] = 0.42,
								},
								["Living Bomb"] = {
									["count"] = 2.310000000000001,
								},
								["Pyroblast"] = {
									["count"] = 0.22,
								},
								["Ignite (DoT)"] = {
									["count"] = 11.86,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 15.7,
								},
								["Rocket Barrage"] = {
									["count"] = 0.1,
								},
							},
							["amount"] = 50.65,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Arcane Explosion"] = {
									["count"] = 3.52,
								},
							},
							["amount"] = 3.52,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 2.18,
								},
								["Inferno Blast"] = {
									["count"] = 1.7,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 7.180000000000001,
								},
								["Ignite (DoT)"] = {
									["count"] = 10.73,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 7.99,
								},
								["Pyroblast"] = {
									["count"] = 1.52,
								},
								["Living Bomb"] = {
									["count"] = 0.6000000000000001,
								},
							},
							["amount"] = 31.9,
						},
					},
					["HealedWho"] = {
						["Uboblorick-Nagrand"] = {
							["Details"] = {
								["Ice Barrier"] = {
									["count"] = 69852,
								},
							},
							["amount"] = 69852,
						},
					},
					["PartialResist"] = {
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 18,
									["amount"] = 0,
								},
							},
							["count"] = 18,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Slashing Claws"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Irresistible Cologne"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 1778,
									["min"] = 1708,
									["count"] = 3,
									["amount"] = 5234,
								},
							},
							["count"] = 3,
							["amount"] = 5234,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 15,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 27324,
									["min"] = 10572,
									["count"] = 3,
									["amount"] = 54405,
								},
							},
							["count"] = 18,
							["amount"] = 54405,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 3142,
									["min"] = 2591,
									["count"] = 5,
									["amount"] = 14592,
								},
							},
							["count"] = 5,
							["amount"] = 14592,
						},
						["Slashing Claws"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 126.7599999999999,
					["ElementTaken"] = {
						["Melee"] = 10805,
					},
					["DOT_Time"] = 696,
					["Damage"] = 4403382,
					["WhoHealed"] = {
						["Kardinalsinn-Barthilas"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 10805,
								},
							},
							["amount"] = 10805,
						},
					},
					["Heals"] = {
						["Ice Barrier"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 53886,
									["min"] = 15966,
									["count"] = 2,
									["amount"] = 69852,
								},
							},
							["count"] = 2,
							["amount"] = 69852,
						},
					},
					["ShieldedWho"] = {
						["Uboblorick-Nagrand"] = {
							["Details"] = {
								["Ice Barrier"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 3,
								},
								["Miss"] = {
									["count"] = 14,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 18,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 8,
								},
							},
							["amount"] = 8,
						},
					},
					["ElementHitsDone"] = {
						["Arcane"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 7,
						},
						["Fire"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 204,
								},
								["Hit"] = {
									["count"] = 51,
								},
								["Crit"] = {
									["count"] = 54,
								},
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 310,
						},
					},
					["TimeDamaging"] = {
						["Corpse Eater"] = {
							["Details"] = {
								["Arcane Explosion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 3.06,
								},
								["Inferno Blast"] = {
									["count"] = 3.61,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 9.770000000000001,
								},
								["Ignite (DoT)"] = {
									["count"] = 9.689999999999998,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 9.279999999999999,
								},
								["Combustion"] = {
									["count"] = 3.5,
								},
								["Pyroblast"] = {
									["count"] = 1.78,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 40.69000000000003,
						},
						["Apothecary Frye"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 4.69,
								},
								["Inferno Blast"] = {
									["count"] = 1.62,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 2.31,
								},
								["Combustion (DoT)"] = {
									["count"] = 11.42,
								},
								["Combustion"] = {
									["count"] = 0.42,
								},
								["Living Bomb"] = {
									["count"] = 2.310000000000001,
								},
								["Pyroblast"] = {
									["count"] = 0.22,
								},
								["Ignite (DoT)"] = {
									["count"] = 11.86,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 15.7,
								},
								["Rocket Barrage"] = {
									["count"] = 0.1,
								},
							},
							["amount"] = 50.65,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Arcane Explosion"] = {
									["count"] = 3.52,
								},
							},
							["amount"] = 3.52,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 2.18,
								},
								["Inferno Blast"] = {
									["count"] = 1.7,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 7.180000000000001,
								},
								["Ignite (DoT)"] = {
									["count"] = 10.73,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 7.99,
								},
								["Pyroblast"] = {
									["count"] = 1.52,
								},
								["Living Bomb"] = {
									["count"] = 0.6000000000000001,
								},
							},
							["amount"] = 31.9,
						},
					},
					["Absorbs"] = 69852,
					["Attacks"] = {
						["Fireball"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 33693,
									["min"] = 28918,
									["count"] = 18,
									["amount"] = 558235,
								},
								["Crit"] = {
									["max"] = 67284,
									["min"] = 55318,
									["count"] = 7,
									["amount"] = 430850,
								},
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 26,
							["amount"] = 989085,
						},
						["Inferno Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 26835,
									["min"] = 22088,
									["count"] = 12,
									["amount"] = 298577,
								},
							},
							["count"] = 12,
							["amount"] = 298577,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 20062,
									["min"] = 13956,
									["count"] = 15,
									["amount"] = 273596,
								},
								["Tick"] = {
									["max"] = 10031,
									["min"] = 6978,
									["count"] = 50,
									["amount"] = 432880,
								},
							},
							["count"] = 65,
							["amount"] = 706476,
						},
						["Combustion (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7967,
									["min"] = 7967,
									["count"] = 2,
									["amount"] = 15934,
								},
								["Tick"] = {
									["max"] = 3984,
									["min"] = 3983,
									["count"] = 19,
									["amount"] = 75695,
								},
							},
							["count"] = 21,
							["amount"] = 91629,
						},
						["Combustion"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 77596,
									["min"] = 77596,
									["count"] = 1,
									["amount"] = 77596,
								},
								["Hit"] = {
									["max"] = 35124,
									["min"] = 35124,
									["count"] = 1,
									["amount"] = 35124,
								},
							},
							["count"] = 2,
							["amount"] = 112720,
						},
						["Arcane Explosion"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 12689,
									["min"] = 12649,
									["count"] = 3,
									["amount"] = 38023,
								},
								["Hit"] = {
									["max"] = 6334,
									["min"] = 6326,
									["count"] = 4,
									["amount"] = 25322,
								},
							},
							["count"] = 7,
							["amount"] = 63345,
						},
						["Living Bomb"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 43129,
									["min"] = 41076,
									["count"] = 5,
									["amount"] = 211539,
								},
								["Hit"] = {
									["max"] = 21565,
									["min"] = 17859,
									["count"] = 23,
									["amount"] = 461436,
								},
							},
							["count"] = 28,
							["amount"] = 672975,
						},
						["Pyroblast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 107046,
									["min"] = 107046,
									["count"] = 1,
									["amount"] = 107046,
								},
								["Hit"] = {
									["max"] = 60889,
									["min"] = 42410,
									["count"] = 8,
									["amount"] = 421925,
								},
							},
							["count"] = 9,
							["amount"] = 528971,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 18314,
									["min"] = 2243,
									["count"] = 70,
									["amount"] = 487881,
								},
							},
							["count"] = 70,
							["amount"] = 487881,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 10731,
									["min"] = 9331,
									["count"] = 11,
									["amount"] = 113839,
								},
								["Tick"] = {
									["max"] = 5902,
									["min"] = 4443,
									["count"] = 65,
									["amount"] = 330584,
								},
							},
							["count"] = 76,
							["amount"] = 444423,
						},
						["Rocket Barrage"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 7300,
									["min"] = 7300,
									["count"] = 1,
									["amount"] = 7300,
								},
							},
							["count"] = 1,
							["amount"] = 7300,
						},
					},
					["ElementDone"] = {
						["Arcane"] = 63345,
						["Fire"] = 4340037,
					},
					["HealingTaken"] = 10805,
					["DamagedWho"] = {
						["Corpse Eater"] = {
							["Details"] = {
								["Arcane Explosion"] = {
									["count"] = 19014,
								},
							},
							["amount"] = 19014,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 467989,
								},
								["Inferno Blast"] = {
									["count"] = 133673,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 226698,
								},
								["Ignite (DoT)"] = {
									["count"] = 175267,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 177591,
								},
								["Combustion"] = {
									["count"] = 77596,
								},
								["Pyroblast"] = {
									["count"] = 170724,
								},
								["Living Bomb"] = {
									["count"] = 172518,
								},
							},
							["amount"] = 1602056,
						},
						["Apothecary Frye"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 258753,
								},
								["Inferno Blast"] = {
									["count"] = 91829,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 217538,
								},
								["Combustion (DoT)"] = {
									["count"] = 91629,
								},
								["Combustion"] = {
									["count"] = 35124,
								},
								["Living Bomb"] = {
									["count"] = 256278,
								},
								["Pyroblast"] = {
									["count"] = 148489,
								},
								["Ignite (DoT)"] = {
									["count"] = 139179,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 131968,
								},
								["Rocket Barrage"] = {
									["count"] = 7300,
								},
							},
							["amount"] = 1378087,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Arcane Explosion"] = {
									["count"] = 44331,
								},
							},
							["amount"] = 44331,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 262343,
								},
								["Inferno Blast"] = {
									["count"] = 73075,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 262240,
								},
								["Ignite (DoT)"] = {
									["count"] = 173435,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 134864,
								},
								["Pyroblast"] = {
									["count"] = 209758,
								},
								["Living Bomb"] = {
									["count"] = 244179,
								},
							},
							["amount"] = 1359894,
						},
					},
					["TimeDamage"] = 126.7599999999999,
					["WhoDamaged"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 10805,
								},
							},
							["amount"] = 10805,
						},
					},
					["DamageTaken"] = 10805,
					["ElementTakenAbsorb"] = {
						["Melee"] = 54405,
						["Nature"] = 19826,
					},
					["Absorbed"] = {
						["Ice Barrier"] = {
							["Details"] = {
								["Uboblorick-Nagrand"] = {
									["max"] = 53886,
									["min"] = 15966,
									["count"] = 2,
									["amount"] = 69852,
								},
							},
							["count"] = 2,
							["amount"] = 69852,
						},
					},
				},
			},
			["Owner"] = false,
			["Pet"] = {
				"Rune of Power <Uboblorick-Nagrand>", -- [1]
				"Mirror Image <Uboblorick-Nagrand>", -- [2]
			},
			["NextEventNum"] = 50,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				100, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				100, -- [11]
				100, -- [12]
				100, -- [13]
				100, -- [14]
				100, -- [15]
				100, -- [16]
				100, -- [17]
				100, -- [18]
				100, -- [19]
				100, -- [20]
				100, -- [21]
				100, -- [22]
				100, -- [23]
				100, -- [24]
				100, -- [25]
				100, -- [26]
				100, -- [27]
				100, -- [28]
				100, -- [29]
				100, -- [30]
				100, -- [31]
				100, -- [32]
				100, -- [33]
				100, -- [34]
				100, -- [35]
				100, -- [36]
				100, -- [37]
				100, -- [38]
				100, -- [39]
				100, -- [40]
				100, -- [41]
				100, -- [42]
				100, -- [43]
				100, -- [44]
				100, -- [45]
				100, -- [46]
				100, -- [47]
				100, -- [48]
				100, -- [49]
				100, -- [50]
			},
			["LastEvents"] = {
				"Uboblorick-Nagrand Combustion (DoT) Apothecary Frye Tick -3984 (Fire)", -- [1]
				"Uboblorick-Nagrand Ignite (DoT) Apothecary Frye Tick -3373 (Fire)", -- [2]
				"Uboblorick-Nagrand Combustion (DoT) Apothecary Frye Tick -3984 (Fire)", -- [3]
				"Uboblorick-Nagrand Combustion (DoT) Apothecary Frye Tick -3984 (Fire)", -- [4]
				"Uboblorick-Nagrand Living Bomb (DoT) Apothecary Frye Tick -4666 (Fire)", -- [5]
				"Uboblorick-Nagrand Pyroblast (DoT) Apothecary Frye Crit -13956 (Fire)", -- [6]
				"Uboblorick-Nagrand Ignite (DoT) Apothecary Frye Tick -3372 (Fire)", -- [7]
				"Uboblorick-Nagrand Combustion (DoT) Apothecary Frye Tick -3984 (Fire)", -- [8]
				"Uboblorick-Nagrand Fireball Apothecary Frye Hit -29035 (Fire)", -- [9]
				"Uboblorick-Nagrand Living Bomb Apothecary Frye Hit -18752 (Fire)", -- [10]
				"Uboblorick-Nagrand Combustion (DoT) Apothecary Frye Tick -3984 (Fire)", -- [11]
				"Uboblorick-Nagrand Inferno Blast Apothecary Frye Crit -23180 (Fire)", -- [12]
				"Uboblorick-Nagrand Ignite (DoT) Apothecary Frye Tick -3090 (Fire)", -- [13]
				"Uboblorick-Nagrand Combustion (DoT) Apothecary Frye Tick -3984 (Fire)", -- [14]
				"Uboblorick-Nagrand Living Bomb (DoT) Apothecary Frye Tick -4665 (Fire)", -- [15]
				"Uboblorick-Nagrand Pyroblast (DoT) Apothecary Frye Tick -6978 (Fire)", -- [16]
				"Uboblorick-Nagrand Combustion (DoT) Apothecary Frye Tick -3984 (Fire)", -- [17]
				"Uboblorick-Nagrand Ignite (DoT) Apothecary Frye Tick -3629 (Fire)", -- [18]
				"Uboblorick-Nagrand Combustion (DoT) Apothecary Frye Tick -3984 (Fire)", -- [19]
				"Uboblorick-Nagrand Combustion (DoT) Apothecary Frye Tick -3984 (Fire)", -- [20]
				"Uboblorick-Nagrand Living Bomb (DoT) Apothecary Frye Tick -4665 (Fire)", -- [21]
				"Uboblorick-Nagrand Pyroblast (DoT) Apothecary Frye Tick -6978 (Fire)", -- [22]
				"Uboblorick-Nagrand Fireball Apothecary Frye Hit -29217 (Fire)", -- [23]
				"Uboblorick-Nagrand Combustion (DoT) Apothecary Frye Tick -3984 (Fire)", -- [24]
				"Uboblorick-Nagrand Ignite (DoT) Apothecary Frye Tick -3629 (Fire)", -- [25]
				"Uboblorick-Nagrand Combustion (DoT) Apothecary Frye Tick -3984 (Fire)", -- [26]
				"No One Concentrated Alluring Perfume Spill Uboblorick-Nagrand Absorb (2803 Absorbed) (Nature)", -- [27]
				"Uboblorick-Nagrand Combustion (DoT) Apothecary Frye Tick -3984 (Fire)", -- [28]
				"Uboblorick-Nagrand Fireball Apothecary Frye Hit -28918 (Fire)", -- [29]
				"Uboblorick-Nagrand Ignite (DoT) Apothecary Frye Tick -3188 (Fire)", -- [30]
				"No One Concentrated Alluring Perfume Spill Uboblorick-Nagrand Absorb (2591 Absorbed) (Nature)", -- [31]
				"Uboblorick-Nagrand Living Bomb (DoT) Apothecary Frye Tick -4666 (Fire)", -- [32]
				"Uboblorick-Nagrand Pyroblast (DoT) Apothecary Frye Tick -6979 (Fire)", -- [33]
				"Uboblorick-Nagrand Combustion (DoT) Apothecary Frye Tick -3984 (Fire)", -- [34]
				"Uboblorick-Nagrand Combustion (DoT) Apothecary Frye Crit -7967 (Fire)", -- [35]
				"Uboblorick-Nagrand Ignite (DoT) Apothecary Frye Tick -4083 (Fire)", -- [36]
				"Uboblorick-Nagrand Inferno Blast Apothecary Frye Crit -23386 (Fire)", -- [37]
				"Uboblorick-Nagrand Combustion (DoT) Apothecary Frye Tick -3984 (Fire)", -- [38]
				"Uboblorick-Nagrand Living Bomb (DoT) Apothecary Frye Tick -4666 (Fire)", -- [39]
				"Uboblorick-Nagrand Ignite (DoT) Apothecary Frye Tick -4305 (Fire)", -- [40]
				"Uboblorick-Nagrand Living Bomb Apothecary Frye Hit -18752 (Fire)", -- [41]
				"Uboblorick-Nagrand Living Bomb (DoT) Apothecary Frye Tick -4665 (Fire)", -- [42]
				"Uboblorick-Nagrand Ignite (DoT) Apothecary Frye Tick -4305 (Fire)", -- [43]
				"Uboblorick-Nagrand Fireball Apothecary Frye Crit -58263 (Fire)", -- [44]
				"Uboblorick-Nagrand Ignite (DoT) Apothecary Frye Tick -6278 (Fire)", -- [45]
				"Uboblorick-Nagrand Living Bomb (DoT) Apothecary Frye Tick -4665 (Fire)", -- [46]
				"Uboblorick-Nagrand Fireball Apothecary Frye Hit -28985 (Fire)", -- [47]
				"Uboblorick-Nagrand Pyroblast Apothecary Frye Hit -52920 (Fire)", -- [48]
				"Uboblorick-Nagrand Ignite (DoT) Apothecary Frye Tick -6278 (Fire)", -- [49]
				"Uboblorick-Nagrand Fireball Apothecary Frye Hit -29017 (Fire)", -- [50]
			},
			["Name"] = "Uboblorick-Nagrand",
			["LastDamageTaken"] = 10805,
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				true, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				true, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["TimeLast"] = {
				["Absorbs"] = 1360560701,
				["HealingTaken"] = 1360560640,
				["TimeDamage"] = 1360560706,
				["ActiveTime"] = 1360560706,
				["DOT_Time"] = 1360560706,
				["OVERALL"] = 1360560706,
				["DamageTaken"] = 1360560639,
				["Damage"] = 1360560706,
			},
			["LastEventTimes"] = {
				20868.929, -- [1]
				20869.5, -- [2]
				20869.881, -- [3]
				20870.821, -- [4]
				20871.256, -- [5]
				20871.269, -- [6]
				20871.51, -- [7]
				20871.76, -- [8]
				20872.329, -- [9]
				20872.381, -- [10]
				20872.696, -- [11]
				20873.201, -- [12]
				20873.501, -- [13]
				20873.636, -- [14]
				20874.087, -- [15]
				20874.105, -- [16]
				20874.577, -- [17]
				20875.486, -- [18]
				20875.53, -- [19]
				20876.468, -- [20]
				20876.907, -- [21]
				20876.928, -- [22]
				20877.331, -- [23]
				20877.401, -- [24]
				20877.499, -- [25]
				20878.342, -- [26]
				20878.847, -- [27]
				20879.281, -- [28]
				20879.33, -- [29]
				20879.505, -- [30]
				20879.629, -- [31]
				20879.754, -- [32]
				20879.754, -- [33]
				20880.244, -- [34]
				20881.182, -- [35]
				20881.488, -- [36]
				20881.651, -- [37]
				20882.135, -- [38]
				20882.564, -- [39]
				20883.514, -- [40]
				20884.073, -- [41]
				20885.393, -- [42]
				20885.49, -- [43]
				20886.639, -- [44]
				20887.496, -- [45]
				20888.092, -- [46]
				20889.276, -- [47]
				20889.478, -- [48]
				20889.5, -- [49]
				20868.628, -- [50]
			},
			["LastAbility"] = 102142.251,
		},
		["Ghost Iron Dragonling <Gato>"] = {
			["GUID"] = "0xF130E1B70001B134",
			["LastEventHealth"] = {
				"???", -- [1]
				"???", -- [2]
				"???", -- [3]
				"???", -- [4]
				"???", -- [5]
				"???", -- [6]
				"???", -- [7]
				"???", -- [8]
				"???", -- [9]
				"???", -- [10]
				"???", -- [11]
				"???", -- [12]
				"???", -- [13]
				"???", -- [14]
				"???", -- [15]
				"???", -- [16]
				"???", -- [17]
				"???", -- [18]
				"???", -- [19]
				"???", -- [20]
				"???", -- [21]
				"???", -- [22]
				"???", -- [23]
				"???", -- [24]
				"???", -- [25]
				"???", -- [26]
				"???", -- [27]
				"???", -- [28]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"MISC", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
			},
			["TimeWindows"] = {
				["DeathCount"] = {
					1, -- [1]
				},
				["ActiveTime"] = {
					23.63, -- [1]
				},
				["TimeDamage"] = {
					23.63, -- [1]
				},
				["DamageTaken"] = {
					86824, -- [1]
				},
				["Damage"] = {
					23083, -- [1]
				},
			},
			["enClass"] = "PET",
			["LastDamageTaken"] = 86824,
			["level"] = 1,
			["LastDamageAbility"] = "Chain Reaction",
			["LastFightIn"] = 1,
			["type"] = "Pet",
			["FightsSaved"] = 5,
			["LastActive"] = 1360560666,
			["UnitLockout"] = 1360560669,
			["Owner"] = "Gato",
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["PartialAbsorb"] = {
						["Chain Reaction"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Lightning Breath"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Lightning Breath"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Lightning Breath"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Lightning Breath"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Lightning Breath"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Lightning Breath"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Lightning Breath"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Lightning Breath"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Lightning Breath"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["Chain Reaction"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["WhoDamaged"] = {
						["Apothecary Hummel"] = {
							["Details"] = {
								["Chain Reaction"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTaken"] = {
						["Fire"] = 0,
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Lightning Breath"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Damage"] = 0,
				},
				["OverallData"] = {
					["PartialAbsorb"] = {
						["Chain Reaction"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 23.63,
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Lightning Breath"] = {
									["count"] = 2.01,
								},
							},
							["amount"] = 2.01,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13.19,
								},
								["Lightning Breath"] = {
									["count"] = 0.33,
								},
							},
							["amount"] = 13.52,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Lightning Breath"] = {
									["count"] = 2.93,
								},
								["Melee"] = {
									["count"] = 5.17,
								},
							},
							["amount"] = 8.1,
						},
					},
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Lightning Breath"] = {
									["count"] = 2.01,
								},
							},
							["amount"] = 2.01,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13.19,
								},
								["Lightning Breath"] = {
									["count"] = 0.33,
								},
							},
							["amount"] = 13.52,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Lightning Breath"] = {
									["count"] = 2.93,
								},
								["Melee"] = {
									["count"] = 5.17,
								},
							},
							["amount"] = 8.1,
						},
					},
					["ElementDone"] = {
						["Melee"] = 7009,
						["Nature"] = 16074,
					},
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DamageTaken"] = 86824,
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Lightning Breath"] = {
									["count"] = 4996,
								},
							},
							["amount"] = 4996,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5308,
								},
								["Lightning Breath"] = {
									["count"] = 6456,
								},
							},
							["amount"] = 11764,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1701,
								},
								["Lightning Breath"] = {
									["count"] = 4622,
								},
							},
							["amount"] = 6323,
						},
					},
					["PartialResist"] = {
						["Chain Reaction"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 1,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 8,
						},
						["Nature"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 4,
						},
					},
					["TimeDamage"] = 23.63,
					["WhoDamaged"] = {
						["Apothecary Hummel"] = {
							["Details"] = {
								["Chain Reaction"] = {
									["count"] = 86824,
								},
							},
							["amount"] = 86824,
						},
					},
					["ElementTaken"] = {
						["Fire"] = 86824,
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 718,
									["min"] = 718,
									["count"] = 1,
									["amount"] = 718,
								},
								["Hit"] = {
									["max"] = 942,
									["min"] = 799,
									["count"] = 7,
									["amount"] = 6291,
								},
							},
							["count"] = 8,
							["amount"] = 7009,
						},
						["Lightning Breath"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 6456,
									["min"] = 4622,
									["count"] = 3,
									["amount"] = 16074,
								},
							},
							["count"] = 4,
							["amount"] = 16074,
						},
					},
					["Damage"] = 23083,
				},
			},
			["NextEventNum"] = 29,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
				0, -- [5]
				0, -- [6]
				0, -- [7]
				0, -- [8]
				0, -- [9]
				0, -- [10]
				0, -- [11]
				0, -- [12]
				0, -- [13]
				0, -- [14]
				0, -- [15]
				0, -- [16]
				0, -- [17]
				0, -- [18]
				0, -- [19]
				0, -- [20]
				0, -- [21]
				0, -- [22]
				0, -- [23]
				0, -- [24]
				0, -- [25]
				0, -- [26]
				0, -- [27]
				0, -- [28]
			},
			["LastEvents"] = {
				"Ghost Iron Dragonling <Gato> Melee Apothecary Hummel Hit -942 (Physical)", -- [1]
				"Ghost Iron Dragonling <Gato> Melee Apothecary Hummel Hit -930 (Physical)", -- [2]
				"Ghost Iron Dragonling <Gato> Lightning Breath Apothecary Baxter Miss (Nature)", -- [3]
				"Ghost Iron Dragonling <Gato> Lightning Breath Apothecary Hummel Hit -6456 (Nature)", -- [4]
				"Ghost Iron Dragonling <Gato> Melee Apothecary Hummel Hit -911 (Physical)", -- [5]
				"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2442 (Nature)", -- [6]
				"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2506 (Nature)", -- [7]
				"Ghost Iron Dragonling <Gato> Melee Apothecary Hummel Hit -892 (Physical)", -- [8]
				"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2462 (Nature)", -- [9]
				"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2417 (Nature)", -- [10]
				"Ghost Iron Dragonling <Gato> Melee Apothecary Hummel Glancing -718 (Physical)", -- [11]
				"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2607 (Nature)", -- [12]
				"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2555 (Nature)", -- [13]
				"Ghost Iron Dragonling <Gato> Melee Apothecary Hummel Hit -915 (Physical)", -- [14]
				"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2377 (Nature)", -- [15]
				"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2427 (Nature)", -- [16]
				"Apothecary Hummel Chain Reaction Ghost Iron Dragonling <Gato> Hit -86824 (Fire)", -- [17]
				"Ghost Iron Dragonling <Gato> dies.", -- [18]
				"Ghost Iron Dragonling <Gato> Melee Apothecary Baxter Hit -799 (Physical)", -- [19]
				"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2591 (Nature)", -- [20]
				"Ghost Iron Dragonling <Gato> Lightning Breath Apothecary Frye Hit -4996 (Nature)", -- [21]
				"Ghost Iron Dragonling <Gato> Lightning Breath Apothecary Baxter Hit -4622 (Nature)", -- [22]
				"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2444 (Nature)", -- [23]
				"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2480 (Nature)", -- [24]
				"Ghost Iron Dragonling <Gato> Melee Apothecary Baxter Hit -902 (Physical)", -- [25]
				"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2607 (Nature)", -- [26]
				"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2495 (Nature)", -- [27]
				"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2462 (Nature)", -- [28]
			},
			["Name"] = "Ghost Iron Dragonling",
			["TimeLast"] = {
				["DeathCount"] = 1360560613,
				["ActiveTime"] = 1360560666,
				["TimeDamage"] = 1360560666,
				["OVERALL"] = 1360560666,
				["DamageTaken"] = 1360560612,
				["Damage"] = 1360560666,
			},
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				true, -- [6]
				true, -- [7]
				false, -- [8]
				true, -- [9]
				true, -- [10]
				false, -- [11]
				true, -- [12]
				true, -- [13]
				false, -- [14]
				true, -- [15]
				true, -- [16]
				true, -- [17]
				true, -- [18]
				false, -- [19]
				true, -- [20]
				false, -- [21]
				false, -- [22]
				true, -- [23]
				true, -- [24]
				false, -- [25]
				true, -- [26]
				true, -- [27]
				true, -- [28]
			},
			["DeathLogs"] = {
				{
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						true, -- [5]
						true, -- [6]
						false, -- [7]
						true, -- [8]
						true, -- [9]
						false, -- [10]
						true, -- [11]
						true, -- [12]
						false, -- [13]
						true, -- [14]
						true, -- [15]
						true, -- [16]
						true, -- [17]
					},
					["Messages"] = {
						"Ghost Iron Dragonling <Gato> Melee Apothecary Hummel Hit -930 (Physical)", -- [1]
						"Ghost Iron Dragonling <Gato> Lightning Breath Apothecary Baxter Miss (Nature)", -- [2]
						"Ghost Iron Dragonling <Gato> Lightning Breath Apothecary Hummel Hit -6456 (Nature)", -- [3]
						"Ghost Iron Dragonling <Gato> Melee Apothecary Hummel Hit -911 (Physical)", -- [4]
						"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2442 (Nature)", -- [5]
						"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2506 (Nature)", -- [6]
						"Ghost Iron Dragonling <Gato> Melee Apothecary Hummel Hit -892 (Physical)", -- [7]
						"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2462 (Nature)", -- [8]
						"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2417 (Nature)", -- [9]
						"Ghost Iron Dragonling <Gato> Melee Apothecary Hummel Glancing -718 (Physical)", -- [10]
						"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2607 (Nature)", -- [11]
						"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2555 (Nature)", -- [12]
						"Ghost Iron Dragonling <Gato> Melee Apothecary Hummel Hit -915 (Physical)", -- [13]
						"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2377 (Nature)", -- [14]
						"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2427 (Nature)", -- [15]
						"Apothecary Hummel Chain Reaction Ghost Iron Dragonling <Gato> Hit -86824 (Fire)", -- [16]
						"Ghost Iron Dragonling <Gato> dies.", -- [17]
					},
					["DeathAt"] = 1360560615,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
					},
					["MessageTimes"] = {
						-13.74300000000221, -- [1]
						-10.81100000000151, -- [2]
						-10.47799999999916, -- [3]
						-8.805000000000291, -- [4]
						-8.449000000000524, -- [5]
						-7.644000000000233, -- [6]
						-6.789000000000669, -- [7]
						-6.431000000000495, -- [8]
						-5.631000000001222, -- [9]
						-4.790000000000873, -- [10]
						-4.414000000000669, -- [11]
						-3.606999999999971, -- [12]
						-2.772000000000844, -- [13]
						-2.416000000001077, -- [14]
						-1.614000000001397, -- [15]
						-0.3690000000024156, -- [16]
						0, -- [17]
					},
					["KilledBy"] = "Apothecary Hummel",
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"MISC", -- [17]
					},
				}, -- [1]
			},
			["LastEventTimes"] = {
				20780.993, -- [1]
				20782.977, -- [2]
				20785.909, -- [3]
				20786.242, -- [4]
				20787.915, -- [5]
				20788.271, -- [6]
				20789.076, -- [7]
				20789.931, -- [8]
				20790.289, -- [9]
				20791.089, -- [10]
				20791.93, -- [11]
				20792.306, -- [12]
				20793.113, -- [13]
				20793.948, -- [14]
				20794.304, -- [15]
				20795.106, -- [16]
				20796.351, -- [17]
				20796.72, -- [18]
				20846.657, -- [19]
				20848.263, -- [20]
				20848.672, -- [21]
				20848.672, -- [22]
				20849.074, -- [23]
				20850.287, -- [24]
				20850.346, -- [25]
				20851.101, -- [26]
				20852.281, -- [27]
				20853.106, -- [28]
			},
			["LastAbility"] = 102142.251,
		},
		["No One <Gato>"] = {
			["GUID"] = "0x0000000000000000",
			["LastEventHealth"] = {
				"???", -- [1]
				"???", -- [2]
				"???", -- [3]
				"???", -- [4]
				"???", -- [5]
				"???", -- [6]
				"???", -- [7]
				"???", -- [8]
				"???", -- [9]
				"???", -- [10]
				"???", -- [11]
				"???", -- [12]
				"???", -- [13]
				"???", -- [14]
				"???", -- [15]
				"???", -- [16]
				"???", -- [17]
				"???", -- [18]
				"???", -- [19]
				"???", -- [20]
				"???", -- [21]
				"???", -- [22]
				"???", -- [23]
				"???", -- [24]
				"???", -- [25]
				"???", -- [26]
				"???", -- [27]
				"???", -- [28]
				"???", -- [29]
				"???", -- [30]
				"???", -- [31]
				"???", -- [32]
				"???", -- [33]
				"???", -- [34]
				"???", -- [35]
				"???", -- [36]
				"???", -- [37]
				"???", -- [38]
				"???", -- [39]
				"???", -- [40]
				"???", -- [41]
				"???", -- [42]
				"???", -- [43]
				"???", -- [44]
				"???", -- [45]
				"???", -- [46]
				"???", -- [47]
				"???", -- [48]
				"???", -- [49]
				"???", -- [50]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["ActiveTime"] = {
					82.88999999999997, -- [1]
				},
				["FDamage"] = {
					312740, -- [1]
				},
				["TimeDamage"] = {
					82.88999999999997, -- [1]
				},
			},
			["enClass"] = "PET",
			["level"] = 1,
			["LastFightIn"] = 2,
			["type"] = "Pet",
			["FightsSaved"] = 5,
			["LastActive"] = 1360560718,
			["Owner"] = "Gato",
			["UnitLockout"] = 1360560718,
			["NextEventNum"] = 21,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
				0, -- [5]
				0, -- [6]
				0, -- [7]
				0, -- [8]
				0, -- [9]
				0, -- [10]
				0, -- [11]
				0, -- [12]
				0, -- [13]
				0, -- [14]
				0, -- [15]
				0, -- [16]
				0, -- [17]
				0, -- [18]
				0, -- [19]
				0, -- [20]
				0, -- [21]
				0, -- [22]
				0, -- [23]
				0, -- [24]
				0, -- [25]
				0, -- [26]
				0, -- [27]
				0, -- [28]
				0, -- [29]
				0, -- [30]
				0, -- [31]
				0, -- [32]
				0, -- [33]
				0, -- [34]
				0, -- [35]
				0, -- [36]
				0, -- [37]
				0, -- [38]
				0, -- [39]
				0, -- [40]
				0, -- [41]
				0, -- [42]
				0, -- [43]
				0, -- [44]
				0, -- [45]
				0, -- [46]
				0, -- [47]
				0, -- [48]
				0, -- [49]
				0, -- [50]
			},
			["LastEvents"] = {
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2607 (Nature)", -- [1]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4948 (Nature)", -- [2]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2400 (Nature)", -- [3]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2465 (Nature)", -- [4]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2487 (Nature)", -- [5]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2460 (Nature)", -- [6]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Hit -378 (Nature)", -- [7]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Hit -391 (Nature)", -- [8]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Hit -376 (Nature)", -- [9]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Hit -401 (Nature)", -- [10]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Hit -388 (Nature)", -- [11]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Crit -771 (Nature)", -- [12]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Crit -777 (Nature)", -- [13]
				"No One <Gato> Concentrated Alluring Perfume Spill Underworld <Gato> Absorb (747 Absorbed) (Nature)", -- [14]
				"No One <Gato> Concentrated Alluring Perfume Spill Underworld <Gato> Absorb (729 Absorbed) (Nature)", -- [15]
				"No One <Gato> Concentrated Alluring Perfume Spill Underworld <Gato> Absorb (716 Absorbed) (Nature)", -- [16]
				"No One <Gato> Concentrated Alluring Perfume Spill Underworld <Gato> Absorb (694 Absorbed) (Nature)", -- [17]
				"No One <Gato> Concentrated Alluring Perfume Spill Underworld <Gato> Absorb (356 Absorbed) (Nature)", -- [18]
				"No One <Gato> Concentrated Alluring Perfume Spill Underworld <Gato> Absorb (711 Absorbed) (Nature)", -- [19]
				"No One <Gato> Concentrated Alluring Perfume Spill Underworld <Gato> Absorb (390 Absorbed) (Nature)", -- [20]
				"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2444 (Nature)", -- [21]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Hit -376 (Nature)", -- [22]
				"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2480 (Nature)", -- [23]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Hit -398 (Nature)", -- [24]
				"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2607 (Nature)", -- [25]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Crit -793 (Nature)", -- [26]
				"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2495 (Nature)", -- [27]
				"No One <Gato> Concentrated Irresistible Cologne Spill Ghost Iron Dragonling <Gato> Hit -2462 (Nature)", -- [28]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Hit -367 (Nature)", -- [29]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Hit -392 (Nature)", -- [30]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Hit -367 (Nature)", -- [31]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Hit -366 (Nature)", -- [32]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2376 (Nature)", -- [33]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2544 (Nature)", -- [34]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2594 (Nature)", -- [35]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2557 (Nature)", -- [36]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4894 (Nature)", -- [37]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2473 (Nature)", -- [38]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2599 (Nature)", -- [39]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2589 (Nature)", -- [40]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2536 (Nature)", -- [41]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2380 (Nature)", -- [42]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2448 (Nature)", -- [43]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2412 (Nature)", -- [44]
				"No One <Gato> Concentrated Irresistible Cologne Spill Underworld <Gato> Crit -776 (Nature)", -- [45]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2444 (Nature)", -- [46]
				"No One <Gato> Concentrated Irresistible Cologne Spill Viper <Gato> Hit -2574 (Nature)", -- [47]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2543 (Nature)", -- [48]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Hit -2466 (Nature)", -- [49]
				"No One <Gato> Concentrated Irresistible Cologne Spill Venomous Snake <Gato> Crit -4946 (Nature)", -- [50]
			},
			["Name"] = "No One",
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight5"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
						["Nature"] = 4343,
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 7,
								},
							},
							["amount"] = 7,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 9.539999999999999,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["Underworld <Gato>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 9.539999999999999,
								},
							},
							["amount"] = 9.539999999999999,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 9.539999999999999,
					["TimeDamaging"] = {
						["Underworld <Gato>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 9.539999999999999,
								},
							},
							["amount"] = 9.539999999999999,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["TimeSpent"] = {
						["Underworld <Gato>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Viper <Gato>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Venomous Snake <Gato>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ghost Iron Dragonling <Gato>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["FAttacks"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementDoneAbsorb"] = {
						["Nature"] = 0,
					},
					["Attacks"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["FDamage"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["Underworld <Gato>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Viper <Gato>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Venomous Snake <Gato>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ghost Iron Dragonling <Gato>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["FDamagedWho"] = {
						["Underworld <Gato>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Viper <Gato>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Venomous Snake <Gato>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ghost Iron Dragonling <Gato>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
				},
				["OverallData"] = {
					["TimeSpent"] = {
						["Underworld <Gato>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 13.85,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 58.91000000000001,
								},
							},
							["amount"] = 72.76000000000001,
						},
						["Viper <Gato>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2.02,
								},
							},
							["amount"] = 2.02,
						},
						["Venomous Snake <Gato>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 3.64,
								},
							},
							["amount"] = 3.64,
						},
						["Ghost Iron Dragonling <Gato>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 4.47,
								},
							},
							["amount"] = 4.47,
						},
					},
					["FAttacks"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 384,
									["min"] = 384,
									["count"] = 1,
									["amount"] = 384,
								},
							},
							["count"] = 1,
							["amount"] = 384,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5240,
									["min"] = 186,
									["count"] = 33,
									["amount"] = 89886,
								},
								["Hit"] = {
									["max"] = 2617,
									["min"] = 91,
									["count"] = 111,
									["amount"] = 222470,
								},
							},
							["count"] = 144,
							["amount"] = 312356,
						},
					},
					["ElementDoneAbsorb"] = {
						["Nature"] = 18630,
					},
					["Attacks"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 67,
									["amount"] = 0,
								},
							},
							["count"] = 67,
							["amount"] = 0,
						},
					},
					["FDamage"] = 312740,
					["TimeDamage"] = 82.88999999999997,
					["TimeDamaging"] = {
						["Underworld <Gato>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 13.85,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 58.91000000000001,
								},
							},
							["amount"] = 72.76000000000001,
						},
						["Viper <Gato>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2.02,
								},
							},
							["amount"] = 2.02,
						},
						["Venomous Snake <Gato>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 3.64,
								},
							},
							["amount"] = 3.64,
						},
						["Ghost Iron Dragonling <Gato>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 4.47,
								},
							},
							["amount"] = 4.47,
						},
					},
					["ActiveTime"] = 82.88999999999997,
					["FDamagedWho"] = {
						["Underworld <Gato>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 384,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 17582,
								},
							},
							["amount"] = 17966,
						},
						["Viper <Gato>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 122441,
								},
							},
							["amount"] = 122441,
						},
						["Venomous Snake <Gato>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 137461,
								},
							},
							["amount"] = 137461,
						},
						["Ghost Iron Dragonling <Gato>"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 34872,
								},
							},
							["amount"] = 34872,
						},
					},
					["ElementHitsDone"] = {
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 75,
								},
							},
							["amount"] = 75,
						},
					},
				},
			},
			["TimeLast"] = {
				["ActiveTime"] = 1360560718,
				["OVERALL"] = 1360560718,
				["FDamage"] = 1360560705,
				["TimeDamage"] = 1360560718,
			},
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				20874.027, -- [1]
				20874.027, -- [2]
				20874.027, -- [3]
				20874.027, -- [4]
				20874.027, -- [5]
				20874.027, -- [6]
				20874.406, -- [7]
				20876.428, -- [8]
				20877.217, -- [9]
				20878.438, -- [10]
				20879.248, -- [11]
				20887.693, -- [12]
				20888.508, -- [13]
				20896.142, -- [14]
				20896.935, -- [15]
				20898.155, -- [16]
				20898.961, -- [17]
				20900.171, -- [18]
				20900.987, -- [19]
				20902.181, -- [20]
				20849.074, -- [21]
				20849.859, -- [22]
				20850.287, -- [23]
				20851.071, -- [24]
				20851.101, -- [25]
				20851.885, -- [26]
				20852.281, -- [27]
				20853.106, -- [28]
				20853.895, -- [29]
				20858.707, -- [30]
				20868.392, -- [31]
				20870.391, -- [32]
				20871.991, -- [33]
				20871.991, -- [34]
				20871.991, -- [35]
				20871.991, -- [36]
				20871.991, -- [37]
				20871.991, -- [38]
				20871.991, -- [39]
				20871.991, -- [40]
				20871.991, -- [41]
				20871.991, -- [42]
				20871.991, -- [43]
				20871.991, -- [44]
				20872.381, -- [45]
				20873.998, -- [46]
				20874.027, -- [47]
				20874.027, -- [48]
				20874.027, -- [49]
				20874.027, -- [50]
			},
			["LastAbility"] = 102142.251,
		},
	},
	["FightNum"] = 7,
	["CombatTimes"] = {
		{
			1360560515, -- [1]
			1360560528, -- [2]
			"21:28:39", -- [3]
			"21:28:48", -- [4]
			"Corpse Eater", -- [5]
		}, -- [1]
		{
			1360560584, -- [1]
			1360560710, -- [2]
			"21:29:45", -- [3]
			"21:31:50", -- [4]
			"Apothecary Hummel", -- [5]
		}, -- [2]
		{
			1360561056, -- [1]
			1360561061, -- [2]
			"21:37:37", -- [3]
			"21:37:41", -- [4]
			"Crown Technician", -- [5]
		}, -- [3]
		{
			1360561078, -- [1]
			1360561083, -- [2]
			"21:37:59", -- [3]
			"21:38:03", -- [4]
			"Crown Technician", -- [5]
		}, -- [4]
		{
			1360561087, -- [1]
			1360561092, -- [2]
			"21:38:07", -- [3]
			"21:38:12", -- [4]
			"Crown Technician", -- [5]
		}, -- [5]
		{
			1360561097, -- [1]
			1360561102, -- [2]
			"21:38:18", -- [3]
			"21:38:22", -- [4]
			"Crown Technician", -- [5]
		}, -- [6]
		{
			1360561109, -- [1]
			1360561117, -- [2]
			"21:38:29", -- [3]
			"21:38:37", -- [4]
			"Crown Technician", -- [5]
		}, -- [7]
	},
	["FoughtWho"] = {
		"Crown Technician 21:38:29-21:38:37", -- [1]
		"Crown Technician 21:38:18-21:38:22", -- [2]
		"Crown Technician 21:38:07-21:38:12", -- [3]
		"Crown Technician 21:37:59-21:38:03", -- [4]
		"Crown Technician 21:37:37-21:37:41", -- [5]
	},
}
