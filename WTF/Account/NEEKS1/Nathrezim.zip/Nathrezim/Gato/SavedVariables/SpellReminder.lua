
SpellReminderDBPerChar = {
	["char"] = {
		["Gato - Nathrezim"] = {
			["spellSetup"] = {
				["Honorless Target"] = {
					["active"] = true,
					["displayName"] = "Honorless Target",
					["installed"] = true,
					["category"] = "Buffs",
					["detected"] = true,
					["last_seen"] = 1352860105,
					["r"] = 5,
					["d"] = 30,
					["icon"] = "Interface\\Icons\\Spell_Magic_LesserInvisibilty",
				},
				["01001000"] = {
					["active"] = true,
					["displayName"] = "01001000",
					["installed"] = true,
					["category"] = "Buffs",
					["detected"] = true,
					["last_seen"] = 1352860105,
					["r"] = 15,
					["d"] = 205,
					["icon"] = "Interface\\Icons\\INV_Misc_PunchCards_Red",
				},
			},
		},
	},
	["profileKeys"] = {
		["Gato - Nathrezim"] = "Default",
	},
}
