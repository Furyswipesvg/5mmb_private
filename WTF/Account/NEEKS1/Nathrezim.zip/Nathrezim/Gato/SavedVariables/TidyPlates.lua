
TidyPlatesOptions = {
	["_EnableMiniButton"] = false,
	["FriendlyAutomation"] = "No Automation",
	["EnemyAutomation"] = "No Automation",
	["primary"] = "Threat Plates",
	["WelcomeShown"] = true,
	["secondary"] = "Threat Plates",
}
