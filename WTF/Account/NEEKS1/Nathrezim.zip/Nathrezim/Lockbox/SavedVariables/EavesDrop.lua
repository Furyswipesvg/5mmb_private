
EavesDropStatsDB = {
	["profileKeys"] = {
		["Lockbox - Nathrezim"] = "Lockbox - Nathrezim",
	},
	["profiles"] = {
		["Lockbox - Nathrezim"] = {
			{
				["hit"] = {
					["Ambush"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 12:58:07|r\n|Hunit:0x0100000004D79169:Lockbox|hYour|h |Hspell:8676:SPELL_DAMAGE|h|cffffffffAmbush|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13011B20000066E:Razorfen Handler|hRazorfen Handler|h |cffffffff889|r |cffffffffPhysical|r. ",
							["amount"] = 889,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Rogue_Ambush",
					},
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 12:36:26|r\n|Hunit:0x0100000004D79169:Lockbox|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF130E4BB000041E3:Scarlet Fanatic|hScarlet Fanatic|h |cffffffff134|r |cffffffffPhysical|r. ",
							["amount"] = 134,
						},
						[2] = {
							["time"] = "|cffffffff11/23/12 01:48:40|r\n|Hunit:0x0100000004D79169:Lockbox|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF13017850000209B:Boar Spirit|hBoar Spirit|h |cffffffff259|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 259,
						},
					},
					["Mutilate"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 12:37:07|r\n|Hunit:0x0100000004D79169:Lockbox|hYour|h |Hspell:5374:SPELL_DAMAGE|h|cffffffffMutilate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E75700004192:Brother Korloff|hBrother Korloff|h |cffffffff315|r |cffffffffPhysical|r. ",
							["amount"] = 315,
						},
						[2] = {
							["time"] = "|cffffffff11/23/12 12:34:19|r\n|Hunit:0x0100000004D79169:Lockbox|hYour|h |Hspell:5374:SPELL_DAMAGE|h|cffffffffMutilate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E4BB000041DC:Scarlet Fanatic|hScarlet Fanatic|h |cffffffff626|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 626,
						},
						["icon"] = "Interface\\Icons\\Ability_DualWield",
					},
					["Deadly Poison"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 01:32:53|r\n|Hunit:0x0100000004D79169:Lockbox|hYour|h |Hspell:2818:SPELL_PERIODIC_DAMAGE|h|cffffffffDeadly Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130114500001FE4:Charlga Razorflank|hCharlga Razorflank|h |cffffffff224|r |cffffffffNature|r. ",
							["amount"] = 224,
						},
						[2] = {
							["time"] = "|cffffffff11/23/12 01:32:56|r\n|Hunit:0x0100000004D79169:Lockbox|hYour|h |Hspell:2818:SPELL_PERIODIC_DAMAGE|h|cffffffffDeadly Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130114500001FE4:Charlga Razorflank|hCharlga Razorflank|h |cffffffff448|r |cffffffffNature|r. (Critical) ",
							["amount"] = 448,
						},
						["icon"] = "Interface\\Icons\\Ability_Rogue_DualWeild",
					},
					["Envenom"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 01:43:59|r\n|Hunit:0x0100000004D79169:Lockbox|hYour|h |Hspell:32645:SPELL_DAMAGE|h|cffffffffEnvenom|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130115400001E93:Razorfen Quilguard|hRazorfen Quilguard|h |cffffffff655|r |cffffffffNature|r. ",
							["amount"] = 655,
						},
						[2] = {
							["time"] = "|cffffffff11/23/12 01:43:09|r\n|Hunit:0x0100000004D79169:Lockbox|hYour|h |Hspell:32645:SPELL_DAMAGE|h|cffffffffEnvenom|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130115400001E98:Razorfen Quilguard|hRazorfen Quilguard|h |cffffffff1309|r |cffffffffNature|r. (Critical) ",
							["amount"] = 1309,
						},
						["icon"] = "Interface\\Icons\\Ability_Rogue_Disembowel",
					},
					["Mutilate Off-Hand"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 12:38:07|r\n|Hunit:0x0100000004D79169:Lockbox|hYour|h |Hspell:27576:SPELL_DAMAGE|h|cffffffffMutilate Off-Hand|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E4BB0000418F:Scarlet Fanatic|hScarlet Fanatic|h |cffffffff179|r |cffffffffPhysical|r. ",
							["amount"] = 179,
						},
						[2] = {
							["time"] = "|cffffffff11/23/12 12:36:48|r\n|Hunit:0x0100000004D79169:Lockbox|hYour|h |Hspell:27576:SPELL_DAMAGE|h|cffffffffMutilate Off-Hand|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E75700004192:Brother Korloff|hBrother Korloff|h |cffffffff411|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 411,
						},
						["icon"] = "Interface\\Icons\\Ability_DualWield",
					},
				},
				["heal"] = {
					["Swift Hand of Justice"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 01:43:13|r\n|Hunit:0x0100000004D79169:Lockbox|hYour|h |Hspell:59913:SPELL_HEAL|h|cffffffffSwift Hand of Justice|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cffffffff61|r |cffffffffPhysical|r. ",
							["amount"] = 61,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_DeathKnight_Vendetta",
					},
					["Holy Strength"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 01:45:27|r\n|Hunit:0x0100000004D79169:Lockbox|hYour|h |Hspell:20007:SPELL_HEAL|h|cffffffffHoly Strength|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cffffffff0|r |cffffffffPhysical|r. (132 Overhealed) ",
							["amount"] = 132,
						},
						[2] = {
							["time"] = "|cffffffff11/23/12 01:04:15|r\n|Hunit:0x0100000004D79169:Lockbox|hYour|h |Hspell:20007:SPELL_HEAL|h|cffffffffHoly Strength|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cffffffff0|r |cffffffffPhysical|r. (252 Overhealed) (Critical) ",
							["amount"] = 252,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_BlessingOfStrength",
					},
					["Recuperate"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 12:32:09|r\n|Hunit:0x0100000004D79169:Lockbox|hYour|h |Hspell:73651:SPELL_PERIODIC_HEAL|h|cffffffffRecuperate|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cffffffff82|r |cffffffffPhysical|r. ",
							["amount"] = 82,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\ability_rogue_recuperate",
					},
				},
			}, -- [1]
			[-1] = {
				["hit"] = {
					["Holy"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 12:34:19|r\n|Hunit:0xF130E4DE000041DB:Scarlet Zealot|hScarlet Zealot|h |Hspell:111010:SPELL_DAMAGE|h|cffff1313Smite|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cffff1313137|r |cffff1313Holy|r. ",
							["amount"] = 137,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolySmite",
					},
					["Shadow"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 01:50:00|r\n|Hunit:0xF130114C00001EBF:Death Speaker Jargba|hDeath Speaker Jargba|h |Hspell:20825:SPELL_DAMAGE|h|cffff1313Shadow Bolt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cffff1313178|r |cffff1313Shadow|r. ",
							["amount"] = 178,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_ShadowBolt",
					},
					["Fire"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 01:37:41|r\n|Hunit:0xF130352100007CD4:Tinkerer Gizlock|hTinkerer Gizlock|h |Hspell:9143:SPELL_DAMAGE|h|cffff1313Bomb|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cffff1313733|r |cffff1313Fire|r. ",
							["amount"] = 733,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_SelfDestruct",
					},
					["Physical"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 01:11:54|r\n|Hunit:0xF130114600000728:Agathelos the Raging|hAgathelos the Raging|h |Hspell:8285:SPELL_DAMAGE|h|cffff1313Rampage|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cffff1313511|r |cffff1313Physical|r. ",
							["amount"] = 511,
						},
						[2] = {
							["time"] = "|cffffffff11/23/12 01:58:06|r\n|Hunit:0xF13011BA00001EE5:Kraul Bat|hKraul Bat|h |Haction:SWING_DAMAGE|h|cffff1313Melee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cffff1313531|r |cffff1313Physical|r. (Critical) ",
							["amount"] = 531,
						},
					},
					["Nature"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 12:24:02|r\n|Hunit:0xF130114500000FBC:Charlga Razorflank|hCharlga Razorflank|h |Hspell:8292:SPELL_DAMAGE|h|cffff1313Chain Bolt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cffff1313181|r |cffff1313Nature|r. ",
							["amount"] = 181,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_ChainLightning",
					},
				},
				["heal"] = {
					["Chi Burst"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 12:38:14|r\n|Hunit:0x03000000073F89E7:Chingwah-Khaz'goroth|hChingwah-Khaz'goroth|h |Hspell:130654:SPELL_HEAL|h|cff82f4ffChi Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff455|r |cff82f4ffNature|r. (101 Overhealed) ",
							["amount"] = 556,
						},
						[2] = {
							["time"] = "|cffffffff11/23/12 12:27:43|r\n|Hunit:0x03000000073F89E7:Chingwah-Khaz'goroth|hChingwah-Khaz'goroth|h |Hspell:130654:SPELL_HEAL|h|cff82f4ffChi Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (863 Overhealed) (Critical) ",
							["amount"] = 863,
						},
						["icon"] = "Interface\\Icons\\Spell_Arcane_ArcaneTorrent",
					},
					["Holy Light"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 01:32:53|r\n|Hunit:0x03000000075F6457:Balarek-Kil'jaeden|hBalarek-Kil'jaeden|h |Hspell:635:SPELL_HEAL|h|cff82f4ffHoly Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff611|r |cff82f4ffHoly|r. (475 Overhealed) ",
							["amount"] = 1086,
						},
						[2] = {
							["time"] = "|cffffffff11/23/12 01:33:03|r\n|Hunit:0x03000000075F6457:Balarek-Kil'jaeden|hBalarek-Kil'jaeden|h |Hspell:635:SPELL_HEAL|h|cff82f4ffHoly Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff507|r |cff82f4ffHoly|r. (1558 Overhealed) (Critical) ",
							["amount"] = 2065,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolyBolt",
					},
					["Healing Wave"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 12:19:53|r\n|Hunit:0x0100000005148604:Zabia-Terenas|hZabia-Terenas|h |Hspell:331:SPELL_HEAL|h|cff82f4ffHealing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff281|r |cff82f4ffNature|r. (434 Overhealed) ",
							["amount"] = 715,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_MagicImmunity",
					},
					["Earthliving"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 12:20:59|r\n|Hunit:0x0100000005148604:Zabia-Terenas|hZabia-Terenas|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (82 Overhealed) ",
							["amount"] = 82,
						},
						[2] = {
							["time"] = "|cffffffff11/23/12 12:21:02|r\n|Hunit:0x0100000005148604:Zabia-Terenas|hZabia-Terenas|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (162 Overhealed) (Critical) ",
							["amount"] = 162,
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_GiftEarthmother",
					},
					["Nourish"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 01:47:38|r\n|Hunit:0x03000000075DCAAC:Síoraí-Kilrogg|hSíoraí-Kilrogg|h |Hspell:50464:SPELL_HEAL|h|cff82f4ffNourish|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff491|r |cff82f4ffNature|r. ",
							["amount"] = 491,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Nourish",
					},
					["Riptide"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 12:24:26|r\n|Hunit:0x0100000005148604:Zabia-Terenas|hZabia-Terenas|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (339 Overhealed) ",
							["amount"] = 339,
						},
						[2] = {
							["time"] = "|cffffffff11/23/12 12:20:04|r\n|Hunit:0x0100000005148604:Zabia-Terenas|hZabia-Terenas|h |Hspell:61295:SPELL_PERIODIC_HEAL|h|cff82f4ffRiptide|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (314 Overhealed) (Critical) ",
							["amount"] = 314,
						},
						["icon"] = "Interface\\Icons\\spell_nature_riptide",
					},
					["Chi Wave"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 12:19:18|r\n|Hicon:1:source|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1.blp:0|t|h|Hunit:0x01000000051692B7:Panduhmonk-Terenas|hPanduhmonk-Terenas|h |Hspell:132463:SPELL_HEAL|h|cff82f4ffChi Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (462 Overhealed) ",
							["amount"] = 462,
						},
						[2] = {
							["time"] = "|cffffffff11/23/12 01:12:03|r\n|Hunit:0x01000000051ADD01:Monkorly-Windrunner|hMonkorly-Windrunner|h |Hspell:132463:SPELL_HEAL|h|cff82f4ffChi Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (891 Overhealed) (Critical) ",
							["amount"] = 891,
						},
						["icon"] = "Interface\\Icons\\ability_monk_chiwave",
					},
					["Holy Radiance"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 01:32:24|r\n|Hunit:0x03000000075F6457:Balarek-Kil'jaeden|hBalarek-Kil'jaeden|h |Hspell:82327:SPELL_HEAL|h|cff82f4ffHoly Radiance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (378 Overhealed) ",
							["amount"] = 378,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\spell_paladin_divinecircle",
					},
					["Swiftmend"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 01:58:06|r\n|Hunit:0x03000000075DCAAC:Síoraí-Kilrogg|hSíoraí-Kilrogg|h |Hspell:81269:SPELL_HEAL|h|cff82f4ffSwiftmend|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff136|r |cff82f4ffNature|r. ",
							["amount"] = 136,
						},
						[2] = {
							["time"] = "|cffffffff11/23/12 01:59:17|r\n|Hunit:0x03000000075DCAAC:Síoraí-Kilrogg|hSíoraí-Kilrogg|h |Hspell:81269:SPELL_HEAL|h|cff82f4ffSwiftmend|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (271 Overhealed) (Critical) ",
							["amount"] = 271,
						},
						["icon"] = "Interface\\Icons\\INV_Misc_Herb_TalandrasRose",
					},
					["Surging Mist"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 01:10:40|r\n|Hunit:0x030000000758C5AB:Preenna-Dath'Remar|hPreenna-Dath'Remar|h |Hspell:116995:SPELL_HEAL|h|cff82f4ffSurging Mist|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff216|r |cff82f4ffNature|r. (1235 Overhealed) ",
							["amount"] = 1451,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_surgingmist",
					},
					["Rejuvenation"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 02:00:11|r\n|Hunit:0x03000000075DCAAC:Síoraí-Kilrogg|hSíoraí-Kilrogg|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cff82f4ffRejuvenation|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff341|r |cff82f4ffNature|r. ",
							["amount"] = 341,
						},
						[2] = {
							["time"] = "|cffffffff11/23/12 01:47:48|r\n|Hunit:0x03000000075DCAAC:Síoraí-Kilrogg|hSíoraí-Kilrogg|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cff82f4ffRejuvenation|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff149|r |cff82f4ffNature|r. (513 Overhealed) (Critical) ",
							["amount"] = 662,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Rejuvenation",
					},
					["Soothing Mist"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 12:32:43|r\n|Hunit:0x0180000004D35581:Wodash-Darkspear|hWodash-Darkspear|h |Hspell:115175:SPELL_PERIODIC_HEAL|h|cff82f4ffSoothing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff217|r |cff82f4ffNature|r. ",
							["amount"] = 217,
						},
						[2] = {
							["time"] = "|cffffffff11/23/12 12:32:46|r\n|Hunit:0x0180000004D35581:Wodash-Darkspear|hWodash-Darkspear|h |Hspell:115175:SPELL_PERIODIC_HEAL|h|cff82f4ffSoothing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff155|r |cff82f4ffNature|r. (279 Overhealed) (Critical) ",
							["amount"] = 434,
						},
						["icon"] = "Interface\\Icons\\ability_monk_soothingmists",
					},
					["Healing Surge"] = {
						[-2] = {
							["time"] = "|cffffffff11/23/12 12:20:55|r\n|Hunit:0x0100000005148604:Zabia-Terenas|hZabia-Terenas|h |Hspell:8004:SPELL_HEAL|h|cff82f4ffHealing Surge|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (1170 Overhealed) ",
							["amount"] = 1170,
						},
						[2] = {
							["time"] = "|cffffffff11/23/12 12:20:49|r\n|Hunit:0x0100000005148604:Zabia-Terenas|hZabia-Terenas|h |Hspell:8004:SPELL_HEAL|h|cff82f4ffHealing Surge|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004D79169:Lockbox|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (2247 Overhealed) (Critical) ",
							["amount"] = 2247,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWay",
					},
				},
			},
		},
	},
}
