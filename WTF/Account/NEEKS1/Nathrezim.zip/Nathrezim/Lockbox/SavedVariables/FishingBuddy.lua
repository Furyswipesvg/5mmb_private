
FishingBuddy_Player = {
	["MinimapData"] = {
		["minimapPos"] = 252.6883806609271,
		["hide"] = false,
	},
	["Settings"] = {
		["ResetWatcher"] = 1,
	},
	["WasWearing"] = {
	},
	["Outfit"] = {
	},
}
