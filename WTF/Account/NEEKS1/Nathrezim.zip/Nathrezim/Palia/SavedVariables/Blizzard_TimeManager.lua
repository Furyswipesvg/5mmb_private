
BlizzardStopwatchOptions = {
	["position"] = {
		["y"] = 560.000244140625,
		["x"] = 1098.000244140625,
	},
}
