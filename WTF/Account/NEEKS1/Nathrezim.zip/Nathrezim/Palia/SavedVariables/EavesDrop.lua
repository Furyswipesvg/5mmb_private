
EavesDropStatsDB = {
	["profileKeys"] = {
		["Palia - Nathrezim"] = "Palia - Nathrezim",
	},
	["profiles"] = {
		["Palia - Nathrezim"] = {
			{
				["hit"] = {
					["Fireball"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 11:55:01|r\n|Hunit:0x01000000034F5406:Palia|hPalia's|h |Hspell:133:SPELL_DAMAGE|h|cffffffffFireball|r|h hits |Hunit:0xF130650900007D84:Frozen Core|hFrozen Core|h for |cffffffff21083|r |cffffffffFire|r.",
							["amount"] = 21083,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 11:53:55|r\n|Hunit:0x01000000034F5406:Palia|hPalia's|h |Hspell:133:SPELL_DAMAGE|h|cffffffffFireball|r|h hits |Hunit:0xF130649C00007D9F:Ahunite Coldwave|hAhunite Coldwave|h for |cffffffff4574|r |cffffffffFire|r.(38973 Overkill) (Critical)",
							["amount"] = 43547,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_FlameBolt",
					},
					["Mantid Poison"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 07:33:48|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:128386:SPELL_PERIODIC_DAMAGE|h|cffffffffMantid Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130F37400654206:Norvakess|hNorvakess|h |cffffffff7581|r |cffffffffNature|r. ",
							["amount"] = 7581,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 07:33:50|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:128386:SPELL_PERIODIC_DAMAGE|h|cffffffffMantid Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130F37400654206:Norvakess|hNorvakess|h |cffffffff15617|r |cffffffffNature|r. (Critical) ",
							["amount"] = 15617,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_NullifyPoison",
					},
					["Frost Bomb"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 06:36:24|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:113092:SPELL_DAMAGE|h|cffffffffFrost Bomb|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFBE0064BD53:Krik'thik Deep-Scout|hKrik'thik Deep-Scout|h |cffffffff22679|r |cffffffffFrost|r. ",
							["amount"] = 22679,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 06:35:05|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:113092:SPELL_DAMAGE|h|cffffffffFrost Bomb|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFBE006470A9:Krik'thik Deep-Scout|hKrik'thik Deep-Scout|h |cffffffff46719|r |cffffffffFrost|r. (Critical) ",
							["amount"] = 46719,
						},
						["icon"] = "Interface\\Icons\\spell_mage_frostbomb",
					},
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff02/03/13 09:57:28|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF1303E9E003E2765:Maggot|hMaggot|h |cffffffff17|r |cffffffffPhysical|r. (7051 Overkill) ",
							["amount"] = 7068,
						},
						[2] = {
							["time"] = "|cffffffff02/03/13 09:48:21|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF1303CBC0002BABD:Spectral Stallion|hSpectral Stallion|h |cffffffff10462|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 10462,
						},
					},
					["Frostbolt"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 07:35:37|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:116:SPELL_DAMAGE|h|cffffffffFrostbolt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F37400654206:Norvakess|hNorvakess|h |cffffffff32151|r |cffffffffFrost|r. ",
							["amount"] = 32151,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 06:36:54|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:116:SPELL_DAMAGE|h|cffffffffFrostbolt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFBE0064B647:Krik'thik Deep-Scout|hKrik'thik Deep-Scout|h |cffffffff70950|r |cffffffffFrost|r. (Critical) ",
							["amount"] = 70950,
						},
						["icon"] = "Interface\\Icons\\Spell_Frost_FrostBolt02",
					},
					["Arcane Explosion"] = {
						[-2] = {
							["time"] = "|cffffffff02/03/13 09:45:56|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:1449:SPELL_DAMAGE|h|cffffffffArcane Explosion|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1303CBE0002C038:Attumen the Huntsman|hAttumen the Huntsman|h |cffffffff4820|r |cffffffffArcane|r. ",
							["amount"] = 4820,
						},
						[2] = {
							["time"] = "|cffffffff02/03/13 09:45:56|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:1449:SPELL_DAMAGE|h|cffffffffArcane Explosion|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1303CBC0002BABF:Spectral Stallion|hSpectral Stallion|h |cffffffff9643|r |cffffffffArcane|r. (Critical) ",
							["amount"] = 9643,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_WispSplode",
					},
					["Living Bomb"] = {
						[-2] = {
							["time"] = "|cffffffff02/03/13 09:45:15|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:44461:SPELL_DAMAGE|h|cffffffffLiving Bomb|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1303F170002BF7F:Midnight|hMidnight|h |cffffffff24774|r |cffffffffFire|r. ",
							["amount"] = 24774,
						},
						[2] = {
							["time"] = "|cffffffff02/03/13 09:45:15|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:44461:SPELL_DAMAGE|h|cffffffffLiving Bomb|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1303CBB0002B967:Spectral Charger|hSpectral Charger|h |cffffffff40970|r |cffffffffFire|r. (8579 Overkill) (Critical) ",
							["amount"] = 49549,
						},
						["icon"] = "Interface\\Icons\\Ability_Mage_LivingBomb",
					},
					["Pyroblast"] = {
						[-2] = {
							["time"] = "|cffffffff02/03/13 09:47:57|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:11366:SPELL_DAMAGE|h|cffffffffPyroblast|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1303CBB0002B960:Spectral Charger|hSpectral Charger|h |cffffffff45240|r |cffffffffFire|r. (3075 Overkill) ",
							["amount"] = 48315,
						},
						[2] = {
							["time"] = "|cffffffff02/03/13 09:48:44|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:11366:SPELL_DAMAGE|h|cffffffffPyroblast|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1303CBF0002BABC:Spectral Stable Hand|hSpectral Stable Hand|h |cffffffff2487|r |cffffffffFire|r. (75074 Overkill) (Critical) ",
							["amount"] = 77561,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_Fireball02",
					},
					["Ice Lance"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 07:35:41|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:30455:SPELL_DAMAGE|h|cffffffffIce Lance|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F37400654206:Norvakess|hNorvakess|h |cffffffff46080|r |cffffffffFrost|r. ",
							["amount"] = 46080,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 07:34:09|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:30455:SPELL_DAMAGE|h|cffffffffIce Lance|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F37400654206:Norvakess|hNorvakess|h |cffffffff95403|r |cffffffffFrost|r. (Critical) ",
							["amount"] = 95403,
						},
						["icon"] = "Interface\\Icons\\Spell_Frost_FrostBlast",
					},
					["Flamestrike"] = {
						[-2] = {
							["time"] = "|cffffffff02/03/13 09:45:21|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:2120:SPELL_DAMAGE|h|cffffffffFlamestrike|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1303F170002BF7F:Midnight|hMidnight|h |cffffffff6031|r |cffffffffFire|r. ",
							["amount"] = 6031,
						},
						[2] = {
							["time"] = "|cffffffff02/03/13 09:49:40|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:2120:SPELL_DAMAGE|h|cffffffffFlamestrike|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1303CBC0002BAF8:Spectral Stallion|hSpectral Stallion|h |cffffffff8066|r |cffffffffFire|r. (Critical) ",
							["amount"] = 8066,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_SelfDestruct",
					},
					["Frozen Orb"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 06:36:18|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:84721:SPELL_DAMAGE|h|cffffffffFrozen Orb|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFBE0064BD53:Krik'thik Deep-Scout|hKrik'thik Deep-Scout|h |cffffffff4677|r |cffffffffFrost|r. ",
							["amount"] = 4677,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 06:36:17|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:84721:SPELL_DAMAGE|h|cffffffffFrozen Orb|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFBE0064BD53:Krik'thik Deep-Scout|hKrik'thik Deep-Scout|h |cffffffff9743|r |cffffffffFrost|r. (Critical) ",
							["amount"] = 9743,
						},
						["icon"] = "Interface\\Icons\\spell_frost_frozenorb",
					},
					["Fire Power"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 11:54:38|r\n|Hunit:0x01000000034F5406:Palia|hPalia's|h |Hspell:83619:SPELL_DAMAGE|h|cffffffffFire Power|r|h hits |Hunit:0xF130650900007D84:Frozen Core|hFrozen Core|h for |cffffffff4163|r |cffffffffFire|r.",
							["amount"] = 4163,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Mage_Burnout",
					},
					["Flame Orb"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 11:53:12|r\n|Hunit:0x01000000034F5406:Palia|hPalia's|h |Hspell:82739:SPELL_DAMAGE|h|cffffffffFlame Orb|r|h hits |Hunit:0xF130649B00007D83:Ahunite Hailstone|hAhunite Hailstone|h for |cffffffff2874|r |cffffffffFire|r.",
							["amount"] = 2874,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 11:53:12|r\n|Hunit:0x01000000034F5406:Palia|hPalia's|h |Hspell:82739:SPELL_DAMAGE|h|cffffffffFlame Orb|r|h hits |Hunit:0xF130649B00007D83:Ahunite Hailstone|hAhunite Hailstone|h for |cffffffff6102|r |cffffffffFire|r.(Critical)",
							["amount"] = 6102,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_mage_flameorb",
					},
					["Fire Blast"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 07:30:16|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:2136:SPELL_DAMAGE|h|cffffffffFire Blast|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EF7600659B52:Agitated Seedstealer|hAgitated Seedstealer|h |cffffffff8197|r |cffffffffFire|r. ",
							["amount"] = 8197,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 06:59:52|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:2136:SPELL_DAMAGE|h|cffffffffFire Blast|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFB500654B8F:Krik'thik Locust-Guard|hKrik'thik Locust-Guard|h |cffffffff16200|r |cffffffffFire|r. (Critical) ",
							["amount"] = 16200,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_Fireball",
					},
					["Inferno Blast"] = {
						[-2] = {
						},
						[2] = {
							["time"] = "|cffffffff02/03/13 09:49:21|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:108853:SPELL_DAMAGE|h|cffffffffInferno Blast|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1303CBF0002B968:Spectral Stable Hand|hSpectral Stable Hand|h |cffffffff23164|r |cffffffffFire|r. (Critical) ",
							["amount"] = 23164,
						},
						["icon"] = "Interface\\Icons\\spell_mage_infernoblast",
					},
					["Molten Armor"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 11:53:43|r\n|Hunit:0x01000000034F5406:Palia|hPalia's|h |Hspell:34913:SPELL_DAMAGE|h|cffffffffMolten Armor|r|h hits |Hunit:0xF130649C00007D9A:Ahunite Coldwave|hAhunite Coldwave|h for |cffffffff302|r |cffffffffFire|r.",
							["amount"] = 302,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 11:53:39|r\n|Hunit:0x01000000034F5406:Palia|hPalia's|h |Hspell:34913:SPELL_DAMAGE|h|cffffffffMolten Armor|r|h hits |Hunit:0xF130649C00007D9C:Ahunite Coldwave|hAhunite Coldwave|h for |cffffffff554|r |cffffffffFire|r.(Critical)",
							["amount"] = 554,
						},
						["icon"] = "Interface\\Icons\\Ability_Mage_MoltenArmor",
					},
					["Combustion"] = {
						[-2] = {
							["time"] = "|cffffffff02/03/13 09:50:16|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:11129:SPELL_DAMAGE|h|cffffffffCombustion|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1303F170002C43E:Midnight|hMidnight|h |cffffffff15581|r |cffffffffFire|r. ",
							["amount"] = 15581,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 07:13:41|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:11129:SPELL_DAMAGE|h|cffffffffCombustion|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB008E60D8:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff19638|r |cffffffffFire|r. (Critical) ",
							["amount"] = 19638,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_SealOfFire",
					},
					["Frostfire Bolt"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 06:36:27|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:44614:SPELL_DAMAGE|h|cffffffffFrostfire Bolt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFBE0064BD53:Krik'thik Deep-Scout|hKrik'thik Deep-Scout|h |cffffffff17633|r |cffffffffFrostfire|r. ",
							["amount"] = 17633,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 07:35:30|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:44614:SPELL_DAMAGE|h|cffffffffFrostfire Bolt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F37400654206:Norvakess|hNorvakess|h |cffffffff43574|r |cffffffffFrostfire|r. (Critical) ",
							["amount"] = 43574,
						},
						["icon"] = "Interface\\Icons\\Ability_Mage_FrostFireBolt",
					},
					["Pyroblast!"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 11:54:58|r\n|Hunit:0x01000000034F5406:Palia|hPalia's|h |Hspell:92315:SPELL_DAMAGE|h|cffffffffPyroblast!|r|h hits |Hunit:0xF130650900007D84:Frozen Core|hFrozen Core|h for |cffffffff23546|r |cffffffffFire|r.",
							["amount"] = 23546,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 11:53:41|r\n|Hunit:0x01000000034F5406:Palia|hPalia's|h |Hspell:92315:SPELL_DAMAGE|h|cffffffffPyroblast!|r|h hits |Hunit:0xF130649C00007D9A:Ahunite Coldwave|hAhunite Coldwave|h for |cffffffff45075|r |cffffffffFire|r.(Critical)",
							["amount"] = 45075,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_Fireball02",
					},
					["Blast of Corruption"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 06:34:39|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:109851:SPELL_PERIODIC_DAMAGE|h|cffffffffBlast of Corruption|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130EFBE0064761F:Krik'thik Deep-Scout|hKrik'thik Deep-Scout|h |cffffffff3318|r |cffffffffNature|r. ",
							["amount"] = 3318,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 06:34:19|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:109851:SPELL_PERIODIC_DAMAGE|h|cffffffffBlast of Corruption|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130EFBE0064719D:Krik'thik Deep-Scout|hKrik'thik Deep-Scout|h |cffffffff6834|r |cffffffffNature|r. (Critical) ",
							["amount"] = 6834,
						},
						["icon"] = "Interface\\Icons\\Ability_Creature_Poison_06",
					},
					["Cauterize"] = {
						[-2] = {
							["time"] = "|cffffffff02/03/13 09:43:24|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:87023:SPELL_PERIODIC_DAMAGE|h|cffffffffCauterize|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x01000000034F5406:Palia|hYou|h |cffffffff29786|r |cffffffffFire|r. ",
							["amount"] = 29786,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\spell_fire_rune",
					},
					["Ignite"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 11:54:47|r\n|Hunit:0xF130650900007D84:Frozen Core|hFrozen Core|h suffers |cffffffff16714|r |cffffffffFire|r damage from |Hunit:0x01000000034F5406:Palia|hPalia's|h |Hspell:12654:SPELL_PERIODIC_DAMAGE|h|cffffffffIgnite|r|h.",
							["amount"] = 16714,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_Incinerate",
					},
					["Frost Nova"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 07:34:06|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:122:SPELL_DAMAGE|h|cffffffffFrost Nova|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F37400654206:Norvakess|hNorvakess|h |cffffffff4973|r |cffffffffFrost|r. ",
							["amount"] = 4973,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 07:35:46|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:122:SPELL_DAMAGE|h|cffffffffFrost Nova|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F37400654206:Norvakess|hNorvakess|h |cffffffff9987|r |cffffffffFrost|r. (Critical) ",
							["amount"] = 9987,
						},
						["icon"] = "Interface\\Icons\\Spell_Frost_FrostNova",
					},
					["Arcane Barrage"] = {
						[-2] = {
							["time"] = "|cffffffff02/03/13 09:45:53|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:44425:SPELL_DAMAGE|h|cffffffffArcane Barrage|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1303F170002BF7F:Midnight|hMidnight|h |cffffffff28589|r |cffffffffArcane|r. ",
							["amount"] = 28589,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Mage_ArcaneBarrage",
					},
					["Cone of Cold"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 06:40:50|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:120:SPELL_DAMAGE|h|cffffffffCone of Cold|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFBE00647B00:Krik'thik Deep-Scout|hKrik'thik Deep-Scout|h |cffffffff6784|r |cffffffffFrost|r. ",
							["amount"] = 6784,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 06:46:44|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:120:SPELL_DAMAGE|h|cffffffffCone of Cold|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFBD00652185:Krik'thik Scentlayer|hKrik'thik Scentlayer|h |cffffffff6500|r |cffffffffFrost|r. (Critical) ",
							["amount"] = 6500,
						},
						["icon"] = "Interface\\Icons\\Spell_Frost_Glacier",
					},
					["Dragon's Breath"] = {
						[-2] = {
							["time"] = "|cffffffff02/03/13 09:48:14|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:31661:SPELL_DAMAGE|h|cffffffffDragon's Breath|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1303CBC0002BABF:Spectral Stallion|hSpectral Stallion|h |cffffffff5576|r |cffffffffFire|r. ",
							["amount"] = 5576,
						},
						[2] = {
							["time"] = "|cffffffff02/03/13 09:49:02|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:31661:SPELL_DAMAGE|h|cffffffffDragon's Breath|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1303CBB0002B964:Spectral Charger|hSpectral Charger|h |cffffffff11407|r |cffffffffFire|r. (Critical) ",
							["amount"] = 11407,
						},
						["icon"] = "Interface\\Icons\\INV_Misc_Head_Dragon_01",
					},
				},
				["heal"] = {
					["Temporal Ripples"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 06:40:58|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:115611:SPELL_PERIODIC_HEAL|h|cffffffffTemporal Ripples|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000034F5406:Palia|hYou|h |cffffffff5927|r |cffffffffArcane|r. ",
							["amount"] = 5927,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\spell_mage_temporalshield",
					},
					["Cintron-Infused Bandage"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 06:56:40|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:120573:SPELL_PERIODIC_HEAL|h|cffffffffCintron-Infused Bandage|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0xF130F0FC0064E941:Injured Gao-Ran Blackguard|hInjured Gao-Ran Blackguard|h |cffffffff39395|r |cffffffffPhysical|r. ",
							["amount"] = 39395,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\inv_misc_bandage_frostweave",
					},
					["Cauterize"] = {
						[-2] = {
							["time"] = "|cffffffff02/03/13 09:43:21|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:87023:SPELL_HEAL|h|cffffffffCauterize|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000034F5406:Palia|hYou|h |cffffffff147519|r |cffffffffFire|r. ",
							["amount"] = 147519,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\spell_fire_rune",
					},
					["Frostbolt"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 07:38:58|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:126201:SPELL_HEAL|h|cffffffffFrostbolt|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0xF140BA3B2E008C80:Water Elemental|hWater Elemental|h |cffffffff15187|r |cffffffffFrost|r. ",
							["amount"] = 15187,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 07:08:57|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:134660:SPELL_HEAL|h|cffffffffFrostbolt|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0xF140BA3B2E008B93:Water Elemental|hWater Elemental|h |cffffffff0|r |cffffffffFrost|r. (11825 Overhealed) (Critical) ",
							["amount"] = 11825,
						},
						["icon"] = "Interface\\Icons\\Spell_Frost_FrostBolt02",
					},
					["Cold Snap"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 07:01:43|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:11958:SPELL_HEAL|h|cffffffffCold Snap|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000034F5406:Palia|hYou|h |cffffffff61746|r |cffffffffPhysical|r. ",
							["amount"] = 61746,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Frost_WizardMark",
					},
					["Evocation"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 07:19:52|r\n|Hunit:0x01000000034F5406:Palia|hYour|h |Hspell:12051:SPELL_PERIODIC_HEAL|h|cffffffffEvocation|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000034F5406:Palia|hYou|h |cffffffff0|r |cffffffffArcane|r. (32930 Overhealed) ",
							["amount"] = 32930,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Purge",
					},
				},
			}, -- [1]
			[-1] = {
				["hit"] = {
					["Frost"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 11:53:40|r\n|Hspell:46588:SPELL_DAMAGE|h|cff82f4ffIce Spear|r|h hits |Hunit:0x01000000034F5406:Palia|hPalia|h for |cff82f4ff8757|r |cff82f4ffFrost|r.(5838 Resisted)",
							["amount"] = 8757,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Trade_Engineering",
					},
					["Shadow"] = {
						[-2] = {
							["time"] = "|cffffffff02/03/13 09:45:35|r\n|Hunit:0xF1303CBE0002C038:Attumen the Huntsman|hAttumen the Huntsman|h |Hspell:29832:SPELL_DAMAGE|h|cffff1313Shadow Cleave|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000034F5406:Palia|hYou|h |cffff13133811|r |cffff1313Shadow|r. ",
							["amount"] = 3811,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_Cleave",
					},
					["Fire"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 06:32:40|r\n|Hspell:124781:SPELL_DAMAGE|h|cff82f4ffMantid Mine|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000034F5406:Palia|hYou|h |cff82f4ff20876|r |cff82f4ffFire|r. ",
							["amount"] = 20876,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Mage_LivingBomb",
					},
					["Physical"] = {
						[-2] = {
							["time"] = "|cffffffff11/29/12 10:14:41|r\n|Haction:ENVIRONMENTAL_DAMAGE|h|cffffffffFalling|r|h |Haction:ENVIRONMENTAL_DAMAGE|hdamaged|h |Hunit:0x01000000034F5406:Palia|hYou|h |cffffffff134683|r |cffffffffPhysical|r. ",
							["amount"] = 134683,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 06:51:52|r\n|Hunit:0xF130EFBD00653158:Krik'thik Scentlayer|hKrik'thik Scentlayer|h |Haction:SWING_DAMAGE|h|cffff1313Melee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0x01000000034F5406:Palia|hYou|h |cffff131316233|r |cffff1313Physical|r. (Critical) ",
							["amount"] = 16233,
						},
					},
					["Nature"] = {
						[-2] = {
							["time"] = "|cffffffff11/29/12 05:16:58|r\n|Hspell:132724:SPELL_DAMAGE|h|cffffffffLightning Field|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000034F5406:Palia|hYou|h |cffffffff143839|r |cffffffffNature|r. (276081 Overkill) ",
							["amount"] = 419920,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Lightning",
					},
				},
				["heal"] = {
					["Riptide"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 11:53:46|r\n|Hunit:0x010000000485F743:Neturi-Frostmane|hNeturi-Frostmane's|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h heals |Hunit:0x01000000034F5406:Palia|hPalia|h for |cff82f4ff7435|r.",
							["amount"] = 7435,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 11:53:22|r\n|Hunit:0x010000000485F743:Neturi-Frostmane|hNeturi-Frostmane's|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h heals |Hunit:0x01000000034F5406:Palia|hPalia|h for |cff82f4ff2393|r.(16047 Overhealed) (Critical)",
							["amount"] = 18440,
						},
						["icon"] = "Interface\\Icons\\spell_nature_riptide",
					},
					["Healing Stream Totem"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 11:53:22|r\n|Hunit:0x01000000034F5406:Palia|hPalia|h gains |cff82f4ff0|r Health from |Hunit:0xF1300DC700007D91:Healing Stream Totem|hHealing Stream Totem's|h |Hspell:52042:SPELL_PERIODIC_HEAL|h|cff82f4ffHealing Stream Totem|r|h.(2230 Overhealed)",
							["amount"] = 2230,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Stoicism",
					},
					["Ancestral Awakening"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 11:53:24|r\n|Hunit:0x010000000485F743:Neturi-Frostmane|hNeturi-Frostmane's|h |Hspell:52752:SPELL_HEAL|h|cff82f4ffAncestral Awakening|r|h heals |Hunit:0x01000000034F5406:Palia|hPalia|h for |cff82f4ff2938|r.(2871 Overhealed)",
							["amount"] = 5809,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_AncestralAwakening",
					},
					["Blood Burst"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 07:03:25|r\n|Hunit:0xF1306D7100A9560B:Bloodworm|hBloodworm|h |Hspell:81280:SPELL_HEAL|h|cff82f4ffBlood Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000034F5406:Palia|hYou|h |cff82f4ff0|r |cff82f4ffShadow|r. (21709 Overhealed) ",
							["amount"] = 21709,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_BloodNova",
					},
				},
			},
		},
	},
}
