
Prat3HighCPUPerCharDB = {
	["time"] = 1360558801,
	["scrollback"] = {
		["ChatFrame1"] = {
			{
				"|cff979797[20:59:45]|r|c00000000|r |Hchannel:channel:1|h[1] |h Joined Channel: |Hchannel:1|h[1. General - Deadwind Pass]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				69, -- [5]
			}, -- [1]
			{
				"|cff979797[20:59:45]|r|c00000000|r |Hchannel:channel:2|h[2] |h Joined Channel: |Hchannel:2|h[2. LocalDefense - Deadwind Pass]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				70, -- [5]
			}, -- [2]
			{
				"|cff979797[21:00:01]|r|c00000000|r |cff9382c9Lockontop|r has gone offline.", -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
				1, -- [5]
			}, -- [3]
		},
	},
}
