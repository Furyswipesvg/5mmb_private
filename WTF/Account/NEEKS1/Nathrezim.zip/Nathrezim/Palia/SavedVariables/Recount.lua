
RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
		["Midnight"] = {
			["GUID"] = "0xF1303F170002BF7F",
			["LastAttackedBy"] = "Palia",
			["enClass"] = "MOB",
			["LastDamageTaken"] = 4636,
			["level"] = -1,
			["LastDamageAbility"] = "Living Bomb (DoT)",
			["LastFightIn"] = 9,
			["type"] = "Trivial",
			["FightsSaved"] = 5,
			["GuardianReverseGUIDs"] = {
				["Attumen the Huntsman"] = {
					["LatestGuardian"] = 2,
					["GUIDs"] = {
						"0xF1303CBE0002D730", -- [1]
						"0xF1303F180002D764", -- [2]
						[0] = "0xF1303CBE0002C038",
					},
				},
			},
			["Owner"] = false,
			["Pet"] = {
				"Attumen the Huntsman <Midnight>", -- [1]
				"Attumen the Huntsman <Attumen the Huntsman>", -- [2]
			},
			["Name"] = "Midnight",
			["LastAbility"] = 18950.966,
			["Fights"] = {
				["Fight1"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
					},
					["HOTs"] = {
					},
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["DamagedWho"] = {
						["Palia"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12344,
								},
							},
							["amount"] = 12344,
						},
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
					},
					["ElementHitsDone"] = {
					},
					["ManaGainedFrom"] = {
					},
					["CCBroken"] = {
					},
					["WhoDamaged"] = {
						["Palia"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 43611,
								},
								["Combustion (DoT)"] = {
									["count"] = 9108,
								},
								["Combustion"] = {
									["count"] = 15581,
								},
								["Living Bomb"] = {
									["count"] = 74523,
								},
								["Ignite (DoT)"] = {
									["count"] = 7735,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 21692,
								},
								["Flamestrike"] = {
									["count"] = 4032,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 12560,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 14104,
								},
							},
							["amount"] = 202946,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["Dispelled"] = 0,
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["FDamage"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["PartialAbsorb"] = {
					},
					["ActiveTime"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Palia"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 15.51,
								},
							},
							["amount"] = 15.51,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["Interrupts"] = 0,
					["EnergyGained"] = {
					},
					["PartialResist"] = {
					},
					["Healing"] = 0,
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["Attacks"] = {
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["Palia"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 15.51,
								},
							},
							["amount"] = 15.51,
						},
					},
					["ManaGain"] = 0,
					["DOT_Time"] = 0,
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
					},
					["HOTs"] = {
					},
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["DamagedWho"] = {
						["Palia"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12344,
								},
							},
							["amount"] = 12344,
						},
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
					},
					["ElementHitsDone"] = {
					},
					["ManaGainedFrom"] = {
					},
					["CCBroken"] = {
					},
					["WhoDamaged"] = {
						["Palia"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 43611,
								},
								["Combustion (DoT)"] = {
									["count"] = 9108,
								},
								["Combustion"] = {
									["count"] = 15581,
								},
								["Living Bomb"] = {
									["count"] = 74523,
								},
								["Ignite (DoT)"] = {
									["count"] = 7735,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 21692,
								},
								["Flamestrike"] = {
									["count"] = 4032,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 12560,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 14104,
								},
							},
							["amount"] = 202946,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["Dispelled"] = 0,
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["FDamage"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["PartialAbsorb"] = {
					},
					["ActiveTime"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Palia"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 15.51,
								},
							},
							["amount"] = 15.51,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["Interrupts"] = 0,
					["EnergyGained"] = {
					},
					["PartialResist"] = {
					},
					["Healing"] = 0,
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["Attacks"] = {
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["Palia"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 15.51,
								},
							},
							["amount"] = 15.51,
						},
					},
					["ManaGain"] = 0,
					["DOT_Time"] = 0,
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
					},
					["HOTs"] = {
					},
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["DamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
					},
					["ElementHitsDone"] = {
					},
					["ManaGainedFrom"] = {
					},
					["CCBroken"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["Dispelled"] = 0,
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["FDamage"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["PartialAbsorb"] = {
					},
					["ActiveTime"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["Interrupts"] = 0,
					["EnergyGained"] = {
					},
					["PartialResist"] = {
					},
					["Healing"] = 0,
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["Attacks"] = {
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["DOT_Time"] = 0,
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["WhoDamaged"] = {
						["Palia"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 43611,
								},
								["Melee"] = {
									["count"] = 43392,
								},
								["Combustion (DoT)"] = {
									["count"] = 9108,
								},
								["Combustion"] = {
									["count"] = 15581,
								},
								["Arcane Explosion"] = {
									["count"] = 17001,
								},
								["Living Bomb"] = {
									["count"] = 99297,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 28268,
								},
								["Flamestrike"] = {
									["count"] = 10063,
								},
								["Ignite (DoT)"] = {
									["count"] = 7735,
								},
								["Frost Nova"] = {
									["count"] = 2112,
								},
								["Arcane Barrage"] = {
									["count"] = 28589,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 56213,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 32954,
								},
							},
							["amount"] = 393924,
						},
					},
					["TimeSpent"] = {
						["Palia"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 61.87000000000001,
								},
								["Knockdown"] = {
									["count"] = 2.18,
								},
							},
							["amount"] = 64.05,
						},
					},
					["DamagedWho"] = {
						["Palia"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 55466,
								},
								["Knockdown"] = {
									["count"] = 318,
								},
							},
							["amount"] = 55784,
						},
					},
					["TimeDamaging"] = {
						["Palia"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 61.87000000000001,
								},
								["Knockdown"] = {
									["count"] = 2.18,
								},
							},
							["amount"] = 64.05,
						},
					},
				},
			},
			["UnitLockout"] = 1359956704,
			["LastActive"] = 1359957025,
		},
		["Palia"] = {
			["GUID"] = "0x01000000034F5406",
			["LastEventHealth"] = {
				"254314 (85%)", -- [1]
				"254314 (85%)", -- [2]
				"252393 (84%)", -- [3]
				"252393 (84%)", -- [4]
				"252724 (84%)", -- [5]
				"252724 (84%)", -- [6]
				"252724 (84%)", -- [7]
				"252724 (84%)", -- [8]
				"252724 (84%)", -- [9]
				"251030 (84%)", -- [10]
				"251359 (84%)", -- [11]
				"249163 (83%)", -- [12]
				"249163 (83%)", -- [13]
				"249163 (83%)", -- [14]
				"249163 (83%)", -- [15]
				"247586 (83%)", -- [16]
				"247586 (83%)", -- [17]
				"247586 (83%)", -- [18]
				"245881 (82%)", -- [19]
				"245881 (82%)", -- [20]
				"244093 (81%)", -- [21]
				"244093 (81%)", -- [22]
				"244093 (81%)", -- [23]
				"244093 (81%)", -- [24]
				"242073 (81%)", -- [25]
				"242073 (81%)", -- [26]
				"242073 (81%)", -- [27]
				"242073 (81%)", -- [28]
				"242402 (81%)", -- [29]
				"240397 (80%)", -- [30]
				"240397 (80%)", -- [31]
				"298135 (100%)", -- [32]
				"298135 (100%)", -- [33]
				"298135 (100%)", -- [34]
				"298135 (100%)", -- [35]
				"298135 (100%)", -- [36]
				"298135 (100%)", -- [37]
				"298135 (100%)", -- [38]
				"298135 (100%)", -- [39]
				"298135 (100%)", -- [40]
				"298135 (100%)", -- [41]
				"298135 (100%)", -- [42]
				"298135 (100%)", -- [43]
				"255584 (85%)", -- [44]
				"255584 (85%)", -- [45]
				"255584 (85%)", -- [46]
				"255913 (85%)", -- [47]
				"255913 (85%)", -- [48]
				"253983 (85%)", -- [49]
				"254314 (85%)", -- [50]
			},
			["LastAttackedBy"] = "Attumen the Huntsman <Midnight>",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"MISC", -- [13]
				"MISC", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					3.4, -- [1]
				},
				["Dispelled"] = {
					1, -- [1]
				},
				["Dispels"] = {
					1, -- [1]
				},
				["Healing"] = {
					146456, -- [1]
				},
				["DamageTaken"] = {
					460642, -- [1]
				},
				["HealingTaken"] = {
					146456, -- [1]
				},
				["FDamage"] = {
					118694, -- [1]
				},
				["TimeDamage"] = {
					233.77, -- [1]
				},
				["DeathCount"] = {
					1, -- [1]
				},
				["ActiveTime"] = {
					237.1700000000001, -- [1]
				},
				["DOT_Time"] = {
					483, -- [1]
				},
				["Damage"] = {
					2387342, -- [1]
				},
			},
			["enClass"] = "MAGE",
			["unit"] = "Palia",
			["LastAbility"] = 18950.966,
			["LastEventTimes"] = {
				340851.715, -- [1]
				340852.007, -- [2]
				340852.837, -- [3]
				340853.324, -- [4]
				340853.356, -- [5]
				340854.55, -- [6]
				340855.232, -- [7]
				340855.304, -- [8]
				340855.329, -- [9]
				340857.346, -- [10]
				340857.388, -- [11]
				340857.823, -- [12]
				340857.919, -- [13]
				340857.919, -- [14]
				340859.327, -- [15]
				340859.773, -- [16]
				340860.205, -- [17]
				340861.324, -- [18]
				340862.186, -- [19]
				340863.041, -- [20]
				340863.395, -- [21]
				340863.791, -- [22]
				340864.499, -- [23]
				340865.344, -- [24]
				340865.888, -- [25]
				340865.981, -- [26]
				340866.614, -- [27]
				340867.343, -- [28]
				340867.483, -- [29]
				340868.613, -- [30]
				340868.646, -- [31]
				341155.978, -- [32]
				341161.71, -- [33]
				341165.914, -- [34]
				341172.775, -- [35]
				341188.211, -- [36]
				341203.769, -- [37]
				341206.982, -- [38]
				341222.859, -- [39]
				341228.487, -- [40]
				341241.016, -- [41]
				341241.217, -- [42]
				341254.278, -- [43]
				340848.074, -- [44]
				340848.568, -- [45]
				340848.886, -- [46]
				340849.567, -- [47]
				340850.02, -- [48]
				340850.516, -- [49]
				340851.466, -- [50]
			},
			["DeathLogs"] = {
				{
					["MessageIncoming"] = {
						false, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						false, -- [5]
						true, -- [6]
						true, -- [7]
						true, -- [8]
						false, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						true, -- [16]
						true, -- [17]
						true, -- [18]
						true, -- [19]
						true, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						false, -- [28]
						true, -- [29]
						true, -- [30]
						false, -- [31]
						false, -- [32]
						false, -- [33]
						false, -- [34]
						false, -- [35]
						false, -- [36]
						false, -- [37]
						false, -- [38]
						false, -- [39]
						false, -- [40]
						false, -- [41]
						false, -- [42]
						false, -- [43]
						false, -- [44]
						false, -- [45]
						false, -- [46]
						false, -- [47]
						false, -- [48]
						false, -- [49]
						false, -- [50]
					},
					["Messages"] = {
						"Palia Cauterize (DoT) Palia Tick -29673 (Fire)", -- [1]
						"Palia Cauterize (DoT) Palia Tick -29673 (Fire)", -- [2]
						"Spectral Stable Hand Melee Palia Miss", -- [3]
						"Spectral Stallion Absorb Vitality Palia Miss (Shadow)", -- [4]
						"Palia Living Bomb (DoT) Midnight Tick -6195 (Fire)", -- [5]
						"Spectral Stable Hand Melee Palia Miss", -- [6]
						"Spectral Stable Hand Melee Palia Hit -871 (Physical)", -- [7]
						"Spectral Stable Hand Melee Palia Hit -765 (Physical)", -- [8]
						"Palia Cauterize (DoT) Palia Tick -29674 (Fire)", -- [9]
						"Palia Cauterize (DoT) Palia Tick -29674 (Fire)", -- [10]
						"Midnight Melee Palia Hit -1632 (Physical)", -- [11]
						"Attumen the Huntsman <Midnight> Melee Palia Hit -2752 (Physical)", -- [12]
						"Spectral Charger Melee Palia Dodge", -- [13]
						"Spectral Stallion Melee Palia Hit -1663 (Physical)", -- [14]
						"Spectral Charger Melee Palia Hit -1634 (Physical)", -- [15]
						"Spectral Stallion Melee Palia Hit -1771 (Physical)", -- [16]
						"Spectral Stallion Melee Palia Hit -1905 (Physical)", -- [17]
						"Spectral Stallion Melee Palia Dodge", -- [18]
						"Spectral Stallion Absorb Vitality Palia Miss (Shadow)", -- [19]
						"Spectral Charger Charge Palia Hit -1845 (Physical)", -- [20]
						"Spectral Charger Fear Palia Miss (Shadow)", -- [21]
						"Spectral Stallion Melee Palia Dodge", -- [22]
						"Spectral Charger Melee Palia Hit -1649 (Physical)", -- [23]
						"Spectral Stallion Melee Palia Hit -1798 (Physical)", -- [24]
						"Spectral Stallion Melee Palia Hit -1600 (Physical)", -- [25]
						"Spectral Stallion Melee Palia Hit -1713 (Physical)", -- [26]
						"Spectral Stable Hand Melee Palia Dodge", -- [27]
						"Palia Cauterize (DoT) Palia Tick -29673 (Fire)", -- [28]
						"Palia Cauterize (DoT) Palia Tick -29673 (Fire)", -- [29]
						"Palia dies.", -- [30]
						"Palia Arcane Explosion Attumen the Huntsman <Midnight> Hit -4820 (Arcane)", -- [31]
						"Palia Arcane Explosion Midnight Hit -4806 (Arcane)", -- [32]
						"Palia Arcane Explosion Spectral Stallion Crit -9637 (Arcane)", -- [33]
						"Palia Arcane Explosion Spectral Stallion Hit -4819 (Arcane)", -- [34]
						"Palia Arcane Explosion Spectral Stable Hand Hit -4802 (Arcane)", -- [35]
						"Palia Arcane Explosion Spectral Stallion Crit -9643 (Arcane)", -- [36]
						"Palia Arcane Explosion Spectral Stallion Crit -9625 (Arcane)", -- [37]
						"Palia Arcane Explosion Spectral Stallion Hit -4815 (Arcane)", -- [38]
						"Palia Arcane Explosion Rat Hit -4819 (Arcane)", -- [39]
						"Palia Arcane Explosion Spectral Stable Hand Hit -4803 (Arcane)", -- [40]
						"Palia Arcane Explosion Spectral Stable Hand Hit -4815 (Arcane)", -- [41]
						"Palia Arcane Explosion Spectral Charger Hit -4803 (Arcane)", -- [42]
						"Palia Arcane Explosion Spectral Stable Hand Hit -4817 (Arcane)", -- [43]
						"Palia Arcane Explosion Spectral Stallion Hit -4806 (Arcane)", -- [44]
						"Palia Arcane Explosion Spectral Charger Hit -4816 (Arcane)", -- [45]
						"Palia Arcane Explosion Spectral Stallion Hit -4813 (Arcane)", -- [46]
						"Palia Arcane Explosion Spectral Charger Hit -4806 (Arcane)", -- [47]
						"Palia Arcane Explosion Spectral Stallion Hit -4808 (Arcane)", -- [48]
						"Palia Arcane Explosion Spectral Charger Hit -4812 (Arcane)", -- [49]
						"Palia Arcane Explosion Spectral Stable Hand Hit -4809 (Arcane)", -- [50]
					},
					["DeathAt"] = 1359956758,
					["HealthNum"] = {
						30.1103678366219, -- [1]
						30.1103678366219, -- [2]
						24.19869580602221, -- [3]
						24.19869580602221, -- [4]
						24.19869580602221, -- [5]
						24.19869580602221, -- [6]
						24.19869580602221, -- [7]
						24.19869580602221, -- [8]
						14.19852730550828, -- [9]
						14.19852730550828, -- [10]
						14.19852730550828, -- [11]
						14.19852730550828, -- [12]
						13.64719362394055, -- [13]
						13.64719362394055, -- [14]
						13.64719362394055, -- [15]
						13.64719362394055, -- [16]
						13.64719362394055, -- [17]
						13.64719362394055, -- [18]
						13.64719362394055, -- [19]
						11.54801422144338, -- [20]
						9.308979392387148, -- [21]
						9.308979392387148, -- [22]
						9.308979392387148, -- [23]
						9.308979392387148, -- [24]
						9.308979392387148, -- [25]
						9.308979392387148, -- [26]
						9.308979392387148, -- [27]
						0.000337001027853135, -- [28]
						0.000337001027853135, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["MessageTimes"] = {
						-3.033999999985099, -- [1]
						-3.033999999985099, -- [2]
						-2.027999999991152, -- [3]
						-2.027999999991152, -- [4]
						-1.975000000034925, -- [5]
						-1.717000000004191, -- [6]
						-1.717000000004191, -- [7]
						-1.717000000004191, -- [8]
						-1.521000000007916, -- [9]
						-1.521000000007916, -- [10]
						-1.435999999986962, -- [11]
						-1.40600000001723, -- [12]
						-1.15500000002794, -- [13]
						-1.15500000002794, -- [14]
						-0.9530000000377186, -- [15]
						-0.9530000000377186, -- [16]
						-0.9530000000377186, -- [17]
						-0.9530000000377186, -- [18]
						-0.8140000000130385, -- [19]
						-0.5540000000037253, -- [20]
						-0.4000000000232831, -- [21]
						-0.2150000000256114, -- [22]
						-0.2150000000256114, -- [23]
						-0.2150000000256114, -- [24]
						-0.2150000000256114, -- [25]
						-0.2150000000256114, -- [26]
						-0.2150000000256114, -- [27]
						-0.02700000000186265, -- [28]
						-0.02700000000186265, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["KilledBy"] = "Spectral Stallion",
					["Health"] = {
						"89348 (30%)", -- [1]
						"89348 (30%)", -- [2]
						"71806 (24%)", -- [3]
						"71806 (24%)", -- [4]
						"71806 (24%)", -- [5]
						"71806 (24%)", -- [6]
						"71806 (24%)", -- [7]
						"71806 (24%)", -- [8]
						"42132 (14%)", -- [9]
						"42132 (14%)", -- [10]
						"42132 (14%)", -- [11]
						"42132 (14%)", -- [12]
						"40496 (13%)", -- [13]
						"40496 (13%)", -- [14]
						"40496 (13%)", -- [15]
						"40496 (13%)", -- [16]
						"40496 (13%)", -- [17]
						"40496 (13%)", -- [18]
						"40496 (13%)", -- [19]
						"34267 (11%)", -- [20]
						"27623 (9%)", -- [21]
						"27623 (9%)", -- [22]
						"27623 (9%)", -- [23]
						"27623 (9%)", -- [24]
						"27623 (9%)", -- [25]
						"27623 (9%)", -- [26]
						"27623 (9%)", -- [27]
						"1 (0%)", -- [28]
						"1 (0%)", -- [29]
						"0 (0%)", -- [30]
						"0 (0%)", -- [31]
						"0 (0%)", -- [32]
						"0 (0%)", -- [33]
						"0 (0%)", -- [34]
						"0 (0%)", -- [35]
						"0 (0%)", -- [36]
						"0 (0%)", -- [37]
						"0 (0%)", -- [38]
						"0 (0%)", -- [39]
						"0 (0%)", -- [40]
						"0 (0%)", -- [41]
						"0 (0%)", -- [42]
						"0 (0%)", -- [43]
						"0 (0%)", -- [44]
						"0 (0%)", -- [45]
						"0 (0%)", -- [46]
						"0 (0%)", -- [47]
						"0 (0%)", -- [48]
						"0 (0%)", -- [49]
						"0 (0%)", -- [50]
					},
					["EventNum"] = {
						0, -- [1]
						9.999831499486074, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0.2935278952600806, -- [7]
						0.2578057863076482, -- [8]
						0, -- [9]
						10.00016850051393, -- [10]
						0.5499856774563162, -- [11]
						0.9274268286518274, -- [12]
						0, -- [13]
						0.5604327093197634, -- [14]
						0.5506596795120226, -- [15]
						0.596828820327902, -- [16]
						0.6419869580602221, -- [17]
						0, -- [18]
						0, -- [19]
						0.621766896389034, -- [20]
						0, -- [21]
						0, -- [22]
						0.5557146949298195, -- [23]
						0.6059278480799366, -- [24]
						0.539201644565016, -- [25]
						0.5772827607124201, -- [26]
						0, -- [27]
						0, -- [28]
						9.999831499486074, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"MISC", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"DAMAGE", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"DAMAGE", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"DAMAGE", -- [45]
						"DAMAGE", -- [46]
						"DAMAGE", -- [47]
						"DAMAGE", -- [48]
						"DAMAGE", -- [49]
						"DAMAGE", -- [50]
					},
				}, -- [1]
			},
			["level"] = 90,
			["LastDamageAbility"] = "Melee",
			["LastFightIn"] = 10,
			["LastEventNum"] = {
				nil, -- [1]
				0.644338973954752, -- [2]
				[24] = 0.7885689368910057,
				[48] = 0.6473577406208597,
				[28] = 0.6725141295050899,
				[15] = 0.6396431146963624,
				[9] = 0.6788870813557617,
				[18] = 0.6829121035772385,
				[10] = 0.7365790665302632,
				[21] = 0.71075184060912,
				[44] = 0.9177050664967212,
			},
			["type"] = "Self",
			["FightsSaved"] = 5,
			["GuardianReverseGUIDs"] = {
				["Guild Battle Standard"] = {
					["LatestGuardian"] = 0,
					["GUIDs"] = {
						[0] = "0xF130BDFE0002CBBE",
					},
				},
			},
			["LastDamageTaken"] = 2005,
			["Owner"] = false,
			["Pet"] = {
				"Guild Battle Standard <Palia>", -- [1]
			},
			["NextEventNum"] = 44,
			["LastEventHealthNum"] = {
				85.30162510272193, -- [1]
				85.30162510272193, -- [2]
				84.65728612876717, -- [3]
				84.65728612876717, -- [4]
				84.76830965837624, -- [5]
				84.76830965837624, -- [6]
				84.76830965837624, -- [7]
				84.76830965837624, -- [8]
				84.76830965837624, -- [9]
				84.2001106881111, -- [10]
				84.31046338068325, -- [11]
				83.57388431415299, -- [12]
				83.57388431415299, -- [13]
				83.57388431415299, -- [14]
				83.57388431415299, -- [15]
				83.04492931054723, -- [16]
				83.04492931054723, -- [17]
				83.04492931054723, -- [18]
				82.47304073657907, -- [19]
				82.47304073657907, -- [20]
				81.87331242557902, -- [21]
				81.87331242557902, -- [22]
				81.87331242557902, -- [23]
				81.87331242557902, -- [24]
				81.19576701829708, -- [25]
				81.19576701829708, -- [26]
				81.19576701829708, -- [27]
				81.19576701829708, -- [28]
				81.30611971086924, -- [29]
				80.63360558136415, -- [30]
				80.63360558136415, -- [31]
				100, -- [32]
				100, -- [33]
				100, -- [34]
				100, -- [35]
				100, -- [36]
				100, -- [37]
				100, -- [38]
				100, -- [39]
				100, -- [40]
				100, -- [41]
				100, -- [42]
				100, -- [43]
				85.72760662116156, -- [44]
				85.72760662116156, -- [45]
				85.72760662116156, -- [46]
				85.83795931373371, -- [47]
				85.83795931373371, -- [48]
				85.19060157311286, -- [49]
				85.30162510272193, -- [50]
			},
			["LastEvents"] = {
				"Palia Living Bomb (DoT) Attumen the Huntsman <Midnight> Tick -4140 (Fire)", -- [1]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -1921 (Physical)", -- [2]
				"Palia Pyroblast Attumen the Huntsman <Midnight> Miss (Fire)", -- [3]
				"Palia Ignite (DoT) Attumen the Huntsman <Midnight> Tick -1839 (Fire)", -- [4]
				"Palia Flamestrike (DoT) Attumen the Huntsman <Midnight> Crit -4701 (Fire)", -- [5]
				"Palia Living Bomb (DoT) Attumen the Huntsman <Midnight> Tick -4140 (Fire)", -- [6]
				"Palia Flamestrike (DoT) Attumen the Huntsman <Midnight> Tick -2350 (Fire)", -- [7]
				"Palia Ignite (DoT) Attumen the Huntsman <Midnight> Tick -1839 (Fire)", -- [8]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2024 (Physical)", -- [9]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2196 (Physical)", -- [10]
				"Palia Living Bomb (DoT) Attumen the Huntsman <Midnight> Tick -4139 (Fire)", -- [11]
				"Palia Pyroblast Attumen the Huntsman <Midnight> Miss (Fire)", -- [12]
				"Palia dispels Palia Intangible Presence (Remove Curse)", -- [13]
				"Palia dispels Palia Intangible Presence (Remove Curse)", -- [14]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -1907 (Physical)", -- [15]
				"Palia Living Bomb Attumen the Huntsman <Midnight> Hit -16638 (Fire)", -- [16]
				"Palia Living Bomb (DoT) Attumen the Huntsman <Midnight> Tick -4140 (Fire)", -- [17]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2036 (Physical)", -- [18]
				"Palia Dragon's Breath Attumen the Huntsman <Midnight> Hit -5274 (Fire)", -- [19]
				"Palia Living Bomb (DoT) Attumen the Huntsman <Midnight> Tick -4140 (Fire)", -- [20]
				"Attumen the Huntsman <Midnight> Shadow Cleave Palia Hit -2119 (Shadow)", -- [21]
				"Palia Inferno Blast Attumen the Huntsman <Midnight> Crit -20720 (Fire)", -- [22]
				"Palia Mantid Poison (DoT) Attumen the Huntsman <Midnight> Tick -3526 (Nature)", -- [23]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2351 (Physical)", -- [24]
				"Palia Living Bomb (DoT) Attumen the Huntsman <Midnight> Crit -8279 (Fire)", -- [25]
				"Palia Mantid Poison (DoT) Attumen the Huntsman <Midnight> Tick -3526 (Nature)", -- [26]
				"Palia Ignite (DoT) Attumen the Huntsman <Midnight> Tick -1837 (Fire)", -- [27]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2005 (Physical)", -- [28]
				"Palia Mantid Poison (DoT) Attumen the Huntsman <Midnight> Tick -3526 (Nature)", -- [29]
				"Palia Ignite (DoT) Attumen the Huntsman <Midnight> Tick -1837 (Fire)", -- [30]
				"Palia Flamestrike Attumen the Huntsman <Midnight> Hit -4491 (Fire)", -- [31]
				"Palia Melee Maggot Hit -4984 (Physical)", -- [32]
				"Palia Melee Undercity Rat Hit -6266 (Physical)", -- [33]
				"Palia Melee Maggot Hit -5673 (Physical)", -- [34]
				"Palia Melee Undercity Rat Hit -5290 (Physical)", -- [35]
				"Palia Melee Maggot Hit -5984 (Physical)", -- [36]
				"Palia Melee Undercity Rat Hit -6413 (Physical)", -- [37]
				"Palia Melee Maggot Hit -5266 (Physical)", -- [38]
				"Palia Melee Undercity Rat Hit -5493 (Physical)", -- [39]
				"Palia Melee Undercity Rat Hit -6735 (Physical)", -- [40]
				"Palia Melee Roach Hit -6944 (Physical)", -- [41]
				"Roach Melee Palia Miss", -- [42]
				"Palia Melee Maggot Hit -7068 (Physical)", -- [43]
				"Attumen the Huntsman <Midnight> Shadow Cleave Palia Hit -2736 (Shadow)", -- [44]
				"Palia Living Bomb (DoT) Attumen the Huntsman <Midnight> Crit -9271 (Fire)", -- [45]
				"Palia Living Bomb Attumen the Huntsman <Midnight> Hit -16639 (Fire)", -- [46]
				"Palia Flamestrike (DoT) Attumen the Huntsman <Midnight> Tick -2351 (Fire)", -- [47]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -1930 (Physical)", -- [48]
				"Palia Inferno Blast Attumen the Huntsman <Midnight> Crit -20731 (Fire)", -- [49]
				"Palia Flamestrike (DoT) Attumen the Huntsman <Midnight> Tick -2350 (Fire)", -- [50]
			},
			["Name"] = "Palia",
			["LastEventIncoming"] = {
				false, -- [1]
				true, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				true, -- [9]
				true, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				true, -- [14]
				true, -- [15]
				false, -- [16]
				false, -- [17]
				true, -- [18]
				false, -- [19]
				false, -- [20]
				true, -- [21]
				false, -- [22]
				false, -- [23]
				true, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				true, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				true, -- [42]
				false, -- [43]
				true, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				true, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["TimeLast"] = {
				["TimeHeal"] = 1359956750,
				["Dispelled"] = 1359957051,
				["Dispels"] = 1359957051,
				["OVERALL"] = 1359957447,
				["DamageTaken"] = 1359957061,
				["DeathCount"] = 1359956756,
				["HealingTaken"] = 1359956750,
				["FDamage"] = 1359956756,
				["ActiveTime"] = 1359957447,
				["Healing"] = 1359956750,
				["TimeDamage"] = 1359957447,
				["DOT_Time"] = 1359957062,
				["Damage"] = 1359957447,
			},
			["Fights"] = {
				["Fight3"] = {
					["DOTs"] = {
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Spectral Stallion"] = {
									["count"] = 0,
								},
								["Spectral Charger"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Spectral Stallion"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["Flamestrike (DoT)"] = {
							["Details"] = {
								["Spectral Stable Hand"] = {
									["count"] = 9,
								},
								["Spectral Stallion"] = {
									["count"] = 18,
								},
							},
							["amount"] = 27,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Spectral Stallion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 3868,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 2,
								},
								["Dodge"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 5,
						},
						["Shadow"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 3868,
					},
					["HOTs"] = {
					},
					["Damage"] = 159702,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["DamagedWho"] = {
						["Spectral Charger"] = {
							["Details"] = {
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Dragon's Breath"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 23153,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 37261,
								},
								["Dragon's Breath"] = {
									["count"] = 11040,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 12559,
								},
								["Flamestrike"] = {
									["count"] = 12068,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 10578,
								},
							},
							["amount"] = 106659,
						},
						["Spectral Stable Hand"] = {
							["Details"] = {
								["Flamestrike (DoT)"] = {
									["count"] = 6279,
								},
								["Flamestrike"] = {
									["count"] = 4005,
								},
								["Dragon's Breath"] = {
									["count"] = 5498,
								},
								["Living Bomb"] = {
									["count"] = 37261,
								},
							},
							["amount"] = 53043,
						},
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
						["Fire"] = 149124,
						["Melee"] = 0,
						["Nature"] = 10578,
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 7,
								},
								["Crit"] = {
									["count"] = 3,
								},
								["Tick"] = {
									["count"] = 9,
								},
							},
							["amount"] = 19,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Tick"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
					},
					["ManaGainedFrom"] = {
					},
					["CCBroken"] = {
					},
					["WhoDamaged"] = {
						["Spectral Stallion"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2972,
								},
							},
							["amount"] = 2972,
						},
						["Spectral Stable Hand"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 896,
								},
							},
							["amount"] = 896,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["Dispelled"] = 0,
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["FDamage"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Absorb Vitality"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 10.77,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Spectral Charger"] = {
							["Details"] = {
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Dragon's Breath"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 0.61,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0.82,
								},
								["Dragon's Breath"] = {
									["count"] = 0.12,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 1.36,
								},
								["Flamestrike"] = {
									["count"] = 3.5,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.6800000000000001,
								},
							},
							["amount"] = 7.090000000000001,
						},
						["Spectral Stable Hand"] = {
							["Details"] = {
								["Flamestrike (DoT)"] = {
									["count"] = 3.68,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Dragon's Breath"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3.68,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["Interrupts"] = 0,
					["EnergyGained"] = {
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Absorb Vitality"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["Attacks"] = {
						["Inferno Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 23153,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 23153,
								},
							},
							["count"] = 1,
							["amount"] = 23153,
						},
						["Dragon's Breath"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5551,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 16538,
								},
							},
							["count"] = 3,
							["amount"] = 16538,
						},
						["Living Bomb"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 37261,
									["min"] = 37261,
									["count"] = 1,
									["amount"] = 37261,
								},
								["Hit"] = {
									["max"] = 18631,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 37261,
								},
							},
							["count"] = 3,
							["amount"] = 74522,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Flamestrike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 8066,
									["min"] = 8066,
									["count"] = 1,
									["amount"] = 8066,
								},
								["Hit"] = {
									["max"] = 4005,
									["min"] = 4002,
									["count"] = 2,
									["amount"] = 8007,
								},
							},
							["count"] = 3,
							["amount"] = 16073,
						},
						["Flamestrike (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 2094,
									["min"] = 2093,
									["count"] = 9,
									["amount"] = 18838,
								},
							},
							["count"] = 9,
							["amount"] = 18838,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7052,
									["min"] = 7052,
									["count"] = 1,
									["amount"] = 7052,
								},
								["Tick"] = {
									["max"] = 3526,
									["min"] = 3526,
									["count"] = 1,
									["amount"] = 3526,
								},
							},
							["count"] = 2,
							["amount"] = 10578,
						},
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 10.77,
					["TimeDamaging"] = {
						["Spectral Charger"] = {
							["Details"] = {
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Dragon's Breath"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 0.61,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0.82,
								},
								["Dragon's Breath"] = {
									["count"] = 0.12,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 1.36,
								},
								["Flamestrike"] = {
									["count"] = 3.5,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.6800000000000001,
								},
							},
							["amount"] = 7.090000000000001,
						},
						["Spectral Stable Hand"] = {
							["Details"] = {
								["Flamestrike (DoT)"] = {
									["count"] = 3.68,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Dragon's Breath"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3.68,
						},
					},
					["ManaGain"] = 0,
					["DOT_Time"] = 33,
					["DispelledWho"] = {
					},
				},
				["Fight5"] = {
					["DOTs"] = {
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Spectral Stable Hand"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
					},
					["HOTs"] = {
					},
					["Damage"] = 51066,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["DamagedWho"] = {
						["Spectral Stable Hand"] = {
							["Details"] = {
								["Living Bomb (DoT)"] = {
									["count"] = 9271,
								},
								["Inferno Blast"] = {
									["count"] = 23164,
								},
							},
							["amount"] = 32435,
						},
						["Rat"] = {
							["Details"] = {
								["Living Bomb"] = {
									["count"] = 18631,
								},
							},
							["amount"] = 18631,
						},
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
						["Fire"] = 51066,
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 3,
						},
					},
					["ManaGainedFrom"] = {
					},
					["CCBroken"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["Dispelled"] = 0,
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["FDamage"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 5.5,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Spectral Stable Hand"] = {
							["Details"] = {
								["Living Bomb (DoT)"] = {
									["count"] = 1.62,
								},
								["Inferno Blast"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 5.12,
						},
						["Rat"] = {
							["Details"] = {
								["Living Bomb"] = {
									["count"] = 0.38,
								},
							},
							["amount"] = 0.38,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["Interrupts"] = 0,
					["EnergyGained"] = {
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["Attacks"] = {
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9271,
									["min"] = 9271,
									["count"] = 1,
									["amount"] = 9271,
								},
							},
							["count"] = 1,
							["amount"] = 9271,
						},
						["Inferno Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 23164,
									["min"] = 23164,
									["count"] = 1,
									["amount"] = 23164,
								},
							},
							["count"] = 1,
							["amount"] = 23164,
						},
						["Living Bomb"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 18631,
									["min"] = 18631,
									["count"] = 1,
									["amount"] = 18631,
								},
							},
							["count"] = 1,
							["amount"] = 18631,
						},
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 5.5,
					["TimeDamaging"] = {
						["Spectral Stable Hand"] = {
							["Details"] = {
								["Living Bomb (DoT)"] = {
									["count"] = 1.62,
								},
								["Inferno Blast"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 5.12,
						},
						["Rat"] = {
							["Details"] = {
								["Living Bomb"] = {
									["count"] = 0.38,
								},
							},
							["amount"] = 0.38,
						},
					},
					["ManaGain"] = 0,
					["DOT_Time"] = 3,
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Spectral Stallion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Spectral Stallion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Spectral Stallion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Shadow"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 0,
					},
					["HOTs"] = {
					},
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["DamagedWho"] = {
						["Undercity Rat"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Maggot"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Roach"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
						["Fire"] = 0,
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGainedFrom"] = {
					},
					["CCBroken"] = {
					},
					["WhoDamaged"] = {
						["Spectral Stallion"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["Dispelled"] = 0,
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["FDamage"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Absorb Vitality"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Undercity Rat"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Maggot"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Roach"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["Interrupts"] = 0,
					["EnergyGained"] = {
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Absorb Vitality"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["Attacks"] = {
						["Inferno Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Flamestrike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["Undercity Rat"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Maggot"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Roach"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["DOT_Time"] = 0,
					["DispelledWho"] = {
					},
				},
				["Fight2"] = {
					["DOTs"] = {
						["Flamestrike (DoT)"] = {
							["Details"] = {
								["Spectral Stable Hand"] = {
									["count"] = 24,
								},
								["Spectral Stallion"] = {
									["count"] = 9,
								},
							},
							["amount"] = 33,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Spectral Stallion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Spectral Stallion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 5152,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 7,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 5152,
						["Physical"] = 0,
					},
					["HOTs"] = {
					},
					["Damage"] = 149356,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["DamagedWho"] = {
						["Spectral Stable Hand"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 20626,
								},
								["Dragon's Breath"] = {
									["count"] = 15835,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 18839,
								},
								["Flamestrike"] = {
									["count"] = 12040,
								},
								["Pyroblast"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 33277,
								},
							},
							["amount"] = 100617,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 33278,
								},
								["Pyroblast"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 6280,
								},
								["Flamestrike"] = {
									["count"] = 4004,
								},
								["Dragon's Breath"] = {
									["count"] = 5177,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 48739,
						},
						["Spectral Charger"] = {
							["Details"] = {
								["Pyroblast"] = {
									["count"] = 0,
								},
								["Inferno Blast"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
						["Fire"] = 149356,
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 10,
								},
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 10,
								},
							},
							["amount"] = 23,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGainedFrom"] = {
					},
					["CCBroken"] = {
					},
					["WhoDamaged"] = {
						["Spectral Charger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2946,
								},
								["Hoof Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2946,
						},
						["Spectral Stable Hand"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2206,
								},
							},
							["amount"] = 2206,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["Dispelled"] = 0,
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["FDamage"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["PartialAbsorb"] = {
						["Absorb Vitality"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Pierce Armor"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Hoof Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 10.35,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Spectral Stable Hand"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 1.72,
								},
								["Dragon's Breath"] = {
									["count"] = 0.38,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 1.82,
								},
								["Flamestrike"] = {
									["count"] = 3.5,
								},
								["Pyroblast"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0.61,
								},
							},
							["amount"] = 8.029999999999999,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0.41,
								},
								["Pyroblast"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 1.91,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Dragon's Breath"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2.32,
						},
						["Spectral Charger"] = {
							["Details"] = {
								["Pyroblast"] = {
									["count"] = 0,
								},
								["Inferno Blast"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["Interrupts"] = 0,
					["EnergyGained"] = {
					},
					["PartialResist"] = {
						["Absorb Vitality"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Pierce Armor"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Hoof Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["Attacks"] = {
						["Inferno Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 20626,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 20626,
								},
							},
							["count"] = 1,
							["amount"] = 20626,
						},
						["Dragon's Breath"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 10550,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 10550,
								},
								["Hit"] = {
									["max"] = 5285,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 10462,
								},
							},
							["count"] = 3,
							["amount"] = 21012,
						},
						["Living Bomb"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16639,
									["min"] = 16638,
									["count"] = 4,
									["amount"] = 66555,
								},
							},
							["count"] = 4,
							["amount"] = 66555,
						},
						["Pyroblast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Flamestrike (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4187,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 4187,
								},
								["Tick"] = {
									["max"] = 2094,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 20932,
								},
							},
							["count"] = 11,
							["amount"] = 25119,
						},
						["Flamestrike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 4023,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 16044,
								},
							},
							["count"] = 4,
							["amount"] = 16044,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 10.35,
					["TimeDamaging"] = {
						["Spectral Stable Hand"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 1.72,
								},
								["Dragon's Breath"] = {
									["count"] = 0.38,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 1.82,
								},
								["Flamestrike"] = {
									["count"] = 3.5,
								},
								["Pyroblast"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0.61,
								},
							},
							["amount"] = 8.029999999999999,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0.41,
								},
								["Pyroblast"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 1.91,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Dragon's Breath"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2.32,
						},
						["Spectral Charger"] = {
							["Details"] = {
								["Pyroblast"] = {
									["count"] = 0,
								},
								["Inferno Blast"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["DOT_Time"] = 33,
					["DispelledWho"] = {
					},
				},
				["Fight4"] = {
					["TimeHealing"] = {
						["Palia"] = {
							["Details"] = {
								["Cauterize"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DOTs"] = {
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Midnight"] = {
									["count"] = 0,
								},
								["Spectral Charger"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Cauterize (DoT)"] = {
							["Details"] = {
								["Palia"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Flamestrike (DoT)"] = {
							["Details"] = {
								["Midnight"] = {
									["count"] = 0,
								},
								["Attumen the Huntsman <Midnight>"] = {
									["count"] = 0,
								},
								["Spectral Stallion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Midnight"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Physical"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 1323,
					["PartialResist"] = {
						["Shadow Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Charge"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Hoof Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Absorb Vitality"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Knockdown"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Fear"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["PartialAbsorb"] = {
						["Shadow Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Charge"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Hoof Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Absorb Vitality"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Knockdown"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Fear"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 5.73,
					["FDamagedWho"] = {
						["Palia"] = {
							["Details"] = {
								["Cauterize (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTaken"] = {
						["Shadow"] = 0,
						["Melee"] = 1323,
						["Physical"] = 0,
					},
					["DOT_Time"] = 3,
					["Damage"] = 75759,
					["HealedWho"] = {
						["Palia"] = {
							["Details"] = {
								["Cauterize"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeHeal"] = 0,
					["FDamage"] = 0,
					["WhoDamaged"] = {
						["Spectral Stable Hand"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Knockdown"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Attumen the Huntsman <Midnight>"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Shadow Cleave"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Midnight"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Knockdown"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Charger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1323,
								},
								["Charge"] = {
									["count"] = 0,
								},
							},
							["amount"] = 1323,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Hoof Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["Inferno Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 20566,
									["min"] = 20566,
									["count"] = 1,
									["amount"] = 20566,
								},
							},
							["count"] = 1,
							["amount"] = 20566,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Arcane Explosion"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Living Bomb"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Pyroblast"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 46914,
									["min"] = 46914,
									["count"] = 1,
									["amount"] = 46914,
								},
							},
							["count"] = 1,
							["amount"] = 46914,
						},
						["Flamestrike (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Flamestrike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Frost Nova"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Arcane Barrage"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 8279,
									["min"] = 8279,
									["count"] = 1,
									["amount"] = 8279,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 8279,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["FAttacks"] = {
						["Cauterize (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Arcane"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Fire"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Frost"] = 0,
						["Melee"] = 0,
						["Arcane"] = 0,
						["Fire"] = 75759,
						["Nature"] = 0,
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["Spectral Stable Hand"] = {
							["Details"] = {
								["Frost Nova"] = {
									["count"] = 0,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Frost Nova"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Rat"] = {
							["Details"] = {
								["Arcane Explosion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Midnight"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Frost Nova"] = {
									["count"] = 0,
								},
								["Arcane Barrage"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Charger"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 20566,
								},
								["Pyroblast"] = {
									["count"] = 46914,
								},
								["Frost Nova"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 8279,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 75759,
						},
						["Attumen the Huntsman <Midnight>"] = {
							["Details"] = {
								["Frost Nova"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 5.73,
					["TimeDamaging"] = {
						["Spectral Stable Hand"] = {
							["Details"] = {
								["Frost Nova"] = {
									["count"] = 0,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Palia"] = {
							["Details"] = {
								["Cauterize (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Frost Nova"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Rat"] = {
							["Details"] = {
								["Arcane Explosion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Midnight"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Frost Nova"] = {
									["count"] = 0,
								},
								["Arcane Barrage"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Charger"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 3.5,
								},
								["Pyroblast"] = {
									["count"] = 0.19,
								},
								["Frost Nova"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 2.04,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 5.73,
						},
						["Attumen the Huntsman <Midnight>"] = {
							["Details"] = {
								["Frost Nova"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Heals"] = {
						["Cauterize"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["Palia"] = {
							["Details"] = {
								["Cauterize"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["Spectral Stable Hand"] = {
							["Details"] = {
								["Frost Nova"] = {
									["count"] = 0,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Palia"] = {
							["Details"] = {
								["Cauterize"] = {
									["count"] = 0,
								},
								["Cauterize (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Frost Nova"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Rat"] = {
							["Details"] = {
								["Arcane Explosion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Midnight"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Frost Nova"] = {
									["count"] = 0,
								},
								["Arcane Barrage"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Charger"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 3.5,
								},
								["Pyroblast"] = {
									["count"] = 0.19,
								},
								["Frost Nova"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 2.04,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 5.73,
						},
						["Attumen the Huntsman <Midnight>"] = {
							["Details"] = {
								["Frost Nova"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
						["Ignite (DoT)"] = {
							["Details"] = {
								["Midnight"] = {
									["count"] = 12,
								},
								["Spectral Stallion"] = {
									["count"] = 0,
								},
								["Attumen the Huntsman <Midnight>"] = {
									["count"] = 18,
								},
							},
							["amount"] = 30,
						},
						["Flamestrike (DoT)"] = {
							["Details"] = {
								["Spectral Charger"] = {
									["count"] = 0,
								},
								["Midnight"] = {
									["count"] = 12,
								},
								["Attumen the Huntsman <Midnight>"] = {
									["count"] = 24,
								},
								["Spectral Stallion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 36,
						},
						["Combustion (DoT)"] = {
							["Details"] = {
								["Midnight"] = {
									["count"] = 24,
								},
								["Attumen the Huntsman <Midnight>"] = {
									["count"] = 21,
								},
							},
							["amount"] = 45,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Spectral Charger"] = {
									["count"] = 0,
								},
								["Spectral Stallion"] = {
									["count"] = 0,
								},
								["Attumen the Huntsman <Midnight>"] = {
									["count"] = 33,
								},
								["Midnight"] = {
									["count"] = 15,
								},
							},
							["amount"] = 48,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Midnight"] = {
									["count"] = 12,
								},
								["Attumen the Huntsman <Midnight>"] = {
									["count"] = 9,
								},
							},
							["amount"] = 21,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 67425,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 27,
								},
								["Miss"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Dodge"] = {
									["count"] = 0,
								},
							},
							["amount"] = 28,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
						["Physical"] = 150,
						["Melee"] = 62420,
						["Shadow"] = 4855,
					},
					["HOTs"] = {
					},
					["Damage"] = 469965,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 1,
					["PartialBlock"] = {
					},
					["DamagedWho"] = {
						["Spectral Charger"] = {
							["Details"] = {
								["Dragon's Breath"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Dragon's Breath"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Attumen the Huntsman <Midnight>"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 64516,
								},
								["Dragon's Breath"] = {
									["count"] = 10501,
								},
								["Combustion (DoT)"] = {
									["count"] = 6377,
								},
								["Living Bomb"] = {
									["count"] = 70539,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 20124,
								},
								["Ignite (DoT)"] = {
									["count"] = 11442,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 56295,
								},
								["Flamestrike"] = {
									["count"] = 13020,
								},
								["Frost Nova"] = {
									["count"] = 3627,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 10578,
								},
							},
							["amount"] = 267019,
						},
						["Midnight"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 43611,
								},
								["Combustion (DoT)"] = {
									["count"] = 9108,
								},
								["Combustion"] = {
									["count"] = 15581,
								},
								["Living Bomb"] = {
									["count"] = 74523,
								},
								["Ignite (DoT)"] = {
									["count"] = 7735,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 21692,
								},
								["Flamestrike"] = {
									["count"] = 4032,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 12560,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 14104,
								},
							},
							["amount"] = 202946,
						},
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
						["Fire"] = 441656,
						["Frost"] = 3627,
						["Nature"] = 24682,
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 11,
								},
								["Miss"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 14,
								},
								["Tick"] = {
									["count"] = 46,
								},
							},
							["amount"] = 74,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 7,
								},
							},
							["amount"] = 7,
						},
					},
					["ManaGainedFrom"] = {
					},
					["CCBroken"] = {
					},
					["WhoDamaged"] = {
						["Spectral Charger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Attumen the Huntsman <Midnight>"] = {
							["Details"] = {
								["Shadow Cleave"] = {
									["count"] = 4855,
								},
								["Knockdown"] = {
									["count"] = 150,
								},
								["Melee"] = {
									["count"] = 50076,
								},
							},
							["amount"] = 55081,
						},
						["Midnight"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12344,
								},
							},
							["amount"] = 12344,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["Dispelled"] = 1,
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["FDamage"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["PartialAbsorb"] = {
						["Absorb Vitality"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Shadow Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Knockdown"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 28,
									["amount"] = 0,
								},
							},
							["count"] = 28,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 52.57,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Spectral Charger"] = {
							["Details"] = {
								["Dragon's Breath"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Dragon's Breath"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Attumen the Huntsman <Midnight>"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 2.9,
								},
								["Dragon's Breath"] = {
									["count"] = 5.48,
								},
								["Combustion (DoT)"] = {
									["count"] = 1.28,
								},
								["Living Bomb"] = {
									["count"] = 2.74,
								},
								["Pyroblast"] = {
									["count"] = 1.55,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 3.25,
								},
								["Ignite (DoT)"] = {
									["count"] = 3.83,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 12.28,
								},
								["Flamestrike"] = {
									["count"] = 1.7,
								},
								["Frost Nova"] = {
									["count"] = 1.62,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 1.67,
								},
							},
							["amount"] = 38.3,
						},
						["Midnight"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 3.59,
								},
								["Combustion (DoT)"] = {
									["count"] = 3.06,
								},
								["Combustion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
								["Combustion Impact"] = {
									["count"] = 1.59,
								},
								["Ignite (DoT)"] = {
									["count"] = 2.11,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 2.65,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0.8200000000000001,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.45,
								},
							},
							["amount"] = 14.27,
						},
					},
					["WhoDispelled"] = {
						["Palia"] = {
							["Details"] = {
								["Intangible Presence (Remove Curse)"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["Interrupts"] = 0,
					["EnergyGained"] = {
					},
					["PartialResist"] = {
						["Absorb Vitality"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Shadow Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Knockdown"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 28,
									["amount"] = 0,
								},
							},
							["count"] = 28,
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["Attacks"] = {
						["Inferno Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 23071,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 108127,
								},
							},
							["count"] = 5,
							["amount"] = 108127,
						},
						["Dragon's Breath"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 5274,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 10501,
								},
							},
							["count"] = 2,
							["amount"] = 10501,
						},
						["Combustion (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1822,
									["min"] = 1822,
									["count"] = 2,
									["amount"] = 3644,
								},
								["Tick"] = {
									["max"] = 911,
									["min"] = 910,
									["count"] = 13,
									["amount"] = 11841,
								},
							},
							["count"] = 15,
							["amount"] = 15485,
						},
						["Combustion Impact"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Living Bomb"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 37262,
									["min"] = 37261,
									["count"] = 2,
									["amount"] = 74523,
								},
								["Hit"] = {
									["max"] = 18631,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 70539,
								},
							},
							["count"] = 6,
							["amount"] = 145062,
						},
						["Combustion"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 15581,
									["min"] = 15581,
									["count"] = 1,
									["amount"] = 15581,
								},
							},
							["count"] = 1,
							["amount"] = 15581,
						},
						["Pyroblast"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Frost Nova"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 3627,
									["min"] = 3627,
									["count"] = 1,
									["amount"] = 3627,
								},
							},
							["count"] = 1,
							["amount"] = 3627,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 2046,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 19177,
								},
							},
							["count"] = 10,
							["amount"] = 19177,
						},
						["Flamestrike (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4701,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 13074,
								},
								["Tick"] = {
									["max"] = 2351,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 19610,
								},
							},
							["count"] = 12,
							["amount"] = 32684,
						},
						["Flamestrike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 4518,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 17052,
								},
							},
							["count"] = 4,
							["amount"] = 17052,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9271,
									["min"] = 8279,
									["count"] = 2,
									["amount"] = 17550,
								},
								["Tick"] = {
									["max"] = 4636,
									["min"] = 0,
									["count"] = 14,
									["amount"] = 60437,
								},
							},
							["count"] = 16,
							["amount"] = 77987,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 3526,
									["min"] = 3526,
									["count"] = 7,
									["amount"] = 24682,
								},
							},
							["count"] = 7,
							["amount"] = 24682,
						},
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 52.57,
					["TimeDamaging"] = {
						["Spectral Charger"] = {
							["Details"] = {
								["Dragon's Breath"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Dragon's Breath"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Attumen the Huntsman <Midnight>"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 2.9,
								},
								["Dragon's Breath"] = {
									["count"] = 5.48,
								},
								["Combustion (DoT)"] = {
									["count"] = 1.28,
								},
								["Living Bomb"] = {
									["count"] = 2.74,
								},
								["Pyroblast"] = {
									["count"] = 1.55,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 3.25,
								},
								["Ignite (DoT)"] = {
									["count"] = 3.83,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 12.28,
								},
								["Flamestrike"] = {
									["count"] = 1.7,
								},
								["Frost Nova"] = {
									["count"] = 1.62,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 1.67,
								},
							},
							["amount"] = 38.3,
						},
						["Midnight"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 3.59,
								},
								["Combustion (DoT)"] = {
									["count"] = 3.06,
								},
								["Combustion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
								["Combustion Impact"] = {
									["count"] = 1.59,
								},
								["Ignite (DoT)"] = {
									["count"] = 2.11,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 2.65,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0.8200000000000001,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.45,
								},
							},
							["amount"] = 14.27,
						},
					},
					["ManaGain"] = 0,
					["DOT_Time"] = 180,
					["DispelledWho"] = {
						["Palia"] = {
							["Details"] = {
								["Intangible Presence (Remove Curse)"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
				},
				["Fight1"] = {
					["DOTs"] = {
						["Ignite (DoT)"] = {
							["Details"] = {
								["Midnight"] = {
									["count"] = 12,
								},
								["Spectral Stallion"] = {
									["count"] = 0,
								},
								["Attumen the Huntsman <Midnight>"] = {
									["count"] = 18,
								},
							},
							["amount"] = 30,
						},
						["Flamestrike (DoT)"] = {
							["Details"] = {
								["Spectral Charger"] = {
									["count"] = 0,
								},
								["Midnight"] = {
									["count"] = 12,
								},
								["Attumen the Huntsman <Midnight>"] = {
									["count"] = 24,
								},
								["Spectral Stallion"] = {
									["count"] = 0,
								},
							},
							["amount"] = 36,
						},
						["Combustion (DoT)"] = {
							["Details"] = {
								["Midnight"] = {
									["count"] = 24,
								},
								["Attumen the Huntsman <Midnight>"] = {
									["count"] = 21,
								},
							},
							["amount"] = 45,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Spectral Charger"] = {
									["count"] = 0,
								},
								["Spectral Stallion"] = {
									["count"] = 0,
								},
								["Attumen the Huntsman <Midnight>"] = {
									["count"] = 33,
								},
								["Midnight"] = {
									["count"] = 15,
								},
							},
							["amount"] = 48,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Midnight"] = {
									["count"] = 12,
								},
								["Attumen the Huntsman <Midnight>"] = {
									["count"] = 9,
								},
							},
							["amount"] = 21,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 67425,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 27,
								},
								["Miss"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Dodge"] = {
									["count"] = 0,
								},
							},
							["amount"] = 28,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
						["Physical"] = 150,
						["Melee"] = 62420,
						["Shadow"] = 4855,
					},
					["HOTs"] = {
					},
					["Damage"] = 469965,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 1,
					["PartialBlock"] = {
					},
					["DamagedWho"] = {
						["Spectral Charger"] = {
							["Details"] = {
								["Dragon's Breath"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Dragon's Breath"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Attumen the Huntsman <Midnight>"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 64516,
								},
								["Dragon's Breath"] = {
									["count"] = 10501,
								},
								["Combustion (DoT)"] = {
									["count"] = 6377,
								},
								["Living Bomb"] = {
									["count"] = 70539,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 20124,
								},
								["Ignite (DoT)"] = {
									["count"] = 11442,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 56295,
								},
								["Flamestrike"] = {
									["count"] = 13020,
								},
								["Frost Nova"] = {
									["count"] = 3627,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 10578,
								},
							},
							["amount"] = 267019,
						},
						["Midnight"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 43611,
								},
								["Combustion (DoT)"] = {
									["count"] = 9108,
								},
								["Combustion"] = {
									["count"] = 15581,
								},
								["Living Bomb"] = {
									["count"] = 74523,
								},
								["Ignite (DoT)"] = {
									["count"] = 7735,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 21692,
								},
								["Flamestrike"] = {
									["count"] = 4032,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 12560,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 14104,
								},
							},
							["amount"] = 202946,
						},
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
						["Fire"] = 441656,
						["Frost"] = 3627,
						["Nature"] = 24682,
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 11,
								},
								["Miss"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 14,
								},
								["Tick"] = {
									["count"] = 46,
								},
							},
							["amount"] = 74,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 7,
								},
							},
							["amount"] = 7,
						},
					},
					["ManaGainedFrom"] = {
					},
					["CCBroken"] = {
					},
					["WhoDamaged"] = {
						["Spectral Charger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Attumen the Huntsman <Midnight>"] = {
							["Details"] = {
								["Shadow Cleave"] = {
									["count"] = 4855,
								},
								["Knockdown"] = {
									["count"] = 150,
								},
								["Melee"] = {
									["count"] = 50076,
								},
							},
							["amount"] = 55081,
						},
						["Midnight"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12344,
								},
							},
							["amount"] = 12344,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["Dispelled"] = 1,
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["FDamage"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["PartialAbsorb"] = {
						["Absorb Vitality"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Shadow Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Knockdown"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 28,
									["amount"] = 0,
								},
							},
							["count"] = 28,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 52.57,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Spectral Charger"] = {
							["Details"] = {
								["Dragon's Breath"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Dragon's Breath"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Attumen the Huntsman <Midnight>"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 2.9,
								},
								["Dragon's Breath"] = {
									["count"] = 5.48,
								},
								["Combustion (DoT)"] = {
									["count"] = 1.28,
								},
								["Living Bomb"] = {
									["count"] = 2.74,
								},
								["Pyroblast"] = {
									["count"] = 1.55,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 3.25,
								},
								["Ignite (DoT)"] = {
									["count"] = 3.83,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 12.28,
								},
								["Flamestrike"] = {
									["count"] = 1.7,
								},
								["Frost Nova"] = {
									["count"] = 1.62,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 1.67,
								},
							},
							["amount"] = 38.3,
						},
						["Midnight"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 3.59,
								},
								["Combustion (DoT)"] = {
									["count"] = 3.06,
								},
								["Combustion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
								["Combustion Impact"] = {
									["count"] = 1.59,
								},
								["Ignite (DoT)"] = {
									["count"] = 2.11,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 2.65,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0.8200000000000001,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.45,
								},
							},
							["amount"] = 14.27,
						},
					},
					["WhoDispelled"] = {
						["Palia"] = {
							["Details"] = {
								["Intangible Presence (Remove Curse)"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["Interrupts"] = 0,
					["EnergyGained"] = {
					},
					["PartialResist"] = {
						["Absorb Vitality"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Shadow Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Knockdown"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 28,
									["amount"] = 0,
								},
							},
							["count"] = 28,
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["Attacks"] = {
						["Inferno Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 23071,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 108127,
								},
							},
							["count"] = 5,
							["amount"] = 108127,
						},
						["Dragon's Breath"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 5274,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 10501,
								},
							},
							["count"] = 2,
							["amount"] = 10501,
						},
						["Combustion (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1822,
									["min"] = 1822,
									["count"] = 2,
									["amount"] = 3644,
								},
								["Tick"] = {
									["max"] = 911,
									["min"] = 910,
									["count"] = 13,
									["amount"] = 11841,
								},
							},
							["count"] = 15,
							["amount"] = 15485,
						},
						["Combustion Impact"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Living Bomb"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 37262,
									["min"] = 37261,
									["count"] = 2,
									["amount"] = 74523,
								},
								["Hit"] = {
									["max"] = 18631,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 70539,
								},
							},
							["count"] = 6,
							["amount"] = 145062,
						},
						["Combustion"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 15581,
									["min"] = 15581,
									["count"] = 1,
									["amount"] = 15581,
								},
							},
							["count"] = 1,
							["amount"] = 15581,
						},
						["Pyroblast"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Frost Nova"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 3627,
									["min"] = 3627,
									["count"] = 1,
									["amount"] = 3627,
								},
							},
							["count"] = 1,
							["amount"] = 3627,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 2046,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 19177,
								},
							},
							["count"] = 10,
							["amount"] = 19177,
						},
						["Flamestrike (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4701,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 13074,
								},
								["Tick"] = {
									["max"] = 2351,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 19610,
								},
							},
							["count"] = 12,
							["amount"] = 32684,
						},
						["Flamestrike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 4518,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 17052,
								},
							},
							["count"] = 4,
							["amount"] = 17052,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9271,
									["min"] = 8279,
									["count"] = 2,
									["amount"] = 17550,
								},
								["Tick"] = {
									["max"] = 4636,
									["min"] = 0,
									["count"] = 14,
									["amount"] = 60437,
								},
							},
							["count"] = 16,
							["amount"] = 77987,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 3526,
									["min"] = 3526,
									["count"] = 7,
									["amount"] = 24682,
								},
							},
							["count"] = 7,
							["amount"] = 24682,
						},
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 52.57,
					["TimeDamaging"] = {
						["Spectral Charger"] = {
							["Details"] = {
								["Dragon's Breath"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 0,
								},
								["Dragon's Breath"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Attumen the Huntsman <Midnight>"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 2.9,
								},
								["Dragon's Breath"] = {
									["count"] = 5.48,
								},
								["Combustion (DoT)"] = {
									["count"] = 1.28,
								},
								["Living Bomb"] = {
									["count"] = 2.74,
								},
								["Pyroblast"] = {
									["count"] = 1.55,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 3.25,
								},
								["Ignite (DoT)"] = {
									["count"] = 3.83,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 12.28,
								},
								["Flamestrike"] = {
									["count"] = 1.7,
								},
								["Frost Nova"] = {
									["count"] = 1.62,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 1.67,
								},
							},
							["amount"] = 38.3,
						},
						["Midnight"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 3.59,
								},
								["Combustion (DoT)"] = {
									["count"] = 3.06,
								},
								["Combustion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
								["Combustion Impact"] = {
									["count"] = 1.59,
								},
								["Ignite (DoT)"] = {
									["count"] = 2.11,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 2.65,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0.8200000000000001,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.45,
								},
							},
							["amount"] = 14.27,
						},
					},
					["ManaGain"] = 0,
					["DOT_Time"] = 180,
					["DispelledWho"] = {
						["Palia"] = {
							["Details"] = {
								["Intangible Presence (Remove Curse)"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
				},
				["OverallData"] = {
					["DOTs"] = {
						["Cauterize (DoT)"] = {
							["Details"] = {
								["Palia"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
						["Combustion (DoT)"] = {
							["Details"] = {
								["Midnight"] = {
									["count"] = 24,
								},
								["Attumen the Huntsman <Midnight>"] = {
									["count"] = 21,
								},
							},
							["amount"] = 45,
						},
						["Flamestrike (DoT)"] = {
							["Details"] = {
								["Spectral Stable Hand"] = {
									["count"] = 72,
								},
								["Spectral Stallion"] = {
									["count"] = 81,
								},
								["Midnight"] = {
									["count"] = 24,
								},
								["Spectral Charger"] = {
									["count"] = 12,
								},
								["Attumen the Huntsman <Midnight>"] = {
									["count"] = 36,
								},
							},
							["amount"] = 225,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Spectral Charger"] = {
									["count"] = 12,
								},
								["Spectral Stallion"] = {
									["count"] = 15,
								},
								["Midnight"] = {
									["count"] = 33,
								},
								["Attumen the Huntsman <Midnight>"] = {
									["count"] = 33,
								},
								["Spectral Stable Hand"] = {
									["count"] = 3,
								},
							},
							["amount"] = 96,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Midnight"] = {
									["count"] = 12,
								},
								["Spectral Stallion"] = {
									["count"] = 21,
								},
								["Attumen the Huntsman <Midnight>"] = {
									["count"] = 18,
								},
							},
							["amount"] = 51,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Midnight"] = {
									["count"] = 24,
								},
								["Spectral Stallion"] = {
									["count"] = 21,
								},
								["Attumen the Huntsman <Midnight>"] = {
									["count"] = 9,
								},
							},
							["amount"] = 54,
						},
					},
					["TimeHealing"] = {
						["Palia"] = {
							["Details"] = {
								["Cauterize"] = {
									["count"] = 3.4,
								},
							},
							["amount"] = 3.4,
						},
					},
					["Dispelled"] = 1,
					["WhoHealed"] = {
						["Palia"] = {
							["Details"] = {
								["Cauterize"] = {
									["count"] = 146456,
								},
							},
							["amount"] = 146456,
						},
					},
					["FDamagedWho"] = {
						["Palia"] = {
							["Details"] = {
								["Cauterize (DoT)"] = {
									["count"] = 118694,
								},
							},
							["amount"] = 118694,
						},
					},
					["TimeSpent"] = {
						["Palia"] = {
							["Details"] = {
								["Cauterize"] = {
									["count"] = 3.4,
								},
								["Cauterize (DoT)"] = {
									["count"] = 2.44,
								},
							},
							["amount"] = 5.84,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 9.33,
								},
								["Melee"] = {
									["count"] = 2.02,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 1.23,
								},
								["Dragon's Breath"] = {
									["count"] = 0.65,
								},
								["Pyroblast"] = {
									["count"] = 5.74,
								},
								["Frost Nova"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 5.47,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 10.84,
								},
								["Flamestrike"] = {
									["count"] = 4.14,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 5.359999999999999,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 5.3,
								},
							},
							["amount"] = 50.07999999999998,
						},
						["Midnight"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 3.59,
								},
								["Melee"] = {
									["count"] = 9.139999999999999,
								},
								["Combustion (DoT)"] = {
									["count"] = 3.06,
								},
								["Combustion Impact"] = {
									["count"] = 1.59,
								},
								["Arcane Explosion"] = {
									["count"] = 1,
								},
								["Living Bomb"] = {
									["count"] = 0.24,
								},
								["Combustion"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 14.26,
								},
								["Arcane Barrage"] = {
									["count"] = 0.32,
								},
								["Ignite (DoT)"] = {
									["count"] = 2.11,
								},
								["Frost Nova"] = {
									["count"] = 3.5,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0.8200000000000001,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 4.559999999999999,
								},
							},
							["amount"] = 44.19000000000002,
						},
						["Roach"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Spectral Charger"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 5.88,
								},
								["Dragon's Breath"] = {
									["count"] = 0.38,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0.12,
								},
								["Pyroblast"] = {
									["count"] = 3.69,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 3.74,
								},
								["Flamestrike"] = {
									["count"] = 3.5,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 4.09,
								},
								["Frost Nova"] = {
									["count"] = 0,
								},
							},
							["amount"] = 21.4,
						},
						["Attumen the Huntsman <Midnight>"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 2.9,
								},
								["Dragon's Breath"] = {
									["count"] = 5.48,
								},
								["Combustion (DoT)"] = {
									["count"] = 1.28,
								},
								["Arcane Explosion"] = {
									["count"] = 1.32,
								},
								["Living Bomb"] = {
									["count"] = 2.74,
								},
								["Pyroblast"] = {
									["count"] = 1.55,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 12.28,
								},
								["Ignite (DoT)"] = {
									["count"] = 3.83,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 3.97,
								},
								["Flamestrike"] = {
									["count"] = 3.33,
								},
								["Frost Nova"] = {
									["count"] = 3.67,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 1.67,
								},
							},
							["amount"] = 44.02,
						},
						["Rat"] = {
							["Details"] = {
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0.38,
								},
							},
							["amount"] = 0.38,
						},
						["Undercity Rat"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 17.5,
								},
							},
							["amount"] = 17.5,
						},
						["Spectral Stable Hand"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 5.35,
								},
								["Dragon's Breath"] = {
									["count"] = 0.38,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0.61,
								},
								["Pyroblast"] = {
									["count"] = 3.5,
								},
								["Frost Nova"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 8.199999999999999,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 1.62,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 13.39,
								},
							},
							["amount"] = 33.05,
						},
						["Maggot"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 17.21,
								},
							},
							["amount"] = 17.21,
						},
					},
					["DamageTaken"] = 460642,
					["TimeDamaging"] = {
						["Palia"] = {
							["Details"] = {
								["Cauterize (DoT)"] = {
									["count"] = 2.44,
								},
							},
							["amount"] = 2.44,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 9.33,
								},
								["Melee"] = {
									["count"] = 2.02,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 1.23,
								},
								["Dragon's Breath"] = {
									["count"] = 0.65,
								},
								["Pyroblast"] = {
									["count"] = 5.74,
								},
								["Frost Nova"] = {
									["count"] = 0,
								},
								["Ignite (DoT)"] = {
									["count"] = 5.47,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 10.84,
								},
								["Flamestrike"] = {
									["count"] = 4.14,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 5.359999999999999,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 5.3,
								},
							},
							["amount"] = 50.07999999999998,
						},
						["Midnight"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 3.59,
								},
								["Melee"] = {
									["count"] = 9.139999999999999,
								},
								["Combustion (DoT)"] = {
									["count"] = 3.06,
								},
								["Combustion Impact"] = {
									["count"] = 1.59,
								},
								["Arcane Explosion"] = {
									["count"] = 1,
								},
								["Living Bomb"] = {
									["count"] = 0.24,
								},
								["Combustion"] = {
									["count"] = 0,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 14.26,
								},
								["Arcane Barrage"] = {
									["count"] = 0.32,
								},
								["Ignite (DoT)"] = {
									["count"] = 2.11,
								},
								["Frost Nova"] = {
									["count"] = 3.5,
								},
								["Flamestrike"] = {
									["count"] = 0,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 0.8200000000000001,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 4.559999999999999,
								},
							},
							["amount"] = 44.19000000000002,
						},
						["Roach"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Spectral Charger"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 5.88,
								},
								["Dragon's Breath"] = {
									["count"] = 0.38,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0.12,
								},
								["Pyroblast"] = {
									["count"] = 3.69,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 3.74,
								},
								["Flamestrike"] = {
									["count"] = 3.5,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 4.09,
								},
								["Frost Nova"] = {
									["count"] = 0,
								},
							},
							["amount"] = 21.4,
						},
						["Attumen the Huntsman <Midnight>"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 2.9,
								},
								["Dragon's Breath"] = {
									["count"] = 5.48,
								},
								["Combustion (DoT)"] = {
									["count"] = 1.28,
								},
								["Arcane Explosion"] = {
									["count"] = 1.32,
								},
								["Living Bomb"] = {
									["count"] = 2.74,
								},
								["Pyroblast"] = {
									["count"] = 1.55,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 12.28,
								},
								["Ignite (DoT)"] = {
									["count"] = 3.83,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 3.97,
								},
								["Flamestrike"] = {
									["count"] = 3.33,
								},
								["Frost Nova"] = {
									["count"] = 3.67,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 1.67,
								},
							},
							["amount"] = 44.02,
						},
						["Rat"] = {
							["Details"] = {
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0.38,
								},
							},
							["amount"] = 0.38,
						},
						["Undercity Rat"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 17.5,
								},
							},
							["amount"] = 17.5,
						},
						["Spectral Stable Hand"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 5.35,
								},
								["Dragon's Breath"] = {
									["count"] = 0.38,
								},
								["Arcane Explosion"] = {
									["count"] = 0,
								},
								["Living Bomb"] = {
									["count"] = 0.61,
								},
								["Pyroblast"] = {
									["count"] = 3.5,
								},
								["Frost Nova"] = {
									["count"] = 0,
								},
								["Flamestrike"] = {
									["count"] = 8.199999999999999,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 1.62,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 13.39,
								},
							},
							["amount"] = 33.05,
						},
						["Maggot"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 17.21,
								},
							},
							["amount"] = 17.21,
						},
					},
					["PartialResist"] = {
						["Shadow Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Charge"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 367,
									["amount"] = 0,
								},
							},
							["count"] = 367,
							["amount"] = 0,
						},
						["Pierce Armor"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Hoof Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Absorb Vitality"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 41,
									["amount"] = 0,
								},
							},
							["count"] = 41,
							["amount"] = 0,
						},
						["Knockdown"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Fear"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 1,
					["FDamage"] = 118694,
					["ActiveTime"] = 237.1700000000001,
					["Damage"] = 2387342,
					["ElementTaken"] = {
						["Shadow"] = 11614,
						["Melee"] = 424813,
						["Physical"] = 24215,
					},
					["DOT_Time"] = 483,
					["WhoDispelled"] = {
						["Palia"] = {
							["Details"] = {
								["Intangible Presence (Remove Curse)"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 8,
								},
								["Hit"] = {
									["count"] = 36,
								},
							},
							["amount"] = 45,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 20,
								},
							},
							["amount"] = 22,
						},
						["Arcane"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 11,
								},
								["Hit"] = {
									["count"] = 73,
								},
							},
							["amount"] = 85,
						},
						["Fire"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Tick"] = {
									["count"] = 125,
								},
								["Miss"] = {
									["count"] = 3,
								},
								["Crit"] = {
									["count"] = 39,
								},
								["Hit"] = {
									["count"] = 53,
								},
							},
							["amount"] = 221,
						},
						["Nature"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Tick"] = {
									["count"] = 17,
								},
							},
							["amount"] = 18,
						},
					},
					["TimeHeal"] = 3.4,
					["HealedWho"] = {
						["Palia"] = {
							["Details"] = {
								["Cauterize"] = {
									["count"] = 146456,
								},
							},
							["amount"] = 146456,
						},
					},
					["Dispels"] = 1,
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 10462,
									["min"] = 8895,
									["count"] = 2,
									["amount"] = 19357,
								},
								["Hit"] = {
									["max"] = 7068,
									["min"] = 4431,
									["count"] = 20,
									["amount"] = 114795,
								},
							},
							["count"] = 22,
							["amount"] = 134152,
						},
						["Inferno Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 23164,
									["min"] = 18646,
									["count"] = 15,
									["amount"] = 320416,
								},
							},
							["count"] = 15,
							["amount"] = 320416,
						},
						["Dragon's Breath"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 11407,
									["min"] = 10550,
									["count"] = 3,
									["amount"] = 33247,
								},
								["Hit"] = {
									["max"] = 5576,
									["min"] = 5177,
									["count"] = 11,
									["amount"] = 59106,
								},
							},
							["count"] = 14,
							["amount"] = 92353,
						},
						["Combustion (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1822,
									["min"] = 1822,
									["count"] = 2,
									["amount"] = 3644,
								},
								["Tick"] = {
									["max"] = 911,
									["min"] = 910,
									["count"] = 13,
									["amount"] = 11841,
								},
							},
							["count"] = 15,
							["amount"] = 15485,
						},
						["Combustion"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 15581,
									["min"] = 15581,
									["count"] = 1,
									["amount"] = 15581,
								},
							},
							["count"] = 1,
							["amount"] = 15581,
						},
						["Combustion Impact"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Arcane Explosion"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 9643,
									["min"] = 7719,
									["count"] = 11,
									["amount"] = 96657,
								},
								["Hit"] = {
									["max"] = 4820,
									["min"] = 3859,
									["count"] = 72,
									["amount"] = 311613,
								},
							},
							["count"] = 84,
							["amount"] = 408270,
						},
						["Living Bomb"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 49549,
									["min"] = 37261,
									["count"] = 4,
									["amount"] = 161333,
								},
								["Hit"] = {
									["max"] = 24774,
									["min"] = 16638,
									["count"] = 15,
									["amount"] = 277803,
								},
							},
							["count"] = 20,
							["amount"] = 439136,
						},
						["Arcane Barrage"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 28589,
									["min"] = 28589,
									["count"] = 1,
									["amount"] = 28589,
								},
							},
							["count"] = 1,
							["amount"] = 28589,
						},
						["Pyroblast"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 77561,
									["min"] = 77561,
									["count"] = 1,
									["amount"] = 77561,
								},
								["Hit"] = {
									["max"] = 48315,
									["min"] = 34297,
									["count"] = 4,
									["amount"] = 168123,
								},
							},
							["count"] = 7,
							["amount"] = 245684,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9271,
									["min"] = 8279,
									["count"] = 4,
									["amount"] = 35100,
								},
								["Tick"] = {
									["max"] = 6195,
									["min"] = 4139,
									["count"] = 28,
									["amount"] = 129068,
								},
							},
							["count"] = 32,
							["amount"] = 164168,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 3042,
									["min"] = 1821,
									["count"] = 17,
									["amount"] = 33477,
								},
							},
							["count"] = 17,
							["amount"] = 33477,
						},
						["Flamestrike (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6283,
									["min"] = 4186,
									["count"] = 8,
									["amount"] = 36103,
								},
								["Tick"] = {
									["max"] = 3142,
									["min"] = 2093,
									["count"] = 67,
									["amount"] = 151505,
								},
							},
							["count"] = 75,
							["amount"] = 187608,
						},
						["Flamestrike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 8066,
									["min"] = 8054,
									["count"] = 2,
									["amount"] = 16120,
								},
								["Hit"] = {
									["max"] = 6031,
									["min"] = 3992,
									["count"] = 22,
									["amount"] = 95809,
								},
							},
							["count"] = 24,
							["amount"] = 111929,
						},
						["Frost Nova"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 4909,
									["min"] = 4206,
									["count"] = 8,
									["amount"] = 35154,
								},
								["Hit"] = {
									["max"] = 3627,
									["min"] = 2098,
									["count"] = 36,
									["amount"] = 83600,
								},
							},
							["count"] = 45,
							["amount"] = 118754,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7052,
									["min"] = 7052,
									["count"] = 1,
									["amount"] = 7052,
								},
								["Tick"] = {
									["max"] = 4713,
									["min"] = 3526,
									["count"] = 17,
									["amount"] = 64688,
								},
							},
							["count"] = 18,
							["amount"] = 71740,
						},
					},
					["Healing"] = 146456,
					["FAttacks"] = {
						["Cauterize (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 29674,
									["min"] = 29673,
									["count"] = 4,
									["amount"] = 118694,
								},
							},
							["count"] = 4,
							["amount"] = 118694,
						},
					},
					["Heals"] = {
						["Cauterize"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 146456,
									["min"] = 146456,
									["count"] = 1,
									["amount"] = 146456,
								},
							},
							["count"] = 1,
							["amount"] = 146456,
						},
					},
					["ElementDone"] = {
						["Frost"] = 118754,
						["Melee"] = 134152,
						["Arcane"] = 436859,
						["Fire"] = 1625837,
						["Nature"] = 71740,
					},
					["HealingTaken"] = 146456,
					["DamagedWho"] = {
						["Spectral Stallion"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 108736,
								},
								["Melee"] = {
									["count"] = 24644,
								},
								["Arcane Explosion"] = {
									["count"] = 166842,
								},
								["Living Bomb"] = {
									["count"] = 95313,
								},
								["Dragon's Breath"] = {
									["count"] = 43788,
								},
								["Pyroblast"] = {
									["count"] = 72894,
								},
								["Frost Nova"] = {
									["count"] = 45270,
								},
								["Ignite (DoT)"] = {
									["count"] = 14300,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 59666,
								},
								["Flamestrike"] = {
									["count"] = 42669,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 21195,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 28208,
								},
							},
							["amount"] = 723525,
						},
						["Midnight"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 43611,
								},
								["Melee"] = {
									["count"] = 43392,
								},
								["Combustion (DoT)"] = {
									["count"] = 9108,
								},
								["Combustion"] = {
									["count"] = 15581,
								},
								["Arcane Explosion"] = {
									["count"] = 17001,
								},
								["Living Bomb"] = {
									["count"] = 99297,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 28268,
								},
								["Flamestrike"] = {
									["count"] = 10063,
								},
								["Ignite (DoT)"] = {
									["count"] = 7735,
								},
								["Frost Nova"] = {
									["count"] = 2112,
								},
								["Arcane Barrage"] = {
									["count"] = 28589,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 56213,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 32954,
								},
							},
							["amount"] = 393924,
						},
						["Roach"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 6944,
								},
							},
							["amount"] = 6944,
						},
						["Spectral Charger"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 41117,
								},
								["Dragon's Breath"] = {
									["count"] = 16731,
								},
								["Arcane Explosion"] = {
									["count"] = 73694,
								},
								["Living Bomb"] = {
									["count"] = 84818,
								},
								["Pyroblast"] = {
									["count"] = 95229,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 21194,
								},
								["Flamestrike"] = {
									["count"] = 4034,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 10468,
								},
								["Frost Nova"] = {
									["count"] = 24655,
								},
							},
							["amount"] = 371940,
						},
						["Attumen the Huntsman <Midnight>"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 64516,
								},
								["Dragon's Breath"] = {
									["count"] = 10501,
								},
								["Combustion (DoT)"] = {
									["count"] = 6377,
								},
								["Arcane Explosion"] = {
									["count"] = 21556,
								},
								["Living Bomb"] = {
									["count"] = 70539,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 56295,
								},
								["Ignite (DoT)"] = {
									["count"] = 11442,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 32689,
								},
								["Flamestrike"] = {
									["count"] = 19034,
								},
								["Frost Nova"] = {
									["count"] = 10580,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 10578,
								},
							},
							["amount"] = 314107,
						},
						["Rat"] = {
							["Details"] = {
								["Arcane Explosion"] = {
									["count"] = 4819,
								},
								["Living Bomb"] = {
									["count"] = 18631,
								},
							},
							["amount"] = 23450,
						},
						["Undercity Rat"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 30197,
								},
							},
							["amount"] = 30197,
						},
						["Spectral Stable Hand"] = {
							["Details"] = {
								["Inferno Blast"] = {
									["count"] = 62436,
								},
								["Dragon's Breath"] = {
									["count"] = 21333,
								},
								["Arcane Explosion"] = {
									["count"] = 124358,
								},
								["Living Bomb"] = {
									["count"] = 70538,
								},
								["Pyroblast"] = {
									["count"] = 77561,
								},
								["Frost Nova"] = {
									["count"] = 36137,
								},
								["Flamestrike"] = {
									["count"] = 36129,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 9271,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 56517,
								},
							},
							["amount"] = 494280,
						},
						["Maggot"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 28975,
								},
							},
							["amount"] = 28975,
						},
					},
					["TimeDamage"] = 233.77,
					["WhoDamaged"] = {
						["Spectral Stable Hand"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 49946,
								},
								["Knockdown"] = {
									["count"] = 3169,
								},
							},
							["amount"] = 53115,
						},
						["Attumen the Huntsman <Midnight>"] = {
							["Details"] = {
								["Shadow Cleave"] = {
									["count"] = 11614,
								},
								["Melee"] = {
									["count"] = 99789,
								},
								["Knockdown"] = {
									["count"] = 150,
								},
							},
							["amount"] = 111553,
						},
						["Midnight"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 57194,
								},
								["Knockdown"] = {
									["count"] = 318,
								},
							},
							["amount"] = 57512,
						},
						["Spectral Charger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 54909,
								},
								["Charge"] = {
									["count"] = 7940,
								},
							},
							["amount"] = 62849,
						},
						["Spectral Stallion"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 162975,
								},
								["Hoof Strike"] = {
									["count"] = 12638,
								},
							},
							["amount"] = 175613,
						},
					},
					["PartialAbsorb"] = {
						["Shadow Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Charge"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 367,
									["amount"] = 0,
								},
							},
							["count"] = 367,
							["amount"] = 0,
						},
						["Pierce Armor"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Hoof Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Absorb Vitality"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 41,
									["amount"] = 0,
								},
							},
							["count"] = 41,
							["amount"] = 0,
						},
						["Knockdown"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Fear"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 4,
								},
								["Miss"] = {
									["count"] = 46,
								},
							},
							["amount"] = 50,
						},
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 96,
								},
								["Dodge"] = {
									["count"] = 27,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 242,
								},
							},
							["amount"] = 367,
						},
						["Physical"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 17,
								},
								["Miss"] = {
									["count"] = 5,
								},
							},
							["amount"] = 23,
						},
					},
					["DispelledWho"] = {
						["Palia"] = {
							["Details"] = {
								["Intangible Presence (Remove Curse)"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
				},
			},
			["UnitLockout"] = 1359956704,
			["LastActive"] = 1359957447,
		},
		["Attumen the Huntsman <Midnight>"] = {
			["GUID"] = "0xF1303CBE0002D730",
			["LastEventHealth"] = {
				"???", -- [1]
				"???", -- [2]
				"???", -- [3]
				"???", -- [4]
				"???", -- [5]
				"???", -- [6]
				"???", -- [7]
				"???", -- [8]
				"???", -- [9]
				"???", -- [10]
				"???", -- [11]
				"???", -- [12]
				"???", -- [13]
				"???", -- [14]
				"???", -- [15]
				"???", -- [16]
				"???", -- [17]
				"???", -- [18]
				"???", -- [19]
				"???", -- [20]
				"???", -- [21]
				"???", -- [22]
				"???", -- [23]
				"???", -- [24]
				"???", -- [25]
				"???", -- [26]
				"???", -- [27]
				"???", -- [28]
				"???", -- [29]
				"???", -- [30]
				"???", -- [31]
				"???", -- [32]
				"???", -- [33]
				"???", -- [34]
				"???", -- [35]
				"???", -- [36]
				"???", -- [37]
				"???", -- [38]
				"???", -- [39]
				"???", -- [40]
				"???", -- [41]
				"???", -- [42]
				"???", -- [43]
				"???", -- [44]
				"???", -- [45]
				"???", -- [46]
				"???", -- [47]
				"???", -- [48]
				"???", -- [49]
				"???", -- [50]
			},
			["LastAttackedBy"] = "Palia",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeDamage"] = {
					61.25000000000001, -- [1]
				},
				["Damage"] = {
					73623, -- [1]
				},
				["DamageTaken"] = {
					107250, -- [1]
				},
				["ActiveTime"] = {
					61.25000000000001, -- [1]
				},
			},
			["enClass"] = "PET",
			["LastDamageTaken"] = 911,
			["level"] = 1,
			["LastDamageAbility"] = "Combustion (DoT)",
			["LastFightIn"] = 9,
			["type"] = "Pet",
			["FightsSaved"] = 5,
			["LastAbility"] = 18950.966,
			["LastEventTimes"] = {
				340830.279, -- [1]
				340830.8, -- [2]
				340831.756, -- [3]
				340521.183, -- [4]
				340524.902, -- [5]
				340526.894, -- [6]
				340528.077, -- [7]
				340529.23, -- [8]
				340529.938, -- [9]
				340530.915, -- [10]
				340531.806, -- [11]
				340532.914, -- [12]
				340533.654, -- [13]
				340533.708, -- [14]
				340534.882, -- [15]
				340534.92, -- [16]
				340535.599, -- [17]
				340536.909, -- [18]
				340538.086, -- [19]
				340540.095, -- [20]
				340542.121, -- [21]
				340544.092, -- [22]
				340546.603, -- [23]
				340548.166, -- [24]
				340548.596, -- [25]
				340550.618, -- [26]
				340552.624, -- [27]
				340554.622, -- [28]
				340556.645, -- [29]
				340559.644, -- [30]
				340561.652, -- [31]
				340563.058, -- [32]
				340819.605, -- [33]
				340821.608, -- [34]
				340822.742, -- [35]
				340823.594, -- [36]
				340824.634, -- [37]
				340825.608, -- [38]
				340826.095, -- [39]
				340826.517, -- [40]
				340826.758, -- [41]
				340827.034, -- [42]
				340827.625, -- [43]
				340827.982, -- [44]
				340827.982, -- [45]
				340828.402, -- [46]
				340828.916, -- [47]
				340829.163, -- [48]
				340829.616, -- [49]
				340829.876, -- [50]
			},
			["Owner"] = "Midnight",
			["LastFlags"] = 2600,
			["NextEventNum"] = 4,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
				0, -- [5]
				0, -- [6]
				0, -- [7]
				0, -- [8]
				0, -- [9]
				0, -- [10]
				0, -- [11]
				0, -- [12]
				0, -- [13]
				0, -- [14]
				0, -- [15]
				0, -- [16]
				0, -- [17]
				0, -- [18]
				0, -- [19]
				0, -- [20]
				0, -- [21]
				0, -- [22]
				0, -- [23]
				0, -- [24]
				0, -- [25]
				0, -- [26]
				0, -- [27]
				0, -- [28]
				0, -- [29]
				0, -- [30]
				0, -- [31]
				0, -- [32]
				0, -- [33]
				0, -- [34]
				0, -- [35]
				0, -- [36]
				0, -- [37]
				0, -- [38]
				0, -- [39]
				0, -- [40]
				0, -- [41]
				0, -- [42]
				0, -- [43]
				0, -- [44]
				0, -- [45]
				0, -- [46]
				0, -- [47]
				0, -- [48]
				0, -- [49]
				0, -- [50]
			},
			["LastEvents"] = {
				"Palia Flamestrike (DoT) Attumen the Huntsman <Midnight> Tick -2093 (Fire)", -- [1]
				"Palia Combustion (DoT) Attumen the Huntsman <Midnight> Tick -911 (Fire)", -- [2]
				"Palia Combustion (DoT) Attumen the Huntsman <Midnight> Tick -911 (Fire)", -- [3]
				"Palia Frost Nova Attumen the Huntsman <Midnight> Hit -2112 (Frost)", -- [4]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2432 (Physical)", -- [5]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2048 (Physical)", -- [6]
				"Palia Flamestrike Attumen the Huntsman <Midnight> Hit -6014 (Fire)", -- [7]
				"Attumen the Huntsman <Midnight> Shadow Cleave Palia Hit -2948 (Shadow)", -- [8]
				"Palia Flamestrike (DoT) Attumen the Huntsman <Midnight> Tick -3142 (Fire)", -- [9]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2184 (Physical)", -- [10]
				"Palia Flamestrike (DoT) Attumen the Huntsman <Midnight> Tick -3141 (Fire)", -- [11]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2877 (Physical)", -- [12]
				"Palia Arcane Explosion Attumen the Huntsman <Midnight> Crit -8317 (Arcane)", -- [13]
				"Palia Flamestrike (DoT) Attumen the Huntsman <Midnight> Tick -3141 (Fire)", -- [14]
				"Palia Arcane Explosion Attumen the Huntsman <Midnight> Hit -4544 (Arcane)", -- [15]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2365 (Physical)", -- [16]
				"Palia Flamestrike (DoT) Attumen the Huntsman <Midnight> Tick -3141 (Fire)", -- [17]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2641 (Physical)", -- [18]
				"Palia Arcane Explosion Attumen the Huntsman <Midnight> Hit -3875 (Arcane)", -- [19]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -3673 (Physical)", -- [20]
				"Attumen the Huntsman <Midnight> Shadow Cleave Palia Hit -3811 (Shadow)", -- [21]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -3660 (Physical)", -- [22]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2044 (Physical)", -- [23]
				"Palia Frost Nova Attumen the Huntsman <Midnight> Crit -4841 (Frost)", -- [24]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2751 (Physical)", -- [25]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2876 (Physical)", -- [26]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2118 (Physical)", -- [27]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2862 (Physical)", -- [28]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2614 (Physical)", -- [29]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2763 (Physical)", -- [30]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2752 (Physical)", -- [31]
				"Palia Arcane Explosion Attumen the Huntsman <Midnight> Hit -4820 (Arcane)", -- [32]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2179 (Physical)", -- [33]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2612 (Physical)", -- [34]
				"Palia Flamestrike Attumen the Huntsman <Midnight> Hit -4011 (Fire)", -- [35]
				"Attumen the Huntsman <Midnight> Melee Palia Crit -5172 (Physical)", -- [36]
				"Palia Flamestrike (DoT) Attumen the Huntsman <Midnight> Tick -2093 (Fire)", -- [37]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2658 (Physical)", -- [38]
				"Palia Combustion (DoT) Attumen the Huntsman <Midnight> Tick -911 (Fire)", -- [39]
				"Palia Flamestrike (DoT) Attumen the Huntsman <Midnight> Tick -2093 (Fire)", -- [40]
				"Palia Living Bomb Attumen the Huntsman <Midnight> Hit -18631 (Fire)", -- [41]
				"Palia Combustion (DoT) Attumen the Huntsman <Midnight> Tick -911 (Fire)", -- [42]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2267 (Physical)", -- [43]
				"Palia Combustion (DoT) Attumen the Huntsman <Midnight> Tick -911 (Fire)", -- [44]
				"Palia Living Bomb (DoT) Attumen the Huntsman <Midnight> Tick -4140 (Fire)", -- [45]
				"Palia Flamestrike (DoT) Attumen the Huntsman <Midnight> Tick -2093 (Fire)", -- [46]
				"Palia Combustion (DoT) Attumen the Huntsman <Midnight> Tick -911 (Fire)", -- [47]
				"Palia Living Bomb Attumen the Huntsman <Midnight> Hit -18631 (Fire)", -- [48]
				"Attumen the Huntsman <Midnight> Melee Palia Hit -2263 (Physical)", -- [49]
				"Palia Combustion (DoT) Attumen the Huntsman <Midnight> Tick -911 (Fire)", -- [50]
			},
			["Name"] = "Attumen the Huntsman",
			["LastEventIncoming"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
				true, -- [4]
				false, -- [5]
				false, -- [6]
				true, -- [7]
				false, -- [8]
				true, -- [9]
				false, -- [10]
				true, -- [11]
				false, -- [12]
				true, -- [13]
				true, -- [14]
				true, -- [15]
				false, -- [16]
				true, -- [17]
				false, -- [18]
				true, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				true, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				true, -- [32]
				false, -- [33]
				false, -- [34]
				true, -- [35]
				false, -- [36]
				true, -- [37]
				false, -- [38]
				true, -- [39]
				true, -- [40]
				true, -- [41]
				true, -- [42]
				false, -- [43]
				true, -- [44]
				true, -- [45]
				true, -- [46]
				true, -- [47]
				true, -- [48]
				false, -- [49]
				true, -- [50]
			},
			["TimeLast"] = {
				["ActiveTime"] = 1359957023,
				["TimeDamage"] = 1359957023,
				["OVERALL"] = 1359957025,
				["DamageTaken"] = 1359957025,
				["Damage"] = 1359957023,
			},
			["Fights"] = {
				["Fight1"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 60162,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 12,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 15,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
						["Fire"] = 60162,
					},
					["HOTs"] = {
					},
					["Damage"] = 17151,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["DamagedWho"] = {
						["Palia"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 17151,
								},
							},
							["amount"] = 17151,
						},
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
						["Melee"] = 17151,
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 6,
						},
					},
					["ManaGainedFrom"] = {
					},
					["CCBroken"] = {
					},
					["WhoDamaged"] = {
						["Palia"] = {
							["Details"] = {
								["Combustion (DoT)"] = {
									["count"] = 6377,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 8372,
								},
								["Flamestrike"] = {
									["count"] = 4011,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 4140,
								},
								["Living Bomb"] = {
									["count"] = 37262,
								},
							},
							["amount"] = 60162,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["Dispelled"] = 0,
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["FDamage"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["PartialAbsorb"] = {
						["Combustion (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Flamestrike (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Flamestrike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Living Bomb"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 13.51,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Palia"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13.51,
								},
							},
							["amount"] = 13.51,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["Interrupts"] = 0,
					["EnergyGained"] = {
					},
					["PartialResist"] = {
						["Combustion (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Flamestrike (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Flamestrike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Living Bomb"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5172,
									["min"] = 5172,
									["count"] = 1,
									["amount"] = 5172,
								},
								["Hit"] = {
									["max"] = 2658,
									["min"] = 2179,
									["count"] = 5,
									["amount"] = 11979,
								},
							},
							["count"] = 6,
							["amount"] = 17151,
						},
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 13.51,
					["TimeDamaging"] = {
						["Palia"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13.51,
								},
							},
							["amount"] = 13.51,
						},
					},
					["ManaGain"] = 0,
					["DOT_Time"] = 0,
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 60162,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 12,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 15,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
						["Fire"] = 60162,
					},
					["HOTs"] = {
					},
					["Damage"] = 17151,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["DamagedWho"] = {
						["Palia"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 17151,
								},
							},
							["amount"] = 17151,
						},
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
						["Melee"] = 17151,
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 6,
						},
					},
					["ManaGainedFrom"] = {
					},
					["CCBroken"] = {
					},
					["WhoDamaged"] = {
						["Palia"] = {
							["Details"] = {
								["Combustion (DoT)"] = {
									["count"] = 6377,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 8372,
								},
								["Flamestrike"] = {
									["count"] = 4011,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 4140,
								},
								["Living Bomb"] = {
									["count"] = 37262,
								},
							},
							["amount"] = 60162,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["Dispelled"] = 0,
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["FDamage"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["PartialAbsorb"] = {
						["Combustion (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Flamestrike (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Flamestrike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Living Bomb"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 13.51,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Palia"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13.51,
								},
							},
							["amount"] = 13.51,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["Interrupts"] = 0,
					["EnergyGained"] = {
					},
					["PartialResist"] = {
						["Combustion (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Flamestrike (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Flamestrike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Living Bomb"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5172,
									["min"] = 5172,
									["count"] = 1,
									["amount"] = 5172,
								},
								["Hit"] = {
									["max"] = 2658,
									["min"] = 2179,
									["count"] = 5,
									["amount"] = 11979,
								},
							},
							["count"] = 6,
							["amount"] = 17151,
						},
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 13.51,
					["TimeDamaging"] = {
						["Palia"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13.51,
								},
							},
							["amount"] = 13.51,
						},
					},
					["ManaGain"] = 0,
					["DOT_Time"] = 0,
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
					},
					["HOTs"] = {
					},
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["DamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
					},
					["ElementHitsDone"] = {
					},
					["ManaGainedFrom"] = {
					},
					["CCBroken"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["Dispelled"] = 0,
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["FDamage"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["PartialAbsorb"] = {
					},
					["ActiveTime"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["Interrupts"] = 0,
					["EnergyGained"] = {
					},
					["PartialResist"] = {
					},
					["Healing"] = 0,
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["Attacks"] = {
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["DOT_Time"] = 0,
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeSpent"] = {
						["Palia"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 56.88,
								},
								["Shadow Cleave"] = {
									["count"] = 4.369999999999999,
								},
							},
							["amount"] = 61.25000000000001,
						},
					},
					["PartialResist"] = {
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Frost Nova"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Combustion (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Flamestrike (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Flamestrike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Arcane Explosion"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Living Bomb"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Frost Nova"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Combustion (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Flamestrike (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Flamestrike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Arcane Explosion"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Living Bomb"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["Palia"] = {
							["Details"] = {
								["Living Bomb (DoT)"] = {
									["count"] = 4140,
								},
								["Frost Nova"] = {
									["count"] = 6953,
								},
								["Combustion (DoT)"] = {
									["count"] = 6377,
								},
								["Flamestrike (DoT)"] = {
									["count"] = 20937,
								},
								["Flamestrike"] = {
									["count"] = 10025,
								},
								["Arcane Explosion"] = {
									["count"] = 21556,
								},
								["Living Bomb"] = {
									["count"] = 37262,
								},
							},
							["amount"] = 107250,
						},
					},
					["ElementHitsTaken"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
						["Fire"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 16,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 20,
						},
						["Arcane"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 4,
						},
					},
					["DamageTaken"] = 107250,
					["TimeDamage"] = 61.25000000000001,
					["ElementDone"] = {
						["Melee"] = 66864,
						["Shadow"] = 6759,
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 24,
								},
							},
							["amount"] = 25,
						},
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["DamagedWho"] = {
						["Palia"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 66864,
								},
								["Shadow Cleave"] = {
									["count"] = 6759,
								},
							},
							["amount"] = 73623,
						},
					},
					["ActiveTime"] = 61.25000000000001,
					["TimeDamaging"] = {
						["Palia"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 56.88,
								},
								["Shadow Cleave"] = {
									["count"] = 4.369999999999999,
								},
							},
							["amount"] = 61.25000000000001,
						},
					},
					["ElementTaken"] = {
						["Frost"] = 6953,
						["Fire"] = 78741,
						["Arcane"] = 21556,
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5172,
									["min"] = 5172,
									["count"] = 1,
									["amount"] = 5172,
								},
								["Hit"] = {
									["max"] = 3673,
									["min"] = 2044,
									["count"] = 24,
									["amount"] = 61692,
								},
							},
							["count"] = 25,
							["amount"] = 66864,
						},
						["Shadow Cleave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 3811,
									["min"] = 2948,
									["count"] = 2,
									["amount"] = 6759,
								},
							},
							["count"] = 2,
							["amount"] = 6759,
						},
					},
					["Damage"] = 73623,
				},
			},
			["UnitLockout"] = 1359957025,
			["LastActive"] = 1359957025,
		},
	},
	["FightNum"] = 10,
	["CombatTimes"] = {
		{
			1359956704, -- [1]
			1359956757, -- [2]
			"21:45:05", -- [3]
			"21:45:57", -- [4]
			"Midnight", -- [5]
		}, -- [1]
		{
			1359956859, -- [1]
			1359956866, -- [2]
			"21:47:39", -- [3]
			"21:47:46", -- [4]
			"Spectral Stallion", -- [5]
		}, -- [2]
		{
			1359956892, -- [1]
			1359956926, -- [2]
			"21:48:12", -- [3]
			"21:48:46", -- [4]
			"Spectral Stable Hand", -- [5]
		}, -- [3]
		{
			1359956935, -- [1]
			1359956945, -- [2]
			"21:48:55", -- [3]
			"21:49:05", -- [4]
			"Spectral Charger", -- [5]
		}, -- [4]
		{
			1359956950, -- [1]
			1359956957, -- [2]
			"21:49:10", -- [3]
			"21:49:17", -- [4]
			"Spectral Stallion", -- [5]
		}, -- [5]
		{
			1359956960, -- [1]
			1359956964, -- [2]
			"21:49:21", -- [3]
			"21:49:24", -- [4]
			"Spectral Stable Hand", -- [5]
		}, -- [6]
		{
			1359956968, -- [1]
			1359956973, -- [2]
			"21:49:29", -- [3]
			"21:49:33", -- [4]
			"Spectral Charger", -- [5]
		}, -- [7]
		{
			1359956980, -- [1]
			1359956990, -- [2]
			"21:49:40", -- [3]
			"21:49:50", -- [4]
			"Spectral Stallion", -- [5]
		}, -- [8]
		{
			1359956998, -- [1]
			1359957006, -- [2]
			"21:49:58", -- [3]
			"21:50:06", -- [4]
			"Spectral Stable Hand", -- [5]
		}, -- [9]
		{
			1359957012, -- [1]
			1359957064, -- [2]
			"21:50:12", -- [3]
			"21:51:04", -- [4]
			"Midnight", -- [5]
		}, -- [10]
	},
	["FoughtWho"] = {
		"Midnight 21:50:12-21:51:04", -- [1]
		"Spectral Stable Hand 21:49:58-21:50:06", -- [2]
		"Spectral Stallion 21:49:40-21:49:50", -- [3]
		"Spectral Charger 21:49:29-21:49:33", -- [4]
		"Spectral Stable Hand 21:49:21-21:49:24", -- [5]
	},
}
