
EavesDropStatsDB = {
	["profileKeys"] = {
		["Severe - Nathrezim"] = "Severe - Nathrezim",
	},
	["profiles"] = {
		["Severe - Nathrezim"] = {
			{
				["heal"] = {
					["Leader of the Pack"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 12:49:18|r\n|Hunit:0x0100000004E9D446:Severe|hSevere|h gains |cffffffff18746|r Health from |Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:34299:SPELL_PERIODIC_HEAL|h|cffffffffLeader of the Pack|r|h.",
							["amount"] = 18746,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_UnyeildingStamina",
					},
					["Healthstone"] = {
						[-2] = {
							["time"] = "|cffffffff06/24/12 09:16:01|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:6262:SPELL_HEAL|h|cffffffffHealthstone|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cffffffff20620|r.",
							["amount"] = 20620,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 05:54:12|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:6262:SPELL_HEAL|h|cffffffffHealthstone|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cffffffff31702|r.(10774 Overhealed) (Critical)",
							["amount"] = 42476,
						},
						["icon"] = "Interface\\Icons\\INV_Stone_04",
					},
					["Tranquility"] = {
						[-2] = {
							["time"] = "|cffffffff11/15/12 03:35:38|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:44203:SPELL_HEAL|h|cffffffffTranquility|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cffffffff0|r |cffffffffNature|r. (14924 Overhealed) ",
							["amount"] = 14924,
						},
						[2] = {
							["time"] = "|cffffffff12/08/12 03:28:24|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:44203:SPELL_HEAL|h|cffffffffTranquility|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cffffffff28024|r |cffffffffNature|r. (Critical) ",
							["amount"] = 28024,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Tranquility",
					},
					["Healing Potion"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 12:35:38|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:78989:SPELL_HEAL|h|cffffffffHealing Potion|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cffffffff30254|r.",
							["amount"] = 30254,
						},
						[2] = {
							["time"] = "|cffffffff11/17/12 10:03:46|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:78989:SPELL_HEAL|h|cffffffffHealing Potion|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cffffffff53988|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 53988,
						},
						["icon"] = "INTERFACE\\ICONS\\inv_misc_potionsetf",
					},
					["Nourish"] = {
						[-2] = {
							["time"] = "|cffffffff06/22/12 09:52:02|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:50464:SPELL_HEAL|h|cffffffffNourish|r|h heals |Hunit:0x0100000004E48298:Snobgoblin|hSnobgoblin|h for |cffffffff6761|r.",
							["amount"] = 6761,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Nourish",
					},
					["Lifeblood"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 03:15:12|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:74497:SPELL_HEAL|h|cffffffffLifeblood|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cffffffff0|r |cffffffffNature|r. (3426 Overhealed) ",
							["amount"] = 3426,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 08:36:19|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:74497:SPELL_HEAL|h|cffffffffLifeblood|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cffffffff6327|r.(Critical)",
							["amount"] = 6327,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_WispSplodeGreen",
					},
					["Lifebloom"] = {
						[-2] = {
							["time"] = "|cffffffff06/22/12 09:52:08|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:33778:SPELL_HEAL|h|cffffffffLifebloom|r|h heals |Hunit:0x0100000004E48298:Snobgoblin|hSnobgoblin|h for |cffffffff14065|r.",
							["amount"] = 14065,
						},
						[2] = {
							["time"] = "|cffffffff07/05/12 02:56:22|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:33778:SPELL_HEAL|h|cffffffffLifebloom|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cffffffff26779|r.(Critical)",
							["amount"] = 26779,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingTouch",
					},
					["Blanche's Elixir of Replenishment"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 11:08:22|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:121951:SPELL_PERIODIC_HEAL|h|cffffffffBlanche's Elixir of Replenishment|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cffffffff0|r |cffffffffPhysical|r. (38565 Overhealed) ",
							["amount"] = 38565,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_healthsphere",
					},
					["Renewal"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 04:27:42|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:108238:SPELL_HEAL|h|cffffffffRenewal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cffffffff0|r |cffffffffNature|r. (69460 Overhealed) ",
							["amount"] = 69460,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_NatureBlessing",
					},
					["Regrowth"] = {
						[-2] = {
							["time"] = "|cffffffff06/22/12 09:51:56|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:8936:SPELL_HEAL|h|cffffffffRegrowth|r|h heals |Hunit:0x0100000004E48298:Snobgoblin|hSnobgoblin|h for |cffffffff7195|r.",
							["amount"] = 7195,
						},
						[2] = {
							["time"] = "|cffffffff06/22/12 11:27:44|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:8936:SPELL_HEAL|h|cffffffffRegrowth|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffffffff12058|r.(Critical)",
							["amount"] = 12058,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_ResistNature",
					},
					["Haunt"] = {
						[-2] = {
							["time"] = "|cffffffff06/29/12 03:01:14|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:48210:SPELL_HEAL|h|cffffffffHaunt|r|h heals |Hunit:0x0180000004A1A1C8:Scariest-Darkspear|hScariest-Darkspear|h for |cffffffff2424|r.(6196 Overhealed)",
							["amount"] = 8620,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Warlock_Haunt",
					},
					["Rejuvenation"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 03:30:00|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cffffffffRejuvenation|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cffffffff10461|r |cffffffffNature|r. ",
							["amount"] = 10461,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 10:59:05|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cffffffffRejuvenation|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cffffffff3053|r |cffffffffNature|r. (13930 Overhealed) (Critical) ",
							["amount"] = 16983,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Rejuvenation",
					},
					["Healing Touch"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 11:06:38|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:5185:SPELL_HEAL|h|cffffffffHealing Touch|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004FF8F6D:Goatmilck|hGoatmilck|h |cffffffff34825|r |cffffffffNature|r. ",
							["amount"] = 34825,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingTouch",
					},
					["Frenzied Regeneration"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 11:09:03|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:22842:SPELL_HEAL|h|cffffffffFrenzied Regeneration|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cffffffff25520|r |cffffffffPhysical|r. ",
							["amount"] = 25520,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 12:49:15|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:22845:SPELL_HEAL|h|cffffffffFrenzied Regeneration|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cffffffff338|r.(27382 Overhealed) (Critical)",
							["amount"] = 27720,
						},
						["icon"] = "Interface\\Icons\\Ability_BullRush",
					},
				},
				["hit"] = {
					["Faerie Fire"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 09:18:04|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:770:SPELL_DAMAGE|h|cffffffffFaerie Fire|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1308ED50000D248:Apothecary Baxter|hApothecary Baxter|h |cffffffff13422|r |cffffffffNature|r. ",
							["amount"] = 13422,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 11:13:57|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:770:SPELL_DAMAGE|h|cffffffffFaerie Fire|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E57100002D5B:Viletongue Warrior|hViletongue Warrior|h |cffffffff13326|r |cffffffffNature|r. (Critical) ",
							["amount"] = 13326,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_FaerieFire",
					},
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff01/17/13 08:14:23|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0x0100000000268382:Mootalia|hMootalia|h |cffffffff20677|r |cffffffffPhysical|r. ",
							["amount"] = 20677,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 12:59:33|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h melee swing hits |Hunit:0xF150D69A0005835C:Archbishop Benedictus|hArchbishop Benedictus|h for |cffffffff34394|r |cffffffffPhysical|r.(Critical)",
							["amount"] = 34394,
						},
					},
					["Lacerate"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 11:04:22|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:33745:SPELL_DAMAGE|h|cffffffffLacerate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F23900007127:Shadows of Anger|hShadows of Anger|h |cffffffff21187|r |cffffffffPhysical|r. ",
							["amount"] = 21187,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 11:04:18|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:33745:SPELL_DAMAGE|h|cffffffffLacerate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F23900007127:Shadows of Anger|hShadows of Anger|h |cffffffff42374|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 42374,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Lacerate",
					},
					["Fel Immolation"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:56:31|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:105006:SPELL_DAMAGE|h|cffffffffFel Immolation|r|h hits |Hunit:0xF150D6B900036BFE:Mannoroth|hMannoroth|h for |cffffffff30000|r |cffffffffFire|r.",
							["amount"] = 30000,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_FelImmolation",
					},
					["Ferocious Bite"] = {
						[-2] = {
							["time"] = "|cffffffff12/08/12 03:17:32|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:22568:SPELL_DAMAGE|h|cffffffffFerocious Bite|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1302D8B0000189E:Molten Destroyer|hMolten Destroyer|h |cffffffff41860|r |cffffffffPhysical|r. ",
							["amount"] = 41860,
						},
						[2] = {
							["time"] = "|cffffffff12/08/12 03:20:16|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:22568:SPELL_DAMAGE|h|cffffffffFerocious Bite|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1302F19000018E6:Garr|hGarr|h |cffffffff105659|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 105659,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_FerociousBite",
					},
					["Mangle"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:10:54|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:33876:SPELL_DAMAGE|h|cffffffffMangle|r|h hits |Hunit:0xF130D3AF0001A6C2:Risen Ghoul|hRisen Ghoul|h for |cffffffff52740|r |cffffffffPhysical|r.",
							["amount"] = 52740,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 08:14:28|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:33876:SPELL_DAMAGE|h|cffffffffMangle|r|h hits |Hunit:0xF130D3AF0001AE95:Risen Ghoul|hRisen Ghoul|h for |cffffffff101713|r |cffffffffPhysical|r.(Critical)",
							["amount"] = 101713,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Mangle2",
					},
					["Hungering Shadows"] = {
						[-2] = {
							["time"] = "|cffffffff06/28/12 11:52:16|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:103023:SPELL_DAMAGE|h|cffffffffHungering Shadows|r|h hits |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cffffffff8200|r |cffffffffShadow|r.(15000 Resisted)",
							["amount"] = 8200,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_Shadowfury",
					},
					["Faerie Fire (Feral)"] = {
						[-2] = {
							["time"] = "|cffffffff06/29/12 12:02:40|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:60089:SPELL_DAMAGE|h|cffffffffFaerie Fire (Feral)|r|h hits |Hunit:0xF150D69A0007F674:Archbishop Benedictus|hArchbishop Benedictus|h for |cffffffff17695|r |cffffffffNature|r.",
							["amount"] = 17695,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 08:36:26|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:60089:SPELL_DAMAGE|h|cffffffffFaerie Fire (Feral)|r|h hits |Hunit:0xF130D96800036C4E:Dreadlord Defender|hDreadlord Defender|h for |cffffffff19348|r |cffffffffNature|r.(Critical)",
							["amount"] = 19348,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_FaerieFire",
					},
					["Maul"] = {
						[-2] = {
							["time"] = "|cffffffff06/29/12 12:02:37|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:6807:SPELL_DAMAGE|h|cffffffffMaul|r|h hits |Hunit:0xF150D69A0007F674:Archbishop Benedictus|hArchbishop Benedictus|h for |cffffffff15932|r |cffffffffPhysical|r.",
							["amount"] = 15932,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 12:59:28|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:6807:SPELL_DAMAGE|h|cffffffffMaul|r|h hits |Hunit:0xF150D69A0005835C:Archbishop Benedictus|hArchbishop Benedictus|h for |cffffffff43632|r |cffffffffPhysical|r.(Critical)",
							["amount"] = 43632,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Maul",
					},
					["Rake"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:10:51|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:1822:SPELL_DAMAGE|h|cffffffffRake|r|h hits |Hunit:0xF130D3AF0001A6C2:Risen Ghoul|hRisen Ghoul|h for |cffffffff19805|r |cffffffffPhysical|r.",
							["amount"] = 19805,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 08:14:28|r\n|Hunit:0xF130D3AF0001AE95:Risen Ghoul|hRisen Ghoul|h suffers |cffffffff62646|r |cffffffffPhysical|r damage from |Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:1822:SPELL_PERIODIC_DAMAGE|h|cffffffffRake|r|h.(Critical)",
							["amount"] = 62646,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Disembowel",
					},
					["Maim"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 06:59:58|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:22570:SPELL_DAMAGE|h|cffffffffMaim|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1302F19000023BB:Garr|hGarr|h |cffffffff3026|r |cffffffffPhysical|r. ",
							["amount"] = 3026,
						},
						[2] = {
							["time"] = "|cffffffff12/15/12 07:01:21|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:22570:SPELL_DAMAGE|h|cffffffffMaim|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1302FE8000023BA:Shazzrah|hShazzrah|h |cffffffff5596|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 5596,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Mangle.tga",
					},
					["Swipe"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 03:25:16|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:62078:SPELL_DAMAGE|h|cffffffffSwipe|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1302D8F000067C4:Flamewaker Healer|hFlamewaker Healer|h |cffffffff25135|r |cffffffffPhysical|r. ",
							["amount"] = 25135,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 03:25:16|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:62078:SPELL_DAMAGE|h|cffffffffSwipe|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1302D8F000067C6:Flamewaker Healer|hFlamewaker Healer|h |cffffffff39870|r |cffffffffPhysical|r. (8961 Overkill) (Critical) ",
							["amount"] = 48831,
						},
						["icon"] = "Interface\\Icons\\INV_Misc_MonsterClaw_03",
					},
					["Ravage"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 07:07:34|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:6785:SPELL_DAMAGE|h|cffffffffRavage|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1302F42000023F2:Sulfuron Harbinger|hSulfuron Harbinger|h |cffffffff21097|r |cffffffffPhysical|r. ",
							["amount"] = 21097,
						},
						[2] = {
							["time"] = "|cffffffff01/19/13 01:33:40|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:6785:SPELL_DAMAGE|h|cffffffffRavage|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF5303059004AD90E:Wailing Spectre|hWailing Spectre|h |cffffffff1571|r |cffffffffPhysical|r. (59654 Overkill) (Critical) ",
							["amount"] = 61225,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Ravage",
					},
					["Retribution Aura"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:07:10|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:7294:DAMAGE_SHIELD|h|cffffffffRetribution Aura|r|h reflects |cffffffff131|r |cffffffffHoly|r damage to |Hunit:0xF130D4EF0001A021:Time-Twisted Geist|hTime-Twisted Geist|h.",
							["amount"] = 131,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_AuraOfLight",
					},
					["Shred"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 09:04:48|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:5221:SPELL_DAMAGE|h|cffffffffShred|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F751000024D9:Little Liuyang|hLittle Liuyang|h |cffffffff19898|r |cffffffffPhysical|r. ",
							["amount"] = 19898,
						},
						[2] = {
							["time"] = "|cffffffff01/17/13 08:14:59|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:5221:SPELL_DAMAGE|h|cffffffffShred|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1302D3F00007AC6:Nefarian|hNefarian|h |cffffffff45123|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 45123,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_VampiricAura",
					},
					["Rip"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:10:51|r\n|Hunit:0xF130D3AF0001A6C2:Risen Ghoul|hRisen Ghoul|h suffers |cffffffff21512|r |cffffffffPhysical|r damage from |Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:1079:SPELL_PERIODIC_DAMAGE|h|cffffffffRip|r|h.",
							["amount"] = 21512,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 12:24:55|r\n|Hunit:0xF130D3AF00021914:Risen Ghoul|hRisen Ghoul|h suffers |cffffffff48519|r |cffffffffPhysical|r damage from |Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:1079:SPELL_PERIODIC_DAMAGE|h|cffffffffRip|r|h.(33184 Overkill) (Critical)",
							["amount"] = 81703,
						},
						["icon"] = "Interface\\Icons\\Ability_GhoulFrenzy",
					},
					["Fury Swipes"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:26:16|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:80861:SPELL_DAMAGE|h|cffffffffFury Swipes|r|h hits |Hicon:128:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8.blp:0|t|h|Hunit:0xF130D68800019DDE:Infinite Suppressor|hInfinite Suppressor|h for |cffffffff28860|r |cffffffffPhysical|r.",
							["amount"] = 28860,
						},
						[2] = {
							["time"] = "|cffffffff06/29/12 12:02:36|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:80861:SPELL_DAMAGE|h|cffffffffFury Swipes|r|h hits |Hunit:0xF150D69A0007F674:Archbishop Benedictus|hArchbishop Benedictus|h for |cffffffff100325|r |cffffffffPhysical|r.(Critical)",
							["amount"] = 100325,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Rake",
					},
					["Magistrike Arc"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:53:49|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:105523:SPELL_DAMAGE|h|cffffffffMagistrike Arc|r|h hits |Hunit:0xF150D6B900036BFE:Mannoroth|hMannoroth|h for |cffffffff1030000|r |cffffffffSpellfire|r.",
							["amount"] = 1030000,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\item_sparkofragnoros",
					},
					["Explosion"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 03:21:03|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:20476:SPELL_DAMAGE|h|cffffffffExplosion|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cffffffff9600|r |cffffffffFire|r. ",
							["amount"] = 9600,
						},
						[2] = {
							["time"] = "|cffffffff12/15/12 07:01:37|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:20476:SPELL_DAMAGE|h|cffffffffExplosion|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cffffffff15986|r |cffffffffFire|r. (Critical) ",
							["amount"] = 15986,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_SelfDestruct",
					},
					["Ravage!"] = {
						[-2] = {
							["time"] = "|cffffffff06/28/12 11:52:41|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:81170:SPELL_DAMAGE|h|cffffffffRavage!|r|h hits |Hunit:0xF130D7450007A8E4:Twilight Shadow-Walker|hTwilight Shadow-Walker|h for |cffffffff16467|r |cffffffffPhysical|r.",
							["amount"] = 16467,
						},
						[2] = {
							["time"] = "|cffffffff07/01/12 08:00:46|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:81170:SPELL_DAMAGE|h|cffffffffRavage!|r|h hits |Hunit:0x01000000018B9BA3:Minfrin|hMinfrin|h for |cffffffff32060|r |cffffffffPhysical|r.(Critical)",
							["amount"] = 32060,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Ravage",
					},
					["Bonfire's Blessing"] = {
						[-2] = {
							["time"] = "|cffffffff06/27/12 11:24:53|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:46366:SPELL_DAMAGE|h|cffffffffBonfire's Blessing|r|h hits |Hunit:0x0100000004E3EFA7:Holoexter|hHoloexter|h for |cffffffff551|r |cffffffffFire|r.",
							["amount"] = 551,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_SummerFest_FireSpirit",
					},
					["Pelted!"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 04:18:08|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Haction:RANGE_DAMAGE|h|cffffffffPelted!|r|h |Haction:RANGE_DAMAGE|hhit|h |Hunit:0xF130443C00B45A53:Prophet Velen|hProphet Velen|h |cffffffff2|r |cffffffffPhysical|r. ",
							["amount"] = 2,
						},
						[2] = {
						},
					},
					["Wrath"] = {
						[-2] = {
							["time"] = "|cffffffff06/24/12 02:21:34|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:5176:SPELL_DAMAGE|h|cffffffffWrath|r|h hits |Hunit:0x0100000004FB869C:Skullrott-Spirestone|hSkullrott-Spirestone|h for |cffffffff578|r |cffffffffNature|r.",
							["amount"] = 578,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\spell_nature_wrathv2",
					},
					["Moonfire"] = {
						[-2] = {
							["time"] = "|cffffffff01/17/13 02:22:49|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:8921:SPELL_DAMAGE|h|cffffffffMoonfire|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130A43A001A4DFD:Ebon Whelp|hEbon Whelp|h |cffffffff1039|r |cffffffffArcane|r. ",
							["amount"] = 1039,
						},
						[2] = {
							["time"] = "|cffffffff01/19/13 12:57:34|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:8921:SPELL_DAMAGE|h|cffffffffMoonfire|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF53010E30010E862:Searing Hatchling|hSearing Hatchling|h |cffffffff1859|r |cffffffffArcane|r. (Critical) ",
							["amount"] = 1859,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_StarFall",
					},
					["Thrash"] = {
						[-2] = {
							["time"] = "|cffffffff06/29/12 12:02:41|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:77758:SPELL_DAMAGE|h|cffffffffThrash|r|h hits |Hunit:0xF150D69A0007F674:Archbishop Benedictus|hArchbishop Benedictus|h for |cffffffff14428|r |cffffffffPhysical|r.",
							["amount"] = 14428,
						},
						[2] = {
							["time"] = "|cffffffff06/28/12 11:49:36|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:77758:SPELL_DAMAGE|h|cffffffffThrash|r|h hits |Hunit:0xF130D748000792E3:Twilight Bruiser|hTwilight Bruiser|h for |cffffffff20821|r |cffffffffPhysical|r.(Critical)",
							["amount"] = 20821,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_druid_thrash",
					},
					["Elune's Wrath"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:53:00|r\n|Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:103919:SPELL_DAMAGE|h|cffffffffElune's Wrath|r|h hits |Hunit:0xF130D9BB0003DCBB:Doomguard Devastator|hDoomguard Devastator|h for |cffffffff86168|r |cffffffffArcane|r.(23753 Overkill)",
							["amount"] = 109921,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_StarFall",
					},
					["Pounce Bleed"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:27:53|r\n|Hunit:0xF130D68800019DDA:Infinite Suppressor|hInfinite Suppressor|h suffers |cffffffff2422|r |cffffffffPhysical|r damage from |Hunit:0x0100000004E9D446:Severe|hSevere's|h |Hspell:9007:SPELL_PERIODIC_DAMAGE|h|cffffffffPounce Bleed|r|h.",
							["amount"] = 2422,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 09:10:50|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:9007:SPELL_PERIODIC_DAMAGE|h|cffffffffPounce Bleed|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130E572000018C7:Viletongue Skirmisher|hViletongue Skirmisher|h |cffffffff5406|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 5406,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_VampiricAura",
					},
					["Mantid Poison"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 11:04:53|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:128386:SPELL_PERIODIC_DAMAGE|h|cffffffffMantid Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130F10B00007270:Abomination of Anger|hAbomination of Anger|h |cffffffff5642|r |cffffffffNature|r. ",
							["amount"] = 5642,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 09:03:27|r\n|Hunit:0x0100000004E9D446:Severe|hYour|h |Hspell:128386:SPELL_PERIODIC_DAMAGE|h|cffffffffMantid Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130F751000024D9:Little Liuyang|hLittle Liuyang|h |cffffffff8716|r |cffffffffNature|r. (Critical) ",
							["amount"] = 8716,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_NullifyPoison",
					},
				},
			}, -- [1]
			[-1] = {
				["heal"] = {
					["Renew"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 12:24:48|r\n|Hunit:0x0100000004E9D446:Severe|hSevere|h gains |cff82f4ff5007|r Health from |Hunit:0x01800000041400DB:Yobananaboy-Stormscale|hYobananaboy-Stormscale's|h |Hspell:139:SPELL_PERIODIC_HEAL|h|cff82f4ffRenew|r|h.",
							["amount"] = 5007,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 12:24:46|r\n|Hunit:0x0100000004E9D446:Severe|hSevere|h gains |cff82f4ff10014|r Health from |Hunit:0x01800000041400DB:Yobananaboy-Stormscale|hYobananaboy-Stormscale's|h |Hspell:139:SPELL_PERIODIC_HEAL|h|cff82f4ffRenew|r|h.(Critical)",
							["amount"] = 10014,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Renew",
					},
					["Holy Light"] = {
						[-2] = {
							["time"] = "|cffffffff06/25/12 08:40:59|r\n|Hunit:0x010000000280A48A:Eldude|hEldude's|h |Hspell:635:SPELL_HEAL|h|cff82f4ffHoly Light|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff15111|r.",
							["amount"] = 15111,
						},
						[2] = {
							["time"] = "|cffffffff06/25/12 08:59:39|r\n|Hunit:0x010000000280A48A:Eldude|hEldude's|h |Hspell:635:SPELL_HEAL|h|cff82f4ffHoly Light|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff0|r.(19763 Overhealed) (Critical)",
							["amount"] = 19763,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolyBolt",
					},
					["Rune Tap"] = {
						[-2] = {
							["time"] = "|cffffffff06/22/12 11:39:16|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:59754:SPELL_HEAL|h|cff82f4ffRune Tap|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff14525|r.",
							["amount"] = 14525,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_DeathKnight_RuneTap",
					},
					["Healing Wave"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 09:17:19|r\n|Hunit:0x0100000003D7B271:Enhanced|hEnhanced|h |Hspell:331:SPELL_HEAL|h|cff82f4ffHealing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff39964|r |cff82f4ffNature|r. (16004 Overhealed) ",
							["amount"] = 55968,
						},
						[2] = {
							["time"] = "|cffffffff02/10/13 09:18:12|r\n|Hunit:0x0100000003D7B271:Enhanced|hEnhanced|h |Hspell:331:SPELL_HEAL|h|cff82f4ffHealing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff43725|r |cff82f4ffNature|r. (44603 Overhealed) (Critical) ",
							["amount"] = 88328,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_MagicImmunity",
					},
					["Holy Nova"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:20:56|r\n|Hunit:0x0100000004EB83A7:Avayra|hAvayra's|h |Hspell:23455:SPELL_HEAL|h|cff82f4ffHoly Nova|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff0|r.(3272 Overhealed)",
							["amount"] = 3272,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 08:15:36|r\n|Hunit:0x0100000004EB83A7:Avayra|hAvayra's|h |Hspell:23455:SPELL_HEAL|h|cff82f4ffHoly Nova|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff703|r.(5852 Overhealed) (Critical)",
							["amount"] = 6555,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolyNova",
					},
					["Glyph of Power Word: Shield"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:18:45|r\n|Hunit:0x0100000004EB83A7:Avayra|hAvayra's|h |Hspell:56160:SPELL_HEAL|h|cff82f4ffGlyph of Power Word: Shield|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff15086|r.",
							["amount"] = 15086,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 08:40:34|r\n|Hunit:0x0100000004EB83A7:Avayra|hAvayra's|h |Hspell:56160:SPELL_HEAL|h|cff82f4ffGlyph of Power Word: Shield|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff4665|r.(23358 Overhealed) (Critical)",
							["amount"] = 28023,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Glyph of Dispel Magic"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:10:36|r\n|Hunit:0x0100000004EB83A7:Avayra|hAvayra's|h |Hspell:56131:SPELL_HEAL|h|cff82f4ffGlyph of Dispel Magic|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff4751|r.",
							["amount"] = 4751,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Prayer of Mending"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:19:39|r\n|Hunit:0x0100000004EB83A7:Avayra|hAvayra's|h |Hspell:33110:SPELL_HEAL|h|cff82f4ffPrayer of Mending|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff17786|r.",
							["amount"] = 17786,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 08:38:32|r\n|Hunit:0x0100000004EB83A7:Avayra|hAvayra's|h |Hspell:33110:SPELL_HEAL|h|cff82f4ffPrayer of Mending|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff16682|r.(18891 Overhealed) (Critical)",
							["amount"] = 35573,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfMendingtga",
					},
					["Circle of Healing"] = {
						[-2] = {
							["time"] = "|cffffffff06/28/12 11:57:43|r\n|Hunit:0x0180000003BFC529:Mortålity-Dunemaul|hMortålity-Dunemaul's|h |Hspell:34861:SPELL_HEAL|h|cff82f4ffCircle of Healing|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff7389|r.",
							["amount"] = 7389,
						},
						[2] = {
							["time"] = "|cffffffff06/29/12 12:03:17|r\n|Hunit:0x0180000003BFC529:Mortålity-Dunemaul|hMortålity-Dunemaul's|h |Hspell:34861:SPELL_HEAL|h|cff82f4ffCircle of Healing|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff14807|r.(Critical)",
							["amount"] = 14807,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_CircleOfRenewal",
					},
					["Efflorescence"] = {
						[-2] = {
							["time"] = "|cffffffff06/30/12 07:41:50|r\n|Hunit:0x0100000004D8D014:Lüg|hLüg's|h |Hspell:81269:SPELL_HEAL|h|cff82f4ffEfflorescence|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff0|r.(3138 Overhealed)",
							["amount"] = 3138,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Misc_Herb_TalandrasRose",
					},
					["Greater Healing Wave"] = {
						[-2] = {
							["time"] = "|cffffffff01/17/13 08:51:17|r\n|Hunit:0x01000000033D9849:Lazuja|hLazuja|h |Hspell:77472:SPELL_HEAL|h|cff82f4ffGreater Healing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff82732|r |cff82f4ffNature|r. ",
							["amount"] = 82732,
						},
						[2] = {
							["time"] = "|cffffffff02/10/13 09:18:33|r\n|Hunit:0x0100000003D7B271:Enhanced|hEnhanced|h |Hspell:77472:SPELL_HEAL|h|cff82f4ffGreater Healing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff158656|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 158656,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWaveLesser",
					},
					["Echo of Light"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:07:37|r\n|Hunit:0x0100000004E9D446:Severe|hSevere|h gains |cff82f4ff0|r Health from |Hunit:0x0100000004EB83A7:Avayra|hAvayra's|h |Hspell:77489:SPELL_PERIODIC_HEAL|h|cff82f4ffEcho of Light|r|h.(1986 Overhealed)",
							["amount"] = 1986,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Aspiration",
					},
					["Nature's Vigil"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 09:09:11|r\n|Hunit:0x0100000004B301BD:Specialkid|hSpecialkid|h |Hspell:124988:SPELL_HEAL|h|cff82f4ffNature's Vigil|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff24868|r |cff82f4ffNature|r. ",
							["amount"] = 24868,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Achievement_Zone_Feralas",
					},
					["Greater Heal"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 12:33:13|r\n|Hunit:0x01800000041400DB:Yobananaboy-Stormscale|hYobananaboy-Stormscale's|h |Hspell:2060:SPELL_HEAL|h|cff82f4ffGreater Heal|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff33367|r.",
							["amount"] = 33367,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 12:35:04|r\n|Hunit:0x01800000041400DB:Yobananaboy-Stormscale|hYobananaboy-Stormscale's|h |Hspell:2060:SPELL_HEAL|h|cff82f4ffGreater Heal|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff39763|r.(25306 Overhealed) (Critical)",
							["amount"] = 65069,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_GreaterHeal",
					},
					["Blood Burst"] = {
						[-2] = {
							["time"] = "|cffffffff12/10/12 02:29:23|r\n|Hunit:0xF1306D71003BCA2B:Bloodworm|hBloodworm|h |Hspell:81280:SPELL_HEAL|h|cff82f4ffBlood Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff0|r |cff82f4ffShadow|r. (29282 Overhealed) ",
							["amount"] = 29282,
						},
						[2] = {
							["time"] = "|cffffffff12/10/12 02:32:07|r\n|Hunit:0xF1306D71003BD24A:Bloodworm|hBloodworm|h |Hspell:81280:SPELL_HEAL|h|cff82f4ffBlood Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff17959|r |cff82f4ffShadow|r. (29957 Overhealed) (Critical) ",
							["amount"] = 47916,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_BloodNova",
					},
					["Flash Heal"] = {
						[-2] = {
							["time"] = "|cffffffff06/28/12 09:31:50|r\n|Hunit:0x0300000006D96964:Thalsadoom-Kil'jaeden|hThalsadoom-Kil'jaeden's|h |Hspell:101062:SPELL_HEAL|h|cff82f4ffFlash Heal|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff9722|r.(11963 Overhealed)",
							["amount"] = 21685,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 08:44:30|r\n|Hunit:0x0100000004EB83A7:Avayra|hAvayra's|h |Hspell:101062:SPELL_HEAL|h|cff82f4ffFlash Heal|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff44487|r.(Critical)",
							["amount"] = 44487,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Healing Rain"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 09:18:09|r\n|Hunit:0x0100000003D7B271:Enhanced|hEnhanced|h |Hspell:73921:SPELL_HEAL|h|cff82f4ffHealing Rain|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff12318|r |cff82f4ffNature|r. ",
							["amount"] = 12318,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 10:59:28|r\n|Hunit:0x0100000004FF8F6D:Goatmilck|hGoatmilck|h |Hspell:73921:SPELL_HEAL|h|cff82f4ffHealing Rain|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff10406|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 10406,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_GiftoftheWaterSpirit",
					},
					["Unleash Life"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 09:17:16|r\n|Hunit:0x0100000003D7B271:Enhanced|hEnhanced|h |Hspell:73685:SPELL_HEAL|h|cff82f4ffUnleash Life|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff16628|r |cff82f4ffNature|r. ",
							["amount"] = 16628,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 12:54:32|r\n|Hunit:0x0300000006F873FA:Mekrukk-Dreadmaul|hMekrukk-Dreadmaul's|h |Hspell:73685:SPELL_HEAL|h|cff82f4ffUnleash Life|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff15057|r.(Critical)",
							["amount"] = 15057,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_shaman_unleashweapon_life",
					},
					["Ancestral Awakening"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 12:43:08|r\n|Hunit:0x0300000006F873FA:Mekrukk-Dreadmaul|hMekrukk-Dreadmaul's|h |Hspell:52752:SPELL_HEAL|h|cff82f4ffAncestral Awakening|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff25435|r.",
							["amount"] = 25435,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_AncestralAwakening",
					},
					["Glyph of Prayer of Healing"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 12:22:05|r\n|Hunit:0x0100000004E9D446:Severe|hSevere|h gains |cff82f4ff453|r Health from |Hunit:0x01800000041400DB:Yobananaboy-Stormscale|hYobananaboy-Stormscale's|h |Hspell:56161:SPELL_PERIODIC_HEAL|h|cff82f4ffGlyph of Prayer of Healing|r|h.(1840 Overhealed)",
							["amount"] = 2293,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfHealing02",
					},
					["Chain Heal"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 12:56:53|r\n|Hunit:0x0300000006F873FA:Mekrukk-Dreadmaul|hMekrukk-Dreadmaul's|h |Hspell:1064:SPELL_HEAL|h|cff82f4ffChain Heal|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff13570|r.",
							["amount"] = 13570,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWaveGreater",
					},
					["Flash of Light"] = {
						[-2] = {
							["time"] = "|cffffffff06/25/12 08:41:13|r\n|Hunit:0x010000000280A48A:Eldude|hEldude's|h |Hspell:19750:SPELL_HEAL|h|cff82f4ffFlash of Light|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff22920|r.(5217 Overhealed)",
							["amount"] = 28137,
						},
						[2] = {
							["time"] = "|cffffffff06/25/12 08:28:13|r\n|Hunit:0x010000000280A48A:Eldude|hEldude's|h |Hspell:19750:SPELL_HEAL|h|cff82f4ffFlash of Light|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff45560|r.(Critical)",
							["amount"] = 45560,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Gift of Sargeras"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:56:31|r\n|Hunit:0x0100000004E9D446:Severe|hSevere|h gains |cff82f4ff0|r Health from |Hunit:0xF130D8EC00036BF9:Illidan Stormrage|hIllidan Stormrage's|h |Hspell:105009:SPELL_PERIODIC_HEAL|h|cff82f4ffGift of Sargeras|r|h.(44395 Overhealed)",
							["amount"] = 44395,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_DemonForm",
					},
					["Lay on Hands"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:29:26|r\n|Hunit:0x01000000029287C2:Diantre|hDiantre's|h |Hspell:633:SPELL_HEAL|h|cff82f4ffLay on Hands|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff0|r.(162529 Overhealed)",
							["amount"] = 162529,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_LayOnHands",
					},
					["Divine Light"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 12:46:16|r\n|Hunit:0x0100000004FD4F4B:Audigier-Dragonmaw|hAudigier-Dragonmaw|h |Hspell:82326:SPELL_HEAL|h|cff82f4ffDivine Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff54799|r |cff82f4ffHoly|r. ",
							["amount"] = 54799,
						},
						[2] = {
							["time"] = "|cffffffff07/01/12 10:37:57|r\n|Hunit:0x010000000280A48A:Eldude|hEldude's|h |Hspell:82326:SPELL_HEAL|h|cff82f4ffDivine Light|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff0|r.(64832 Overhealed) (Critical)",
							["amount"] = 64832,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SurgeOfLight",
					},
					["Healing Touch"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 09:08:16|r\n|Hunit:0x0100000004B301BD:Specialkid|hSpecialkid|h |Hspell:5185:SPELL_HEAL|h|cff82f4ffHealing Touch|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff47849|r |cff82f4ffNature|r. ",
							["amount"] = 47849,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingTouch",
					},
					["Healing Stream Totem"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 10:59:27|r\n|Hunit:0x0100000004FF8F6D:Goatmilck|hGoatmilck|h |Hspell:52042:SPELL_PERIODIC_HEAL|h|cff82f4ffHealing Stream Totem|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff6654|r |cff82f4ffNature|r. ",
							["amount"] = 6654,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Spear_04",
					},
					["Holy Word: Serenity"] = {
						[-2] = {
							["time"] = "|cffffffff06/29/12 12:02:09|r\n|Hunit:0x0180000003BFC529:Mortålity-Dunemaul|hMortålity-Dunemaul's|h |Hspell:88684:SPELL_HEAL|h|cff82f4ffHoly Word: Serenity|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff17926|r.",
							["amount"] = 17926,
						},
						[2] = {
							["time"] = "|cffffffff06/28/12 11:44:06|r\n|Hunit:0x0180000003BFC529:Mortålity-Dunemaul|hMortålity-Dunemaul's|h |Hspell:88684:SPELL_HEAL|h|cff82f4ffHoly Word: Serenity|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff32603|r.(Critical)",
							["amount"] = 32603,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_holy_persuitofjustice",
					},
					["Light of the Ancient Kings"] = {
						[-2] = {
							["time"] = "|cffffffff06/25/12 09:06:13|r\n|Hunit:0xF130B5A30000001D:Guardian of Ancient Kings|hGuardian of Ancient Kings's|h |Hspell:86678:SPELL_HEAL|h|cff82f4ffLight of the Ancient Kings|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff0|r.(45244 Overhealed)",
							["amount"] = 45244,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolyBolt",
					},
					["Blaze of Life"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:31:33|r\n|Hunit:0x0100000004EB83A7:Avayra|hAvayra's|h |Hspell:97136:SPELL_HEAL|h|cff82f4ffBlaze of Life|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff0|r.(19383 Overhealed)",
							["amount"] = 19383,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 08:18:27|r\n|Hunit:0x0100000004EB83A7:Avayra|hAvayra's|h |Hspell:97136:SPELL_HEAL|h|cff82f4ffBlaze of Life|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff0|r.(37077 Overhealed) (Critical)",
							["amount"] = 37077,
						},
						["icon"] = "INTERFACE\\ICONS\\inv_jewelcrafting_dragonseye04",
					},
					["Holy Word: Sanctuary"] = {
						[-2] = {
							["time"] = "|cffffffff06/28/12 09:32:44|r\n|Hunit:0x0300000006D96964:Thalsadoom-Kil'jaeden|hThalsadoom-Kil'jaeden's|h |Hspell:88686:SPELL_HEAL|h|cff82f4ffHoly Word: Sanctuary|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff1213|r.",
							["amount"] = 1213,
						},
						[2] = {
							["time"] = "|cffffffff06/28/12 09:32:15|r\n|Hunit:0x0300000006D96964:Thalsadoom-Kil'jaeden|hThalsadoom-Kil'jaeden's|h |Hspell:88686:SPELL_HEAL|h|cff82f4ffHoly Word: Sanctuary|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff0|r.(2349 Overhealed) (Critical)",
							["amount"] = 2349,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_DivineProvidence",
					},
					["Binding Heal"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:19:47|r\n|Hunit:0x0100000004EB83A7:Avayra|hAvayra's|h |Hspell:32546:SPELL_HEAL|h|cff82f4ffBinding Heal|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff16845|r.",
							["amount"] = 16845,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_BlindingHeal",
					},
					["Living Seed"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:11:00|r\n|Hunit:0x04800000040C808A:Sunbearr-Agamaggan|hSunbearr-Agamaggan's|h |Hspell:48503:SPELL_HEAL|h|cff82f4ffLiving Seed|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff10680|r.",
							["amount"] = 10680,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_GiftoftheEarthmother",
					},
					["Lifebloom"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:11:30|r\n|Hunit:0x0100000004E9D446:Severe|hSevere|h gains |cff82f4ff1582|r Health from |Hunit:0x04800000040C808A:Sunbearr-Agamaggan|hSunbearr-Agamaggan's|h |Hspell:33763:SPELL_PERIODIC_HEAL|h|cff82f4ffLifebloom|r|h.(625 Overhealed)",
							["amount"] = 2207,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:11:36|r\n|Hunit:0x04800000040C808A:Sunbearr-Agamaggan|hSunbearr-Agamaggan's|h |Hspell:33778:SPELL_HEAL|h|cff82f4ffLifebloom|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff0|r.(43956 Overhealed) (Critical)",
							["amount"] = 43956,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingTouch",
					},
					["Divine Star"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 09:17:06|r\n|Hunit:0x010000000521AB3F:Fearaah|hFearaah|h |Hspell:122128:SPELL_HEAL|h|cff82f4ffDivine Star|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff20326|r |cff82f4ffSpellshadow|r. (5692 Overhealed) ",
							["amount"] = 26018,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\spell_priest_divinestar_shadow2",
					},
					["Divine Hymn"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:31:10|r\n|Hunit:0x0100000004EB83A7:Avayra|hAvayra's|h |Hspell:64844:SPELL_HEAL|h|cff82f4ffDivine Hymn|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff10833|r.",
							["amount"] = 10833,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 08:31:11|r\n|Hunit:0x0100000004EB83A7:Avayra|hAvayra's|h |Hspell:64844:SPELL_HEAL|h|cff82f4ffDivine Hymn|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff8514|r.(13150 Overhealed) (Critical)",
							["amount"] = 21664,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_DivineProvidence",
					},
					["Divine Touch"] = {
						[-2] = {
							["time"] = "|cffffffff06/28/12 11:53:53|r\n|Hunit:0x0180000003BFC529:Mortålity-Dunemaul|hMortålity-Dunemaul's|h |Hspell:63544:SPELL_HEAL|h|cff82f4ffDivine Touch|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff2341|r.",
							["amount"] = 2341,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Paladin_InfusionofLight",
					},
					["Riptide"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 09:16:57|r\n|Hunit:0x0100000003D7B271:Enhanced|hEnhanced|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff25089|r |cff82f4ffNature|r. ",
							["amount"] = 25089,
						},
						[2] = {
							["time"] = "|cffffffff02/10/13 09:18:34|r\n|Hunit:0x0100000003D7B271:Enhanced|hEnhanced|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff23922|r |cff82f4ffNature|r. (7439 Overhealed) (Critical) ",
							["amount"] = 31361,
						},
						["icon"] = "Interface\\Icons\\spell_nature_riptide",
					},
					["Holy Radiance"] = {
						[-2] = {
							["time"] = "|cffffffff06/22/12 09:24:14|r\n|Hunit:0x0100000002603940:Alexsiss|hAlexsiss's|h |Hspell:82327:SPELL_HEAL|h|cff82f4ffHoly Radiance|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff0|r.(6868 Overhealed)",
							["amount"] = 6868,
						},
						[2] = {
							["time"] = "|cffffffff06/22/12 09:24:16|r\n|Hunit:0x0100000004E9D446:Severe|hSevere|h gains |cff82f4ff0|r Health from |Hunit:0x0100000002603940:Alexsiss|hAlexsiss's|h |Hspell:86452:SPELL_PERIODIC_HEAL|h|cff82f4ffHoly Radiance|r|h.(2467 Overhealed) (Critical)",
							["amount"] = 2467,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_paladin_divinecircle",
					},
					["Ancestral Guidance"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 11:04:45|r\n|Hunit:0x0100000004FF8F6D:Goatmilck|hGoatmilck|h |Hspell:114911:SPELL_HEAL|h|cff82f4ffAncestral Guidance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff6720|r |cff82f4ffPhysical|r. (34664 Overhealed) ",
							["amount"] = 41384,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_shaman_ancestralguidance",
					},
					["Earth Shield"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 09:18:21|r\n|Hunit:0x0100000003D7B271:Enhanced|hEnhanced|h |Hspell:379:SPELL_HEAL|h|cff82f4ffEarth Shield|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff9099|r |cff82f4ffNature|r. ",
							["amount"] = 9099,
						},
						[2] = {
							["time"] = "|cffffffff02/10/13 09:17:26|r\n|Hunit:0x0100000003D7B271:Enhanced|hEnhanced|h |Hspell:379:SPELL_HEAL|h|cff82f4ffEarth Shield|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff19151|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 19151,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_SkinofEarth",
					},
					["Earthliving"] = {
						[-2] = {
							["time"] = "|cffffffff01/17/13 08:51:29|r\n|Hunit:0x01000000033D9849:Lazuja|hLazuja|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff5245|r |cff82f4ffNature|r. ",
							["amount"] = 5245,
						},
						[2] = {
							["time"] = "|cffffffff01/17/13 08:51:20|r\n|Hunit:0x01000000033D9849:Lazuja|hLazuja|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (8786 Overhealed) (Critical) ",
							["amount"] = 8786,
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_GiftEarthmother",
					},
					["Word of Glory"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:30:46|r\n|Hunit:0x01000000029287C2:Diantre|hDiantre's|h |Hspell:85673:SPELL_HEAL|h|cff82f4ffWord of Glory|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff0|r.(48667 Overhealed)",
							["amount"] = 48667,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 08:56:46|r\n|Hunit:0x01000000029287C2:Diantre|hDiantre's|h |Hspell:85673:SPELL_HEAL|h|cff82f4ffWord of Glory|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff0|r.(124796 Overhealed) (Critical)",
							["amount"] = 124796,
						},
						["icon"] = "INTERFACE\\ICONS\\inv_helmet_96",
					},
					["Prayer of Healing"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 12:24:49|r\n|Hunit:0x01800000041400DB:Yobananaboy-Stormscale|hYobananaboy-Stormscale's|h |Hspell:596:SPELL_HEAL|h|cff82f4ffPrayer of Healing|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff11744|r.",
							["amount"] = 11744,
						},
						[2] = {
							["time"] = "|cffffffff06/28/12 09:32:35|r\n|Hunit:0x0300000006D96964:Thalsadoom-Kil'jaeden|hThalsadoom-Kil'jaeden's|h |Hspell:596:SPELL_HEAL|h|cff82f4ffPrayer of Healing|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff20138|r.(Critical)",
							["amount"] = 20138,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfHealing02",
					},
					["Cleansing Flames"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:58:13|r\n|Hunit:0x0100000004EB83A7:Avayra|hAvayra's|h |Hspell:109847:SPELL_HEAL|h|cff82f4ffCleansing Flames|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff0|r.(8345 Overhealed)",
							["amount"] = 8345,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 08:21:03|r\n|Hunit:0x0100000004EB83A7:Avayra|hAvayra's|h |Hspell:109847:SPELL_HEAL|h|cff82f4ffCleansing Flames|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff0|r.(14647 Overhealed) (Critical)",
							["amount"] = 14647,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_MoltenBlood",
					},
					["Cleansing Waters"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 07:13:40|r\n|Hunit:0x01000000011D4634:Wasicoki|hWasicoki's|h |Hspell:86958:SPELL_HEAL|h|cff82f4ffCleansing Waters|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff0|r.(7141 Overhealed)",
							["amount"] = 7141,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 07:13:33|r\n|Hunit:0x01000000011D4634:Wasicoki|hWasicoki's|h |Hspell:86958:SPELL_HEAL|h|cff82f4ffCleansing Waters|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff14422|r.(Critical)",
							["amount"] = 14422,
						},
						["icon"] = "Interface\\Icons\\Ability_Shaman_CleanseSpirit",
					},
					["Cascade"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 04:35:25|r\n|Hunit:0x0100000005028EF7:Oxee|hOxee|h |Hspell:121148:SPELL_HEAL|h|cff82f4ffCascade|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (35399 Overhealed) ",
							["amount"] = 35399,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_priest_cascade",
					},
					["First Aid"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 06:51:28|r\n|Hunit:0x0100000004E9D446:Severe|hSevere|h gains |cff82f4ff0|r Health from |Hunit:0x0100000004E3EFA7:Holoexter|hHoloexter's|h |Hspell:74555:SPELL_PERIODIC_HEAL|h|cff82f4ffFirst Aid|r|h.(5250 Overhealed)",
							["amount"] = 5250,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Heal",
					},
					["Holy Shock"] = {
						[-2] = {
							["time"] = "|cffffffff06/25/12 08:41:10|r\n|Hunit:0x010000000280A48A:Eldude|hEldude's|h |Hspell:25914:SPELL_HEAL|h|cff82f4ffHoly Shock|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff12806|r.",
							["amount"] = 12806,
						},
						[2] = {
							["time"] = "|cffffffff02/10/13 12:46:14|r\n|Hunit:0x0100000004FD4F4B:Audigier-Dragonmaw|hAudigier-Dragonmaw|h |Hspell:25914:SPELL_HEAL|h|cff82f4ffHoly Shock|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff59921|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 59921,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SearingLight",
					},
					["Battle Insight"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 04:31:33|r\n|Hunit:0x01000000046866FA:Lithelys|hLithelys|h |Hspell:123530:SPELL_HEAL|h|cff82f4ffBattle Insight|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (1854 Overhealed) ",
							["amount"] = 1854,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_CircleOfRenewal",
					},
					["Heal"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 12:27:11|r\n|Hunit:0x01800000041400DB:Yobananaboy-Stormscale|hYobananaboy-Stormscale's|h |Hspell:2050:SPELL_HEAL|h|cff82f4ffHeal|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff12476|r.",
							["amount"] = 12476,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 12:26:30|r\n|Hunit:0x01800000041400DB:Yobananaboy-Stormscale|hYobananaboy-Stormscale's|h |Hspell:2050:SPELL_HEAL|h|cff82f4ffHeal|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff0|r.(24930 Overhealed) (Critical)",
							["amount"] = 24930,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_LesserHeal",
					},
					["Penance"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:53:50|r\n|Hunit:0x0100000004EB83A7:Avayra|hAvayra's|h |Hspell:47750:SPELL_HEAL|h|cff82f4ffPenance|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff0|r.(10368 Overhealed)",
							["amount"] = 10368,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 08:54:04|r\n|Hunit:0x0100000004EB83A7:Avayra|hAvayra's|h |Hspell:47750:SPELL_HEAL|h|cff82f4ffPenance|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff0|r.(20459 Overhealed) (Critical)",
							["amount"] = 20459,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Penance",
					},
					["Swiftmend"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:11:20|r\n|Hunit:0x04800000040C808A:Sunbearr-Agamaggan|hSunbearr-Agamaggan's|h |Hspell:18562:SPELL_HEAL|h|cff82f4ffSwiftmend|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff18587|r.",
							["amount"] = 18587,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:10:57|r\n|Hunit:0x04800000040C808A:Sunbearr-Agamaggan|hSunbearr-Agamaggan's|h |Hspell:18562:SPELL_HEAL|h|cff82f4ffSwiftmend|r|h heals |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cff82f4ff35600|r.(Critical)",
							["amount"] = 35600,
						},
						["icon"] = "Interface\\Icons\\INV_Relics_IdolofRejuvenation",
					},
					["Tranquility"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 09:01:42|r\n|Hunit:0x0100000004B301BD:Specialkid|hSpecialkid|h |Hspell:44203:SPELL_HEAL|h|cff82f4ffTranquility|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff17567|r |cff82f4ffNature|r. ",
							["amount"] = 17567,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Tranquility",
					},
					["Rejuvenation"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:11:31|r\n|Hunit:0x0100000004E9D446:Severe|hSevere|h gains |cff82f4ff0|r Health from |Hunit:0x04800000040C808A:Sunbearr-Agamaggan|hSunbearr-Agamaggan's|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cff82f4ffRejuvenation|r|h.(4125 Overhealed)",
							["amount"] = 4125,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:10:54|r\n|Hunit:0x0100000004E9D446:Severe|hSevere|h gains |cff82f4ff8496|r Health from |Hunit:0x04800000040C808A:Sunbearr-Agamaggan|hSunbearr-Agamaggan's|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cff82f4ffRejuvenation|r|h.(Critical)",
							["amount"] = 8496,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Rejuvenation",
					},
					["Healing Surge"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 11:02:19|r\n|Hunit:0x0100000004FF8F6D:Goatmilck|hGoatmilck|h |Hspell:8004:SPELL_HEAL|h|cff82f4ffHealing Surge|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff44151|r |cff82f4ffNature|r. ",
							["amount"] = 44151,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 11:01:09|r\n|Hunit:0x0100000004FF8F6D:Goatmilck|hGoatmilck|h |Hspell:8004:SPELL_HEAL|h|cff82f4ffHealing Surge|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff91763|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 91763,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWay",
					},
					["Beacon of Light"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 12:46:02|r\n|Hunit:0x0100000004FD4F4B:Audigier-Dragonmaw|hAudigier-Dragonmaw|h |Hspell:53652:SPELL_HEAL|h|cff82f4ffBeacon of Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cff82f4ff33330|r |cff82f4ffHoly|r. (32261 Overhealed) ",
							["amount"] = 65591,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Paladin_BeaconofLight",
					},
				},
				["hit"] = {
					["Shadow"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:10:55|r\n|Hunit:0xF130D36B00019FB3:Echo of Sylvanas|hEcho of Sylvanas's|h |Hspell:101348:SPELL_DAMAGE|h|cffff1313Sacrifice|r|h hits |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cffff1313152589|r |cffff1313Shadow|r.(31268 Resisted) (128820 Overkill)",
							["amount"] = 281409,
						},
						[2] = {
							["time"] = "|cffffffff06/25/12 07:38:52|r\n|Hunit:0x0100000004AB6997:Killurazz|hKillurazz's|h |Hspell:8092:SPELL_DAMAGE|h|cffff1313Mind Blast|r|h hits |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cffff131324641|r |cffff1313Shadow|r.(Critical)",
							["amount"] = 24641,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_ShadowMend",
					},
					["Physical"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 07:15:45|r\n|Haction:ENVIRONMENTAL_DAMAGE|h|cffffffffFalling|r|h |Haction:ENVIRONMENTAL_DAMAGE|hdamaged|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cffffffff187264|r |cffffffffPhysical|r. ",
							["amount"] = 187264,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 03:49:06|r\n|Hunit:0xF13073AB00001E07:King Varian Wrynn|hKing Varian Wrynn|h |Haction:SWING_DAMAGE|h|cffff1313Melee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cffff1313177534|r |cffff1313Physical|r. (54321 Overkill) (Critical) ",
							["amount"] = 231855,
						},
					},
					["Arcane"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 08:30:29|r\n|Hunit:0xF130D4A000019DC7:Murozond|hMurozond's|h |Hspell:102569:SPELL_DAMAGE|h|cffff1313Infinite Breath|r|h hits |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cffff131385233|r |cffff1313Arcane|r.(7699 Resisted)",
							["amount"] = 85233,
						},
						[2] = {
							["time"] = "|cffffffff06/29/12 12:11:45|r\n|Hunit:0x0200000005C89BFD:Brutalmage-Stormrage|hBrutalmage-Stormrage's|h |Hspell:30451:SPELL_DAMAGE|h|cffff1313Arcane Blast|r|h hits |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cffff131329059|r |cffff1313Arcane|r.(Critical)",
							["amount"] = 29059,
						},
						["icon"] = "Interface\\Icons\\Ability_Warlock_ShadowFlame",
					},
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff07/05/12 03:35:53|r\n|Hunit:0x01000000044ADCD7:Etahone-Dragonmaw|hEtahone-Dragonmaw's|h |Hspell:78674:SPELL_DAMAGE|h|cffff1313Starsurge|r|h hits |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cffff131316907|r |cffff1313Spellstorm|r.",
							["amount"] = 16907,
						},
						[2] = {
							["time"] = "|cffffffff06/25/12 08:30:17|r\n|Hunit:0x0100000004CB0F41:Silentshadw-Skywall|hSilentshadw-Skywall's|h |Hspell:78674:SPELL_DAMAGE|h|cffff1313Starsurge|r|h hits |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cffff131330270|r |cffff1313Spellstorm|r.(Critical)",
							["amount"] = 30270,
						},
						["icon"] = "Interface\\Icons\\Spell_Arcane_Arcane03",
					},
					["Holy"] = {
						[-2] = {
							["time"] = "|cffffffff06/29/12 12:02:21|r\n|Hunit:0xF150D69A0007F674:Archbishop Benedictus|hArchbishop Benedictus's|h |Hspell:104503:SPELL_DAMAGE|h|cffff1313Smite|r|h hits |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cffff131341155|r |cffff1313Holy|r.",
							["amount"] = 41155,
						},
						[2] = {
							["time"] = "|cffffffff07/05/12 04:49:58|r\n|Hunit:0x0100000004FE046B:Sçoobý-Frostmane|hSçoobý-Frostmane's|h |Hspell:24275:SPELL_DAMAGE|h|cffff1313Hammer of Wrath|r|h hits |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cffff131325719|r |cffff1313Holy|r.(Critical)",
							["amount"] = 25719,
						},
						["icon"] = "Interface\\Icons\\INV_Hammer_04",
					},
					["Fire"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 09:17:22|r\n|Hunit:0xF1308ED50000D248:Apothecary Baxter|hApothecary Baxter|h |Hspell:68821:SPELL_DAMAGE|h|cffff1313Chain Reaction|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cffff131369865|r |cffff1313Fire|r. ",
							["amount"] = 69865,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 07:13:31|r\n|Hunit:0x0100000003220DA6:Whôpper-Frostmane|hWhôpper-Frostmane's|h |Hspell:51505:SPELL_DAMAGE|h|cffff1313Lava Burst|r|h hits |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cffff131332807|r |cffff1313Fire|r.(1641 Resisted) (Critical)",
							["amount"] = 32807,
						},
						["icon"] = "Interface\\Icons\\Spell_Holiday_ToW_SpiceCloud",
					},
					["Frost"] = {
						[-2] = {
							["time"] = "|cffffffff06/28/12 11:44:09|r\n|Hunit:0xF130D53E000749B6:Arcurion|hArcurion's|h |Hspell:102593:SPELL_DAMAGE|h|cffff1313Hand of Frost|r|h hits |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cffff131344670|r |cffff1313Frost|r.",
							["amount"] = 44670,
						},
						[2] = {
							["time"] = "|cffffffff07/03/12 11:09:33|r\n|Hunit:0x010000000498B395:Icekin|hIcekin's|h |Hspell:116:SPELL_DAMAGE|h|cffff1313Frostbolt|r|h hits |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cffff131330283|r |cffff1313Frost|r.(Critical)",
							["amount"] = 30283,
						},
						["icon"] = "Interface\\Icons\\Spell_Frost_FrostBolt02",
					},
					["Nature"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 11:08:24|r\n|Hunit:0xF130E5F500002C13:Blanche's Lightning Rod|hBlanche's Lightning Rod|h |Hspell:111544:SPELL_DAMAGE|h|cffff1313Lightning Impact|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004E9D446:Severe|hYou|h |cffff131380887|r |cffff1313Nature|r. ",
							["amount"] = 80887,
						},
						[2] = {
							["time"] = "|cffffffff06/21/12 08:18:28|r\n|Hunit:0x0100000004E34EF1:Barlzzul-Shadowsong|hBarlzzul-Shadowsong's|h |Hspell:53209:SPELL_DAMAGE|h|cffff1313Chimera Shot|r|h hits |Hunit:0x0100000004E9D446:Severe|hSevere|h for |cffff131324959|r |cffff1313Nature|r.(Critical)",
							["amount"] = 24959,
						},
						["icon"] = "Interface\\Icons\\Spell_Lightning_LightningBolt01",
					},
				},
			},
		},
	},
}
