
SpellReminderDBPerChar = {
	["char"] = {
		["Severe - Nathrezim"] = {
			["spellSetup"] = {
				["Dash"] = {
					["moduleManaged"] = true,
					["spellId"] = 1850,
					["active"] = true,
					["last_seen"] = 1352859992,
					["displayName"] = "Dash",
					["installed"] = true,
					["r"] = 5,
					["category"] = "Buffs",
					["d"] = 15,
					["icon"] = "Interface\\Icons\\Ability_Druid_Dash",
					["rank"] = "",
				},
				["Mark of the Wild"] = {
					["moduleManaged"] = true,
					["active"] = true,
					["displayName"] = "Mark of the Wild",
					["installed"] = true,
					["category"] = "Buffs",
					["last_seen"] = 1352860020,
					["r"] = 15,
					["d"] = 3444,
					["icon"] = "Interface\\Icons\\Spell_Nature_Regeneration",
				},
			},
		},
	},
	["profileKeys"] = {
		["Severe - Nathrezim"] = "Default",
	},
}
