
TidyPlatesOptions = {
	["_EnableMiniButton"] = false,
	["FriendlyAutomation"] = "No Automation",
	["EnemyAutomation"] = "No Automation",
	["primary"] = "Neon/|cFFFF4400Damage",
	["WelcomeShown"] = true,
	["secondary"] = "Neon/|cFFFF4400Damage",
}
