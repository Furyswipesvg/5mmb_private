
WatchOutDB = {
	["height"] = 35,
	["isLocked"] = true,
	["width"] = 35,
	["barWidth"] = 240,
}
