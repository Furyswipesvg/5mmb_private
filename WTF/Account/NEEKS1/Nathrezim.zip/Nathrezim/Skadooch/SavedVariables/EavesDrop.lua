
EavesDropStatsDB = {
	["profileKeys"] = {
		["Skadooch - Nathrezim"] = "Skadooch - Nathrezim",
	},
	["profiles"] = {
		["Skadooch - Nathrezim"] = {
			{
				["heal"] = {
					["Gift of the Ox"] = {
						[-2] = {
							["time"] = "|cffffffff11/21/12 12:29:47|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:124507:SPELL_HEAL|h|cffffffffGift of the Ox|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff746|r |cffffffffNature|r. (2570 Overhealed) ",
							["amount"] = 3316,
						},
						[2] = {
							["time"] = "|cffffffff11/21/12 12:17:29|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:124507:SPELL_HEAL|h|cffffffffGift of the Ox|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff888|r |cffffffffNature|r. (5384 Overhealed) (Critical) ",
							["amount"] = 6272,
						},
						["icon"] = "Interface\\Icons\\ability_monk_healthsphere",
					},
					["Eminence"] = {
						[-2] = {
							["time"] = "|cffffffff12/12/12 03:29:40|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:126890:SPELL_HEAL|h|cffffffffEminence|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff0|r |cffffffffNature|r. (4756 Overhealed) ",
							["amount"] = 4756,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\inv_jewelcrafting_jadeserpent",
					},
					["Zen Sphere: Detonate"] = {
						[-2] = {
							["time"] = "|cffffffff11/18/12 09:58:33|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:124101:SPELL_HEAL|h|cffffffffZen Sphere: Detonate|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0380000004B89E34:Deathkite-Mug'thol|hDeathkite-Mug'thol|h |cffffffff956|r |cffffffffNature|r. (960 Overhealed) ",
							["amount"] = 1916,
						},
						[2] = {
							["time"] = "|cffffffff11/18/12 09:58:33|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:124101:SPELL_HEAL|h|cffffffffZen Sphere: Detonate|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0xF140B915D900000D:Warp Stalker|hWarp Stalker|h |cffffffff0|r |cffffffffNature|r. (3042 Overhealed) (Critical) ",
							["amount"] = 3042,
						},
						["icon"] = "Interface\\Icons\\ability_monk_forcesphere",
					},
					["Healing Potion"] = {
						[-2] = {
							["time"] = "|cffffffff10/24/12 11:23:28|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:4042:SPELL_HEAL|h|cffffffffHealing Potion|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff1157|r |cffffffffPhysical|r. ",
							["amount"] = 1157,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Potion_53",
					},
					["Zen Sphere"] = {
						[-2] = {
							["time"] = "|cffffffff11/21/12 12:23:13|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:124081:SPELL_PERIODIC_HEAL|h|cffffffffZen Sphere|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff0|r |cffffffffNature|r. (460 Overhealed) ",
							["amount"] = 460,
						},
						[2] = {
							["time"] = "|cffffffff11/21/12 12:15:31|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:124081:SPELL_PERIODIC_HEAL|h|cffffffffZen Sphere|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff0|r |cffffffffNature|r. (771 Overhealed) (Critical) ",
							["amount"] = 771,
						},
						["icon"] = "Interface\\Icons\\ability_monk_forcesphere",
					},
					["Healing Sphere"] = {
						[-2] = {
							["time"] = "|cffffffff11/18/12 10:08:17|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:115464:SPELL_HEAL|h|cffffffffHealing Sphere|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0300000000070886:Corrode-Kil'jaeden|hCorrode-Kil'jaeden|h |cffffffff230|r |cffffffffNature|r. (5918 Overhealed) ",
							["amount"] = 6148,
						},
						[2] = {
							["time"] = "|cffffffff11/18/12 11:39:16|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:115464:SPELL_HEAL|h|cffffffffHealing Sphere|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff0|r |cffffffffNature|r. (11963 Overhealed) (Critical) ",
							["amount"] = 11963,
						},
						["icon"] = "Interface\\Icons\\ability_monk_healthsphere",
					},
					["Renewing Mist"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 11:01:52|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:119611:SPELL_PERIODIC_HEAL|h|cffffffffRenewing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000051240AB:Pawsnreflect|hPawsnreflect|h |cffffffff3699|r |cffffffffNature|r. ",
							["amount"] = 3699,
						},
						[2] = {
							["time"] = "|cffffffff11/18/12 11:39:48|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:119611:SPELL_PERIODIC_HEAL|h|cffffffffRenewing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000051240AB:Pawsnreflect|hPawsnreflect|h |cffffffff0|r |cffffffffNature|r. (5426 Overhealed) (Critical) ",
							["amount"] = 5426,
						},
						["icon"] = "Interface\\Icons\\ability_monk_renewingmists",
					},
					["Expel Harm"] = {
						[-2] = {
							["time"] = "|cffffffff11/21/12 12:34:29|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:115072:SPELL_HEAL|h|cffffffffExpel Harm|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff1634|r |cffffffffNature|r. ",
							["amount"] = 1634,
						},
						[2] = {
							["time"] = "|cffffffff11/21/12 12:28:18|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:115072:SPELL_HEAL|h|cffffffffExpel Harm|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff2042|r |cffffffffNature|r. (1027 Overhealed) (Critical) ",
							["amount"] = 3069,
						},
						["icon"] = "Interface\\Icons\\ability_monk_expelharm",
					},
					["Swift Hand of Justice"] = {
						[-2] = {
							["time"] = "|cffffffff11/21/12 12:25:21|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:59913:SPELL_HEAL|h|cffffffffSwift Hand of Justice|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff161|r |cffffffffPhysical|r. (99 Overhealed) ",
							["amount"] = 260,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_DeathKnight_Vendetta",
					},
					["Spinning Crane Kick"] = {
						[-2] = {
							["time"] = "|cffffffff11/18/12 11:39:19|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:117640:SPELL_HEAL|h|cffffffffSpinning Crane Kick|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000051240AB:Pawsnreflect|hPawsnreflect|h |cffffffff924|r |cffffffffNature|r. (1385 Overhealed) ",
							["amount"] = 2309,
						},
						[2] = {
							["time"] = "|cffffffff11/18/12 11:40:15|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:117640:SPELL_HEAL|h|cffffffffSpinning Crane Kick|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000051240AB:Pawsnreflect|hPawsnreflect|h |cffffffff80|r |cffffffffNature|r. (4529 Overhealed) (Critical) ",
							["amount"] = 4609,
						},
						["icon"] = "Interface\\Icons\\ability_monk_cranekick_new",
					},
					["Eminence (Statue)"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 11:01:42|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:117895:SPELL_HEAL|h|cffffffffEminence (Statue)|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff0|r |cffffffffNature|r. (4243 Overhealed) ",
							["amount"] = 4243,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\inv_jewelcrafting_jadeserpent",
					},
					["Surging Mist"] = {
						[-2] = {
							["time"] = "|cffffffff12/26/12 06:34:54|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:116995:SPELL_HEAL|h|cffffffffSurging Mist|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff7506|r |cffffffffNature|r. (6110 Overhealed) ",
							["amount"] = 13616,
						},
						[2] = {
							["time"] = "|cffffffff11/15/12 10:20:22|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:116995:SPELL_HEAL|h|cffffffffSurging Mist|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000517F436:Sarsha-Terenas|hSarsha-Terenas|h |cffffffff1920|r |cffffffffNature|r. (14483 Overhealed) (Critical) ",
							["amount"] = 16403,
						},
						["icon"] = "Interface\\Icons\\ability_monk_surgingmist",
					},
					["Uplift"] = {
						[-2] = {
							["time"] = "|cffffffff11/21/12 01:04:36|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:116670:SPELL_HEAL|h|cffffffffUplift|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0300000007051DA5:Dellap-Khaz'goroth|hDellap-Khaz'goroth|h |cffffffff4273|r |cffffffffNature|r. (1502 Overhealed) ",
							["amount"] = 5775,
						},
						[2] = {
							["time"] = "|cffffffff11/21/12 01:04:36|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:116670:SPELL_HEAL|h|cffffffffUplift|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x03800000057F5E50:Yaoshin-Runetotem|hYaoshin-Runetotem|h |cffffffff0|r |cffffffffNature|r. (11122 Overhealed) (Critical) ",
							["amount"] = 11122,
						},
						["icon"] = "Interface\\Icons\\ability_monk_uplift",
					},
					["Soothing Mist"] = {
						[-2] = {
							["time"] = "|cffffffff12/26/12 06:35:02|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:115175:SPELL_PERIODIC_HEAL|h|cffffffffSoothing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff0|r |cffffffffNature|r. (4083 Overhealed) ",
							["amount"] = 4083,
						},
						[2] = {
							["time"] = "|cffffffff12/26/12 06:37:51|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:115175:SPELL_PERIODIC_HEAL|h|cffffffffSoothing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff0|r |cffffffffNature|r. (6260 Overhealed) (Critical) ",
							["amount"] = 6260,
						},
						["icon"] = "Interface\\Icons\\ability_monk_soothingmists",
					},
					["Enveloping Mist"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 10:59:08|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:132120:SPELL_PERIODIC_HEAL|h|cffffffffEnveloping Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000051240AB:Pawsnreflect|hPawsnreflect|h |cffffffff0|r |cffffffffNature|r. (11007 Overhealed) ",
							["amount"] = 11007,
						},
						[2] = {
							["time"] = "|cffffffff11/24/12 10:59:07|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:132120:SPELL_PERIODIC_HEAL|h|cffffffffEnveloping Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000051240AB:Pawsnreflect|hPawsnreflect|h |cffffffff73|r |cffffffffNature|r. (21941 Overhealed) (Critical) ",
							["amount"] = 22014,
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_SpiritLink",
					},
				},
				["hit"] = {
					["Fiery Keg Smash"] = {
						[-2] = {
							["time"] = "|cffffffff10/21/12 08:16:37|r\n|Hunit:0xF13105F400193925:Master Cheng|hMaster Cheng|h |Hspell:131831:SPELL_DAMAGE|h|cffffffffFiery Keg Smash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff274|r |cffffffffFire|r. ",
							["amount"] = 274,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\achievement_brewery_2",
					},
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff11/21/12 12:22:08|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF1305DFF0016359B:Dragonflayer Worg|hDragonflayer Worg|h |cffffffff717|r |cffffffffPhysical|r. ",
							["amount"] = 717,
						},
						[2] = {
							["time"] = "|cffffffff11/21/12 12:44:42|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF1305DFF0016AC61:Dragonflayer Worg|hDragonflayer Worg|h |cffffffff1408|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 1408,
						},
					},
					["Breath of Fire"] = {
						[-2] = {
							["time"] = "|cffffffff11/21/12 12:30:34|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:115181:SPELL_DAMAGE|h|cffffffffBreath of Fire|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1305DFF001660A3:Dragonflayer Worg|hDragonflayer Worg|h |cffffffff1341|r |cffffffffFire|r. ",
							["amount"] = 1341,
						},
						[2] = {
							["time"] = "|cffffffff11/21/12 12:24:27|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:115181:SPELL_DAMAGE|h|cffffffffBreath of Fire|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1305DF300164124:Dragonflayer Invader|hDragonflayer Invader|h |cffffffff1287|r |cffffffffFire|r. (1130 Overkill) (Critical) ",
							["amount"] = 2417,
						},
						["icon"] = "Interface\\Icons\\ability_monk_breathoffire",
					},
					["Touch of Death"] = {
						[-2] = {
							["time"] = "|cffffffff12/12/12 03:29:40|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:115080:SPELL_DAMAGE|h|cffffffffTouch of Death|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF131016B0010941D:Master Kistane|hMaster Kistane|h |cffffffff11279|r |cffffffffPhysical|r. (1933 Overkill) ",
							["amount"] = 13212,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_touchofdeath",
					},
					["Expel Harm"] = {
						[-2] = {
							["time"] = "|cffffffff10/17/12 06:34:34|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:115129:SPELL_DAMAGE|h|cffffffffExpel Harm|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13022D9000084EB:Bloodhound|hBloodhound|h |cffffffff1039|r |cffffffffNature|r. ",
							["amount"] = 1039,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Spinning Crane Kick"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 10:37:01|r\n|Hunit:0xF1310284004928F0:Master Cheng|hMaster Cheng|h |Hspell:130151:SPELL_DAMAGE|h|cffffffffSpinning Crane Kick|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff745|r |cffffffffPhysical|r. ",
							["amount"] = 745,
						},
						[2] = {
							["time"] = "|cffffffff11/24/12 11:05:01|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:107270:SPELL_DAMAGE|h|cffffffffSpinning Crane Kick|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130083E0000141A:Black Rat|hBlack Rat|h |cffffffff1|r |cffffffffPhysical|r. (574 Overkill) (Critical) ",
							["amount"] = 575,
						},
						["icon"] = "Interface\\Icons\\ability_monk_cranekick_new",
					},
					["Path of Blossoms"] = {
						[-2] = {
							["time"] = "|cffffffff11/18/12 10:17:55|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:122036:SPELL_DAMAGE|h|cffffffffPath of Blossoms|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13047A800000D51:Nexus-Prince Shaffar|hNexus-Prince Shaffar|h |cffffffff476|r |cffffffffFire|r. ",
							["amount"] = 476,
						},
						[2] = {
							["time"] = "|cffffffff11/18/12 10:17:58|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:122036:SPELL_DAMAGE|h|cffffffffPath of Blossoms|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13047A800000D51:Nexus-Prince Shaffar|hNexus-Prince Shaffar|h |cffffffff952|r |cffffffffFire|r. (Critical) ",
							["amount"] = 952,
						},
						["icon"] = "Interface\\Icons\\warlock_ healthstone",
					},
					["Tiger Palm"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 10:37:34|r\n|Hunit:0xF1310284004928F0:Master Cheng|hMaster Cheng|h |Hspell:130782:SPELL_DAMAGE|h|cffffffffTiger Palm|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff419|r |cffffffffPhysical|r. ",
							["amount"] = 419,
						},
						[2] = {
							["time"] = "|cffffffff11/21/12 12:20:11|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:100787:SPELL_DAMAGE|h|cffffffffTiger Palm|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1305DFF00162AE9:Dragonflayer Worg|hDragonflayer Worg|h |cffffffff770|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 770,
						},
						["icon"] = "Interface\\Icons\\ability_monk_tigerpalm",
					},
					["Thorns"] = {
						[-2] = {
							["time"] = "|cffffffff10/26/12 11:58:35|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:15438:DAMAGE_SHIELD|h|cffffffffThorns|r|h |Haction:DAMAGE_SHIELD|hdamages|h |Hunit:0xF13023890000327A:Scarshield Legionnaire|hScarshield Legionnaire|h |cffffffff4|r |cffffffffArcane|r. ",
							["amount"] = 4,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_LightningShield",
					},
					["Zen Sphere"] = {
						[-2] = {
							["time"] = "|cffffffff11/18/12 09:58:31|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:124098:SPELL_DAMAGE|h|cffffffffZen Sphere|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13047C500000C67:Exarch Maladaar|hExarch Maladaar|h |cffffffff151|r |cffffffffNature|r. ",
							["amount"] = 151,
						},
						[2] = {
							["time"] = "|cffffffff10/17/12 08:10:33|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:124098:SPELL_DAMAGE|h|cffffffffZen Sphere|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130149600001ABF:Atal'ai Corpse Eater|hAtal'ai Corpse Eater|h |cffffffff190|r |cffffffffNature|r. (Critical) ",
							["amount"] = 190,
						},
						["icon"] = "Interface\\Icons\\ability_monk_forcesphere",
					},
					["Dizzying Haze"] = {
						[-2] = {
							["time"] = "|cffffffff11/21/12 12:32:49|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:118022:SPELL_DAMAGE|h|cffffffffDizzying Haze|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1305DFF00166CE0:Dragonflayer Worg|hDragonflayer Worg|h |cffffffff1214|r |cffffffffPhysical|r. ",
							["amount"] = 1214,
						},
						[2] = {
							["time"] = "|cffffffff11/21/12 12:26:46|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:118022:SPELL_DAMAGE|h|cffffffffDizzying Haze|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1305DF300164BD0:Dragonflayer Invader|hDragonflayer Invader|h |cffffffff1943|r |cffffffffPhysical|r. (162 Overkill) (Critical) ",
							["amount"] = 2105,
						},
						["icon"] = "Interface\\Icons\\ability_monk_drunkenhaze",
					},
					["Keg Smash"] = {
						[-2] = {
							["time"] = "|cffffffff11/21/12 12:13:52|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:121253:SPELL_DAMAGE|h|cffffffffKeg Smash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1305E6E0000507A:Fjord Rat|hFjord Rat|h |cffffffff1|r |cffffffffPhysical|r. (1965 Overkill) ",
							["amount"] = 1966,
						},
						[2] = {
							["time"] = "|cffffffff11/21/12 12:40:25|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:121253:SPELL_DAMAGE|h|cffffffffKeg Smash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1305E6E001692D6:Fjord Rat|hFjord Rat|h |cffffffff1|r |cffffffffPhysical|r. (3657 Overkill) (Critical) ",
							["amount"] = 3658,
						},
						["icon"] = "Interface\\Icons\\achievement_brewery_2",
					},
					["Stagger"] = {
						[-2] = {
							["time"] = "|cffffffff10/26/12 11:40:30|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:124255:SPELL_PERIODIC_DAMAGE|h|cffffffffStagger|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff254|r |cffffffffPhysical|r. ",
							["amount"] = 254,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Rogue_CheatDeath",
					},
					["Jab"] = {
						[-2] = {
							["time"] = "|cffffffff11/21/12 12:34:58|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:108557:SPELL_DAMAGE|h|cffffffffJab|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1305DFF0016799E:Dragonflayer Worg|hDragonflayer Worg|h |cffffffff192|r |cffffffffPhysical|r. ",
							["amount"] = 192,
						},
						[2] = {
							["time"] = "|cffffffff11/21/12 12:19:48|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:108557:SPELL_DAMAGE|h|cffffffffJab|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1305DFF001629D9:Dragonflayer Worg|hDragonflayer Worg|h |cffffffff380|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 380,
						},
						["icon"] = "Interface\\Icons\\ability_monk_staffstrike",
					},
					["Blackout Kick"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 11:09:03|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:100784:SPELL_DAMAGE|h|cffffffffBlackout Kick|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130742700001446:Savage Worg|hSavage Worg|h |cffffffff379|r |cffffffffPhysical|r. (417 Overkill) ",
							["amount"] = 796,
						},
						[2] = {
							["time"] = "|cffffffff11/24/12 11:02:30|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:100784:SPELL_DAMAGE|h|cffffffffBlackout Kick|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1305E15000013E7:Dragonflayer Overseer|hDragonflayer Overseer|h |cffffffff1496|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 1496,
						},
						["icon"] = "Interface\\Icons\\ability_monk_roundhousekick",
					},
					["Swift Reflexes"] = {
						[-2] = {
							["time"] = "|cffffffff11/21/12 12:30:41|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:124335:SPELL_DAMAGE|h|cffffffffSwift Reflexes|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1305DFF001660A3:Dragonflayer Worg|hDragonflayer Worg|h |cffffffff614|r |cffffffffPhysical|r. ",
							["amount"] = 614,
						},
						[2] = {
							["time"] = "|cffffffff11/21/12 12:34:58|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:124335:SPELL_DAMAGE|h|cffffffffSwift Reflexes|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1305DFF0016799E:Dragonflayer Worg|hDragonflayer Worg|h |cffffffff1110|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 1110,
						},
						["icon"] = "Interface\\Icons\\inv_gloves_mail_challengehunter_d_01",
					},
					["Crackling Jade Lightning"] = {
						[-2] = {
							["time"] = "|cffffffff12/12/12 03:28:52|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:117952:SPELL_PERIODIC_DAMAGE|h|cffffffffCrackling Jade Lightning|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF131016B0010941D:Master Kistane|hMaster Kistane|h |cffffffff640|r |cffffffffNature|r. ",
							["amount"] = 640,
						},
						[2] = {
							["time"] = "|cffffffff11/21/12 12:44:30|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:117952:SPELL_PERIODIC_DAMAGE|h|cffffffffCrackling Jade Lightning|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF1305DFF0016A9C5:Dragonflayer Worg|hDragonflayer Worg|h |cffffffff1003|r |cffffffffNature|r. (Critical) ",
							["amount"] = 1003,
						},
						["icon"] = "Interface\\Icons\\ability_monk_cracklingjadelightning",
					},
					["Rising Sun Kick"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 10:37:15|r\n|Hunit:0xF1310284004928F0:Master Cheng|hMaster Cheng|h |Hspell:130784:SPELL_DAMAGE|h|cffffffffRising Sun Kick|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff941|r |cffffffffPhysical|r. ",
							["amount"] = 941,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_risingsunkick",
					},
					["Zen Sphere: Detonate"] = {
						[-2] = {
							["time"] = "|cffffffff11/18/12 09:58:33|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:125033:SPELL_DAMAGE|h|cffffffffZen Sphere: Detonate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13047C500000C67:Exarch Maladaar|hExarch Maladaar|h |cffffffff438|r |cffffffffNature|r. ",
							["amount"] = 438,
						},
						[2] = {
							["time"] = "|cffffffff10/23/12 11:55:15|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:125033:SPELL_DAMAGE|h|cffffffffZen Sphere: Detonate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130165700000525:Morphaz|hMorphaz|h |cffffffff246|r |cffffffffNature|r. (Critical) ",
							["amount"] = 246,
						},
						["icon"] = "Interface\\Icons\\ability_monk_forcesphere",
					},
					["Tiger Strikes"] = {
						[-2] = {
							["time"] = "|cffffffff10/27/12 12:52:54|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:120274:SPELL_DAMAGE|h|cffffffffTiger Strikes|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130439C00002229:Omor the Unscarred|hOmor the Unscarred|h |cffffffff336|r |cffffffffPhysical|r. ",
							["amount"] = 336,
						},
						[2] = {
							["time"] = "|cffffffff11/18/12 09:54:19|r\n|Hunit:0x010000000513BAA0:Skadooch|hYour|h |Hspell:120274:SPELL_DAMAGE|h|cffffffffTiger Strikes|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13047C300000C66:Shirrak the Dead Watcher|hShirrak the Dead Watcher|h |cffffffff655|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 655,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Cyclone",
					},
				},
			}, -- [1]
			[-1] = {
				["heal"] = {
					["Healing Touch"] = {
						[-2] = {
							["time"] = "|cffffffff10/17/12 08:10:11|r\n|Hunit:0x0100000004FE6558:Felaron-Arathor|hFelaron-Arathor|h |Hspell:5185:SPELL_HEAL|h|cff82f4ffHealing Touch|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff2232|r |cff82f4ffNature|r. ",
							["amount"] = 2232,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingTouch",
					},
					["Swiftmend"] = {
						[-2] = {
							["time"] = "|cffffffff10/24/12 11:06:52|r\n|Hunit:0x0300000005717707:Naige-Blackrock|hNaige-Blackrock|h |Hspell:18562:SPELL_HEAL|h|cff82f4ffSwiftmend|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff1839|r |cff82f4ffNature|r. ",
							["amount"] = 1839,
						},
						[2] = {
							["time"] = "|cffffffff10/17/12 08:00:34|r\n|Hunit:0x0180000004AE5B33:Feralheart-AzjolNerub|hFeralheart-AzjolNerub|h |Hspell:18562:SPELL_HEAL|h|cff82f4ffSwiftmend|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff392|r |cff82f4ffNature|r. (3289 Overhealed) (Critical) ",
							["amount"] = 3681,
						},
						["icon"] = "Interface\\Icons\\INV_Relics_IdolofRejuvenation",
					},
					["Renew"] = {
						[-2] = {
							["time"] = "|cffffffff10/26/12 11:40:34|r\n|Hunit:0x030000000748E11D:Escapewolf-Blackrock|hEscapewolf-Blackrock|h |Hspell:139:SPELL_PERIODIC_HEAL|h|cff82f4ffRenew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff240|r |cff82f4ffHoly|r. (885 Overhealed) ",
							["amount"] = 1125,
						},
						[2] = {
							["time"] = "|cffffffff10/26/12 11:40:24|r\n|Hunit:0x030000000748E11D:Escapewolf-Blackrock|hEscapewolf-Blackrock|h |Hspell:139:SPELL_PERIODIC_HEAL|h|cff82f4ffRenew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff799|r |cff82f4ffHoly|r. (1451 Overhealed) (Critical) ",
							["amount"] = 2250,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Renew",
					},
					["Healing Surge"] = {
						[-2] = {
							["time"] = "|cffffffff10/24/12 10:57:12|r\n|Hunit:0x03000000074B00FE:Wdee-Tichondrius|hWdee-Tichondrius|h |Hspell:8004:SPELL_HEAL|h|cff82f4ffHealing Surge|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff2652|r |cff82f4ffNature|r. ",
							["amount"] = 2652,
						},
						[2] = {
							["time"] = "|cffffffff10/24/12 10:43:55|r\n|Hunit:0x03000000074B00FE:Wdee-Tichondrius|hWdee-Tichondrius|h |Hspell:8004:SPELL_HEAL|h|cff82f4ffHealing Surge|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff397|r |cff82f4ffNature|r. (4896 Overhealed) (Critical) ",
							["amount"] = 5293,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWay",
					},
					["Cenarion Ward"] = {
						[-2] = {
							["time"] = "|cffffffff10/17/12 08:04:53|r\n|Hunit:0x0100000004FE6558:Felaron-Arathor|hFelaron-Arathor|h |Hspell:102352:SPELL_PERIODIC_HEAL|h|cff82f4ffCenarion Ward|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (726 Overhealed) ",
							["amount"] = 726,
						},
						[2] = {
							["time"] = "|cffffffff10/17/12 08:09:24|r\n|Hunit:0x0100000004FE6558:Felaron-Arathor|hFelaron-Arathor|h |Hspell:102352:SPELL_PERIODIC_HEAL|h|cff82f4ffCenarion Ward|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff182|r |cff82f4ffNature|r. (1270 Overhealed) (Critical) ",
							["amount"] = 1452,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_NaturalPerfection",
					},
					["Nourish"] = {
						[-2] = {
							["time"] = "|cffffffff10/17/12 08:00:46|r\n|Hunit:0x0180000004AE5B33:Feralheart-AzjolNerub|hFeralheart-AzjolNerub|h |Hspell:50464:SPELL_HEAL|h|cff82f4ffNourish|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff1113|r |cff82f4ffNature|r. ",
							["amount"] = 1113,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Nourish",
					},
					["Binding Heal"] = {
						[-2] = {
							["time"] = "|cffffffff10/26/12 11:43:34|r\n|Hunit:0x030000000748E11D:Escapewolf-Blackrock|hEscapewolf-Blackrock|h |Hspell:32546:SPELL_HEAL|h|cff82f4ffBinding Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff2288|r |cff82f4ffHoly|r. (3356 Overhealed) ",
							["amount"] = 5644,
						},
						[2] = {
							["time"] = "|cffffffff10/26/12 11:40:11|r\n|Hunit:0x030000000748E11D:Escapewolf-Blackrock|hEscapewolf-Blackrock|h |Hspell:32546:SPELL_HEAL|h|cff82f4ffBinding Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff1507|r |cff82f4ffHoly|r. (9188 Overhealed) (Critical) ",
							["amount"] = 10695,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_BlindingHeal",
					},
					["Living Seed"] = {
						[-2] = {
							["time"] = "|cffffffff10/17/12 08:00:36|r\n|Hunit:0x0180000004AE5B33:Feralheart-AzjolNerub|hFeralheart-AzjolNerub|h |Hspell:48503:SPELL_HEAL|h|cff82f4ffLiving Seed|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (1160 Overhealed) ",
							["amount"] = 1160,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_GiftoftheEarthmother",
					},
					["Lifebloom"] = {
						[-2] = {
							["time"] = "|cffffffff10/17/12 08:01:02|r\n|Hunit:0x0180000004AE5B33:Feralheart-AzjolNerub|hFeralheart-AzjolNerub|h |Hspell:33778:SPELL_HEAL|h|cff82f4ffLifebloom|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff63|r |cff82f4ffNature|r. (3158 Overhealed) ",
							["amount"] = 3221,
						},
						[2] = {
							["time"] = "|cffffffff10/24/12 11:08:42|r\n|Hunit:0x0300000005717707:Naige-Blackrock|hNaige-Blackrock|h |Hspell:33778:SPELL_HEAL|h|cff82f4ffLifebloom|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (6438 Overhealed) (Critical) ",
							["amount"] = 6438,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingTouch",
					},
					["Chi Wave"] = {
						[-2] = {
							["time"] = "|cffffffff11/18/12 11:17:29|r\n|Hunit:0x0180000004C98AA6:Alpinespring-Draenor|hAlpinespring-Draenor|h |Hspell:132463:SPELL_HEAL|h|cff82f4ffChi Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (1063 Overhealed) ",
							["amount"] = 1063,
						},
						[2] = {
							["time"] = "|cffffffff11/18/12 11:17:36|r\n|Hunit:0x0180000004C98AA6:Alpinespring-Draenor|hAlpinespring-Draenor|h |Hspell:132463:SPELL_HEAL|h|cff82f4ffChi Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff61|r |cff82f4ffNature|r. (2052 Overhealed) (Critical) ",
							["amount"] = 2113,
						},
						["icon"] = "Interface\\Icons\\ability_monk_chiwave",
					},
					["Spinning Crane Kick"] = {
						[-2] = {
							["time"] = "|cffffffff10/26/12 11:24:25|r\n|Hunit:0x0180000004C921B9:Anatomikelly-Crushridge|hAnatomikelly-Crushridge|h |Hspell:117640:SPELL_HEAL|h|cff82f4ffSpinning Crane Kick|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff94|r |cff82f4ffNature|r. (873 Overhealed) ",
							["amount"] = 967,
						},
						[2] = {
							["time"] = "|cffffffff10/26/12 11:24:25|r\n|Hunit:0x0180000004C921B9:Anatomikelly-Crushridge|hAnatomikelly-Crushridge|h |Hspell:117640:SPELL_HEAL|h|cff82f4ffSpinning Crane Kick|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff260|r |cff82f4ffNature|r. (1673 Overhealed) (Critical) ",
							["amount"] = 1933,
						},
						["icon"] = "Interface\\Icons\\ability_monk_cranekick_new",
					},
					["Rejuvenation"] = {
						[-2] = {
							["time"] = "|cffffffff12/12/12 06:22:03|r\n|Hunit:0x05000000055BBD2D:Tomalo-Executus|hTomalo-Executus|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cff82f4ffRejuvenation|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff671|r |cff82f4ffNature|r. (1611 Overhealed) ",
							["amount"] = 2282,
						},
						[2] = {
							["time"] = "|cffffffff10/17/12 08:00:50|r\n|Hunit:0x0180000004AE5B33:Feralheart-AzjolNerub|hFeralheart-AzjolNerub|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cff82f4ffRejuvenation|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff306|r |cff82f4ffNature|r. (811 Overhealed) (Critical) ",
							["amount"] = 1117,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Rejuvenation",
					},
					["Healing Sphere"] = {
						[-2] = {
							["time"] = "|cffffffff11/18/12 11:32:07|r\n|Hunit:0x0180000004C98AA6:Alpinespring-Draenor|hAlpinespring-Draenor|h |Hspell:115464:SPELL_HEAL|h|cff82f4ffHealing Sphere|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff1545|r |cff82f4ffNature|r. (2714 Overhealed) ",
							["amount"] = 4259,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_healthsphere",
					},
					["Regrowth"] = {
						[-2] = {
							["time"] = "|cffffffff10/24/12 11:15:24|r\n|Hunit:0x0300000005717707:Naige-Blackrock|hNaige-Blackrock|h |Hspell:8936:SPELL_HEAL|h|cff82f4ffRegrowth|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff1403|r |cff82f4ffNature|r. ",
							["amount"] = 1403,
						},
						[2] = {
							["time"] = "|cffffffff10/24/12 11:12:57|r\n|Hunit:0x0300000005717707:Naige-Blackrock|hNaige-Blackrock|h |Hspell:8936:SPELL_HEAL|h|cff82f4ffRegrowth|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff822|r |cff82f4ffNature|r. (2025 Overhealed) (Critical) ",
							["amount"] = 2847,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_ResistNature",
					},
					["Soothing Mist"] = {
						[-2] = {
							["time"] = "|cffffffff10/26/12 11:24:52|r\n|Hunit:0x0180000004C921B9:Anatomikelly-Crushridge|hAnatomikelly-Crushridge|h |Hspell:115175:SPELL_PERIODIC_HEAL|h|cff82f4ffSoothing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (1559 Overhealed) ",
							["amount"] = 1559,
						},
						[2] = {
							["time"] = "|cffffffff10/26/12 11:24:20|r\n|Hunit:0x0180000004C921B9:Anatomikelly-Crushridge|hAnatomikelly-Crushridge|h |Hspell:115175:SPELL_PERIODIC_HEAL|h|cff82f4ffSoothing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff386|r |cff82f4ffNature|r. (2327 Overhealed) (Critical) ",
							["amount"] = 2713,
						},
						["icon"] = "Interface\\Icons\\ability_monk_soothingmists",
					},
					["Ancestral Awakening"] = {
						[-2] = {
							["time"] = "|cffffffff10/24/12 10:56:48|r\n|Hunit:0x03000000074B00FE:Wdee-Tichondrius|hWdee-Tichondrius|h |Hspell:52752:SPELL_HEAL|h|cff82f4ffAncestral Awakening|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff1661|r |cff82f4ffNature|r. ",
							["amount"] = 1661,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_AncestralAwakening",
					},
					["Chi Burst"] = {
						[-2] = {
							["time"] = "|cffffffff10/26/12 11:25:56|r\n|Hunit:0x0180000004C921B9:Anatomikelly-Crushridge|hAnatomikelly-Crushridge|h |Hspell:130654:SPELL_HEAL|h|cff82f4ffChi Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff1452|r |cff82f4ffNature|r. ",
							["amount"] = 1452,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Arcane_ArcaneTorrent",
					},
					["Greater Heal"] = {
						[-2] = {
							["time"] = "|cffffffff10/26/12 11:45:21|r\n|Hunit:0x030000000748E11D:Escapewolf-Blackrock|hEscapewolf-Blackrock|h |Hspell:2060:SPELL_HEAL|h|cff82f4ffGreater Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff2096|r |cff82f4ffHoly|r. (7474 Overhealed) ",
							["amount"] = 9570,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_GreaterHeal",
					},
					["Prayer of Healing"] = {
						[-2] = {
							["time"] = "|cffffffff10/26/12 11:43:30|r\n|Hunit:0x030000000748E11D:Escapewolf-Blackrock|hEscapewolf-Blackrock|h |Hspell:596:SPELL_HEAL|h|cff82f4ffPrayer of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff3692|r |cff82f4ffHoly|r. ",
							["amount"] = 3692,
						},
						[2] = {
							["time"] = "|cffffffff10/17/12 06:43:38|r\n|Hunit:0x03800000056E5F65:Nevaehh-Akama|hNevaehh-Akama|h |Hspell:596:SPELL_HEAL|h|cff82f4ffPrayer of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff905|r |cff82f4ffHoly|r. (2838 Overhealed) (Critical) ",
							["amount"] = 3743,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfHealing02",
					},
					["Flash Heal"] = {
						[-2] = {
							["time"] = "|cffffffff10/26/12 11:46:19|r\n|Hunit:0x030000000748E11D:Escapewolf-Blackrock|hEscapewolf-Blackrock|h |Hspell:2061:SPELL_HEAL|h|cff82f4ffFlash Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff4288|r |cff82f4ffHoly|r. (3277 Overhealed) ",
							["amount"] = 7565,
						},
						[2] = {
							["time"] = "|cffffffff10/26/12 11:45:12|r\n|Hunit:0x030000000748E11D:Escapewolf-Blackrock|hEscapewolf-Blackrock|h |Hspell:2061:SPELL_HEAL|h|cff82f4ffFlash Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff3954|r |cff82f4ffHoly|r. (11161 Overhealed) (Critical) ",
							["amount"] = 15115,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Healing Wave"] = {
						[-2] = {
							["time"] = "|cffffffff10/24/12 10:44:24|r\n|Hunit:0x03000000074B00FE:Wdee-Tichondrius|hWdee-Tichondrius|h |Hspell:331:SPELL_HEAL|h|cff82f4ffHealing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (1770 Overhealed) ",
							["amount"] = 1770,
						},
						[2] = {
							["time"] = "|cffffffff10/24/12 10:56:20|r\n|Hunit:0x03000000074B00FE:Wdee-Tichondrius|hWdee-Tichondrius|h |Hspell:331:SPELL_HEAL|h|cff82f4ffHealing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff1718|r |cff82f4ffNature|r. (1764 Overhealed) (Critical) ",
							["amount"] = 3482,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_MagicImmunity",
					},
					["Earthliving"] = {
						[-2] = {
							["time"] = "|cffffffff10/24/12 10:43:30|r\n|Hunit:0x03000000074B00FE:Wdee-Tichondrius|hWdee-Tichondrius|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff69|r |cff82f4ffNature|r. (86 Overhealed) ",
							["amount"] = 155,
						},
						[2] = {
							["time"] = "|cffffffff10/24/12 10:45:04|r\n|Hunit:0x03000000074B00FE:Wdee-Tichondrius|hWdee-Tichondrius|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff309|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 309,
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_GiftEarthmother",
					},
					["Earth Shield"] = {
						[-2] = {
							["time"] = "|cffffffff10/24/12 10:42:25|r\n|Hunit:0x03000000074B00FE:Wdee-Tichondrius|hWdee-Tichondrius|h |Hspell:379:SPELL_HEAL|h|cff82f4ffEarth Shield|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff242|r |cff82f4ffNature|r. (104 Overhealed) ",
							["amount"] = 346,
						},
						[2] = {
							["time"] = "|cffffffff10/24/12 10:43:56|r\n|Hunit:0x03000000074B00FE:Wdee-Tichondrius|hWdee-Tichondrius|h |Hspell:379:SPELL_HEAL|h|cff82f4ffEarth Shield|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff30|r |cff82f4ffNature|r. (662 Overhealed) (Critical) ",
							["amount"] = 692,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_SkinofEarth",
					},
					["Healing Rain"] = {
						[-2] = {
							["time"] = "|cffffffff11/18/12 11:44:58|r\n|Hunit:0x0300000007387454:Lostbee-Thaurissan|hLostbee-Thaurissan|h |Hspell:73921:SPELL_HEAL|h|cff82f4ffHealing Rain|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (887 Overhealed) ",
							["amount"] = 887,
						},
						[2] = {
							["time"] = "|cffffffff11/21/12 01:00:20|r\n|Hunit:0x03800000058763A2:Rahpin-Jubei'Thos|hRahpin-Jubei'Thos|h |Hspell:73921:SPELL_HEAL|h|cff82f4ffHealing Rain|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (5241 Overhealed) (Critical) ",
							["amount"] = 5241,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_GiftoftheWaterSpirit",
					},
					["Riptide"] = {
						[-2] = {
							["time"] = "|cffffffff10/24/12 10:42:21|r\n|Hunit:0x03000000074B00FE:Wdee-Tichondrius|hWdee-Tichondrius|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff586|r |cff82f4ffNature|r. (174 Overhealed) ",
							["amount"] = 760,
						},
						[2] = {
							["time"] = "|cffffffff10/24/12 10:49:06|r\n|Hunit:0x03000000074B00FE:Wdee-Tichondrius|hWdee-Tichondrius|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff104|r |cff82f4ffNature|r. (1415 Overhealed) (Critical) ",
							["amount"] = 1519,
						},
						["icon"] = "Interface\\Icons\\spell_nature_riptide",
					},
					["Renewing Mist"] = {
						[-2] = {
							["time"] = "|cffffffff10/26/12 11:34:42|r\n|Hunit:0x0180000004C921B9:Anatomikelly-Crushridge|hAnatomikelly-Crushridge|h |Hspell:119611:SPELL_PERIODIC_HEAL|h|cff82f4ffRenewing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff822|r |cff82f4ffNature|r. (657 Overhealed) ",
							["amount"] = 1479,
						},
						[2] = {
							["time"] = "|cffffffff10/26/12 11:27:44|r\n|Hunit:0x0180000004C921B9:Anatomikelly-Crushridge|hAnatomikelly-Crushridge|h |Hspell:119611:SPELL_PERIODIC_HEAL|h|cff82f4ffRenewing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff993|r |cff82f4ffNature|r. (1501 Overhealed) (Critical) ",
							["amount"] = 2494,
						},
						["icon"] = "Interface\\Icons\\ability_monk_renewingmists",
					},
					["Penance"] = {
						[-2] = {
							["time"] = "|cffffffff10/17/12 06:39:33|r\n|Hunit:0x03800000056E5F65:Nevaehh-Akama|hNevaehh-Akama|h |Hspell:47750:SPELL_HEAL|h|cff82f4ffPenance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (1498 Overhealed) ",
							["amount"] = 1498,
						},
						[2] = {
							["time"] = "|cffffffff10/17/12 06:39:32|r\n|Hunit:0x03800000056E5F65:Nevaehh-Akama|hNevaehh-Akama|h |Hspell:47750:SPELL_HEAL|h|cff82f4ffPenance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff889|r |cff82f4ffHoly|r. (2003 Overhealed) (Critical) ",
							["amount"] = 2892,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Penance",
					},
					["Enveloping Mist"] = {
						[-2] = {
							["time"] = "|cffffffff10/26/12 11:24:57|r\n|Hunit:0x0180000004C921B9:Anatomikelly-Crushridge|hAnatomikelly-Crushridge|h |Hspell:132120:SPELL_PERIODIC_HEAL|h|cff82f4ffEnveloping Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (5727 Overhealed) ",
							["amount"] = 5727,
						},
						[2] = {
							["time"] = "|cffffffff10/26/12 11:27:07|r\n|Hunit:0x0180000004C921B9:Anatomikelly-Crushridge|hAnatomikelly-Crushridge|h |Hspell:132120:SPELL_PERIODIC_HEAL|h|cff82f4ffEnveloping Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (8231 Overhealed) (Critical) ",
							["amount"] = 8231,
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_SpiritLink",
					},
					["Surging Mist"] = {
						[-2] = {
							["time"] = "|cffffffff10/26/12 11:32:07|r\n|Hunit:0x0180000004C921B9:Anatomikelly-Crushridge|hAnatomikelly-Crushridge|h |Hspell:116995:SPELL_HEAL|h|cff82f4ffSurging Mist|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff965|r |cff82f4ffNature|r. (6097 Overhealed) ",
							["amount"] = 7062,
						},
						[2] = {
							["time"] = "|cffffffff10/26/12 11:34:24|r\n|Hunit:0x0180000004C921B9:Anatomikelly-Crushridge|hAnatomikelly-Crushridge|h |Hspell:116995:SPELL_HEAL|h|cff82f4ffSurging Mist|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (11565 Overhealed) (Critical) ",
							["amount"] = 11565,
						},
						["icon"] = "Interface\\Icons\\ability_monk_surgingmist",
					},
					["Healing Stream Totem"] = {
						[-2] = {
							["time"] = "|cffffffff10/24/12 10:42:54|r\n|Hunit:0x03000000074B00FE:Wdee-Tichondrius|hWdee-Tichondrius|h |Hspell:52042:SPELL_PERIODIC_HEAL|h|cff82f4ffHealing Stream Totem|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff78|r |cff82f4ffNature|r. (308 Overhealed) ",
							["amount"] = 386,
						},
						[2] = {
							["time"] = "|cffffffff11/18/12 11:44:58|r\n|Hunit:0x0300000007387454:Lostbee-Thaurissan|hLostbee-Thaurissan|h |Hspell:52042:SPELL_PERIODIC_HEAL|h|cff82f4ffHealing Stream Totem|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (352 Overhealed) (Critical) ",
							["amount"] = 352,
						},
						["icon"] = "Interface\\Icons\\INV_Spear_04",
					},
					["Atonement"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 11:07:51|r\n|Hunit:0x03000000058B97C5:Rikash-Barthilas|hRikash-Barthilas|h |Hspell:81751:SPELL_HEAL|h|cff82f4ffAtonement|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff3688|r |cff82f4ffHoly|r. (257 Overhealed) ",
							["amount"] = 3945,
						},
						[2] = {
							["time"] = "|cffffffff11/24/12 11:04:02|r\n|Hunit:0x03000000058B97C5:Rikash-Barthilas|hRikash-Barthilas|h |Hspell:94472:SPELL_HEAL|h|cff82f4ffAtonement|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (5519 Overhealed) (Critical) ",
							["amount"] = 5519,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_CircleOfRenewal",
					},
					["Eminence"] = {
						[-2] = {
							["time"] = "|cffffffff10/26/12 11:22:02|r\n|Hunit:0x0180000004C921B9:Anatomikelly-Crushridge|hAnatomikelly-Crushridge|h |Hspell:126890:SPELL_HEAL|h|cff82f4ffEminence|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cff82f4ff965|r |cff82f4ffNature|r. ",
							["amount"] = 965,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\inv_jewelcrafting_jadeserpent",
					},
				},
				["hit"] = {
					["Shadow"] = {
						[-2] = {
							["time"] = "|cffffffff11/21/12 01:08:39|r\n|Hunit:0xF1305D9200004BDD:Ingvar the Plunderer|hIngvar the Plunderer|h |Hspell:42729:SPELL_DAMAGE|h|cffff1313Dreadful Roar|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffff13133657|r |cffff1313Shadow|r. ",
							["amount"] = 3657,
						},
						[2] = {
							["time"] = "|cffffffff11/18/12 10:11:25|r\n|Hunit:0xF1304B6B00000D0B:Nexus Terror|hNexus Terror|h |Haction:SWING_DAMAGE|h|cffff1313Melee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffff13133114|r |cffff1313Shadow|r. (Critical) ",
							["amount"] = 3114,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_ConeOfSilence",
					},
					["Holy"] = {
						[-2] = {
							["time"] = "|cffffffff10/24/12 11:15:03|r\n|Hunit:0xF13022C2000045E5:Anvilrage Marshal|hAnvilrage Marshal|h |Hspell:13953:SPELL_DAMAGE|h|cffff1313Holy Strike|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffff1313785|r |cffff1313Holy|r. ",
							["amount"] = 785,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_ThunderBolt",
					},
					["Arcane"] = {
						[-2] = {
							["time"] = "|cffffffff11/18/12 10:17:20|r\n|Hunit:0xF1304B6A00000D28:Mana Leech|hMana Leech|h |Hspell:34933:SPELL_DAMAGE|h|cffff1313Arcane Explosion|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffff1313720|r |cffff1313Arcane|r. ",
							["amount"] = 720,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_WispSplode",
					},
					["Frost"] = {
						[-2] = {
							["time"] = "|cffffffff11/15/12 10:15:48|r\n|Hunit:0xF13046470000110D:Rokmar the Crackler|hRokmar the Crackler|h |Hspell:35008:SPELL_DAMAGE|h|cffff1313Water Spit|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffff13131871|r |cffff1313Frost|r. ",
							["amount"] = 1871,
						},
						[2] = {
							["time"] = "|cffffffff12/12/12 06:21:17|r\n|Hunit:0x02800000057782AC:Dkfufo-Quel'Thalas|hDkfufo-Quel'Thalas|h |Hspell:55095:SPELL_PERIODIC_DAMAGE|h|cffff1313Frost Fever|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffff1313368|r |cffff1313Frost|r. (Critical) ",
							["amount"] = 368,
						},
						["icon"] = "Interface\\Icons\\Spell_DeathKnight_FrostFever",
					},
					["Fire"] = {
						[-2] = {
							["time"] = "|cffffffff10/30/12 12:31:40|r\n|Hunit:0xF130470300001356:Corrupted Nova Totem|hCorrupted Nova Totem|h |Hspell:33132:SPELL_DAMAGE|h|cffff1313Fire Nova|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffff13132597|r |cffff1313Fire|r. ",
							["amount"] = 2597,
						},
						[2] = {
							["time"] = "|cffffffff12/12/12 06:19:41|r\n|Hunit:0x06800000022DC36E:Mandraque-Farstriders|hMandraque-Farstriders|h |Hspell:108853:SPELL_DAMAGE|h|cffff1313Inferno Blast|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffff13131163|r |cffff1313Fire|r. (Critical) ",
							["amount"] = 1163,
						},
						["icon"] = "Interface\\Icons\\spell_mage_infernoblast",
					},
					["Physical"] = {
						[-2] = {
							["time"] = "|cffffffff11/21/12 12:07:25|r\n|Haction:ENVIRONMENTAL_DAMAGE|h|cffffffffFalling|r|h |Haction:ENVIRONMENTAL_DAMAGE|hdamaged|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffffffff4893|r |cffffffffPhysical|r. ",
							["amount"] = 4893,
						},
						[2] = {
							["time"] = "|cffffffff11/24/12 11:05:01|r\n|Hunit:0xF1305D940000146E:Dragonflayer Strategist|hDragonflayer Strategist|h |Haction:SWING_DAMAGE|h|cffff1313Melee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffff13133428|r |cffff1313Physical|r. (Critical) ",
							["amount"] = 3428,
						},
					},
					["Nature"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 11:08:57|r\n|Hunit:0xF1306EFA00001444:Dragonflayer Spiritualist|hDragonflayer Spiritualist|h |Hspell:51587:SPELL_DAMAGE|h|cffff1313Lightning Bolt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000513BAA0:Skadooch|hYou|h |cffff13132021|r |cffff1313Nature|r. ",
							["amount"] = 2021,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Lightning",
					},
				},
			},
		},
	},
}
