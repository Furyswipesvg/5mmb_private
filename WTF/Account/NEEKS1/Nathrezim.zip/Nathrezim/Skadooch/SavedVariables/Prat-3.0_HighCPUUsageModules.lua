
Prat3HighCPUPerCharDB = {
	["time"] = 1360445529,
	["scrollback"] = {
		["ChatFrame1"] = {
			{
				"|cff979797[20:42:52]|r|c00000000|r |Hchannel:channel:1|h[1] |h Joined Channel: |Hchannel:1|h[1. General - Shadowmoon Valley]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				69, -- [5]
			}, -- [1]
			{
				"|cff979797[20:42:52]|r|c00000000|r |Hchannel:channel:2|h[2] |h Joined Channel: |Hchannel:2|h[2. LocalDefense - Shadowmoon Valley]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				70, -- [5]
			}, -- [2]
			{
				"|cff979797[20:43:03]|r|c00000000|r Quest accepted: Grand Master Antari", -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
				1, -- [5]
			}, -- [3]
			{
				"|cff979797[20:43:21]|r|c00000000|r |cff0070ddDiezel|r has gone offline.", -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
				1, -- [5]
			}, -- [4]
			{
				"|cff979797[20:44:45]|r|c00000000|r |cffd8d8d8[|r|Hplayer:Jolena:690|h|cff8b8b8b57|r:|cfff48cbaJolena|r|h|cffd8d8d8]|r has come online.", -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
				1, -- [5]
			}, -- [5]
			{
				"|cff979797[20:45:26]|r|c00000000|r |cffaad372Oslesmus|r has gone offline.", -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
				1, -- [5]
			}, -- [6]
			{
				"|cff979797[20:45:31]|r|c00000000|r Grand Master Antari completed.", -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
				1, -- [5]
			}, -- [7]
			{
				"|cff979797[20:45:31]|r|c00000000|r Received 5 Gold, 30 Silver.", -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
				1, -- [5]
			}, -- [8]
			{
				"|cff979797[20:45:31]|r|c00000000|r Received item: |cffffffff|Hitem:89125:0:0:0:0:0:0:0:73:0:0|h[Sack of Pet Supplies]|h|r.", -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
				1, -- [5]
			}, -- [9]
			{
				"|cff979797[13:31:31]|r|c00000000|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Decarabia:3200:GUILD|h|cffd84e4e85|r:|cffffffffDecarabia|r|h|cffd8d8d8]|r:  |cffff2020|Hquest:31779:86|h[The Darkness Within]|h|r where is this cave??? ive been serching for 30mins now", -- [1]
				0.250980406999588, -- [2]
				1, -- [3]
				0.250980406999588, -- [4]
				5, -- [5]
			}, -- [10]
			{
				"|cff979797[13:31:31]|r|c00000000|r |Hchannel:channel:1|h[1] |h Joined Channel: |Hchannel:1|h[1. General - Shadowmoon Valley]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				69, -- [5]
			}, -- [11]
			{
				"|cff979797[13:31:31]|r|c00000000|r |Hchannel:channel:2|h[2] |h Joined Channel: |Hchannel:2|h[2. LocalDefense - Shadowmoon Valley]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				70, -- [5]
			}, -- [12]
			{
				"|cff979797[13:31:49]|r|c00000000|r |cffd8d8d8[|r|Hplayer:Marknutt:3203:GUILD|h|cff8b8b8b19|r:|cffff7c0aMarknutt|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:7:010000000527DA0F:1:2:9:13:4294967295:4294967295:4294967295:4294967295|h[Level 20]|h|r!", -- [1]
				0.250980406999588, -- [2]
				1, -- [3]
				0.250980406999588, -- [4]
				48, -- [5]
			}, -- [13]
			{
				"|cff979797[13:31:56]|r|c00000000|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Vvinitup:3204:GUILD|h|cffd84e4e84|r:|cffc69b6dVvinitup|r|h|cffd8d8d8]|r: where do i go learn past 450 enchanting?", -- [1]
				0.250980406999588, -- [2]
				1, -- [3]
				0.250980406999588, -- [4]
				5, -- [5]
			}, -- [14]
			{
				"|cff979797[13:31:57]|r|c00000000|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Skadooch:3205:GUILD|h|cffd8d83f73|r:|cff00ff96Skadooch|r|h|cffd8d8d8]|r: Gratz", -- [1]
				0.250980406999588, -- [2]
				1, -- [3]
				0.250980406999588, -- [4]
				5, -- [5]
			}, -- [15]
			{
				"|cff979797[13:32:09]|r|c00000000|r |cffaad372Gato|r has gone offline.", -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
				1, -- [5]
			}, -- [16]
			{
				"|cff979797[13:32:09]|r|c00000000|r |cffaad372Relah|r has gone offline.", -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
				1, -- [5]
			}, -- [17]
		},
	},
}
