
RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
		["Slaughtered"] = {
			["GUID"] = "0x01000000051942CA",
			["LastEventHealth"] = {
				"407589 (99%)", -- [1]
				"408732 (100%)", -- [2]
				"408732 (100%)", -- [3]
				"407432 (99%)", -- [4]
				"407432 (99%)", -- [5]
				"406279 (99%)", -- [6]
				"408732 (100%)", -- [7]
				"408732 (100%)", -- [8]
				"408732 (100%)", -- [9]
				"408732 (100%)", -- [10]
				"407415 (99%)", -- [11]
				"407415 (99%)", -- [12]
				"407415 (99%)", -- [13]
				"407415 (99%)", -- [14]
				"407415 (99%)", -- [15]
				"459794 (97%)", -- [16]
				"472488 (100%)", -- [17]
				"472488 (100%)", -- [18]
				"472488 (100%)", -- [19]
				"472488 (100%)", -- [20]
				"472488 (100%)", -- [21]
				"472488 (100%)", -- [22]
				"472488 (100%)", -- [23]
				"472488 (100%)", -- [24]
				"472488 (100%)", -- [25]
				"472488 (100%)", -- [26]
				"472488 (100%)", -- [27]
				"472488 (100%)", -- [28]
				"472488 (100%)", -- [29]
				"472488 (100%)", -- [30]
				"472488 (100%)", -- [31]
				"405805 (99%)", -- [32]
				"404674 (99%)", -- [33]
				"404674 (99%)", -- [34]
				"404674 (99%)", -- [35]
				"403556 (98%)", -- [36]
				"403556 (98%)", -- [37]
				"408732 (100%)", -- [38]
				"408732 (100%)", -- [39]
				"408732 (100%)", -- [40]
				"408732 (100%)", -- [41]
				"408732 (100%)", -- [42]
				"408732 (100%)", -- [43]
				"407641 (99%)", -- [44]
				"408732 (100%)", -- [45]
				"408732 (100%)", -- [46]
				"407751 (99%)", -- [47]
				"408732 (100%)", -- [48]
				"408732 (100%)", -- [49]
				"408732 (100%)", -- [50]
			},
			["LastAttackedBy"] = "Forgotten One",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"HEAL", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"HEAL", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"HEAL", -- [16]
				"HEAL", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"HEAL", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"HEAL", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"HEAL", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"HEAL", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"HEAL", -- [48]
				"HEAL", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					30.67, -- [1]
				},
				["Healing"] = {
					250424, -- [1]
				},
				["DamageTaken"] = {
					95942, -- [1]
				},
				["Ressed"] = {
					2, -- [1]
				},
				["HealingTaken"] = {
					251063, -- [1]
				},
				["Overhealing"] = {
					1017354, -- [1]
				},
				["TimeDamage"] = {
					291.73, -- [1]
				},
				["ActiveTime"] = {
					322.4, -- [1]
				},
				["RunicPowerGain"] = {
					550, -- [1]
				},
				["DOT_Time"] = {
					489, -- [1]
				},
				["Damage"] = {
					6838750, -- [1]
				},
			},
			["enClass"] = "DEATHKNIGHT",
			["unit"] = "Slaughtered",
			["LastAbility"] = 70545.014,
			["LastEventTimes"] = {
				503880.9, -- [1]
				503881.71, -- [2]
				503881.77, -- [3]
				503882.91, -- [4]
				503884.91, -- [5]
				503885.45, -- [6]
				503886.7, -- [7]
				503886.82, -- [8]
				503886.97, -- [9]
				503887.42, -- [10]
				503888.35, -- [11]
				503888.95, -- [12]
				503888.979, -- [13]
				503888.979, -- [14]
				503890.189, -- [15]
				503894.18, -- [16]
				503894.18, -- [17]
				503894.219, -- [18]
				503894.219, -- [19]
				503894.509, -- [20]
				503894.509, -- [21]
				503895.409, -- [22]
				503896.239, -- [23]
				503896.239, -- [24]
				503897.419, -- [25]
				503897.839, -- [26]
				503898.659, -- [27]
				503899.849, -- [28]
				503901.139, -- [29]
				503901.639, -- [30]
				503901.872, -- [31]
				503797.182, -- [32]
				503798.522, -- [33]
				503798.522, -- [34]
				503799.273, -- [35]
				503799.922, -- [36]
				503799.922, -- [37]
				503800.992, -- [38]
				503801.212, -- [39]
				503801.243, -- [40]
				503801.514, -- [41]
				503801.552, -- [42]
				503801.552, -- [43]
				503801.644, -- [44]
				503803.422, -- [45]
				503804.272, -- [46]
				503806.102, -- [47]
				503876.85, -- [48]
				503877.27, -- [49]
				503877.27, -- [50]
			},
			["level"] = 90,
			["LastDamageAbility"] = "Melee",
			["LastFightIn"] = 16,
			["LastEventNum"] = {
				[48] = 6.999941281817915,
				[7] = 8.400125265455115,
				[2] = 8.399880606363094,
				[16] = 9.800037249623271,
				[30] = 11.20007280608185,
				[45] = 8.400125265455115,
				[17] = 2.99986454682447,
				[49] = 3.000009786363681,
				[10] = 0.322216024191891,
				[38] = 4.006537290938806,
				[40] = 0.2184805691749117,
				[5] = 0.2820919331004179,
				[44] = 0.2669230693951049,
				[20] = 3.000076192411236,
			},
			["type"] = "Ungrouped",
			["FightsSaved"] = 5,
			["GuardianReverseGUIDs"] = {
				["Rune Weapon"] = {
					["LatestGuardian"] = 0,
					["GUIDs"] = {
						[0] = "0xF1306CF500003D60",
					},
				},
				["Bloodworm"] = {
					["LatestGuardian"] = 12,
					["GUIDs"] = {
						"0xF1306D7100003D74", -- [1]
						"0xF1306D7100003D79", -- [2]
						"0xF1306D7100003D7C", -- [3]
						"0xF1306D7100003D81", -- [4]
						"0xF1306D7100003E42", -- [5]
						"0xF1306D7100003E59", -- [6]
						"0xF1306D7100003E5B", -- [7]
						"0xF1306D7100003EE3", -- [8]
						"0xF1306D7100003F0E", -- [9]
						"0xF1306D7100003F1B", -- [10]
						"0xF1306D7100003F22", -- [11]
						"0xF1306D7100003F70", -- [12]
						[0] = "0xF1306D7100003D66",
					},
				},
			},
			["TimeLast"] = {
				["TimeHeal"] = 1356576089,
				["OVERALL"] = 1356576104,
				["DamageTaken"] = 1356576090,
				["Ressed"] = 1356575942,
				["TimeDamage"] = 1356576104,
				["HealingTaken"] = 1356576089,
				["Overhealing"] = 1356576104,
				["ActiveTime"] = 1356576104,
				["Healing"] = 1356576089,
				["RunicPowerGain"] = 1356576104,
				["DOT_Time"] = 1356576004,
				["Damage"] = 1356576104,
			},
			["Owner"] = false,
			["Pet"] = {
				"Rune Weapon <Slaughtered>", -- [1]
				"Bloodworm <Slaughtered>", -- [2]
			},
			["NextEventNum"] = 32,
			["LastEventHealthNum"] = {
				99.7203546578198, -- [1]
				100, -- [2]
				100, -- [3]
				99.68194318037247, -- [4]
				99.68194318037247, -- [5]
				99.39985124727205, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				99.67778397580811, -- [11]
				99.67778397580811, -- [12]
				99.67778397580811, -- [13]
				99.67778397580811, -- [14]
				99.67778397580811, -- [15]
				97.31337092158954, -- [16]
				100, -- [17]
				100, -- [18]
				100, -- [19]
				100, -- [20]
				100, -- [21]
				100, -- [22]
				100, -- [23]
				100, -- [24]
				100, -- [25]
				100, -- [26]
				100, -- [27]
				100, -- [28]
				100, -- [29]
				100, -- [30]
				100, -- [31]
				99.28388283765402, -- [32]
				99.00717340457805, -- [33]
				99.00717340457805, -- [34]
				99.00717340457805, -- [35]
				98.73364453969839, -- [36]
				98.73364453969839, -- [37]
				100, -- [38]
				100, -- [39]
				100, -- [40]
				100, -- [41]
				100, -- [42]
				100, -- [43]
				99.7330769306049, -- [44]
				100, -- [45]
				100, -- [46]
				99.75998943072723, -- [47]
				100, -- [48]
				100, -- [49]
				100, -- [50]
			},
			["LastEvents"] = {
				"Forgotten One Melee Slaughtered Miss", -- [1]
				"Slaughtered Death Strike Slaughtered Hit +34333 (33190 overheal)", -- [2]
				"Slaughtered Melee Forgotten One Hit -16208 (Physical)", -- [3]
				"Forgotten One Melee Slaughtered Miss", -- [4]
				"Forgotten One Melee Slaughtered Hit -1153 (Physical)", -- [5]
				"Slaughtered Death Grip Forgotten One Immune (Shadow)", -- [6]
				"Slaughtered Death Strike Slaughtered Hit +34334 (31881 overheal)", -- [7]
				"Slaughtered Melee Forgotten One Hit -19482 (Physical)", -- [8]
				"Slaughtered Death Strike Forgotten One Crit -127916 (Physical)", -- [9]
				"Forgotten One Melee Slaughtered Hit -1317 (Physical)", -- [10]
				"Forgotten One Melee Slaughtered Parry", -- [11]
				"Slaughtered Melee Forgotten One Hit -18173 (Physical)", -- [12]
				"Slaughtered Heart Strike Forgotten One Hit -9214 (Physical)", -- [13]
				"Slaughtered Heart Strike Forgotten One Crit -33799 (Physical)", -- [14]
				"Slaughtered Rune Strike Forgotten One Hit -28060 (Physical)", -- [15]
				"Slaughtered Death Strike Slaughtered Hit +46304", -- [16]
				"Slaughtered Unholy Strength Slaughtered Hit +14174 (1480 overheal)", -- [17]
				"Herald Volazj Melee Slaughtered Dodge", -- [18]
				"Slaughtered Death Strike Herald Volazj Hit -45628 (Physical)", -- [19]
				"Slaughtered Unholy Strength Slaughtered Hit +14175 (14175 overheal)", -- [20]
				"Slaughtered Melee Herald Volazj Hit -18404 (Physical)", -- [21]
				"Slaughtered Heart Strike Herald Volazj Hit -19517 (Physical)", -- [22]
				"Herald Volazj Melee Slaughtered Dodge", -- [23]
				"Slaughtered Rune Strike Herald Volazj Crit -55340 (Physical)", -- [24]
				"Slaughtered Heart Strike Herald Volazj Hit -18733 (Physical)", -- [25]
				"Slaughtered Melee Herald Volazj Hit -17525 (Physical)", -- [26]
				"Slaughtered Rune Strike Herald Volazj Hit -24900 (Physical)", -- [27]
				"Slaughtered Heart Strike Herald Volazj Hit -17213 (Physical)", -- [28]
				"Slaughtered Melee Herald Volazj Hit -14571 (Physical)", -- [29]
				"Slaughtered Death Strike Slaughtered Hit +52919 (52919 overheal)", -- [30]
				"Slaughtered Death Strike Herald Volazj Hit -44358 (Physical)", -- [31]
				"Savage Cave Beast Melee Slaughtered Miss", -- [32]
				"Slaughtered Blood Plague (DoT) Savage Cave Beast Crit -6953 (Shadow)", -- [33]
				"Slaughtered Frost Fever (DoT) Savage Cave Beast Tick -3346 (Frost)", -- [34]
				"Savage Cave Beast Melee Slaughtered Miss", -- [35]
				"Slaughtered Blood Plague (DoT) Savage Cave Beast Crit -8056 (Shadow)", -- [36]
				"Slaughtered Frost Fever (DoT) Savage Cave Beast Tick -3882 (Frost)", -- [37]
				"Slaughtered Lifeblood Slaughtered Hit +16376 (11200 overheal)", -- [38]
				"Slaughtered Blood Boil Savage Cave Beast Hit -11225 (Shadow)", -- [39]
				"Savage Cave Beast Melee Slaughtered Hit -893 (Physical)", -- [40]
				"Slaughtered Melee Savage Cave Beast Hit -15107 (Physical)", -- [41]
				"Slaughtered Blood Plague (DoT) Savage Cave Beast Tick -3375 (Shadow)", -- [42]
				"Slaughtered Frost Fever (DoT) Savage Cave Beast Tick -3346 (Frost)", -- [43]
				"Savage Cave Beast Uppercut Slaughtered Hit -1091 (Physical)", -- [44]
				"Slaughtered Death Strike Slaughtered Hit +34334 (31339 overheal)", -- [45]
				"Slaughtered Melee Savage Cave Beast Hit -14623 (Physical)", -- [46]
				"Slaughtered Melee Savage Cave Beast Hit -15323 (Physical)", -- [47]
				"Slaughtered Death Strike Slaughtered Hit +28611 (28611 overheal)", -- [48]
				"Slaughtered Unholy Strength Slaughtered Hit +12262 (12262 overheal)", -- [49]
				"Slaughtered Melee Forgotten One Hit -14539 (Physical)", -- [50]
			},
			["Name"] = "Slaughtered",
			["LastEventIncoming"] = {
				true, -- [1]
				true, -- [2]
				false, -- [3]
				true, -- [4]
				true, -- [5]
				false, -- [6]
				true, -- [7]
				false, -- [8]
				false, -- [9]
				true, -- [10]
				true, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				true, -- [16]
				true, -- [17]
				true, -- [18]
				false, -- [19]
				true, -- [20]
				false, -- [21]
				false, -- [22]
				true, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				true, -- [30]
				false, -- [31]
				true, -- [32]
				false, -- [33]
				false, -- [34]
				true, -- [35]
				false, -- [36]
				false, -- [37]
				true, -- [38]
				false, -- [39]
				true, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				true, -- [44]
				true, -- [45]
				false, -- [46]
				false, -- [47]
				true, -- [48]
				true, -- [49]
				false, -- [50]
			},
			["LastDamageTaken"] = 1317,
			["Fights"] = {
				["Fight3"] = {
					["DOTs"] = {
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Ahn'kahar Web Winder"] = {
									["count"] = 0,
								},
								["Ahn'kahar Slasher"] = {
									["count"] = 0,
								},
								["Savage Cave Beast"] = {
									["count"] = 9,
								},
								["Ahn'kahar Spell Flinger"] = {
									["count"] = 0,
								},
								["Plague Walker"] = {
									["count"] = 0,
								},
							},
							["amount"] = 9,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Ahn'kahar Web Winder"] = {
									["count"] = 0,
								},
								["Ahn'kahar Slasher"] = {
									["count"] = 0,
								},
								["Savage Cave Beast"] = {
									["count"] = 9,
								},
								["Ahn'kahar Spell Flinger"] = {
									["count"] = 0,
								},
								["Plague Walker"] = {
									["count"] = 0,
								},
							},
							["amount"] = 9,
						},
					},
					["Ressed"] = 0,
					["ElementDoneResist"] = {
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Frost"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 2,
								},
								["Dodge"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 1,
								},
								["Parry"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DamageTaken"] = 1984,
					["RageGainedFrom"] = {
					},
					["HOTs"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["RunicPowerGain"] = 30,
					["ElementTakenBlock"] = {
					},
					["ElementTaken"] = {
						["Melee"] = 893,
						["Physical"] = 1091,
					},
					["DOT_Time"] = 18,
					["Damage"] = 93172,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 2.94,
					["ShieldedWho"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Blood Shield"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Dispels"] = 0,
					["FDamagedWho"] = {
					},
					["HealingTaken"] = 8171,
					["FAttacks"] = {
					},
					["DamagedWho"] = {
						["Frostbringer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Savage Cave Beast"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 18384,
								},
								["Melee"] = {
									["count"] = 45053,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 10574,
								},
								["Blood Boil"] = {
									["count"] = 19161,
								},
							},
							["amount"] = 93172,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Eye of Taldaram"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Shadow"] = 37545,
						["Frost"] = 10574,
						["Melee"] = 45053,
						["Physical"] = 0,
					},
					["RunicPowerGainedFrom"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Scent of Blood"] = {
									["count"] = 30,
								},
							},
							["amount"] = 30,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
						["Scent of Blood"] = {
							["Details"] = {
								["Slaughtered"] = {
									["count"] = 30,
								},
							},
							["amount"] = 30,
						},
					},
					["WhoDamaged"] = {
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Savage Cave Beast"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 893,
								},
								["Uppercut"] = {
									["count"] = 1091,
								},
							},
							["amount"] = 1984,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Eye of Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Lifeblood"] = {
									["count"] = 1.07,
								},
								["Death Strike"] = {
									["count"] = 1.87,
								},
								["Unholy Strength"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2.94,
						},
					},
					["OverHeals"] = {
						["Lifeblood"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 11200,
									["min"] = 11200,
									["count"] = 1,
									["amount"] = 11200,
								},
							},
							["count"] = 1,
							["amount"] = 11200,
						},
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 31339,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 31339,
								},
							},
							["count"] = 1,
							["amount"] = 31339,
						},
						["Unholy Strength"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Lifeblood"] = {
									["count"] = 5176,
								},
								["Death Strike"] = {
									["count"] = 2995,
								},
								["Unholy Strength"] = {
									["count"] = 0,
								},
							},
							["amount"] = 8171,
						},
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
						["Shadowfury"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Shadow Blast"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Uppercut"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Frostbolt"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Interrupts"] = 0,
					["PartialResist"] = {
						["Shadowfury"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Shadow Blast"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Uppercut"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Frostbolt"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["ActiveTime"] = 12.79,
					["Overhealing"] = 42539,
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Lifeblood"] = {
									["count"] = 1.07,
								},
								["Death Strike"] = {
									["count"] = 1.87,
								},
								["Unholy Strength"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2.94,
						},
						["Frostbringer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Savage Cave Beast"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 3.15,
								},
								["Melee"] = {
									["count"] = 2.98,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 3.72,
								},
							},
							["amount"] = 9.85,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Eye of Taldaram"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["InterruptData"] = {
					},
					["RessedWho"] = {
					},
					["Heals"] = {
						["Lifeblood"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5176,
									["min"] = 5176,
									["count"] = 1,
									["amount"] = 5176,
								},
							},
							["count"] = 1,
							["amount"] = 5176,
						},
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2995,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 2995,
								},
							},
							["count"] = 1,
							["amount"] = 2995,
						},
						["Unholy Strength"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 0,
					},
					["EnergyGained"] = {
					},
					["HealedWho"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Lifeblood"] = {
									["count"] = 5176,
								},
								["Death Strike"] = {
									["count"] = 2995,
								},
								["Unholy Strength"] = {
									["count"] = 0,
								},
							},
							["amount"] = 8171,
						},
					},
					["Healing"] = 8171,
					["RageGained"] = {
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 5,
						},
						["Frost"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 8056,
									["min"] = 6953,
									["count"] = 2,
									["amount"] = 15009,
								},
								["Tick"] = {
									["max"] = 3375,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 3375,
								},
							},
							["count"] = 3,
							["amount"] = 18384,
						},
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 15323,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 45053,
								},
							},
							["count"] = 3,
							["amount"] = 45053,
						},
						["Death and Decay"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 3882,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 10574,
								},
							},
							["count"] = 3,
							["amount"] = 10574,
						},
						["Blood Boil"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 11225,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 19161,
								},
							},
							["count"] = 2,
							["amount"] = 19161,
						},
					},
					["RageGain"] = 0,
					["PartialBlock"] = {
					},
					["TimeDamage"] = 9.85,
					["TimeDamaging"] = {
						["Frostbringer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Savage Cave Beast"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 3.15,
								},
								["Melee"] = {
									["count"] = 2.98,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 3.72,
								},
							},
							["amount"] = 9.85,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Eye of Taldaram"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["ElementTakenResist"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight5"] = {
					["RunicPowerGainedFrom"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Scent of Blood"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
					},
					["TimeHealing"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Unholy Strength"] = {
									["count"] = 0.3,
								},
							},
							["amount"] = 0.3,
						},
					},
					["OverHeals"] = {
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 34334,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 34334,
								},
							},
							["count"] = 1,
							["amount"] = 34334,
						},
						["Unholy Strength"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 11474,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 11474,
								},
							},
							["count"] = 1,
							["amount"] = 11474,
						},
					},
					["HealedWho"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Unholy Strength"] = {
									["count"] = 787,
								},
							},
							["amount"] = 787,
						},
					},
					["WhoHealed"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Unholy Strength"] = {
									["count"] = 787,
								},
							},
							["amount"] = 787,
						},
						["Skadooch"] = {
							["Details"] = {
								["Soothing Mist"] = {
									["count"] = 0,
								},
								["Renewing Mist"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Ressed"] = 1,
					["DamageTaken"] = 787,
					["WhoDamaged"] = {
						["Frostbringer"] = {
							["Details"] = {
								["Frostbolt"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Apostle"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 787,
								},
							},
							["amount"] = 787,
						},
						["Plundering Geist"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Bonegrinder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Eye of Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["Corruption"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Shadowfury"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Shadow Shock"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Frostbolt"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Trample"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Plunder Health"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Heals"] = {
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Unholy Strength"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 787,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 787,
								},
							},
							["count"] = 1,
							["amount"] = 787,
						},
					},
					["Overhealing"] = 45808,
					["ActiveTime"] = 9.140000000000001,
					["DamagedWho"] = {
						["Spider"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Frostbringer"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Worshipper"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 16966,
								},
								["Death and Decay"] = {
									["count"] = 6147,
								},
								["Rune Strike"] = {
									["count"] = 25082,
								},
								["Death Strike"] = {
									["count"] = 49659,
								},
								["Heart Strike"] = {
									["count"] = 16235,
								},
							},
							["amount"] = 114089,
						},
						["Roach"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Apostle"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 16712,
								},
								["Rune Strike"] = {
									["count"] = 55956,
								},
								["Death and Decay"] = {
									["count"] = 9531,
								},
							},
							["amount"] = 82199,
						},
						["Twilight Darkcaster"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 21206,
								},
								["Melee"] = {
									["count"] = 18041,
								},
								["Death and Decay"] = {
									["count"] = 7683,
								},
							},
							["amount"] = 46930,
						},
						["Bonegrinder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Plundering Geist"] = {
							["Details"] = {
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Eye of Taldaram"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Deep Crawler"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 787,
						["Frost"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 243218,
					["RessedWho"] = {
						["Skadooch"] = {
							["Details"] = {
								["Mass Resurrection"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["TimeHeal"] = 0.3,
					["ShieldedWho"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Blood Shield"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Shadow"] = 23361,
						["Physical"] = 184850,
						["Melee"] = 35007,
						["Frost"] = 0,
					},
					["PartialAbsorb"] = {
						["Corruption"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Shadowfury"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Shadow Shock"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Frostbolt"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Trample"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Plunder Health"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Healing"] = 787,
					["ElementHitsTaken"] = {
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Shadow"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Miss"] = {
									["count"] = 3,
								},
								["Parry"] = {
									["count"] = 0,
								},
							},
							["amount"] = 5,
						},
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DOTs"] = {
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Bonegrinder"] = {
									["count"] = 0,
								},
								["Eye of Taldaram"] = {
									["count"] = 0,
								},
								["Spider"] = {
									["count"] = 0,
								},
								["Frostbringer"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Bonegrinder"] = {
									["count"] = 0,
								},
								["Eye of Taldaram"] = {
									["count"] = 0,
								},
								["Frostbringer"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 18041,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 35007,
								},
							},
							["count"] = 2,
							["amount"] = 35007,
						},
						["Death and Decay"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3165,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 3165,
								},
								["Hit"] = {
									["max"] = 1757,
									["min"] = 0,
									["count"] = 13,
									["amount"] = 20196,
								},
							},
							["count"] = 14,
							["amount"] = 23361,
						},
						["Icy Touch"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 55956,
									["min"] = 55956,
									["count"] = 1,
									["amount"] = 55956,
								},
								["Hit"] = {
									["max"] = 25082,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 25082,
								},
							},
							["count"] = 2,
							["amount"] = 81038,
						},
						["Blood Boil"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16780,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 54153,
								},
							},
							["count"] = 5,
							["amount"] = 54153,
						},
						["Death Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 49659,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 49659,
								},
							},
							["count"] = 1,
							["amount"] = 49659,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 787,
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 13,
								},
							},
							["amount"] = 14,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 8,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 8.840000000000002,
					["TimeDamaging"] = {
						["Spider"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Frostbringer"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Worshipper"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0.49,
								},
								["Death and Decay"] = {
									["count"] = 1.2,
								},
								["Rune Strike"] = {
									["count"] = 0.82,
								},
								["Death Strike"] = {
									["count"] = 0.32,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2.83,
						},
						["Roach"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Apostle"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 0.5,
								},
								["Rune Strike"] = {
									["count"] = 0.82,
								},
								["Death and Decay"] = {
									["count"] = 0.4,
								},
							},
							["amount"] = 1.72,
						},
						["Twilight Darkcaster"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 0.79,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 4.29,
						},
						["Bonegrinder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Plundering Geist"] = {
							["Details"] = {
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Eye of Taldaram"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Deep Crawler"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 20,
					["TimeSpent"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Unholy Strength"] = {
									["count"] = 0.3,
								},
							},
							["amount"] = 0.3,
						},
						["Spider"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Frostbringer"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Worshipper"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0.49,
								},
								["Death and Decay"] = {
									["count"] = 1.2,
								},
								["Rune Strike"] = {
									["count"] = 0.82,
								},
								["Death Strike"] = {
									["count"] = 0.32,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2.83,
						},
						["Roach"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Apostle"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 0.5,
								},
								["Rune Strike"] = {
									["count"] = 0.82,
								},
								["Death and Decay"] = {
									["count"] = 0.4,
								},
							},
							["amount"] = 1.72,
						},
						["Twilight Darkcaster"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 0.79,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 4.29,
						},
						["Bonegrinder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Plundering Geist"] = {
							["Details"] = {
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Eye of Taldaram"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Deep Crawler"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGained"] = {
						["Scent of Blood"] = {
							["Details"] = {
								["Slaughtered"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Bound Fire Elemental"] = {
									["count"] = 0,
								},
								["Ahn'kahar Web Winder"] = {
									["count"] = 0,
								},
								["Twilight Worshipper"] = {
									["count"] = 0,
								},
								["Plague Walker"] = {
									["count"] = 0,
								},
								["Bound Water Elemental"] = {
									["count"] = 0,
								},
								["Twilight Darkcaster"] = {
									["count"] = 0,
								},
								["Bound Air Elemental"] = {
									["count"] = 0,
								},
								["Ahn'kahar Spell Flinger"] = {
									["count"] = 0,
								},
								["Twilight Apostle"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Bound Fire Elemental"] = {
									["count"] = 0,
								},
								["Bound Water Elemental"] = {
									["count"] = 0,
								},
								["Twilight Darkcaster"] = {
									["count"] = 0,
								},
								["Twilight Worshipper"] = {
									["count"] = 0,
								},
								["Bound Air Elemental"] = {
									["count"] = 0,
								},
								["Twilight Apostle"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Ressed"] = 0,
					["ElementDoneResist"] = {
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Fire"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Frost"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["HOTs"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["ElementTaken"] = {
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["ShieldedWho"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Blood Shield"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Dispels"] = 0,
					["FDamagedWho"] = {
					},
					["HealingTaken"] = 0,
					["FAttacks"] = {
					},
					["DamagedWho"] = {
						["Bound Fire Elemental"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Volunteer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Initiate"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Worshipper"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Jedoga Shadowseeker"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Bound Air Elemental"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Apostle"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Bound Water Elemental"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Darkcaster"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Roach"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Black Rat"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Deep Crawler"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Frost"] = 0,
						["Shadow"] = 0,
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["RunicPowerGainedFrom"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Scent of Blood"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
						["Scent of Blood"] = {
							["Details"] = {
								["Slaughtered"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["Bound Fire Elemental"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Volunteer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Worshipper"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Bound Water Elemental"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Darkcaster"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Bound Air Elemental"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Apostle"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Lightning Shield"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Lifeblood"] = {
									["count"] = 0,
								},
								["Unholy Strength"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Lifeblood"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Unholy Strength"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Lifeblood"] = {
									["count"] = 0,
								},
								["Unholy Strength"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
						["Fireball"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Thundershock"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Shadow Blast"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Lightning Bolt"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Shadow Bolt"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Aura of Lost Hope"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Lightning Shield"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Cyclone Strike"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Fire Nova"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Corruption"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Water Bolt"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Interrupts"] = 0,
					["PartialResist"] = {
						["Fireball"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Thundershock"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Shadow Blast"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Lightning Bolt"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Shadow Bolt"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Aura of Lost Hope"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Lightning Shield"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Cyclone Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Fire Nova"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Corruption"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Water Bolt"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["ActiveTime"] = 0,
					["Overhealing"] = 0,
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["Bound Fire Elemental"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Volunteer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Roach"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Initiate"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Lifeblood"] = {
									["count"] = 0,
								},
								["Unholy Strength"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Bound Air Elemental"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Worshipper"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Apostle"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Bound Water Elemental"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Darkcaster"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Jedoga Shadowseeker"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Black Rat"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Deep Crawler"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["InterruptData"] = {
					},
					["RessedWho"] = {
						["Pawsnreflect"] = {
							["Details"] = {
								["Raise Ally"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Heals"] = {
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Lifeblood"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Unholy Strength"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["EnergyGained"] = {
					},
					["HealedWho"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Lifeblood"] = {
									["count"] = 0,
								},
								["Unholy Strength"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["RageGained"] = {
					},
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Death and Decay"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Icy Touch"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Blood Boil"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["PartialBlock"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["Bound Fire Elemental"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Volunteer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Initiate"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Worshipper"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Jedoga Shadowseeker"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Bound Air Elemental"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Apostle"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Bound Water Elemental"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Darkcaster"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Roach"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Black Rat"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Deep Crawler"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["ElementTakenResist"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight2"] = {
					["DOTs"] = {
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Frostbringer"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Frostbringer"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Ressed"] = 0,
					["ElementDoneResist"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 2,
								},
								["Dodge"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 2,
								},
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 5,
						},
						["Shadow"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 2470,
					["RageGainedFrom"] = {
					},
					["HOTs"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["RunicPowerGain"] = 40,
					["ElementTakenBlock"] = {
					},
					["ElementTaken"] = {
						["Melee"] = 2470,
					},
					["DOT_Time"] = 0,
					["Damage"] = 267391,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 4.75,
					["ShieldedWho"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Blood Shield"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Dispels"] = 0,
					["FDamagedWho"] = {
					},
					["HealingTaken"] = 3596,
					["FAttacks"] = {
					},
					["DamagedWho"] = {
						["Forgotten One"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 28060,
								},
								["Heart Strike"] = {
									["count"] = 43013,
								},
								["Death Strike"] = {
									["count"] = 127916,
								},
								["Melee"] = {
									["count"] = 68402,
								},
							},
							["amount"] = 267391,
						},
						["Spider"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Frostbringer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Eye of Taldaram"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Shadow"] = 0,
						["Physical"] = 198989,
						["Melee"] = 68402,
						["Frost"] = 0,
					},
					["RunicPowerGainedFrom"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Scent of Blood"] = {
									["count"] = 40,
								},
							},
							["amount"] = 40,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
						["Scent of Blood"] = {
							["Details"] = {
								["Slaughtered"] = {
									["count"] = 40,
								},
							},
							["amount"] = 40,
						},
					},
					["WhoDamaged"] = {
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Forgotten One"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2470,
								},
							},
							["amount"] = 2470,
						},
						["Eye of Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 4.75,
								},
								["Lifeblood"] = {
									["count"] = 0,
								},
								["Unholy Strength"] = {
									["count"] = 0,
								},
							},
							["amount"] = 4.75,
						},
					},
					["OverHeals"] = {
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 33190,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 65071,
								},
							},
							["count"] = 2,
							["amount"] = 65071,
						},
						["Unholy Strength"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 3596,
								},
								["Lifeblood"] = {
									["count"] = 0,
								},
								["Unholy Strength"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3596,
						},
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
						["Shadowfury"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Shadow Blast"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Interrupts"] = 0,
					["PartialResist"] = {
						["Shadowfury"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Shadow Blast"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["ActiveTime"] = 15.3,
					["Overhealing"] = 65071,
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 4.75,
								},
								["Lifeblood"] = {
									["count"] = 0,
								},
								["Unholy Strength"] = {
									["count"] = 0,
								},
							},
							["amount"] = 4.75,
						},
						["Forgotten One"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.66,
								},
								["Rune Strike"] = {
									["count"] = 1.21,
								},
								["Heart Strike"] = {
									["count"] = 0.03,
								},
								["Death Strike"] = {
									["count"] = 0.15,
								},
								["Death Grip"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 10.55,
						},
						["Spider"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Frostbringer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Eye of Taldaram"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["InterruptData"] = {
					},
					["RessedWho"] = {
					},
					["Heals"] = {
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2453,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 3596,
								},
							},
							["count"] = 2,
							["amount"] = 3596,
						},
						["Lifeblood"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Unholy Strength"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["EnergyGained"] = {
					},
					["HealedWho"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 3596,
								},
								["Lifeblood"] = {
									["count"] = 0,
								},
								["Unholy Strength"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3596,
						},
					},
					["Healing"] = 3596,
					["RageGained"] = {
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
								["Immune"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 1,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 4,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["Frost"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["Death Grip"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 19482,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 68402,
								},
							},
							["count"] = 4,
							["amount"] = 68402,
						},
						["Heart Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 33799,
									["min"] = 33799,
									["count"] = 1,
									["amount"] = 33799,
								},
								["Hit"] = {
									["max"] = 9214,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 9214,
								},
							},
							["count"] = 2,
							["amount"] = 43013,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 28060,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 28060,
								},
							},
							["count"] = 1,
							["amount"] = 28060,
						},
						["Death Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 127916,
									["min"] = 127916,
									["count"] = 1,
									["amount"] = 127916,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 127916,
						},
						["Blood Boil"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["PartialBlock"] = {
					},
					["TimeDamage"] = 10.55,
					["TimeDamaging"] = {
						["Forgotten One"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.66,
								},
								["Rune Strike"] = {
									["count"] = 1.21,
								},
								["Heart Strike"] = {
									["count"] = 0.03,
								},
								["Death Strike"] = {
									["count"] = 0.15,
								},
								["Death Grip"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 10.55,
						},
						["Spider"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Frostbringer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Eye of Taldaram"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["ElementTakenResist"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight4"] = {
					["DOTs"] = {
					},
					["Ressed"] = 0,
					["ElementDoneResist"] = {
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 1,
								},
								["Parry"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
						["Nature"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["HOTs"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["RunicPowerGain"] = 10,
					["ElementTakenBlock"] = {
					},
					["ElementTaken"] = {
						["Physical"] = 0,
						["Melee"] = 0,
						["Shadow"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 97966,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["ShieldedWho"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Blood Shield"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Dispels"] = 0,
					["FDamagedWho"] = {
					},
					["HealingTaken"] = 0,
					["FAttacks"] = {
					},
					["DamagedWho"] = {
						["Bonegrinder"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Swarmer"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Plague Strike"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Savage Cave Beast"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 18888,
								},
								["Rune Strike"] = {
									["count"] = 22634,
								},
								["Death Strike"] = {
									["count"] = 40472,
								},
								["Melee"] = {
									["count"] = 15972,
								},
							},
							["amount"] = 97966,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Deep Crawler"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Frost"] = 0,
						["Physical"] = 81994,
						["Melee"] = 15972,
						["Shadow"] = 0,
					},
					["RunicPowerGainedFrom"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Scent of Blood"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
						["Scent of Blood"] = {
							["Details"] = {
								["Slaughtered"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["WhoDamaged"] = {
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Web Grab"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Shadow Sickle"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Swarmer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Deep Crawler"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Unholy Strength"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 34334,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 34334,
								},
							},
							["count"] = 1,
							["amount"] = 34334,
						},
						["Unholy Strength"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Unholy Strength"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
						["Aura of Lost Hope"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Shadow Blast"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Web Grab"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Shadow Sickle"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Glutinous Poison"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Interrupts"] = 0,
					["PartialResist"] = {
						["Aura of Lost Hope"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Shadow Blast"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Web Grab"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Shadow Sickle"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Glutinous Poison"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["ActiveTime"] = 5.49,
					["Overhealing"] = 34334,
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Unholy Strength"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Plague Strike"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Savage Cave Beast"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 0.8100000000000001,
								},
								["Rune Strike"] = {
									["count"] = 1.11,
								},
								["Death Strike"] = {
									["count"] = 3.5,
								},
								["Melee"] = {
									["count"] = 0.07000000000000001,
								},
							},
							["amount"] = 5.49,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Bonegrinder"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Grip"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Swarmer"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Deep Crawler"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["InterruptData"] = {
					},
					["RessedWho"] = {
					},
					["Heals"] = {
						["Unholy Strength"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["EnergyGained"] = {
					},
					["HealedWho"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Unholy Strength"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["RageGained"] = {
					},
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Shadow"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 15972,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 15972,
								},
							},
							["count"] = 1,
							["amount"] = 15972,
						},
						["Death and Decay"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Icy Touch"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 22634,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 22634,
								},
							},
							["count"] = 1,
							["amount"] = 22634,
						},
						["Blood Boil"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 18888,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 18888,
								},
							},
							["count"] = 1,
							["amount"] = 18888,
						},
						["Plague Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 40472,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 40472,
								},
							},
							["count"] = 1,
							["amount"] = 40472,
						},
						["Death Grip"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["PartialBlock"] = {
					},
					["TimeDamage"] = 5.49,
					["TimeDamaging"] = {
						["Bonegrinder"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Grip"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Swarmer"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Plague Strike"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Savage Cave Beast"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 0.8100000000000001,
								},
								["Rune Strike"] = {
									["count"] = 1.11,
								},
								["Death Strike"] = {
									["count"] = 3.5,
								},
								["Melee"] = {
									["count"] = 0.07000000000000001,
								},
							},
							["amount"] = 5.49,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Deep Crawler"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["ElementTakenResist"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Prince Taldaram"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Prince Taldaram"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Ressed"] = 0,
					["ElementDoneResist"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2,
						},
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["HOTs"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["RunicPowerGain"] = 30,
					["ElementTakenBlock"] = {
					},
					["ElementTaken"] = {
						["Melee"] = 0,
						["Shadow"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 276189,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["ShieldedWho"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Blood Shield"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Dispels"] = 0,
					["FDamagedWho"] = {
					},
					["HealingTaken"] = 0,
					["FAttacks"] = {
					},
					["DamagedWho"] = {
						["Prince Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Plague Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spider"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Elder Nadox"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Swarmer"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Herald Volazj"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 80240,
								},
								["Heart Strike"] = {
									["count"] = 55463,
								},
								["Melee"] = {
									["count"] = 50500,
								},
								["Death Strike"] = {
									["count"] = 89986,
								},
							},
							["amount"] = 276189,
						},
					},
					["ElementDone"] = {
						["Shadow"] = 0,
						["Physical"] = 225689,
						["Melee"] = 50500,
						["Frost"] = 0,
					},
					["RunicPowerGainedFrom"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Scent of Blood"] = {
									["count"] = 30,
								},
							},
							["amount"] = 30,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
						["Scent of Blood"] = {
							["Details"] = {
								["Slaughtered"] = {
									["count"] = 30,
								},
							},
							["amount"] = 30,
						},
					},
					["WhoDamaged"] = {
						["Prince Taldaram"] = {
							["Details"] = {
								["Embrace of the Vampyr (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 52919,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 52919,
								},
							},
							["count"] = 1,
							["amount"] = 52919,
						},
						["Unholy Strength"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 14175,
									["min"] = 14175,
									["count"] = 1,
									["amount"] = 14175,
								},
							},
							["count"] = 1,
							["amount"] = 14175,
						},
					},
					["WhoHealed"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Embrace of the Vampyr (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Interrupts"] = 0,
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Embrace of the Vampyr (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["ActiveTime"] = 11.15,
					["Overhealing"] = 67094,
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Prince Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Plague Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spider"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Elder Nadox"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Swarmer"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Herald Volazj"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 1.65,
								},
								["Heart Strike"] = {
									["count"] = 3.27,
								},
								["Melee"] = {
									["count"] = 2,
								},
								["Death Strike"] = {
									["count"] = 4.23,
								},
							},
							["amount"] = 11.15,
						},
					},
					["InterruptData"] = {
					},
					["RessedWho"] = {
					},
					["Heals"] = {
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["EnergyGained"] = {
					},
					["HealedWho"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["RageGained"] = {
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 7,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Frost"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 18404,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 50500,
								},
							},
							["count"] = 3,
							["amount"] = 50500,
						},
						["Death and Decay"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Icy Touch"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 55340,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 55340,
								},
								["Hit"] = {
									["max"] = 24900,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 24900,
								},
							},
							["count"] = 2,
							["amount"] = 80240,
						},
						["Blood Boil"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 19517,
									["min"] = 17213,
									["count"] = 3,
									["amount"] = 55463,
								},
							},
							["count"] = 3,
							["amount"] = 55463,
						},
						["Plague Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 45628,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 89986,
								},
							},
							["count"] = 2,
							["amount"] = 89986,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["PartialBlock"] = {
					},
					["TimeDamage"] = 11.15,
					["TimeDamaging"] = {
						["Prince Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Plague Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spider"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Elder Nadox"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Swarmer"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Herald Volazj"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 1.65,
								},
								["Heart Strike"] = {
									["count"] = 3.27,
								},
								["Melee"] = {
									["count"] = 2,
								},
								["Death Strike"] = {
									["count"] = 4.23,
								},
							},
							["amount"] = 11.15,
						},
					},
					["ManaGain"] = 0,
					["ElementTakenResist"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["DOTs"] = {
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Prince Taldaram"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Prince Taldaram"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Ressed"] = 0,
					["ElementDoneResist"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2,
						},
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["HOTs"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["RunicPowerGain"] = 30,
					["ElementTakenBlock"] = {
					},
					["ElementTaken"] = {
						["Melee"] = 0,
						["Shadow"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 276189,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["ShieldedWho"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Blood Shield"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Dispels"] = 0,
					["FDamagedWho"] = {
					},
					["HealingTaken"] = 0,
					["FAttacks"] = {
					},
					["DamagedWho"] = {
						["Prince Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Plague Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spider"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Elder Nadox"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Swarmer"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Herald Volazj"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 80240,
								},
								["Heart Strike"] = {
									["count"] = 55463,
								},
								["Melee"] = {
									["count"] = 50500,
								},
								["Death Strike"] = {
									["count"] = 89986,
								},
							},
							["amount"] = 276189,
						},
					},
					["ElementDone"] = {
						["Shadow"] = 0,
						["Physical"] = 225689,
						["Melee"] = 50500,
						["Frost"] = 0,
					},
					["RunicPowerGainedFrom"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Scent of Blood"] = {
									["count"] = 30,
								},
							},
							["amount"] = 30,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
						["Scent of Blood"] = {
							["Details"] = {
								["Slaughtered"] = {
									["count"] = 30,
								},
							},
							["amount"] = 30,
						},
					},
					["WhoDamaged"] = {
						["Prince Taldaram"] = {
							["Details"] = {
								["Embrace of the Vampyr (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 52919,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 52919,
								},
							},
							["count"] = 1,
							["amount"] = 52919,
						},
						["Unholy Strength"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 14175,
									["min"] = 14175,
									["count"] = 1,
									["amount"] = 14175,
								},
							},
							["count"] = 1,
							["amount"] = 14175,
						},
					},
					["WhoHealed"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Embrace of the Vampyr (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Interrupts"] = 0,
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Embrace of the Vampyr (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["ActiveTime"] = 11.15,
					["Overhealing"] = 67094,
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Prince Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Plague Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spider"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Elder Nadox"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Swarmer"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Herald Volazj"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 1.65,
								},
								["Heart Strike"] = {
									["count"] = 3.27,
								},
								["Melee"] = {
									["count"] = 2,
								},
								["Death Strike"] = {
									["count"] = 4.23,
								},
							},
							["amount"] = 11.15,
						},
					},
					["InterruptData"] = {
					},
					["RessedWho"] = {
					},
					["Heals"] = {
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["EnergyGained"] = {
					},
					["HealedWho"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["RageGained"] = {
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 7,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Frost"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 18404,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 50500,
								},
							},
							["count"] = 3,
							["amount"] = 50500,
						},
						["Death and Decay"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Icy Touch"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 55340,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 55340,
								},
								["Hit"] = {
									["max"] = 24900,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 24900,
								},
							},
							["count"] = 2,
							["amount"] = 80240,
						},
						["Blood Boil"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 19517,
									["min"] = 17213,
									["count"] = 3,
									["amount"] = 55463,
								},
							},
							["count"] = 3,
							["amount"] = 55463,
						},
						["Plague Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 45628,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 89986,
								},
							},
							["count"] = 2,
							["amount"] = 89986,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["PartialBlock"] = {
					},
					["TimeDamage"] = 11.15,
					["TimeDamaging"] = {
						["Prince Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Plague Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Spider"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Elder Nadox"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Swarmer"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Herald Volazj"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 1.65,
								},
								["Heart Strike"] = {
									["count"] = 3.27,
								},
								["Melee"] = {
									["count"] = 2,
								},
								["Death Strike"] = {
									["count"] = 4.23,
								},
							},
							["amount"] = 11.15,
						},
					},
					["ManaGain"] = 0,
					["ElementTakenResist"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["DOTs"] = {
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Bound Fire Elemental"] = {
									["count"] = 9,
								},
								["Prince Taldaram"] = {
									["count"] = 6,
								},
								["Spider"] = {
									["count"] = 3,
								},
								["Frostbringer"] = {
									["count"] = 30,
								},
								["Twilight Apostle"] = {
									["count"] = 30,
								},
								["Savage Cave Beast"] = {
									["count"] = 9,
								},
								["Plague Walker"] = {
									["count"] = 3,
								},
								["Eye of Taldaram"] = {
									["count"] = 24,
								},
								["Bound Air Elemental"] = {
									["count"] = 9,
								},
								["Twilight Worshipper"] = {
									["count"] = 27,
								},
								["Bound Water Elemental"] = {
									["count"] = 9,
								},
								["Twilight Darkcaster"] = {
									["count"] = 42,
								},
								["Ahn'kahar Slasher"] = {
									["count"] = 3,
								},
								["Ahn'kahar Web Winder"] = {
									["count"] = 3,
								},
								["Ahn'kahar Spell Flinger"] = {
									["count"] = 3,
								},
								["Bonegrinder"] = {
									["count"] = 6,
								},
							},
							["amount"] = 216,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Bound Fire Elemental"] = {
									["count"] = 6,
								},
								["Prince Taldaram"] = {
									["count"] = 9,
								},
								["Frostbringer"] = {
									["count"] = 33,
								},
								["Twilight Apostle"] = {
									["count"] = 36,
								},
								["Savage Cave Beast"] = {
									["count"] = 9,
								},
								["Plague Walker"] = {
									["count"] = 9,
								},
								["Eye of Taldaram"] = {
									["count"] = 24,
								},
								["Bound Air Elemental"] = {
									["count"] = 6,
								},
								["Twilight Worshipper"] = {
									["count"] = 30,
								},
								["Bound Water Elemental"] = {
									["count"] = 9,
								},
								["Twilight Darkcaster"] = {
									["count"] = 45,
								},
								["Ahn'kahar Slasher"] = {
									["count"] = 3,
								},
								["Ahn'kahar Web Winder"] = {
									["count"] = 9,
								},
								["Ahn'kahar Spell Flinger"] = {
									["count"] = 39,
								},
								["Bonegrinder"] = {
									["count"] = 6,
								},
							},
							["amount"] = 273,
						},
					},
					["TimeSpent"] = {
						["Bound Fire Elemental"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0.85,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0.85,
								},
							},
							["amount"] = 1.7,
						},
						["Prince Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1.49,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 2.08,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 7.08,
								},
								["Icy Touch"] = {
									["count"] = 3.5,
								},
								["Plague Strike"] = {
									["count"] = 0.19,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0.07000000000000001,
								},
							},
							["amount"] = 14.41,
						},
						["Frostbringer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.04,
								},
								["Death Strike"] = {
									["count"] = 0.43,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 4.850000000000001,
								},
								["Death and Decay"] = {
									["count"] = 1.59,
								},
								["Rune Strike"] = {
									["count"] = 0.42,
								},
								["Heart Strike"] = {
									["count"] = 0.3,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0.13,
								},
								["Blood Boil"] = {
									["count"] = 0.11,
								},
							},
							["amount"] = 9.869999999999999,
						},
						["Savage Cave Beast"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 6.55,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 3.15,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0.8100000000000001,
								},
								["Rune Strike"] = {
									["count"] = 1.92,
								},
								["Death Strike"] = {
									["count"] = 3.7,
								},
								["Blood Boil"] = {
									["count"] = 3.72,
								},
							},
							["amount"] = 19.85,
						},
						["Eye of Taldaram"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 4.34,
								},
								["Death Strike"] = {
									["count"] = 0.03,
								},
								["Melee"] = {
									["count"] = 3.76,
								},
								["Death and Decay"] = {
									["count"] = 5.640000000000001,
								},
								["Rune Strike"] = {
									["count"] = 0.41,
								},
								["Heart Strike"] = {
									["count"] = 2.07,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 3.6,
								},
								["Blood Boil"] = {
									["count"] = 2.74,
								},
							},
							["amount"] = 22.59,
						},
						["Twilight Apostle"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 1.59,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0.4,
								},
								["Rune Strike"] = {
									["count"] = 0.82,
								},
								["Heart Strike"] = {
									["count"] = 0.5,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0.54,
								},
								["Blood Boil"] = {
									["count"] = 2.07,
								},
							},
							["amount"] = 5.920000000000001,
						},
						["Forgotten One"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.66,
								},
								["Rune Strike"] = {
									["count"] = 1.21,
								},
								["Heart Strike"] = {
									["count"] = 0.03,
								},
								["Death Strike"] = {
									["count"] = 0.15,
								},
								["Death Grip"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 10.55,
						},
						["Jedoga Shadowseeker"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0.37,
								},
								["Rune Strike"] = {
									["count"] = 4.1,
								},
								["Melee"] = {
									["count"] = 3.56,
								},
								["Blood Boil"] = {
									["count"] = 6.03,
								},
							},
							["amount"] = 14.06,
						},
						["Twilight Volunteer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
								["Death and Decay"] = {
									["count"] = 1.63,
								},
								["Rune Strike"] = {
									["count"] = 1.21,
								},
								["Death Strike"] = {
									["count"] = 0.33,
								},
								["Blood Boil"] = {
									["count"] = 4.319999999999999,
								},
							},
							["amount"] = 10.99,
						},
						["Plundering Geist"] = {
							["Details"] = {
								["Icy Touch"] = {
									["count"] = 1.2,
								},
								["Blood Boil"] = {
									["count"] = 5.18,
								},
								["Melee"] = {
									["count"] = 5.4,
								},
								["Death and Decay"] = {
									["count"] = 9.870000000000001,
								},
							},
							["amount"] = 21.65,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 5.54,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 10.87,
								},
								["Rune Strike"] = {
									["count"] = 3.41,
								},
								["Heart Strike"] = {
									["count"] = 1.9,
								},
								["Death Strike"] = {
									["count"] = 0.06,
								},
								["Blood Boil"] = {
									["count"] = 4.02,
								},
							},
							["amount"] = 25.8,
						},
						["Bonegrinder"] = {
							["Details"] = {
								["Death Grip"] = {
									["count"] = 3.5,
								},
								["Melee"] = {
									["count"] = 2.83,
								},
								["Death Strike"] = {
									["count"] = 0.18,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 1.43,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0.89,
								},
							},
							["amount"] = 8.83,
						},
						["Slaughtered"] = {
							["Details"] = {
								["Lifeblood"] = {
									["count"] = 5.74,
								},
								["Death Strike"] = {
									["count"] = 13.42,
								},
								["Unholy Strength"] = {
									["count"] = 11.51,
								},
							},
							["amount"] = 30.67,
						},
						["Twilight Initiate"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0.5,
								},
							},
							["amount"] = 0.5,
						},
						["Elder Nadox"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 1.83,
								},
								["Melee"] = {
									["count"] = 3.99,
								},
								["Death Strike"] = {
									["count"] = 1.21,
								},
							},
							["amount"] = 7.03,
						},
						["Bound Air Elemental"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 1.82,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 2.53,
								},
								["Death Strike"] = {
									["count"] = 0.28,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 4.63,
						},
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.15,
								},
								["Plague Strike"] = {
									["count"] = 0.37,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0.18,
								},
								["Icy Touch"] = {
									["count"] = 4.66,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 1.76,
								},
								["Blood Boil"] = {
									["count"] = 2.35,
								},
							},
							["amount"] = 11.47,
						},
						["Twilight Worshipper"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0.98,
								},
								["Death Strike"] = {
									["count"] = 1.11,
								},
								["Melee"] = {
									["count"] = 3.87,
								},
								["Death and Decay"] = {
									["count"] = 7.500000000000001,
								},
								["Heart Strike"] = {
									["count"] = 1.64,
								},
								["Rune Strike"] = {
									["count"] = 1.31,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 4.63,
								},
								["Blood Boil"] = {
									["count"] = 2.2,
								},
							},
							["amount"] = 23.24,
						},
						["Ahn'kahar Swarmer"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 7,
								},
								["Melee"] = {
									["count"] = 3.5,
								},
								["Blood Boil"] = {
									["count"] = 0.03,
								},
							},
							["amount"] = 10.53,
						},
						["Herald Volazj"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 1.65,
								},
								["Heart Strike"] = {
									["count"] = 3.27,
								},
								["Melee"] = {
									["count"] = 2,
								},
								["Death Strike"] = {
									["count"] = 4.23,
								},
							},
							["amount"] = 11.15,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Frost Fever (DoT)"] = {
									["count"] = 1.78,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0.95,
								},
								["Blood Boil"] = {
									["count"] = 1.46,
								},
							},
							["amount"] = 4.19,
						},
						["Spider"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0.03,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0.03,
						},
						["Bound Water Elemental"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0.8,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0.38,
								},
								["Blood Boil"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 4.68,
						},
						["Twilight Darkcaster"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 4.62,
								},
								["Death and Decay"] = {
									["count"] = 10.63,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0.79,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 4.85,
								},
								["Blood Boil"] = {
									["count"] = 1.68,
								},
							},
							["amount"] = 22.57,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 2.81,
								},
								["Death Strike"] = {
									["count"] = 2.6,
								},
								["Blood Boil"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 12.41,
						},
						["Roach"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Black Rat"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Deep Crawler"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4.65,
								},
								["Death and Decay"] = {
									["count"] = 3.24,
								},
								["Heart Strike"] = {
									["count"] = 0.03,
								},
								["Rune Strike"] = {
									["count"] = 0.85,
								},
								["Death Strike"] = {
									["count"] = 0.8100000000000001,
								},
								["Blood Boil"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 13.08,
						},
					},
					["HealedWho"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Lifeblood"] = {
									["count"] = 37177,
								},
								["Death Strike"] = {
									["count"] = 152495,
								},
								["Unholy Strength"] = {
									["count"] = 60752,
								},
							},
							["amount"] = 250424,
						},
					},
					["Overhealing"] = 1017354,
					["ElementTaken"] = {
						["Shadow"] = 4655,
						["Melee"] = 86600,
						["Physical"] = 2747,
						["Frost"] = 1808,
						["Nature"] = 132,
					},
					["DOT_Time"] = 489,
					["Damage"] = 6838750,
					["TimeHeal"] = 30.67,
					["ShieldedWho"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Blood Shield"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["ElementDone"] = {
						["Shadow"] = 2632754,
						["Physical"] = 2707620,
						["Melee"] = 1075048,
						["Frost"] = 423328,
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 60,
								},
								["Immune"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 39,
								},
								["Hit"] = {
									["count"] = 340,
								},
							},
							["amount"] = 441,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 12,
								},
								["Hit"] = {
									["count"] = 71,
								},
							},
							["amount"] = 83,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 9,
								},
								["Hit"] = {
									["count"] = 46,
								},
							},
							["amount"] = 55,
						},
						["Frost"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 81,
								},
								["Crit"] = {
									["count"] = 10,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 95,
						},
					},
					["WhoDamaged"] = {
						["Bound Fire Elemental"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4427,
								},
							},
							["amount"] = 4427,
						},
						["Prince Taldaram"] = {
							["Details"] = {
								["Embrace of the Vampyr (DoT)"] = {
									["count"] = 2700,
								},
								["Melee"] = {
									["count"] = 993,
								},
							},
							["amount"] = 3693,
						},
						["Frostbringer"] = {
							["Details"] = {
								["Frostbolt"] = {
									["count"] = 1808,
								},
							},
							["amount"] = 1808,
						},
						["Savage Cave Beast"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 893,
								},
								["Uppercut"] = {
									["count"] = 1091,
								},
							},
							["amount"] = 1984,
						},
						["Eye of Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3143,
								},
							},
							["amount"] = 3143,
						},
						["Plundering Geist"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2136,
								},
							},
							["amount"] = 2136,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 599,
								},
								["Shadow Sickle"] = {
									["count"] = 1955,
								},
							},
							["amount"] = 2554,
						},
						["Bonegrinder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3888,
								},
							},
							["amount"] = 3888,
						},
						["Bound Air Elemental"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3139,
								},
							},
							["amount"] = 3139,
						},
						["Twilight Worshipper"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 8623,
								},
							},
							["amount"] = 8623,
						},
						["Ahn'kahar Swarmer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 782,
								},
							},
							["amount"] = 782,
						},
						["Twilight Apostle"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 7496,
								},
								["Lightning Shield"] = {
									["count"] = 132,
								},
							},
							["amount"] = 7628,
						},
						["Twilight Volunteer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 23221,
								},
							},
							["amount"] = 23221,
						},
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5010,
								},
								["Web Grab"] = {
									["count"] = 1656,
								},
							},
							["amount"] = 6666,
						},
						["Bound Water Elemental"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 9258,
								},
							},
							["amount"] = 9258,
						},
						["Twilight Darkcaster"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2070,
								},
							},
							["amount"] = 2070,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3172,
								},
							},
							["amount"] = 3172,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3260,
								},
							},
							["amount"] = 3260,
						},
						["Forgotten One"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2470,
								},
							},
							["amount"] = 2470,
						},
						["Deep Crawler"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2020,
								},
							},
							["amount"] = 2020,
						},
					},
					["RunicPowerGained"] = {
						["Scent of Blood"] = {
							["Details"] = {
								["Slaughtered"] = {
									["count"] = 550,
								},
							},
							["amount"] = 550,
						},
					},
					["TimeHealing"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Lifeblood"] = {
									["count"] = 5.74,
								},
								["Death Strike"] = {
									["count"] = 13.42,
								},
								["Unholy Strength"] = {
									["count"] = 11.51,
								},
							},
							["amount"] = 30.67,
						},
					},
					["OverHeals"] = {
						["Lifeblood"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16793,
									["min"] = 11200,
									["count"] = 2,
									["amount"] = 27993,
								},
							},
							["count"] = 2,
							["amount"] = 27993,
						},
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 59534,
									["min"] = 16573,
									["count"] = 20,
									["amount"] = 767960,
								},
							},
							["count"] = 20,
							["amount"] = 767960,
						},
						["Unholy Strength"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 29200,
									["min"] = 29200,
									["count"] = 2,
									["amount"] = 58400,
								},
								["Hit"] = {
									["max"] = 14175,
									["min"] = 4417,
									["count"] = 14,
									["amount"] = 163001,
								},
							},
							["count"] = 16,
							["amount"] = 221401,
						},
					},
					["PartialResist"] = {
						["Corruption"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Shadowfury"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Shadow Sickle"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Frostbolt"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Glutinous Poison"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Aura of Lost Hope"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Shadow Shock"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Plunder Health"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Uppercut"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Trample"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 313,
									["amount"] = 0,
								},
							},
							["count"] = 313,
							["amount"] = 0,
						},
						["Shadow Blast"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Web Grab"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Thundershock"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Embrace of the Vampyr (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Shadow Bolt"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Cyclone Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Lightning Shield"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Fire Nova"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Lightning Bolt"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Water Bolt"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Fireball"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Cleave"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Corruption"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Shadowfury"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Shadow Sickle"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Frostbolt"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Glutinous Poison"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Aura of Lost Hope"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Shadow Shock"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Plunder Health"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Uppercut"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Trample"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 301,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1229,
									["min"] = 466,
									["count"] = 12,
									["amount"] = 7966,
								},
							},
							["count"] = 313,
							["amount"] = 7966,
						},
						["Shadow Blast"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Web Grab"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Thundershock"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Embrace of the Vampyr (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Shadow Bolt"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Cyclone Strike"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 1723,
									["min"] = 1723,
									["count"] = 1,
									["amount"] = 1723,
								},
							},
							["count"] = 1,
							["amount"] = 1723,
						},
						["Lightning Shield"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Fire Nova"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Scorch"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Lightning Bolt"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Water Bolt"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Fireball"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Cleave"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 322.4,
					["Heals"] = {
						["Lifeblood"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16327,
									["min"] = 5176,
									["count"] = 3,
									["amount"] = 37177,
								},
							},
							["count"] = 3,
							["amount"] = 37177,
						},
						["Death Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 46304,
									["min"] = 417,
									["count"] = 10,
									["amount"] = 152495,
								},
							},
							["count"] = 10,
							["amount"] = 152495,
						},
						["Unholy Strength"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 14175,
									["min"] = 131,
									["count"] = 11,
									["amount"] = 60752,
								},
							},
							["count"] = 11,
							["amount"] = 60752,
						},
					},
					["RessedWho"] = {
						["Skadooch"] = {
							["Details"] = {
								["Mass Resurrection"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Pawsnreflect"] = {
							["Details"] = {
								["Raise Ally"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Ressed"] = 2,
					["ElementTakenAbsorb"] = {
						["Melee"] = 7966,
						["Physical"] = 1723,
					},
					["Healing"] = 250424,
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 2,
								},
								["Absorb"] = {
									["count"] = 1,
								},
								["Parry"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 6,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 12,
								},
								["Miss"] = {
									["count"] = 88,
								},
								["Dodge"] = {
									["count"] = 30,
								},
								["Hit"] = {
									["count"] = 143,
								},
								["Parry"] = {
									["count"] = 40,
								},
							},
							["amount"] = 313,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
								["Miss"] = {
									["count"] = 9,
								},
							},
							["amount"] = 11,
						},
						["Fire"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 7,
								},
							},
							["amount"] = 7,
						},
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 3,
								},
								["Miss"] = {
									["count"] = 41,
								},
							},
							["amount"] = 46,
						},
						["Nature"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 1,
								},
								["Miss"] = {
									["count"] = 4,
								},
							},
							["amount"] = 11,
						},
					},
					["DamageTaken"] = 95942,
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 41358,
									["min"] = 27892,
									["count"] = 9,
									["amount"] = 311958,
								},
								["Hit"] = {
									["max"] = 19743,
									["min"] = 13575,
									["count"] = 46,
									["amount"] = 763090,
								},
							},
							["count"] = 55,
							["amount"] = 1075048,
						},
						["Death and Decay"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4068,
									["min"] = 2887,
									["count"] = 12,
									["amount"] = 41263,
								},
								["Hit"] = {
									["max"] = 2037,
									["min"] = 1401,
									["count"] = 124,
									["amount"] = 212867,
								},
							},
							["count"] = 136,
							["amount"] = 254130,
						},
						["Icy Touch"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 9186,
									["min"] = 7393,
									["count"] = 4,
									["amount"] = 32968,
								},
							},
							["count"] = 4,
							["amount"] = 32968,
						},
						["Rune Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 56365,
									["min"] = 46842,
									["count"] = 6,
									["amount"] = 321234,
								},
								["Hit"] = {
									["max"] = 30455,
									["min"] = 20911,
									["count"] = 23,
									["amount"] = 588385,
								},
							},
							["count"] = 29,
							["amount"] = 909619,
						},
						["Blood Boil"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 24669,
									["min"] = 13406,
									["count"] = 15,
									["amount"] = 273923,
								},
								["Hit"] = {
									["max"] = 12679,
									["min"] = 4650,
									["count"] = 216,
									["amount"] = 1777674,
								},
							},
							["count"] = 231,
							["amount"] = 2051597,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9078,
									["min"] = 6952,
									["count"] = 12,
									["amount"] = 92898,
								},
								["Tick"] = {
									["max"] = 4503,
									["min"] = 3375,
									["count"] = 60,
									["amount"] = 234129,
								},
							},
							["count"] = 72,
							["amount"] = 327027,
						},
						["Heart Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 33799,
									["min"] = 8162,
									["count"] = 3,
									["amount"] = 54687,
								},
								["Hit"] = {
									["max"] = 22320,
									["min"] = 4426,
									["count"] = 27,
									["amount"] = 399013,
								},
							},
							["count"] = 30,
							["amount"] = 453700,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9263,
									["min"] = 6892,
									["count"] = 10,
									["amount"] = 79524,
								},
								["Tick"] = {
									["max"] = 4496,
									["min"] = 3346,
									["count"] = 81,
									["amount"] = 310836,
								},
							},
							["count"] = 91,
							["amount"] = 390360,
						},
						["Plague Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 17188,
									["min"] = 16352,
									["count"] = 2,
									["amount"] = 33540,
								},
							},
							["count"] = 2,
							["amount"] = 33540,
						},
						["Death Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 127916,
									["min"] = 93896,
									["count"] = 3,
									["amount"] = 331640,
								},
								["Hit"] = {
									["max"] = 64954,
									["min"] = 40472,
									["count"] = 19,
									["amount"] = 979121,
								},
							},
							["count"] = 22,
							["amount"] = 1310761,
						},
						["Death Grip"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 251063,
					["WhoHealed"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Lifeblood"] = {
									["count"] = 37177,
								},
								["Death Strike"] = {
									["count"] = 152495,
								},
								["Unholy Strength"] = {
									["count"] = 60752,
								},
							},
							["amount"] = 250424,
						},
						["Skadooch"] = {
							["Details"] = {
								["Soothing Mist"] = {
									["count"] = 509,
								},
								["Renewing Mist"] = {
									["count"] = 130,
								},
							},
							["amount"] = 639,
						},
					},
					["TimeDamage"] = 291.73,
					["TimeDamaging"] = {
						["Bound Fire Elemental"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0.85,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0.85,
								},
							},
							["amount"] = 1.7,
						},
						["Prince Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1.49,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 2.08,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 7.08,
								},
								["Icy Touch"] = {
									["count"] = 3.5,
								},
								["Plague Strike"] = {
									["count"] = 0.19,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0.07000000000000001,
								},
							},
							["amount"] = 14.41,
						},
						["Frostbringer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.04,
								},
								["Death Strike"] = {
									["count"] = 0.43,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 4.850000000000001,
								},
								["Death and Decay"] = {
									["count"] = 1.59,
								},
								["Rune Strike"] = {
									["count"] = 0.42,
								},
								["Heart Strike"] = {
									["count"] = 0.3,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0.13,
								},
								["Blood Boil"] = {
									["count"] = 0.11,
								},
							},
							["amount"] = 9.869999999999999,
						},
						["Savage Cave Beast"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 6.55,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 3.15,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0.8100000000000001,
								},
								["Rune Strike"] = {
									["count"] = 1.92,
								},
								["Death Strike"] = {
									["count"] = 3.7,
								},
								["Blood Boil"] = {
									["count"] = 3.72,
								},
							},
							["amount"] = 19.85,
						},
						["Eye of Taldaram"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 4.34,
								},
								["Death Strike"] = {
									["count"] = 0.03,
								},
								["Melee"] = {
									["count"] = 3.76,
								},
								["Death and Decay"] = {
									["count"] = 5.640000000000001,
								},
								["Rune Strike"] = {
									["count"] = 0.41,
								},
								["Heart Strike"] = {
									["count"] = 2.07,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 3.6,
								},
								["Blood Boil"] = {
									["count"] = 2.74,
								},
							},
							["amount"] = 22.59,
						},
						["Twilight Apostle"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 1.59,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0.4,
								},
								["Rune Strike"] = {
									["count"] = 0.82,
								},
								["Heart Strike"] = {
									["count"] = 0.5,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0.54,
								},
								["Blood Boil"] = {
									["count"] = 2.07,
								},
							},
							["amount"] = 5.920000000000001,
						},
						["Forgotten One"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.66,
								},
								["Rune Strike"] = {
									["count"] = 1.21,
								},
								["Heart Strike"] = {
									["count"] = 0.03,
								},
								["Death Strike"] = {
									["count"] = 0.15,
								},
								["Death Grip"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 10.55,
						},
						["Jedoga Shadowseeker"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0.37,
								},
								["Rune Strike"] = {
									["count"] = 4.1,
								},
								["Melee"] = {
									["count"] = 3.56,
								},
								["Blood Boil"] = {
									["count"] = 6.03,
								},
							},
							["amount"] = 14.06,
						},
						["Plundering Geist"] = {
							["Details"] = {
								["Icy Touch"] = {
									["count"] = 1.2,
								},
								["Blood Boil"] = {
									["count"] = 5.18,
								},
								["Melee"] = {
									["count"] = 5.4,
								},
								["Death and Decay"] = {
									["count"] = 9.870000000000001,
								},
							},
							["amount"] = 21.65,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 5.54,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 10.87,
								},
								["Rune Strike"] = {
									["count"] = 3.41,
								},
								["Heart Strike"] = {
									["count"] = 1.9,
								},
								["Death Strike"] = {
									["count"] = 0.06,
								},
								["Blood Boil"] = {
									["count"] = 4.02,
								},
							},
							["amount"] = 25.8,
						},
						["Bonegrinder"] = {
							["Details"] = {
								["Death Grip"] = {
									["count"] = 3.5,
								},
								["Melee"] = {
									["count"] = 2.83,
								},
								["Death Strike"] = {
									["count"] = 0.18,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 1.43,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0.89,
								},
							},
							["amount"] = 8.83,
						},
						["Twilight Volunteer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
								["Death and Decay"] = {
									["count"] = 1.63,
								},
								["Rune Strike"] = {
									["count"] = 1.21,
								},
								["Death Strike"] = {
									["count"] = 0.33,
								},
								["Blood Boil"] = {
									["count"] = 4.319999999999999,
								},
							},
							["amount"] = 10.99,
						},
						["Twilight Initiate"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0.5,
								},
							},
							["amount"] = 0.5,
						},
						["Spider"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 0.03,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0.03,
						},
						["Bound Air Elemental"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 1.82,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 2.53,
								},
								["Death Strike"] = {
									["count"] = 0.28,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 4.63,
						},
						["Ahn'kahar Swarmer"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 7,
								},
								["Melee"] = {
									["count"] = 3.5,
								},
								["Blood Boil"] = {
									["count"] = 0.03,
								},
							},
							["amount"] = 10.53,
						},
						["Twilight Worshipper"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0.98,
								},
								["Death Strike"] = {
									["count"] = 1.11,
								},
								["Melee"] = {
									["count"] = 3.87,
								},
								["Death and Decay"] = {
									["count"] = 7.500000000000001,
								},
								["Heart Strike"] = {
									["count"] = 1.64,
								},
								["Rune Strike"] = {
									["count"] = 1.31,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 4.63,
								},
								["Blood Boil"] = {
									["count"] = 2.2,
								},
							},
							["amount"] = 23.24,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Frost Fever (DoT)"] = {
									["count"] = 1.78,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0.95,
								},
								["Blood Boil"] = {
									["count"] = 1.46,
								},
							},
							["amount"] = 4.19,
						},
						["Herald Volazj"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 1.65,
								},
								["Heart Strike"] = {
									["count"] = 3.27,
								},
								["Melee"] = {
									["count"] = 2,
								},
								["Death Strike"] = {
									["count"] = 4.23,
								},
							},
							["amount"] = 11.15,
						},
						["Elder Nadox"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 1.83,
								},
								["Melee"] = {
									["count"] = 3.99,
								},
								["Death Strike"] = {
									["count"] = 1.21,
								},
							},
							["amount"] = 7.03,
						},
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.15,
								},
								["Plague Strike"] = {
									["count"] = 0.37,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0.18,
								},
								["Icy Touch"] = {
									["count"] = 4.66,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 1.76,
								},
								["Blood Boil"] = {
									["count"] = 2.35,
								},
							},
							["amount"] = 11.47,
						},
						["Bound Water Elemental"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0.8,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0.38,
								},
								["Blood Boil"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 4.68,
						},
						["Twilight Darkcaster"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 4.62,
								},
								["Death and Decay"] = {
									["count"] = 10.63,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0.79,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 4.85,
								},
								["Blood Boil"] = {
									["count"] = 1.68,
								},
							},
							["amount"] = 22.57,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 2.81,
								},
								["Death Strike"] = {
									["count"] = 2.6,
								},
								["Blood Boil"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 12.41,
						},
						["Roach"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Black Rat"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Deep Crawler"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4.65,
								},
								["Death and Decay"] = {
									["count"] = 3.24,
								},
								["Heart Strike"] = {
									["count"] = 0.03,
								},
								["Rune Strike"] = {
									["count"] = 0.85,
								},
								["Death Strike"] = {
									["count"] = 0.8100000000000001,
								},
								["Blood Boil"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 13.08,
						},
					},
					["RunicPowerGain"] = 550,
					["RunicPowerGainedFrom"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Scent of Blood"] = {
									["count"] = 550,
								},
							},
							["amount"] = 550,
						},
					},
					["DamagedWho"] = {
						["Bound Fire Elemental"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 13316,
								},
								["Melee"] = {
									["count"] = 15839,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 8756,
								},
								["Blood Boil"] = {
									["count"] = 48413,
								},
							},
							["amount"] = 86324,
						},
						["Prince Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 71492,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 10327,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 10038,
								},
								["Icy Touch"] = {
									["count"] = 8007,
								},
								["Plague Strike"] = {
									["count"] = 16352,
								},
								["Death Strike"] = {
									["count"] = 55280,
								},
								["Blood Boil"] = {
									["count"] = 24669,
								},
							},
							["amount"] = 196165,
						},
						["Frostbringer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 80841,
								},
								["Death Strike"] = {
									["count"] = 110583,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 39600,
								},
								["Death and Decay"] = {
									["count"] = 14617,
								},
								["Rune Strike"] = {
									["count"] = 25802,
								},
								["Heart Strike"] = {
									["count"] = 56960,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 47405,
								},
								["Blood Boil"] = {
									["count"] = 84544,
								},
							},
							["amount"] = 460352,
						},
						["Savage Cave Beast"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 91841,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 18384,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 10574,
								},
								["Heart Strike"] = {
									["count"] = 18888,
								},
								["Rune Strike"] = {
									["count"] = 45211,
								},
								["Death Strike"] = {
									["count"] = 83880,
								},
								["Blood Boil"] = {
									["count"] = 19161,
								},
							},
							["amount"] = 287939,
						},
						["Eye of Taldaram"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 35865,
								},
								["Death Strike"] = {
									["count"] = 58854,
								},
								["Melee"] = {
									["count"] = 37785,
								},
								["Death and Decay"] = {
									["count"] = 12520,
								},
								["Rune Strike"] = {
									["count"] = 30455,
								},
								["Heart Strike"] = {
									["count"] = 38959,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 31415,
								},
								["Blood Boil"] = {
									["count"] = 115657,
								},
							},
							["amount"] = 361510,
						},
						["Twilight Apostle"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 47503,
								},
								["Melee"] = {
									["count"] = 18155,
								},
								["Death and Decay"] = {
									["count"] = 20811,
								},
								["Rune Strike"] = {
									["count"] = 55956,
								},
								["Heart Strike"] = {
									["count"] = 16712,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 55474,
								},
								["Blood Boil"] = {
									["count"] = 146723,
								},
							},
							["amount"] = 361334,
						},
						["Forgotten One"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 28060,
								},
								["Heart Strike"] = {
									["count"] = 43013,
								},
								["Death Strike"] = {
									["count"] = 127916,
								},
								["Melee"] = {
									["count"] = 68402,
								},
							},
							["amount"] = 267391,
						},
						["Jedoga Shadowseeker"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 55724,
								},
								["Rune Strike"] = {
									["count"] = 77987,
								},
								["Melee"] = {
									["count"] = 58474,
								},
								["Blood Boil"] = {
									["count"] = 24019,
								},
							},
							["amount"] = 216204,
						},
						["Plundering Geist"] = {
							["Details"] = {
								["Icy Touch"] = {
									["count"] = 9186,
								},
								["Blood Boil"] = {
									["count"] = 188208,
								},
								["Melee"] = {
									["count"] = 48761,
								},
								["Death and Decay"] = {
									["count"] = 76094,
								},
							},
							["amount"] = 322249,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 3955,
								},
								["Melee"] = {
									["count"] = 67749,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 61573,
								},
								["Rune Strike"] = {
									["count"] = 80067,
								},
								["Heart Strike"] = {
									["count"] = 34815,
								},
								["Death Strike"] = {
									["count"] = 53838,
								},
								["Blood Boil"] = {
									["count"] = 137876,
								},
							},
							["amount"] = 439873,
						},
						["Bonegrinder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 49702,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 7957,
								},
								["Death Strike"] = {
									["count"] = 106760,
								},
								["Rune Strike"] = {
									["count"] = 72432,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 7899,
								},
								["Blood Boil"] = {
									["count"] = 7813,
								},
							},
							["amount"] = 252563,
						},
						["Twilight Volunteer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 15064,
								},
								["Death and Decay"] = {
									["count"] = 11258,
								},
								["Rune Strike"] = {
									["count"] = 27733,
								},
								["Death Strike"] = {
									["count"] = 46192,
								},
								["Blood Boil"] = {
									["count"] = 165728,
								},
							},
							["amount"] = 265975,
						},
						["Twilight Initiate"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 96746,
								},
							},
							["amount"] = 96746,
						},
						["Spider"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 1417,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 3978,
								},
								["Blood Boil"] = {
									["count"] = 15655,
								},
							},
							["amount"] = 21050,
						},
						["Bound Air Elemental"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 13266,
								},
								["Death and Decay"] = {
									["count"] = 1877,
								},
								["Melee"] = {
									["count"] = 15493,
								},
								["Death Strike"] = {
									["count"] = 52774,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 13396,
								},
								["Blood Boil"] = {
									["count"] = 39028,
								},
							},
							["amount"] = 135834,
						},
						["Ahn'kahar Swarmer"] = {
							["Details"] = {
								["Death and Decay"] = {
									["count"] = 19689,
								},
								["Melee"] = {
									["count"] = 32085,
								},
								["Blood Boil"] = {
									["count"] = 71053,
								},
							},
							["amount"] = 122827,
						},
						["Twilight Worshipper"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 36535,
								},
								["Death Strike"] = {
									["count"] = 96822,
								},
								["Melee"] = {
									["count"] = 51613,
								},
								["Death and Decay"] = {
									["count"] = 55088,
								},
								["Heart Strike"] = {
									["count"] = 34152,
								},
								["Rune Strike"] = {
									["count"] = 107848,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 36037,
								},
								["Blood Boil"] = {
									["count"] = 226474,
								},
							},
							["amount"] = 644569,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Frost Fever (DoT)"] = {
									["count"] = 10962,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 3937,
								},
								["Blood Boil"] = {
									["count"] = 142281,
								},
							},
							["amount"] = 157180,
						},
						["Herald Volazj"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 80240,
								},
								["Heart Strike"] = {
									["count"] = 55463,
								},
								["Melee"] = {
									["count"] = 50500,
								},
								["Death Strike"] = {
									["count"] = 89986,
								},
							},
							["amount"] = 276189,
						},
						["Elder Nadox"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 101521,
								},
								["Melee"] = {
									["count"] = 43660,
								},
								["Death Strike"] = {
									["count"] = 52115,
								},
							},
							["amount"] = 197296,
						},
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 98168,
								},
								["Plague Strike"] = {
									["count"] = 17188,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 3955,
								},
								["Rune Strike"] = {
									["count"] = 79649,
								},
								["Icy Touch"] = {
									["count"] = 15775,
								},
								["Heart Strike"] = {
									["count"] = 52721,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 10972,
								},
								["Blood Boil"] = {
									["count"] = 187757,
								},
							},
							["amount"] = 466185,
						},
						["Bound Water Elemental"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 13220,
								},
								["Death and Decay"] = {
									["count"] = 3866,
								},
								["Rune Strike"] = {
									["count"] = 25084,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 22414,
								},
								["Blood Boil"] = {
									["count"] = 29038,
								},
							},
							["amount"] = 93622,
						},
						["Twilight Darkcaster"] = {
							["Details"] = {
								["Blood Plague (DoT)"] = {
									["count"] = 71274,
								},
								["Death and Decay"] = {
									["count"] = 15367,
								},
								["Melee"] = {
									["count"] = 18041,
								},
								["Heart Strike"] = {
									["count"] = 21206,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 59519,
								},
								["Blood Boil"] = {
									["count"] = 41986,
								},
							},
							["amount"] = 227393,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 16557,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 3955,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 3926,
								},
								["Heart Strike"] = {
									["count"] = 32987,
								},
								["Rune Strike"] = {
									["count"] = 48425,
								},
								["Death Strike"] = {
									["count"] = 210209,
								},
								["Blood Boil"] = {
									["count"] = 125123,
								},
							},
							["amount"] = 441182,
						},
						["Roach"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 14538,
								},
								["Death and Decay"] = {
									["count"] = 3677,
								},
							},
							["amount"] = 18215,
						},
						["Black Rat"] = {
							["Details"] = {
								["Blood Boil"] = {
									["count"] = 7136,
								},
							},
							["amount"] = 7136,
						},
						["Deep Crawler"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 124826,
								},
								["Death and Decay"] = {
									["count"] = 17849,
								},
								["Heart Strike"] = {
									["count"] = 47824,
								},
								["Rune Strike"] = {
									["count"] = 23149,
								},
								["Death Strike"] = {
									["count"] = 109828,
								},
								["Blood Boil"] = {
									["count"] = 91971,
								},
							},
							["amount"] = 415447,
						},
					},
				},
			},
			["UnitLockout"] = 1356575480,
			["LastActive"] = 1356576104,
		},
		["Prince Taldaram"] = {
			["GUID"] = "0xF130727C00003C05",
			["LastEventHealth"] = {
				"204693 (96%)", -- [1]
				"204693 (96%)", -- [2]
				"204693 (96%)", -- [3]
				"188341 (88%)", -- [4]
				"173759 (81%)", -- [5]
				"118479 (55%)", -- [6]
				"???", -- [7]
				"???", -- [8]
				"???", -- [9]
				"104768 (49%)", -- [10]
				"63262 (29%)", -- [11]
				"61286 (28%)", -- [12]
				"61286 (28%)", -- [13]
				"53986 (25%)", -- [14]
				"53986 (25%)", -- [15]
				"53986 (25%)", -- [16]
				"53986 (25%)", -- [17]
				"41103 (19%)", -- [18]
				"41103 (19%)", -- [19]
				"41103 (19%)", -- [20]
				"41103 (19%)", -- [21]
				"33797 (15%)", -- [22]
				"33797 (15%)", -- [23]
				"33797 (15%)", -- [24]
				"9128 (4%)", -- [25]
				"9128 (4%)", -- [26]
				"9128 (4%)", -- [27]
				"0 (0%)", -- [28]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"MISC", -- [28]
			},
			["TimeWindows"] = {
				["DeathCount"] = {
					1, -- [1]
				},
				["ActiveTime"] = {
					9.82, -- [1]
				},
				["TimeDamage"] = {
					9.82, -- [1]
				},
				["DOT_Time"] = {
					6, -- [1]
				},
				["DamageTaken"] = {
					219590, -- [1]
				},
				["Damage"] = {
					3693, -- [1]
				},
			},
			["enClass"] = "MOB",
			["unit"] = "party1target",
			["LastAbility"] = 70545.014,
			["level"] = -1,
			["LastDamageAbility"] = "Melee",
			["LastFightIn"] = 10,
			["LastEventNum"] = {
				3.764456981664316, -- [1]
				6.855665256229431, -- [2]
				nil, -- [3]
				7.687823225199812, -- [4]
				0.7842031029619182, -- [5]
				25.98965679360602, -- [6]
				nil, -- [7]
				nil, -- [8]
				nil, -- [9]
				0.9290079924776681, -- [10]
				1.586741889985896, -- [11]
				0.9294781382228491, -- [12]
				0.9294781382228491, -- [13]
				1.573107663375646, -- [14]
				nil, -- [15]
				0.9294781382228491, -- [16]
				1.858956276445698, -- [17]
				3.268453220498354, -- [18]
				0.9308885754583921, -- [19]
				0.9308885754583921, -- [20]
				[27] = 0.9308885754583921,
				[25] = 11.59802538787024,
				[22] = 1.573107663375646,
				[26] = 8.828866948754113,
				[23] = 0.9308885754583921,
			},
			["type"] = "Boss",
			["FightsSaved"] = 5,
			["LastEventTimes"] = {
				503584.999, -- [1]
				503586.039, -- [2]
				503586.229, -- [3]
				503586.229, -- [4]
				503587.007, -- [5]
				503587.007, -- [6]
				503590.226, -- [7]
				503591.012, -- [8]
				503591.344, -- [9]
				503591.533, -- [10]
				503592.209, -- [11]
				503593.135, -- [12]
				503593.328, -- [13]
				503594.003, -- [14]
				503594.248, -- [15]
				503594.447, -- [16]
				503594.617, -- [17]
				503595.217, -- [18]
				503595.744, -- [19]
				503595.928, -- [20]
				503596.248, -- [21]
				503597.003, -- [22]
				503597.032, -- [23]
				503597.072, -- [24]
				503597.072, -- [25]
				503597.188, -- [26]
				503597.219, -- [27]
				503597.869, -- [28]
			},
			["LastDamageTaken"] = 1980,
			["Owner"] = false,
			["TimeLast"] = {
				["DeathCount"] = 1356575800,
				["TimeDamage"] = 1356575799,
				["ActiveTime"] = 1356575799,
				["DOT_Time"] = 1356575799,
				["OVERALL"] = 1356575800,
				["DamageTaken"] = 1356575800,
				["Damage"] = 1356575799,
			},
			["NextEventNum"] = 29,
			["LastEventHealthNum"] = {
				96.23554301833569, -- [1]
				96.23554301833569, -- [2]
				96.23554301833569, -- [3]
				88.54771979313587, -- [4]
				81.69205453690644, -- [5]
				55.70239774330042, -- [6]
				0, -- [7]
				0, -- [8]
				0, -- [9]
				49.25622943112365, -- [10]
				29.74236013164081, -- [11]
				28.81335213916314, -- [12]
				28.81335213916314, -- [13]
				25.3812881993418, -- [14]
				25.3812881993418, -- [15]
				25.3812881993418, -- [16]
				25.3812881993418, -- [17]
				19.32440056417489, -- [18]
				19.32440056417489, -- [19]
				19.32440056417489, -- [20]
				19.32440056417489, -- [21]
				15.88951574988246, -- [22]
				15.88951574988246, -- [23]
				15.88951574988246, -- [24]
				4.291490362012224, -- [25]
				4.291490362012224, -- [26]
				4.291490362012224, -- [27]
				0, -- [28]
			},
			["LastEvents"] = {
				"Slaughtered Icy Touch Prince Taldaram Hit -8007 (Frost)", -- [1]
				"Slaughtered Melee Prince Taldaram Hit -14582 (Physical)", -- [2]
				"Prince Taldaram Melee Slaughtered Miss", -- [3]
				"Slaughtered Plague Strike Prince Taldaram Hit -16352 (Physical)", -- [4]
				"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1668 (Physical)", -- [5]
				"Slaughtered Death Strike Prince Taldaram Hit -55280 (Physical)", -- [6]
				"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1976 (Physical)", -- [7]
				"Slaughtered Frost Fever (DoT) Prince Taldaram Tick -3346 (Frost)", -- [8]
				"Slaughtered Melee Prince Taldaram Crit -38131 (Physical)", -- [9]
				"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1976 (Physical)", -- [10]
				"Slaughtered Blood Plague (DoT) Prince Taldaram Tick -3375 (Shadow)", -- [11]
				"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1977 (Physical)", -- [12]
				"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1977 (Physical)", -- [13]
				"Slaughtered Frost Fever (DoT) Prince Taldaram Tick -3346 (Frost)", -- [14]
				"Prince Taldaram Embrace of the Vampyr (DoT) Slaughtered Tick -1350 (Shadow)", -- [15]
				"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1977 (Physical)", -- [16]
				"Bloodworm <Slaughtered> Melee Prince Taldaram Crit -3954 (Physical)", -- [17]
				"Slaughtered Blood Plague (DoT) Prince Taldaram Crit -6952 (Shadow)", -- [18]
				"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1980 (Physical)", -- [19]
				"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1980 (Physical)", -- [20]
				"Prince Taldaram Embrace of the Vampyr (DoT) Slaughtered Tick -1350 (Shadow)", -- [21]
				"Slaughtered Frost Fever (DoT) Prince Taldaram Tick -3346 (Frost)", -- [22]
				"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1980 (Physical)", -- [23]
				"Prince Taldaram Melee Slaughtered Hit -993 (Physical)", -- [24]
				"Slaughtered Blood Boil Prince Taldaram Crit -24669 (Shadow)", -- [25]
				"Slaughtered Melee Prince Taldaram Hit -18779 (Physical)", -- [26]
				"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1980 (Physical)", -- [27]
				"Prince Taldaram dies.", -- [28]
			},
			["Name"] = "Prince Taldaram",
			["LastEventIncoming"] = {
				true, -- [1]
				true, -- [2]
				false, -- [3]
				true, -- [4]
				true, -- [5]
				true, -- [6]
				true, -- [7]
				true, -- [8]
				true, -- [9]
				true, -- [10]
				true, -- [11]
				true, -- [12]
				true, -- [13]
				true, -- [14]
				false, -- [15]
				true, -- [16]
				true, -- [17]
				true, -- [18]
				true, -- [19]
				true, -- [20]
				false, -- [21]
				true, -- [22]
				true, -- [23]
				false, -- [24]
				true, -- [25]
				true, -- [26]
				true, -- [27]
				true, -- [28]
			},
			["DeathLogs"] = {
				{
					["MessageIncoming"] = {
						true, -- [1]
						true, -- [2]
						false, -- [3]
						true, -- [4]
						true, -- [5]
						true, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						true, -- [13]
						true, -- [14]
						false, -- [15]
						true, -- [16]
						true, -- [17]
						true, -- [18]
						true, -- [19]
						true, -- [20]
						false, -- [21]
						true, -- [22]
						true, -- [23]
						false, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
					},
					["Messages"] = {
						"Slaughtered Icy Touch Prince Taldaram Hit -8007 (Frost)", -- [1]
						"Slaughtered Melee Prince Taldaram Hit -14582 (Physical)", -- [2]
						"Prince Taldaram Melee Slaughtered Miss", -- [3]
						"Slaughtered Plague Strike Prince Taldaram Hit -16352 (Physical)", -- [4]
						"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1668 (Physical)", -- [5]
						"Slaughtered Death Strike Prince Taldaram Hit -55280 (Physical)", -- [6]
						"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1976 (Physical)", -- [7]
						"Slaughtered Frost Fever (DoT) Prince Taldaram Tick -3346 (Frost)", -- [8]
						"Slaughtered Melee Prince Taldaram Crit -38131 (Physical)", -- [9]
						"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1976 (Physical)", -- [10]
						"Slaughtered Blood Plague (DoT) Prince Taldaram Tick -3375 (Shadow)", -- [11]
						"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1977 (Physical)", -- [12]
						"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1977 (Physical)", -- [13]
						"Slaughtered Frost Fever (DoT) Prince Taldaram Tick -3346 (Frost)", -- [14]
						"Prince Taldaram Embrace of the Vampyr (DoT) Slaughtered Tick -1350 (Shadow)", -- [15]
						"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1977 (Physical)", -- [16]
						"Bloodworm <Slaughtered> Melee Prince Taldaram Crit -3954 (Physical)", -- [17]
						"Slaughtered Blood Plague (DoT) Prince Taldaram Crit -6952 (Shadow)", -- [18]
						"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1980 (Physical)", -- [19]
						"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1980 (Physical)", -- [20]
						"Prince Taldaram Embrace of the Vampyr (DoT) Slaughtered Tick -1350 (Shadow)", -- [21]
						"Slaughtered Frost Fever (DoT) Prince Taldaram Tick -3346 (Frost)", -- [22]
						"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1980 (Physical)", -- [23]
						"Prince Taldaram Melee Slaughtered Hit -993 (Physical)", -- [24]
						"Slaughtered Blood Boil Prince Taldaram Crit -24669 (Shadow)", -- [25]
						"Slaughtered Melee Prince Taldaram Hit -18779 (Physical)", -- [26]
						"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1980 (Physical)", -- [27]
						"Prince Taldaram dies.", -- [28]
					},
					["DeathAt"] = 1356575802,
					["HealthNum"] = {
						96.23554301833569, -- [1]
						96.23554301833569, -- [2]
						96.23554301833569, -- [3]
						88.54771979313587, -- [4]
						81.69205453690644, -- [5]
						55.70239774330042, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						49.25622943112365, -- [10]
						29.74236013164081, -- [11]
						28.81335213916314, -- [12]
						28.81335213916314, -- [13]
						25.3812881993418, -- [14]
						25.3812881993418, -- [15]
						25.3812881993418, -- [16]
						25.3812881993418, -- [17]
						19.32440056417489, -- [18]
						19.32440056417489, -- [19]
						19.32440056417489, -- [20]
						19.32440056417489, -- [21]
						15.88951574988246, -- [22]
						15.88951574988246, -- [23]
						15.88951574988246, -- [24]
						4.291490362012224, -- [25]
						4.291490362012224, -- [26]
						4.291490362012224, -- [27]
						0, -- [28]
					},
					["MessageTimes"] = {
						-12.86999999999534, -- [1]
						-11.8300000000163, -- [2]
						-11.64000000001397, -- [3]
						-11.64000000001397, -- [4]
						-10.86200000002282, -- [5]
						-10.86200000002282, -- [6]
						-7.642999999981839, -- [7]
						-6.857000000018161, -- [8]
						-6.525000000023283, -- [9]
						-6.336000000010245, -- [10]
						-5.659999999974389, -- [11]
						-4.73399999999674, -- [12]
						-4.540999999968335, -- [13]
						-3.865999999979977, -- [14]
						-3.620999999984633, -- [15]
						-3.422000000020489, -- [16]
						-3.25199999997858, -- [17]
						-2.652000000001863, -- [18]
						-2.125, -- [19]
						-1.940999999991618, -- [20]
						-1.620999999984633, -- [21]
						-0.8659999999799766, -- [22]
						-0.8369999999995343, -- [23]
						-0.7970000000204891, -- [24]
						-0.7970000000204891, -- [25]
						-0.6809999999823049, -- [26]
						-0.6500000000232831, -- [27]
						0, -- [28]
					},
					["KilledBy"] = "Bloodworm <Slaughtered>",
					["Health"] = {
						"204693 (96%)", -- [1]
						"204693 (96%)", -- [2]
						"204693 (96%)", -- [3]
						"188341 (88%)", -- [4]
						"173759 (81%)", -- [5]
						"118479 (55%)", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"104768 (49%)", -- [10]
						"63262 (29%)", -- [11]
						"61286 (28%)", -- [12]
						"61286 (28%)", -- [13]
						"53986 (25%)", -- [14]
						"53986 (25%)", -- [15]
						"53986 (25%)", -- [16]
						"53986 (25%)", -- [17]
						"41103 (19%)", -- [18]
						"41103 (19%)", -- [19]
						"41103 (19%)", -- [20]
						"41103 (19%)", -- [21]
						"33797 (15%)", -- [22]
						"33797 (15%)", -- [23]
						"33797 (15%)", -- [24]
						"9128 (4%)", -- [25]
						"9128 (4%)", -- [26]
						"9128 (4%)", -- [27]
						"0 (0%)", -- [28]
					},
					["EventNum"] = {
						3.764456981664316, -- [1]
						6.855665256229431, -- [2]
						0, -- [3]
						7.687823225199812, -- [4]
						0.7842031029619182, -- [5]
						25.98965679360602, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0.9290079924776681, -- [10]
						1.586741889985896, -- [11]
						0.9294781382228491, -- [12]
						0.9294781382228491, -- [13]
						1.573107663375646, -- [14]
						0, -- [15]
						0.9294781382228491, -- [16]
						1.858956276445698, -- [17]
						3.268453220498354, -- [18]
						0.9308885754583921, -- [19]
						0.9308885754583921, -- [20]
						0, -- [21]
						1.573107663375646, -- [22]
						0.9308885754583921, -- [23]
						0, -- [24]
						11.59802538787024, -- [25]
						8.828866948754113, -- [26]
						0.9308885754583921, -- [27]
						0, -- [28]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"MISC", -- [28]
					},
				}, -- [1]
			},
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
						["Embrace of the Vampyr (DoT)"] = {
							["Details"] = {
								["Slaughtered"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Frost"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Shadow"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Icy Touch"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Plague Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Blood Boil"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Icy Touch"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Plague Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Blood Boil"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["ElementTaken"] = {
						["Frost"] = 0,
						["Physical"] = 0,
						["Melee"] = 0,
						["Shadow"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Embrace of the Vampyr (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Embrace of the Vampyr (DoT)"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["WhoDamaged"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 0,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 0,
								},
								["Icy Touch"] = {
									["count"] = 0,
								},
								["Plague Strike"] = {
									["count"] = 0,
								},
								["Death Strike"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Melee"] = 0,
						["Shadow"] = 0,
					},
					["TimeSpent"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Embrace of the Vampyr (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamaging"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Embrace of the Vampyr (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["Damage"] = 0,
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["ElementHitsDone"] = {
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
					},
					["DamagedWho"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["PartialAbsorb"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["ActiveTime"] = 0,
					["EnergyGained"] = {
					},
					["EnergyGain"] = 0,
					["Healing"] = 0,
					["Dispelled"] = 0,
					["RageGained"] = {
					},
					["Attacks"] = {
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["DOTs"] = {
						["Embrace of the Vampyr (DoT)"] = {
							["Details"] = {
								["Slaughtered"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
					},
					["ElementHitsTaken"] = {
						["Frost"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 4,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 12,
								},
							},
							["amount"] = 14,
						},
						["Shadow"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Tick"] = {
									["count"] = 1,
								},
							},
							["amount"] = 3,
						},
					},
					["DamageTaken"] = 219590,
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 14,
									["amount"] = 0,
								},
							},
							["count"] = 14,
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Icy Touch"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Plague Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Blood Boil"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 1,
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 14,
									["amount"] = 0,
								},
							},
							["count"] = 14,
							["amount"] = 0,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Icy Touch"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Plague Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Blood Boil"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 9.82,
					["ElementTaken"] = {
						["Frost"] = 18045,
						["Physical"] = 71632,
						["Melee"] = 94917,
						["Shadow"] = 34996,
					},
					["DOT_Time"] = 6,
					["Damage"] = 3693,
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 993,
									["min"] = 993,
									["count"] = 1,
									["amount"] = 993,
								},
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 993,
						},
						["Embrace of the Vampyr (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 1350,
									["min"] = 1350,
									["count"] = 2,
									["amount"] = 2700,
								},
							},
							["count"] = 2,
							["amount"] = 2700,
						},
					},
					["DamagedWho"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Embrace of the Vampyr (DoT)"] = {
									["count"] = 2700,
								},
								["Melee"] = {
									["count"] = 993,
								},
							},
							["amount"] = 3693,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["TimeDamage"] = 9.82,
					["WhoDamaged"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 71492,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 10327,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 10038,
								},
								["Icy Touch"] = {
									["count"] = 8007,
								},
								["Plague Strike"] = {
									["count"] = 16352,
								},
								["Death Strike"] = {
									["count"] = 55280,
								},
								["Blood Boil"] = {
									["count"] = 24669,
								},
							},
							["amount"] = 196165,
						},
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 23425,
								},
							},
							["amount"] = 23425,
						},
					},
					["ElementDone"] = {
						["Melee"] = 993,
						["Shadow"] = 2700,
					},
					["TimeSpent"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4.32,
								},
								["Embrace of the Vampyr (DoT)"] = {
									["count"] = 5.5,
								},
							},
							["amount"] = 9.82,
						},
					},
					["TimeDamaging"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4.32,
								},
								["Embrace of the Vampyr (DoT)"] = {
									["count"] = 5.5,
								},
							},
							["amount"] = 9.82,
						},
					},
				},
			},
			["UnitLockout"] = 1356575794,
			["LastActive"] = 1356575800,
		},
		["Elder Nadox"] = {
			["GUID"] = "0xF130727D00003C71",
			["LastEventHealth"] = {
				"180795 (100%)", -- [1]
				"180795 (100%)", -- [2]
				"180795 (100%)", -- [3]
				"180795 (100%)", -- [4]
				"153309 (84%)", -- [5]
				"66980 (37%)", -- [6]
				"66980 (37%)", -- [7]
				"66980 (37%)", -- [8]
				"66980 (37%)", -- [9]
				"66980 (37%)", -- [10]
				"44488 (24%)", -- [11]
				"28720 (15%)", -- [12]
				"28720 (15%)", -- [13]
				"1 (0%)", -- [14]
				"0 (0%)", -- [15]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"MISC", -- [15]
			},
			["TimeWindows"] = {
				["TimeDamage"] = {
					5.52, -- [1]
				},
				["DeathCount"] = {
					1, -- [1]
				},
				["DamageTaken"] = {
					209942, -- [1]
				},
				["ActiveTime"] = {
					5.52, -- [1]
				},
			},
			["enClass"] = "MOB",
			["unit"] = "party1target",
			["LastAbility"] = 70545.014,
			["level"] = -1,
			["LastDamageAbility"] = "Rune Strike",
			["LastFightIn"] = 4,
			["LastEventNum"] = {
				15.42741779363367, -- [1]
				1.748389059431953, -- [2]
				1.748389059431953, -- [3]
				nil, -- [4]
				15.20285406122957, -- [5]
				28.82546530600957, -- [6]
				0.8744710860366713, -- [7]
				0.8744710860366713, -- [8]
				8.721480129428358, -- [9]
				nil, -- [10]
				11.56613844409414, -- [11]
				0.8744710860366713, -- [12]
				0.8744710860366713, -- [13]
				29.38355596117149, -- [14]
			},
			["type"] = "Boss",
			["FightsSaved"] = 5,
			["LastEventTimes"] = {
				503380.655, -- [1]
				503380.965, -- [2]
				503380.965, -- [3]
				503380.965, -- [4]
				503380.965, -- [5]
				503382.175, -- [6]
				503382.265, -- [7]
				503382.265, -- [8]
				503382.665, -- [9]
				503382.985, -- [10]
				503382.985, -- [11]
				503383.555, -- [12]
				503383.785, -- [13]
				503384.185, -- [14]
				503384.585, -- [15]
			},
			["LastDamageTaken"] = 53124,
			["Owner"] = false,
			["TimeLast"] = {
				["DeathCount"] = 1356575587,
				["ActiveTime"] = 1356575585,
				["OVERALL"] = 1356575587,
				["DamageTaken"] = 1356575587,
				["TimeDamage"] = 1356575585,
			},
			["NextEventNum"] = 16,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				84.79714593877043, -- [5]
				37.04748472026328, -- [6]
				37.04748472026328, -- [7]
				37.04748472026328, -- [8]
				37.04748472026328, -- [9]
				37.04748472026328, -- [10]
				24.60687519013247, -- [11]
				15.88539506070411, -- [12]
				15.88539506070411, -- [13]
				0.0005531126413894189, -- [14]
				0, -- [15]
			},
			["LastEvents"] = {
				"Slaughtered Melee Elder Nadox Crit -27892 (Physical)", -- [1]
				"Bloodworm <Slaughtered> Melee Elder Nadox Crit -3161 (Physical)", -- [2]
				"Bloodworm <Slaughtered> Melee Elder Nadox Crit -3161 (Physical)", -- [3]
				"Elder Nadox Melee Slaughtered Parry", -- [4]
				"Slaughtered Rune Strike Elder Nadox Hit -27486 (Physical)", -- [5]
				"Slaughtered Death Strike Elder Nadox Hit -52115 (Physical)", -- [6]
				"Bloodworm <Slaughtered> Melee Elder Nadox Hit -1581 (Physical)", -- [7]
				"Bloodworm <Slaughtered> Melee Elder Nadox Hit -1581 (Physical)", -- [8]
				"Slaughtered Melee Elder Nadox Hit -15768 (Physical)", -- [9]
				"Elder Nadox Melee Slaughtered Parry", -- [10]
				"Slaughtered Rune Strike Elder Nadox Hit -20911 (Physical)", -- [11]
				"Bloodworm <Slaughtered> Melee Elder Nadox Hit -1581 (Physical)", -- [12]
				"Bloodworm <Slaughtered> Melee Elder Nadox Hit -1581 (Physical)", -- [13]
				"Slaughtered Rune Strike Elder Nadox Crit -53124 (Physical)", -- [14]
				"Elder Nadox dies.", -- [15]
			},
			["Name"] = "Elder Nadox",
			["LastEventIncoming"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
				false, -- [4]
				true, -- [5]
				true, -- [6]
				true, -- [7]
				true, -- [8]
				true, -- [9]
				false, -- [10]
				true, -- [11]
				true, -- [12]
				true, -- [13]
				true, -- [14]
				true, -- [15]
			},
			["DeathLogs"] = {
				{
					["MessageIncoming"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						false, -- [4]
						true, -- [5]
						true, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						false, -- [10]
						true, -- [11]
						true, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
					},
					["Messages"] = {
						"Slaughtered Melee Elder Nadox Crit -27892 (Physical)", -- [1]
						"Bloodworm <Slaughtered> Melee Elder Nadox Crit -3161 (Physical)", -- [2]
						"Bloodworm <Slaughtered> Melee Elder Nadox Crit -3161 (Physical)", -- [3]
						"Elder Nadox Melee Slaughtered Parry", -- [4]
						"Slaughtered Rune Strike Elder Nadox Hit -27486 (Physical)", -- [5]
						"Slaughtered Death Strike Elder Nadox Hit -52115 (Physical)", -- [6]
						"Bloodworm <Slaughtered> Melee Elder Nadox Hit -1581 (Physical)", -- [7]
						"Bloodworm <Slaughtered> Melee Elder Nadox Hit -1581 (Physical)", -- [8]
						"Slaughtered Melee Elder Nadox Hit -15768 (Physical)", -- [9]
						"Elder Nadox Melee Slaughtered Parry", -- [10]
						"Slaughtered Rune Strike Elder Nadox Hit -20911 (Physical)", -- [11]
						"Bloodworm <Slaughtered> Melee Elder Nadox Hit -1581 (Physical)", -- [12]
						"Bloodworm <Slaughtered> Melee Elder Nadox Hit -1581 (Physical)", -- [13]
						"Slaughtered Rune Strike Elder Nadox Crit -53124 (Physical)", -- [14]
						"Elder Nadox dies.", -- [15]
					},
					["DeathAt"] = 1356575589,
					["HealthNum"] = {
						100, -- [1]
						100, -- [2]
						100, -- [3]
						100, -- [4]
						84.79714593877043, -- [5]
						37.04748472026328, -- [6]
						37.04748472026328, -- [7]
						37.04748472026328, -- [8]
						37.04748472026328, -- [9]
						37.04748472026328, -- [10]
						24.60687519013247, -- [11]
						15.88539506070411, -- [12]
						15.88539506070411, -- [13]
						0.0005531126413894189, -- [14]
						0, -- [15]
					},
					["MessageTimes"] = {
						-3.929999999993015, -- [1]
						-3.619999999995343, -- [2]
						-3.619999999995343, -- [3]
						-3.619999999995343, -- [4]
						-3.619999999995343, -- [5]
						-2.410000000032596, -- [6]
						-2.320000000006985, -- [7]
						-2.320000000006985, -- [8]
						-1.919999999983702, -- [9]
						-1.600000000034925, -- [10]
						-1.600000000034925, -- [11]
						-1.03000000002794, -- [12]
						-0.7999999999883585, -- [13]
						-0.4000000000232831, -- [14]
						0, -- [15]
					},
					["KilledBy"] = "Slaughtered",
					["Health"] = {
						"180795 (100%)", -- [1]
						"180795 (100%)", -- [2]
						"180795 (100%)", -- [3]
						"180795 (100%)", -- [4]
						"153309 (84%)", -- [5]
						"66980 (37%)", -- [6]
						"66980 (37%)", -- [7]
						"66980 (37%)", -- [8]
						"66980 (37%)", -- [9]
						"66980 (37%)", -- [10]
						"44488 (24%)", -- [11]
						"28720 (15%)", -- [12]
						"28720 (15%)", -- [13]
						"1 (0%)", -- [14]
						"0 (0%)", -- [15]
					},
					["EventNum"] = {
						15.42741779363367, -- [1]
						1.748389059431953, -- [2]
						1.748389059431953, -- [3]
						0, -- [4]
						15.20285406122957, -- [5]
						28.82546530600957, -- [6]
						0.8744710860366713, -- [7]
						0.8744710860366713, -- [8]
						8.721480129428358, -- [9]
						0, -- [10]
						11.56613844409414, -- [11]
						0.8744710860366713, -- [12]
						0.8744710860366713, -- [13]
						29.38355596117149, -- [14]
						0, -- [15]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"MISC", -- [15]
					},
				}, -- [1]
			},
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["Damage"] = 0,
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["ElementHitsDone"] = {
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
					},
					["DamagedWho"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["PartialAbsorb"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["ActiveTime"] = 0,
					["EnergyGained"] = {
					},
					["EnergyGain"] = 0,
					["Healing"] = 0,
					["Dispelled"] = 0,
					["RageGained"] = {
					},
					["Attacks"] = {
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["Damage"] = 0,
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["ElementHitsDone"] = {
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
					},
					["DamagedWho"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["PartialAbsorb"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["ActiveTime"] = 0,
					["EnergyGained"] = {
					},
					["EnergyGain"] = 0,
					["Healing"] = 0,
					["Dispelled"] = 0,
					["RageGained"] = {
					},
					["Attacks"] = {
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 8,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 4,
						},
					},
					["DamageTaken"] = 209942,
					["TimeDamaging"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.52,
								},
							},
							["amount"] = 5.52,
						},
					},
					["PartialResist"] = {
						["Rune Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 1,
					["PartialAbsorb"] = {
						["Rune Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 5.52,
					["WhoDamaged"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 101521,
								},
								["Melee"] = {
									["count"] = 43660,
								},
								["Death Strike"] = {
									["count"] = 52115,
								},
							},
							["amount"] = 197296,
						},
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12646,
								},
							},
							["amount"] = 12646,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 56306,
						["Physical"] = 153636,
					},
					["TimeDamage"] = 5.52,
					["TimeSpent"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.52,
								},
							},
							["amount"] = 5.52,
						},
					},
				},
			},
			["UnitLockout"] = 1356575583,
			["LastActive"] = 1356575587,
		},
		["Rune Weapon <Slaughtered>"] = {
			["GUID"] = "0xF1306CF500003D60",
			["LastEventHealth"] = {
				"???", -- [1]
				"???", -- [2]
				"???", -- [3]
				"???", -- [4]
				"???", -- [5]
				"???", -- [6]
				"???", -- [7]
				"???", -- [8]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
			},
			["TimeWindows"] = {
				["Damage"] = {
					70250, -- [1]
				},
				["TimeDamage"] = {
					13.99, -- [1]
				},
				["ActiveTime"] = {
					13.99, -- [1]
				},
			},
			["enClass"] = "PET",
			["level"] = 1,
			["LastFightIn"] = 1,
			["type"] = "Pet",
			["FightsSaved"] = 5,
			["LastAbility"] = 70545.014,
			["Owner"] = "Slaughtered",
			["LastEventTimes"] = {
				503309.667, -- [1]
				503310.867, -- [2]
				503312.907, -- [3]
				503315.307, -- [4]
				503315.307, -- [5]
				503315.307, -- [6]
				503316.927, -- [7]
				503320.157, -- [8]
			},
			["NextEventNum"] = 9,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
				0, -- [5]
				0, -- [6]
				0, -- [7]
				0, -- [8]
			},
			["LastEvents"] = {
				"Rune Weapon <Slaughtered> Melee Plague Walker Hit -8481 (Physical)", -- [1]
				"Rune Weapon <Slaughtered> Rune Strike Plague Walker Hit -13569 (Physical)", -- [2]
				"Rune Weapon <Slaughtered> Melee Ahn'kahar Web Winder Hit -8522 (Physical)", -- [3]
				"Rune Weapon <Slaughtered> Heart Strike Deep Crawler Hit -2361 (Physical)", -- [4]
				"Rune Weapon <Slaughtered> Heart Strike Ahn'kahar Slasher Crit -9440 (Physical)", -- [5]
				"Rune Weapon <Slaughtered> Heart Strike Ahn'kahar Web Winder Hit -9441 (Physical)", -- [6]
				"Rune Weapon <Slaughtered> Melee Ahn'kahar Slasher Hit -8523 (Physical)", -- [7]
				"Rune Weapon <Slaughtered> Melee Roach Hit -9913 (Physical)", -- [8]
			},
			["Name"] = "Rune Weapon",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
			},
			["TimeLast"] = {
				["Damage"] = 1356575523,
				["OVERALL"] = 1356575523,
				["TimeDamage"] = 1356575523,
				["ActiveTime"] = 1356575523,
			},
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["Damage"] = 0,
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["ElementHitsDone"] = {
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
					},
					["DamagedWho"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["PartialAbsorb"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["ActiveTime"] = 0,
					["EnergyGained"] = {
					},
					["EnergyGain"] = 0,
					["Healing"] = 0,
					["Dispelled"] = 0,
					["RageGained"] = {
					},
					["Attacks"] = {
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["Damage"] = 0,
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["ElementHitsDone"] = {
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
					},
					["DamagedWho"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["PartialAbsorb"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["ActiveTime"] = 0,
					["EnergyGained"] = {
					},
					["EnergyGain"] = 0,
					["Healing"] = 0,
					["Dispelled"] = 0,
					["RageGained"] = {
					},
					["Attacks"] = {
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeSpent"] = {
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.04,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2.04,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1.62,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 1.62,
						},
						["Roach"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.23,
								},
							},
							["amount"] = 3.23,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
								["Rune Strike"] = {
									["count"] = 1.2,
								},
							},
							["amount"] = 4.7,
						},
						["Deep Crawler"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 2.4,
								},
							},
							["amount"] = 2.4,
						},
					},
					["ElementDone"] = {
						["Melee"] = 35439,
						["Physical"] = 34811,
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 4,
						},
					},
					["DamagedWho"] = {
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 8522,
								},
								["Heart Strike"] = {
									["count"] = 9441,
								},
							},
							["amount"] = 17963,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 8523,
								},
								["Heart Strike"] = {
									["count"] = 9440,
								},
							},
							["amount"] = 17963,
						},
						["Roach"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 9913,
								},
							},
							["amount"] = 9913,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 8481,
								},
								["Rune Strike"] = {
									["count"] = 13569,
								},
							},
							["amount"] = 22050,
						},
						["Deep Crawler"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 2361,
								},
							},
							["amount"] = 2361,
						},
					},
					["TimeDamage"] = 13.99,
					["TimeDamaging"] = {
						["Ahn'kahar Web Winder"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2.04,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2.04,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1.62,
								},
								["Heart Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 1.62,
						},
						["Roach"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.23,
								},
							},
							["amount"] = 3.23,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
								["Rune Strike"] = {
									["count"] = 1.2,
								},
							},
							["amount"] = 4.7,
						},
						["Deep Crawler"] = {
							["Details"] = {
								["Heart Strike"] = {
									["count"] = 2.4,
								},
							},
							["amount"] = 2.4,
						},
					},
					["Attacks"] = {
						["Rune Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 13569,
									["min"] = 13569,
									["count"] = 1,
									["amount"] = 13569,
								},
							},
							["count"] = 1,
							["amount"] = 13569,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 9913,
									["min"] = 8481,
									["count"] = 4,
									["amount"] = 35439,
								},
							},
							["count"] = 4,
							["amount"] = 35439,
						},
						["Heart Strike"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9440,
									["min"] = 9440,
									["count"] = 1,
									["amount"] = 9440,
								},
								["Hit"] = {
									["max"] = 9441,
									["min"] = 2361,
									["count"] = 2,
									["amount"] = 11802,
								},
							},
							["count"] = 3,
							["amount"] = 21242,
						},
					},
					["ActiveTime"] = 13.99,
					["Damage"] = 70250,
				},
			},
			["UnitLockout"] = 1356575523,
			["LastActive"] = 1356575523,
		},
		["Bloodworm <Slaughtered>"] = {
			["GUID"] = "0xF1306D7100003F70",
			["LastEventHealth"] = {
				"???", -- [1]
				"???", -- [2]
				"???", -- [3]
				"???", -- [4]
				"???", -- [5]
				"???", -- [6]
				"???", -- [7]
				"???", -- [8]
				"???", -- [9]
				"???", -- [10]
				"???", -- [11]
				"???", -- [12]
				"???", -- [13]
				"???", -- [14]
				"???", -- [15]
				"???", -- [16]
				"???", -- [17]
				"???", -- [18]
				"???", -- [19]
				"???", -- [20]
				"???", -- [21]
				"???", -- [22]
				"???", -- [23]
				"???", -- [24]
				"???", -- [25]
				"???", -- [26]
				"???", -- [27]
				"???", -- [28]
				"???", -- [29]
				"???", -- [30]
				"???", -- [31]
				"???", -- [32]
				"???", -- [33]
				"???", -- [34]
				"???", -- [35]
				"???", -- [36]
				"???", -- [37]
				"???", -- [38]
				"???", -- [39]
				"???", -- [40]
				"???", -- [41]
				"???", -- [42]
				"???", -- [43]
				"???", -- [44]
				"???", -- [45]
				"???", -- [46]
				"???", -- [47]
				"???", -- [48]
				"???", -- [49]
				"???", -- [50]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"HEAL", -- [5]
				"MISC", -- [6]
				"MISC", -- [7]
				"HEAL", -- [8]
				"HEAL", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"MISC", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"MISC", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"MISC", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"MISC", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"MISC", -- [41]
				"MISC", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					0.39, -- [1]
				},
				["Healing"] = {
					153, -- [1]
				},
				["DamageTaken"] = {
					316, -- [1]
				},
				["DeathCount"] = {
					13, -- [1]
				},
				["Overhealing"] = {
					76389, -- [1]
				},
				["ActiveTime"] = {
					104.72, -- [1]
				},
				["HealingTaken"] = {
					153, -- [1]
				},
				["TimeDamage"] = {
					104.33, -- [1]
				},
				["Damage"] = {
					124850, -- [1]
				},
			},
			["enClass"] = "PET",
			["LastDamageTaken"] = 153,
			["LastAbility"] = 70545.014,
			["LastEventTimes"] = {
				503706.295, -- [1]
				503706.975, -- [2]
				503707.585, -- [3]
				503707.787, -- [4]
				503708.175, -- [5]
				503708.175, -- [6]
				503708.175, -- [7]
				503708.605, -- [8]
				503708.605, -- [9]
				503708.665, -- [10]
				503710.635, -- [11]
				503725.085, -- [12]
				503725.914, -- [13]
				503727.504, -- [14]
				503776.243, -- [15]
				503785.493, -- [16]
				503786.673, -- [17]
				503787.853, -- [18]
				503789.053, -- [19]
				503795.992, -- [20]
				503803.552, -- [21]
				503805.352, -- [22]
				503806.442, -- [23]
				503807.572, -- [24]
				503822.562, -- [25]
				503890.189, -- [26]
				503895.22, -- [27]
				503896.509, -- [28]
				503897.839, -- [29]
				503899.109, -- [30]
				503900.399, -- [31]
				503901.709, -- [32]
				503909.499, -- [33]
				503593.328, -- [34]
				503594.447, -- [35]
				503594.617, -- [36]
				503595.744, -- [37]
				503595.928, -- [38]
				503597.032, -- [39]
				503597.219, -- [40]
				503607.136, -- [41]
				503611.958, -- [42]
				503696.106, -- [43]
				503697.336, -- [44]
				503698.575, -- [45]
				503699.795, -- [46]
				503701.095, -- [47]
				503702.399, -- [48]
				503703.687, -- [49]
				503704.995, -- [50]
			},
			["level"] = 1,
			["LastDamageAbility"] = "Cyclone Strike",
			["LastFightIn"] = 17,
			["LastFlags"] = 2600,
			["type"] = "Pet",
			["FightsSaved"] = 5,
			["LastKilledAt"] = 503708.175,
			["LastKilledBy"] = "Bloodworm <Slaughtered>",
			["Owner"] = "Slaughtered",
			["DeathLogs"] = {
				{
					["MessageTimes"] = {
						-14.27899999998044, -- [1]
						-12.98999999999069, -- [2]
						-11.65999999997439, -- [3]
						-10.39000000001397, -- [4]
						-9.099999999976717, -- [5]
						-7.789999999979045, -- [6]
						0, -- [7]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
					},
					["Messages"] = {
						"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1850 (Physical)", -- [1]
						"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1850 (Physical)", -- [2]
						"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1850 (Physical)", -- [3]
						"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1716 (Physical)", -- [4]
						"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1716 (Physical)", -- [5]
						"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1716 (Physical)", -- [6]
						"Bloodworm <Slaughtered> dies.", -- [7]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
					},
					["DeathAt"] = 1356576114,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"MISC", -- [7]
					},
				}, -- [1]
				{
					["MessageTimes"] = {
						-14.99000000004889, -- [1]
						0, -- [2]
					},
					["MessageIncoming"] = {
						false, -- [1]
						true, -- [2]
					},
					["Messages"] = {
						"Bloodworm <Slaughtered> Melee Savage Cave Beast Hit -1850 (Physical)", -- [1]
						"Bloodworm <Slaughtered> dies.", -- [2]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
					},
					["DeathAt"] = 1356576027,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"MISC", -- [2]
					},
				}, -- [2]
				{
					["MessageTimes"] = {
						-10.49900000001071, -- [1]
						-9.319000000017695, -- [2]
						-8.13900000002468, -- [3]
						-6.939000000013039, -- [4]
						0, -- [5]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						true, -- [5]
					},
					["Messages"] = {
						"Bloodworm <Slaughtered> Melee Savage Cave Beast Hit -1669 (Physical)", -- [1]
						"Bloodworm <Slaughtered> Melee Savage Cave Beast Hit -1668 (Physical)", -- [2]
						"Bloodworm <Slaughtered> Melee Savage Cave Beast Crit -3337 (Physical)", -- [3]
						"Bloodworm <Slaughtered> Melee Savage Cave Beast Hit -1669 (Physical)", -- [4]
						"Bloodworm <Slaughtered> dies.", -- [5]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
					},
					["DeathAt"] = 1356576000,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"MISC", -- [5]
					},
				}, -- [3]
				{
					["MessageIncoming"] = {
						true, -- [1]
						false, -- [2]
						true, -- [3]
					},
					["Messages"] = {
						"Jedoga Shadowseeker Thundershock Bloodworm <Slaughtered> Miss (Nature)", -- [1]
						"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -1728 (Physical)", -- [2]
						"Bloodworm <Slaughtered> dies.", -- [3]
					},
					["DeathAt"] = 1356575932,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
					},
					["MessageTimes"] = {
						-2.418999999994412, -- [1]
						-1.590000000025611, -- [2]
						0, -- [3]
					},
					["KilledBy"] = "Jedoga Shadowseeker",
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"MISC", -- [3]
					},
				}, -- [4]
				{
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						true, -- [10]
						false, -- [11]
						false, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						false, -- [16]
						true, -- [17]
						false, -- [18]
					},
					["Messages"] = {
						"Bloodworm <Slaughtered> Melee Twilight Worshipper Hit -1758 (Physical)", -- [1]
						"Bloodworm <Slaughtered> Melee Twilight Worshipper Hit -1758 (Physical)", -- [2]
						"Bloodworm <Slaughtered> Melee Twilight Worshipper Hit -1758 (Physical)", -- [3]
						"Bloodworm <Slaughtered> Melee Twilight Worshipper Hit -1908 (Physical)", -- [4]
						"Bloodworm <Slaughtered> Melee Twilight Worshipper Crit -3816 (Physical)", -- [5]
						"Bloodworm <Slaughtered> Melee Twilight Worshipper Hit -1908 (Physical)", -- [6]
						"Bloodworm <Slaughtered> Melee Twilight Worshipper Hit -1907 (Physical)", -- [7]
						"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2247 (Physical)", -- [8]
						"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2247 (Physical)", -- [9]
						"Jedoga Shadowseeker Cyclone Strike Bloodworm <Slaughtered> Hit -153 (Physical)", -- [10]
						"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2246 (Physical)", -- [11]
						"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2244 (Physical)", -- [12]
						"Bloodworm <Slaughtered> Blood Burst Bloodworm <Slaughtered> Hit +25514 (25361 overheal)", -- [13]
						"Bloodworm <Slaughtered> dies.", -- [14]
						"Bloodworm <Slaughtered> dies.", -- [15]
						"Bloodworm <Slaughtered> Blood Burst Slaughtered Hit +25514 (25514 overheal)", -- [16]
						"Bloodworm <Slaughtered> Blood Burst Bloodworm <Slaughtered> Hit +25514 (25514 overheal)", -- [17]
						"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2244 (Physical)", -- [18]
					},
					["DeathAt"] = 1356575913,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
					},
					["MessageTimes"] = {
						-12.06899999995949, -- [1]
						-10.83899999997811, -- [2]
						-9.599999999976717, -- [3]
						-8.380000000004657, -- [4]
						-7.079999999958091, -- [5]
						-5.775999999954365, -- [6]
						-4.4879999999539, -- [7]
						-3.179999999993015, -- [8]
						-1.880000000004657, -- [9]
						-1.199999999953434, -- [10]
						-0.5899999999674037, -- [11]
						-0.3879999999771826, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0.4300000000512227, -- [16]
						0.4300000000512227, -- [17]
						0.4900000000488944, -- [18]
					},
					["KilledBy"] = "Bloodworm <Slaughtered>",
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"HEAL", -- [13]
						"MISC", -- [14]
						"MISC", -- [15]
						"HEAL", -- [16]
						"HEAL", -- [17]
						"DAMAGE", -- [18]
					},
				}, -- [5]
				{
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						true, -- [10]
						false, -- [11]
						false, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						false, -- [16]
						true, -- [17]
						false, -- [18]
					},
					["Messages"] = {
						"Bloodworm <Slaughtered> Melee Twilight Worshipper Hit -1758 (Physical)", -- [1]
						"Bloodworm <Slaughtered> Melee Twilight Worshipper Hit -1758 (Physical)", -- [2]
						"Bloodworm <Slaughtered> Melee Twilight Worshipper Hit -1758 (Physical)", -- [3]
						"Bloodworm <Slaughtered> Melee Twilight Worshipper Hit -1908 (Physical)", -- [4]
						"Bloodworm <Slaughtered> Melee Twilight Worshipper Crit -3816 (Physical)", -- [5]
						"Bloodworm <Slaughtered> Melee Twilight Worshipper Hit -1908 (Physical)", -- [6]
						"Bloodworm <Slaughtered> Melee Twilight Worshipper Hit -1907 (Physical)", -- [7]
						"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2247 (Physical)", -- [8]
						"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2247 (Physical)", -- [9]
						"Jedoga Shadowseeker Cyclone Strike Bloodworm <Slaughtered> Hit -153 (Physical)", -- [10]
						"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2246 (Physical)", -- [11]
						"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2244 (Physical)", -- [12]
						"Bloodworm <Slaughtered> Blood Burst Bloodworm <Slaughtered> Hit +25514 (25361 overheal)", -- [13]
						"Bloodworm <Slaughtered> dies.", -- [14]
						"Bloodworm <Slaughtered> dies.", -- [15]
						"Bloodworm <Slaughtered> Blood Burst Slaughtered Hit +25514 (25514 overheal)", -- [16]
						"Bloodworm <Slaughtered> Blood Burst Bloodworm <Slaughtered> Hit +25514 (25514 overheal)", -- [17]
						"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2244 (Physical)", -- [18]
					},
					["DeathAt"] = 1356575913,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
					},
					["MessageTimes"] = {
						-12.06899999995949, -- [1]
						-10.83899999997811, -- [2]
						-9.599999999976717, -- [3]
						-8.380000000004657, -- [4]
						-7.079999999958091, -- [5]
						-5.775999999954365, -- [6]
						-4.4879999999539, -- [7]
						-3.179999999993015, -- [8]
						-1.880000000004657, -- [9]
						-1.199999999953434, -- [10]
						-0.5899999999674037, -- [11]
						-0.3879999999771826, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0.4300000000512227, -- [16]
						0.4300000000512227, -- [17]
						0.4900000000488944, -- [18]
					},
					["KilledBy"] = "Bloodworm <Slaughtered>",
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"HEAL", -- [13]
						"MISC", -- [14]
						"MISC", -- [15]
						"HEAL", -- [16]
						"HEAL", -- [17]
						"DAMAGE", -- [18]
					},
				}, -- [6]
				{
					["MessageTimes"] = {
						-14.92599999997765, -- [1]
						-14.7390000000014, -- [2]
						-4.821999999985565, -- [3]
						0, -- [4]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						true, -- [3]
						true, -- [4]
					},
					["Messages"] = {
						"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1980 (Physical)", -- [1]
						"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1980 (Physical)", -- [2]
						"Bloodworm <Slaughtered> dies.", -- [3]
						"Bloodworm <Slaughtered> dies.", -- [4]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
					},
					["DeathAt"] = 1356575816,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"MISC", -- [3]
						"MISC", -- [4]
					},
				}, -- [7]
				{
					["MessageTimes"] = {
						-14.00099999998929, -- [1]
						-13.80799999996088, -- [2]
						-12.68900000001304, -- [3]
						-12.51899999997113, -- [4]
						-11.39199999999255, -- [5]
						-11.20799999998417, -- [6]
						-10.10399999999208, -- [7]
						-9.917000000015833, -- [8]
						0, -- [9]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						false, -- [7]
						false, -- [8]
						true, -- [9]
					},
					["Messages"] = {
						"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1977 (Physical)", -- [1]
						"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1977 (Physical)", -- [2]
						"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1977 (Physical)", -- [3]
						"Bloodworm <Slaughtered> Melee Prince Taldaram Crit -3954 (Physical)", -- [4]
						"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1980 (Physical)", -- [5]
						"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1980 (Physical)", -- [6]
						"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1980 (Physical)", -- [7]
						"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1980 (Physical)", -- [8]
						"Bloodworm <Slaughtered> dies.", -- [9]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
					},
					["DeathAt"] = 1356575812,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"MISC", -- [9]
					},
				}, -- [8]
				{
					["MessageIncoming"] = {
						true, -- [1]
					},
					["Messages"] = {
						"Bloodworm <Slaughtered> dies.", -- [1]
					},
					["DeathAt"] = 1356575756,
					["HealthNum"] = {
						0, -- [1]
					},
					["MessageTimes"] = {
						0, -- [1]
					},
					["KilledBy"] = "Eye of Taldaram",
					["Health"] = {
						"???", -- [1]
					},
					["EventNum"] = {
						0, -- [1]
					},
					["MessageType"] = {
						"MISC", -- [1]
					},
				}, -- [9]
				{
					["MessageTimes"] = {
						-14.51900000002934, -- [1]
						-5.130000000004657, -- [2]
						-3.85999999998603, -- [3]
						-2.559999999997672, -- [4]
						-1.309999999997672, -- [5]
						-1.049999999988359, -- [6]
						0, -- [7]
					},
					["MessageIncoming"] = {
						true, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						false, -- [5]
						true, -- [6]
						true, -- [7]
					},
					["Messages"] = {
						"Bloodworm <Slaughtered> dies.", -- [1]
						"Bloodworm <Slaughtered> Melee Ahn'kahar Spell Flinger Hit -1587 (Physical)", -- [2]
						"Bloodworm <Slaughtered> Melee Ahn'kahar Spell Flinger Hit -1587 (Physical)", -- [3]
						"Bloodworm <Slaughtered> Melee Ahn'kahar Spell Flinger Hit -1587 (Physical)", -- [4]
						"Bloodworm <Slaughtered> Melee Ahn'kahar Spell Flinger Hit -1744 (Physical)", -- [5]
						"Plague Walker Aura of Lost Hope Bloodworm <Slaughtered> Miss (Shadow)", -- [6]
						"Bloodworm <Slaughtered> dies.", -- [7]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
					},
					["DeathAt"] = 1356575608,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
					},
					["MessageType"] = {
						"MISC", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"MISC", -- [7]
					},
				}, -- [10]
				{
					["MessageTimes"] = {
						-8.019999999960419, -- [1]
						-8.019999999960419, -- [2]
						-6.71999999997206, -- [3]
						-6.71999999997206, -- [4]
						-6.409999999974389, -- [5]
						-5.429999999993015, -- [6]
						-5.199999999953434, -- [7]
						0, -- [8]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						true, -- [5]
						false, -- [6]
						false, -- [7]
						true, -- [8]
					},
					["Messages"] = {
						"Bloodworm <Slaughtered> Melee Elder Nadox Crit -3161 (Physical)", -- [1]
						"Bloodworm <Slaughtered> Melee Elder Nadox Crit -3161 (Physical)", -- [2]
						"Bloodworm <Slaughtered> Melee Elder Nadox Hit -1581 (Physical)", -- [3]
						"Bloodworm <Slaughtered> Melee Elder Nadox Hit -1581 (Physical)", -- [4]
						"Bloodworm <Slaughtered> dies.", -- [5]
						"Bloodworm <Slaughtered> Melee Elder Nadox Hit -1581 (Physical)", -- [6]
						"Bloodworm <Slaughtered> Melee Elder Nadox Hit -1581 (Physical)", -- [7]
						"Bloodworm <Slaughtered> dies.", -- [8]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
					},
					["DeathAt"] = 1356575593,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"MISC", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"MISC", -- [8]
					},
				}, -- [11]
				{
					["MessageTimes"] = {
						-1.60999999998603, -- [1]
						-1.60999999998603, -- [2]
						-0.3099999999976717, -- [3]
						-0.3099999999976717, -- [4]
						0, -- [5]
						0.9799999999813736, -- [6]
						1.210000000020955, -- [7]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						false, -- [4]
						true, -- [5]
						false, -- [6]
						false, -- [7]
					},
					["Messages"] = {
						"Bloodworm <Slaughtered> Melee Elder Nadox Crit -3161 (Physical)", -- [1]
						"Bloodworm <Slaughtered> Melee Elder Nadox Crit -3161 (Physical)", -- [2]
						"Bloodworm <Slaughtered> Melee Elder Nadox Hit -1581 (Physical)", -- [3]
						"Bloodworm <Slaughtered> Melee Elder Nadox Hit -1581 (Physical)", -- [4]
						"Bloodworm <Slaughtered> dies.", -- [5]
						"Bloodworm <Slaughtered> Melee Elder Nadox Hit -1581 (Physical)", -- [6]
						"Bloodworm <Slaughtered> Melee Elder Nadox Hit -1581 (Physical)", -- [7]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
					},
					["DeathAt"] = 1356575587,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"MISC", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
					},
				}, -- [12]
				{
					["MessageTimes"] = {
						-12.88000000000466, -- [1]
						-1.619999999995343, -- [2]
						-0.3400000000256114, -- [3]
						0, -- [4]
					},
					["MessageIncoming"] = {
						true, -- [1]
						false, -- [2]
						false, -- [3]
						true, -- [4]
					},
					["Messages"] = {
						"Bloodworm <Slaughtered> dies.", -- [1]
						"Bloodworm <Slaughtered> Melee Plague Walker Hit -1870 (Physical)", -- [2]
						"Bloodworm <Slaughtered> Melee Plague Walker Hit -1869 (Physical)", -- [3]
						"Bloodworm <Slaughtered> dies.", -- [4]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
					},
					["DeathAt"] = 1356575553,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
					},
					["MessageType"] = {
						"MISC", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"MISC", -- [4]
					},
				}, -- [13]
				{
					["MessageTimes"] = {
						-13.99900000001071, -- [1]
						-12.72899999999208, -- [2]
						-8.879000000015367, -- [3]
						0, -- [4]
					},
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						false, -- [3]
						true, -- [4]
					},
					["Messages"] = {
						"Bloodworm <Slaughtered> Melee Ahn'kahar Spell Flinger Hit -1757 (Physical)", -- [1]
						"Bloodworm <Slaughtered> Melee Ahn'kahar Spell Flinger Hit -1745 (Physical)", -- [2]
						"Bloodworm <Slaughtered> Melee Ahn'kahar Spell Flinger Hit -1745 (Physical)", -- [3]
						"Bloodworm <Slaughtered> dies.", -- [4]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
					},
					["DeathAt"] = 1356575540,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"MISC", -- [4]
					},
				}, -- [14]
			},
			["NextEventNum"] = 34,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
				0, -- [5]
				0, -- [6]
				0, -- [7]
				0, -- [8]
				0, -- [9]
				0, -- [10]
				0, -- [11]
				0, -- [12]
				0, -- [13]
				0, -- [14]
				0, -- [15]
				0, -- [16]
				0, -- [17]
				0, -- [18]
				0, -- [19]
				0, -- [20]
				0, -- [21]
				0, -- [22]
				0, -- [23]
				0, -- [24]
				0, -- [25]
				0, -- [26]
				0, -- [27]
				0, -- [28]
				0, -- [29]
				0, -- [30]
				0, -- [31]
				0, -- [32]
				0, -- [33]
				0, -- [34]
				0, -- [35]
				0, -- [36]
				0, -- [37]
				0, -- [38]
				0, -- [39]
				0, -- [40]
				0, -- [41]
				0, -- [42]
				0, -- [43]
				0, -- [44]
				0, -- [45]
				0, -- [46]
				0, -- [47]
				0, -- [48]
				0, -- [49]
				0, -- [50]
			},
			["LastEvents"] = {
				"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2247 (Physical)", -- [1]
				"Jedoga Shadowseeker Cyclone Strike Bloodworm <Slaughtered> Hit -153 (Physical)", -- [2]
				"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2246 (Physical)", -- [3]
				"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2244 (Physical)", -- [4]
				"Bloodworm <Slaughtered> Blood Burst Bloodworm <Slaughtered> Hit +25514 (25361 overheal)", -- [5]
				"Bloodworm <Slaughtered> dies.", -- [6]
				"Bloodworm <Slaughtered> dies.", -- [7]
				"Bloodworm <Slaughtered> Blood Burst Slaughtered Hit +25514 (25514 overheal)", -- [8]
				"Bloodworm <Slaughtered> Blood Burst Bloodworm <Slaughtered> Hit +25514 (25514 overheal)", -- [9]
				"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2244 (Physical)", -- [10]
				"Bloodworm <Slaughtered> Melee Twilight Worshipper Crit -4512 (Physical)", -- [11]
				"Jedoga Shadowseeker Thundershock Bloodworm <Slaughtered> Miss (Nature)", -- [12]
				"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -1728 (Physical)", -- [13]
				"Bloodworm <Slaughtered> dies.", -- [14]
				"Bloodworm <Slaughtered> Melee Savage Cave Beast Hit -1668 (Physical)", -- [15]
				"Bloodworm <Slaughtered> Melee Savage Cave Beast Hit -1669 (Physical)", -- [16]
				"Bloodworm <Slaughtered> Melee Savage Cave Beast Hit -1668 (Physical)", -- [17]
				"Bloodworm <Slaughtered> Melee Savage Cave Beast Crit -3337 (Physical)", -- [18]
				"Bloodworm <Slaughtered> Melee Savage Cave Beast Hit -1669 (Physical)", -- [19]
				"Bloodworm <Slaughtered> dies.", -- [20]
				"Bloodworm <Slaughtered> Melee Savage Cave Beast Hit -1850 (Physical)", -- [21]
				"Bloodworm <Slaughtered> Melee Savage Cave Beast Crit -3700 (Physical)", -- [22]
				"Bloodworm <Slaughtered> Melee Savage Cave Beast Hit -1850 (Physical)", -- [23]
				"Bloodworm <Slaughtered> Melee Savage Cave Beast Hit -1850 (Physical)", -- [24]
				"Bloodworm <Slaughtered> dies.", -- [25]
				"Bloodworm <Slaughtered> Melee Forgotten One Hit -2038 (Physical)", -- [26]
				"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1850 (Physical)", -- [27]
				"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1850 (Physical)", -- [28]
				"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1850 (Physical)", -- [29]
				"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1716 (Physical)", -- [30]
				"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1716 (Physical)", -- [31]
				"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1716 (Physical)", -- [32]
				"Bloodworm <Slaughtered> dies.", -- [33]
				"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1977 (Physical)", -- [34]
				"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1977 (Physical)", -- [35]
				"Bloodworm <Slaughtered> Melee Prince Taldaram Crit -3954 (Physical)", -- [36]
				"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1980 (Physical)", -- [37]
				"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1980 (Physical)", -- [38]
				"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1980 (Physical)", -- [39]
				"Bloodworm <Slaughtered> Melee Prince Taldaram Hit -1980 (Physical)", -- [40]
				"Bloodworm <Slaughtered> dies.", -- [41]
				"Bloodworm <Slaughtered> dies.", -- [42]
				"Bloodworm <Slaughtered> Melee Twilight Worshipper Hit -1758 (Physical)", -- [43]
				"Bloodworm <Slaughtered> Melee Twilight Worshipper Hit -1758 (Physical)", -- [44]
				"Bloodworm <Slaughtered> Melee Twilight Worshipper Hit -1758 (Physical)", -- [45]
				"Bloodworm <Slaughtered> Melee Twilight Worshipper Hit -1908 (Physical)", -- [46]
				"Bloodworm <Slaughtered> Melee Twilight Worshipper Crit -3816 (Physical)", -- [47]
				"Bloodworm <Slaughtered> Melee Twilight Worshipper Hit -1908 (Physical)", -- [48]
				"Bloodworm <Slaughtered> Melee Twilight Worshipper Hit -1907 (Physical)", -- [49]
				"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2247 (Physical)", -- [50]
			},
			["Name"] = "Bloodworm",
			["LastEventIncoming"] = {
				false, -- [1]
				true, -- [2]
				false, -- [3]
				false, -- [4]
				true, -- [5]
				true, -- [6]
				true, -- [7]
				false, -- [8]
				true, -- [9]
				false, -- [10]
				false, -- [11]
				true, -- [12]
				false, -- [13]
				true, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				true, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				true, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				true, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				true, -- [41]
				true, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["TimeLast"] = {
				["TimeHeal"] = 1356575911,
				["OVERALL"] = 1356576112,
				["DamageTaken"] = 1356575909,
				["DeathCount"] = 1356576112,
				["Overhealing"] = 1356575911,
				["TimeDamage"] = 1356576104,
				["HealingTaken"] = 1356575911,
				["Healing"] = 1356575911,
				["ActiveTime"] = 1356576104,
				["Damage"] = 1356576104,
			},
			["Fights"] = {
				["Fight2"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 1,
					["HOT_Time"] = 0,
					["Damage"] = 2038,
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
						["Melee"] = 2038,
					},
					["DamagedWho"] = {
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Forgotten One"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2038,
								},
							},
							["amount"] = 2038,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["PartialAbsorb"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Forgotten One"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["ActiveTime"] = 3.5,
					["EnergyGained"] = {
					},
					["EnergyGain"] = 0,
					["Healing"] = 0,
					["Dispelled"] = 0,
					["RageGained"] = {
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2038,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 2038,
								},
							},
							["count"] = 1,
							["amount"] = 2038,
						},
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 3.5,
					["TimeDamaging"] = {
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Forgotten One"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["Damage"] = 0,
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
						["Physical"] = 0,
					},
					["DOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
						["Melee"] = 0,
					},
					["DamagedWho"] = {
						["Twilight Worshipper"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Jedoga Shadowseeker"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["WhoDamaged"] = {
						["Jedoga Shadowseeker"] = {
							["Details"] = {
								["Cyclone Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Blood Burst"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["Blood Burst"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Blood Burst"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["HealedWho"] = {
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Blood Burst"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["PartialAbsorb"] = {
						["Aura of Lost Hope"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Thundershock"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Cyclone Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["Aura of Lost Hope"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Thundershock"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Cyclone Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Blood Burst"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Worshipper"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Jedoga Shadowseeker"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
						["Blood Burst"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["EnergyGained"] = {
					},
					["EnergyGain"] = 0,
					["Healing"] = 0,
					["Dispelled"] = 0,
					["RageGained"] = {
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["Twilight Worshipper"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Jedoga Shadowseeker"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 1,
					["HOT_Time"] = 0,
					["Damage"] = 17593,
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
						["Shadow"] = 0,
					},
					["DOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 8,
						},
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
						["Melee"] = 17593,
					},
					["DamagedWho"] = {
						["Savage Cave Beast"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 17593,
								},
							},
							["amount"] = 17593,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Frostbringer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["WhoDamaged"] = {
						["Eye of Taldaram"] = {
							["Details"] = {
								["Shadowfury"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["PartialAbsorb"] = {
						["Shadowfury"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["Shadowfury"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Savage Cave Beast"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 14.58,
								},
							},
							["amount"] = 14.58,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Frostbringer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["ActiveTime"] = 14.58,
					["EnergyGained"] = {
					},
					["EnergyGain"] = 0,
					["Healing"] = 0,
					["Dispelled"] = 0,
					["RageGained"] = {
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3700,
									["min"] = 3337,
									["count"] = 2,
									["amount"] = 7037,
								},
								["Hit"] = {
									["max"] = 1850,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 10556,
								},
							},
							["count"] = 8,
							["amount"] = 17593,
						},
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 14.58,
					["TimeDamaging"] = {
						["Savage Cave Beast"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 14.58,
								},
							},
							["amount"] = 14.58,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Frostbringer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight4"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["Damage"] = 1668,
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
						["Melee"] = 1668,
					},
					["DamagedWho"] = {
						["Savage Cave Beast"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 1668,
								},
							},
							["amount"] = 1668,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["PartialAbsorb"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Savage Cave Beast"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["ActiveTime"] = 3.5,
					["EnergyGained"] = {
					},
					["EnergyGain"] = 0,
					["Healing"] = 0,
					["Dispelled"] = 0,
					["RageGained"] = {
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1668,
									["min"] = 1668,
									["count"] = 1,
									["amount"] = 1668,
								},
							},
							["count"] = 1,
							["amount"] = 1668,
						},
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 3.5,
					["TimeDamaging"] = {
						["Savage Cave Beast"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["Damage"] = 10698,
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
						["Melee"] = 10698,
					},
					["DamagedWho"] = {
						["Prince Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Elder Nadox"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Herald Volazj"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 10698,
								},
							},
							["amount"] = 10698,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["PartialAbsorb"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Prince Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Elder Nadox"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Herald Volazj"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 9.99,
								},
							},
							["amount"] = 9.99,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["ActiveTime"] = 9.99,
					["EnergyGained"] = {
					},
					["EnergyGain"] = 0,
					["Healing"] = 0,
					["Dispelled"] = 0,
					["RageGained"] = {
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 1850,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 10698,
								},
							},
							["count"] = 6,
							["amount"] = 10698,
						},
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 9.99,
					["TimeDamaging"] = {
						["Prince Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Elder Nadox"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Herald Volazj"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 9.99,
								},
							},
							["amount"] = 9.99,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["Damage"] = 10698,
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
						["Melee"] = 10698,
					},
					["DamagedWho"] = {
						["Prince Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Elder Nadox"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Herald Volazj"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 10698,
								},
							},
							["amount"] = 10698,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["PartialAbsorb"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Prince Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Elder Nadox"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Herald Volazj"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 9.99,
								},
							},
							["amount"] = 9.99,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["ActiveTime"] = 9.99,
					["EnergyGained"] = {
					},
					["EnergyGain"] = 0,
					["Healing"] = 0,
					["Dispelled"] = 0,
					["RageGained"] = {
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 1850,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 10698,
								},
							},
							["count"] = 6,
							["amount"] = 10698,
						},
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 9.99,
					["TimeDamaging"] = {
						["Prince Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Elder Nadox"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Herald Volazj"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 9.99,
								},
							},
							["amount"] = 9.99,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeHealing"] = {
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Blood Burst"] = {
									["count"] = 0.39,
								},
							},
							["amount"] = 0.39,
						},
					},
					["OverHeals"] = {
						["Blood Burst"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 25514,
									["min"] = 25361,
									["count"] = 3,
									["amount"] = 76389,
								},
							},
							["count"] = 3,
							["amount"] = 76389,
						},
					},
					["TimeSpent"] = {
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Blood Burst"] = {
									["count"] = 0.39,
								},
							},
							["amount"] = 0.39,
						},
						["Prince Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13.71,
								},
							},
							["amount"] = 13.71,
						},
						["Elder Nadox"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 6.32,
								},
							},
							["amount"] = 6.32,
						},
						["Frostbringer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Twilight Worshipper"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13.05,
								},
							},
							["amount"] = 13.05,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4.78,
								},
							},
							["amount"] = 4.78,
						},
						["Jedoga Shadowseeker"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 8.09,
								},
							},
							["amount"] = 8.09,
						},
						["Herald Volazj"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 9.99,
								},
							},
							["amount"] = 9.99,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 6.42,
								},
							},
							["amount"] = 6.42,
						},
						["Forgotten One"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 16.89,
								},
							},
							["amount"] = 16.89,
						},
						["Savage Cave Beast"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 18.08,
								},
							},
							["amount"] = 18.08,
						},
					},
					["DamageTaken"] = 316,
					["PartialResist"] = {
						["Aura of Lost Hope"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Shadowfury"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Cyclone Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Thundershock"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 13,
					["PartialAbsorb"] = {
						["Aura of Lost Hope"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Shadowfury"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Cyclone Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Thundershock"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 104.72,
					["ElementTaken"] = {
						["Physical"] = 153,
						["Shadow"] = 163,
					},
					["Damage"] = 124850,
					["TimeHeal"] = 0.39,
					["WhoHealed"] = {
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Blood Burst"] = {
									["count"] = 153,
								},
							},
							["amount"] = 153,
						},
					},
					["Overhealing"] = 76389,
					["HealedWho"] = {
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Blood Burst"] = {
									["count"] = 153,
								},
							},
							["amount"] = 153,
						},
					},
					["Healing"] = 153,
					["TimeDamaging"] = {
						["Prince Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13.71,
								},
							},
							["amount"] = 13.71,
						},
						["Elder Nadox"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 6.32,
								},
							},
							["amount"] = 6.32,
						},
						["Frostbringer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Twilight Worshipper"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13.05,
								},
							},
							["amount"] = 13.05,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 4.78,
								},
							},
							["amount"] = 4.78,
						},
						["Jedoga Shadowseeker"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 8.09,
								},
							},
							["amount"] = 8.09,
						},
						["Herald Volazj"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 9.99,
								},
							},
							["amount"] = 9.99,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 6.42,
								},
							},
							["amount"] = 6.42,
						},
						["Forgotten One"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 16.89,
								},
							},
							["amount"] = 16.89,
						},
						["Savage Cave Beast"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 18.08,
								},
							},
							["amount"] = 18.08,
						},
					},
					["DamagedWho"] = {
						["Prince Taldaram"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 23425,
								},
							},
							["amount"] = 23425,
						},
						["Elder Nadox"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12646,
								},
							},
							["amount"] = 12646,
						},
						["Frostbringer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2010,
								},
							},
							["amount"] = 2010,
						},
						["Twilight Worshipper"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 19325,
								},
							},
							["amount"] = 19325,
						},
						["Plague Walker"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3739,
								},
							},
							["amount"] = 3739,
						},
						["Jedoga Shadowseeker"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12956,
								},
							},
							["amount"] = 12956,
						},
						["Herald Volazj"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 10698,
								},
							},
							["amount"] = 10698,
						},
						["Ahn'kahar Slasher"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5243,
								},
							},
							["amount"] = 5243,
						},
						["Forgotten One"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2038,
								},
							},
							["amount"] = 2038,
						},
						["Ahn'kahar Spell Flinger"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13509,
								},
							},
							["amount"] = 13509,
						},
						["Savage Cave Beast"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 19261,
								},
							},
							["amount"] = 19261,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4512,
									["min"] = 3161,
									["count"] = 7,
									["amount"] = 25641,
								},
								["Hit"] = {
									["max"] = 2247,
									["min"] = 1581,
									["count"] = 54,
									["amount"] = 99209,
								},
							},
							["count"] = 61,
							["amount"] = 124850,
						},
					},
					["HealingTaken"] = 153,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 7,
								},
								["Hit"] = {
									["count"] = 54,
								},
							},
							["amount"] = 61,
						},
					},
					["TimeDamage"] = 104.33,
					["WhoDamaged"] = {
						["Jedoga Shadowseeker"] = {
							["Details"] = {
								["Cyclone Strike"] = {
									["count"] = 153,
								},
							},
							["amount"] = 153,
						},
						["Eye of Taldaram"] = {
							["Details"] = {
								["Shadowfury"] = {
									["count"] = 163,
								},
							},
							["amount"] = 163,
						},
					},
					["ElementDone"] = {
						["Melee"] = 124850,
					},
					["Heals"] = {
						["Blood Burst"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 153,
									["min"] = 153,
									["count"] = 1,
									["amount"] = 153,
								},
							},
							["count"] = 1,
							["amount"] = 153,
						},
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
								["Miss"] = {
									["count"] = 2,
								},
							},
							["amount"] = 3,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Nature"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
				},
			},
			["UnitLockout"] = 1356576112,
			["LastActive"] = 1356576104,
		},
		["Herald Volazj"] = {
			["GUID"] = "0xF130727F00003C8C",
			["LastEventHealth"] = {
				"265875 (100%)", -- [1]
				"220247 (82%)", -- [2]
				"220247 (82%)", -- [3]
				"201843 (75%)", -- [4]
				"182326 (68%)", -- [5]
				"180476 (67%)", -- [6]
				"125136 (47%)", -- [7]
				"125136 (47%)", -- [8]
				"104553 (39%)", -- [9]
				"104553 (39%)", -- [10]
				"104553 (39%)", -- [11]
				"60278 (22%)", -- [12]
				"60278 (22%)", -- [13]
				"41349 (15%)", -- [14]
				"41349 (15%)", -- [15]
				"39633 (14%)", -- [16]
				"39633 (14%)", -- [17]
				"1 (0%)", -- [18]
				"???", -- [19]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"MISC", -- [19]
			},
			["TimeWindows"] = {
				["TimeDamage"] = {
					5.52, -- [1]
				},
				["DeathCount"] = {
					1, -- [1]
				},
				["DamageTaken"] = {
					286887, -- [1]
				},
				["ActiveTime"] = {
					5.52, -- [1]
				},
			},
			["enClass"] = "MOB",
			["LastDamageTaken"] = 44358,
			["level"] = -1,
			["LastDamageAbility"] = "Death Strike",
			["LastFightIn"] = 16,
			["LastEventNum"] = {
				nil, -- [1]
				17.16144804889516, -- [2]
				6.922049835448989, -- [3]
				0.6958157028678891, -- [4]
				7.340667606958157, -- [5]
				nil, -- [6]
				20.8142924306535, -- [7]
				0.6958157028678891, -- [8]
				7.04579219558063, -- [9]
				0.6958157028678891, -- [10]
				6.591443347437706, -- [11]
				9.365303244005641, -- [12]
				0.6454160789844852, -- [13]
				6.474094969440527, -- [14]
				0.6454160789844852, -- [15]
				5.480394922425952, -- [16]
				0.6454160789844852, -- [17]
				16.68377997179126, -- [18]
			},
			["type"] = "Boss",
			["FightsSaved"] = 1,
			["LastAbility"] = 70545.014,
			["LastEventTimes"] = {
				503894.219, -- [1]
				503894.219, -- [2]
				503894.509, -- [3]
				503895.22, -- [4]
				503895.409, -- [5]
				503896.239, -- [6]
				503896.239, -- [7]
				503896.509, -- [8]
				503897.419, -- [9]
				503897.839, -- [10]
				503897.839, -- [11]
				503898.659, -- [12]
				503899.109, -- [13]
				503899.849, -- [14]
				503900.399, -- [15]
				503901.139, -- [16]
				503901.709, -- [17]
				503901.872, -- [18]
				503902.259, -- [19]
			},
			["Owner"] = false,
			["DeathLogs"] = {
				{
					["MessageIncoming"] = {
						false, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						true, -- [16]
						true, -- [17]
						true, -- [18]
						true, -- [19]
					},
					["Messages"] = {
						"Herald Volazj Melee Slaughtered Dodge", -- [1]
						"Slaughtered Death Strike Herald Volazj Hit -45628 (Physical)", -- [2]
						"Slaughtered Melee Herald Volazj Hit -18404 (Physical)", -- [3]
						"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1850 (Physical)", -- [4]
						"Slaughtered Heart Strike Herald Volazj Hit -19517 (Physical)", -- [5]
						"Herald Volazj Melee Slaughtered Dodge", -- [6]
						"Slaughtered Rune Strike Herald Volazj Crit -55340 (Physical)", -- [7]
						"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1850 (Physical)", -- [8]
						"Slaughtered Heart Strike Herald Volazj Hit -18733 (Physical)", -- [9]
						"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1850 (Physical)", -- [10]
						"Slaughtered Melee Herald Volazj Hit -17525 (Physical)", -- [11]
						"Slaughtered Rune Strike Herald Volazj Hit -24900 (Physical)", -- [12]
						"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1716 (Physical)", -- [13]
						"Slaughtered Heart Strike Herald Volazj Hit -17213 (Physical)", -- [14]
						"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1716 (Physical)", -- [15]
						"Slaughtered Melee Herald Volazj Hit -14571 (Physical)", -- [16]
						"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1716 (Physical)", -- [17]
						"Slaughtered Death Strike Herald Volazj Hit -44358 (Physical)", -- [18]
						"Herald Volazj dies.", -- [19]
					},
					["DeathAt"] = 1356576107,
					["HealthNum"] = {
						100, -- [1]
						82.83855195110485, -- [2]
						82.83855195110485, -- [3]
						75.91650211565586, -- [4]
						68.5758345086977, -- [5]
						67.88001880582981, -- [6]
						47.0657263751763, -- [7]
						47.0657263751763, -- [8]
						39.32411847672778, -- [9]
						39.32411847672778, -- [10]
						39.32411847672778, -- [11]
						22.67155618241655, -- [12]
						22.67155618241655, -- [13]
						15.55204513399154, -- [14]
						15.55204513399154, -- [15]
						14.90662905500705, -- [16]
						14.90662905500705, -- [17]
						0.0003761165961448049, -- [18]
						0, -- [19]
					},
					["MessageTimes"] = {
						-8.040000000037253, -- [1]
						-8.040000000037253, -- [2]
						-7.75, -- [3]
						-7.038999999989756, -- [4]
						-6.850000000034925, -- [5]
						-6.020000000018627, -- [6]
						-6.020000000018627, -- [7]
						-5.75, -- [8]
						-4.840000000025611, -- [9]
						-4.419999999983702, -- [10]
						-4.419999999983702, -- [11]
						-3.600000000034925, -- [12]
						-3.150000000023283, -- [13]
						-2.410000000032596, -- [14]
						-1.85999999998603, -- [15]
						-1.119999999995343, -- [16]
						-0.5499999999883585, -- [17]
						-0.3869999999878928, -- [18]
						0, -- [19]
					},
					["KilledBy"] = "Slaughtered",
					["Health"] = {
						"265875 (100%)", -- [1]
						"220247 (82%)", -- [2]
						"220247 (82%)", -- [3]
						"201843 (75%)", -- [4]
						"182326 (68%)", -- [5]
						"180476 (67%)", -- [6]
						"125136 (47%)", -- [7]
						"125136 (47%)", -- [8]
						"104553 (39%)", -- [9]
						"104553 (39%)", -- [10]
						"104553 (39%)", -- [11]
						"60278 (22%)", -- [12]
						"60278 (22%)", -- [13]
						"41349 (15%)", -- [14]
						"41349 (15%)", -- [15]
						"39633 (14%)", -- [16]
						"39633 (14%)", -- [17]
						"1 (0%)", -- [18]
						"???", -- [19]
					},
					["EventNum"] = {
						0, -- [1]
						17.16144804889516, -- [2]
						6.922049835448989, -- [3]
						0.6958157028678891, -- [4]
						7.340667606958157, -- [5]
						0, -- [6]
						20.8142924306535, -- [7]
						0.6958157028678891, -- [8]
						7.04579219558063, -- [9]
						0.6958157028678891, -- [10]
						6.591443347437706, -- [11]
						9.365303244005641, -- [12]
						0.6454160789844852, -- [13]
						6.474094969440527, -- [14]
						0.6454160789844852, -- [15]
						5.480394922425952, -- [16]
						0.6454160789844852, -- [17]
						16.68377997179126, -- [18]
						0, -- [19]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"MISC", -- [19]
					},
				}, -- [1]
			},
			["NextEventNum"] = 20,
			["LastEventHealthNum"] = {
				100, -- [1]
				82.83855195110485, -- [2]
				82.83855195110485, -- [3]
				75.91650211565586, -- [4]
				68.5758345086977, -- [5]
				67.88001880582981, -- [6]
				47.0657263751763, -- [7]
				47.0657263751763, -- [8]
				39.32411847672778, -- [9]
				39.32411847672778, -- [10]
				39.32411847672778, -- [11]
				22.67155618241655, -- [12]
				22.67155618241655, -- [13]
				15.55204513399154, -- [14]
				15.55204513399154, -- [15]
				14.90662905500705, -- [16]
				14.90662905500705, -- [17]
				0.0003761165961448049, -- [18]
				0, -- [19]
			},
			["LastEvents"] = {
				"Herald Volazj Melee Slaughtered Dodge", -- [1]
				"Slaughtered Death Strike Herald Volazj Hit -45628 (Physical)", -- [2]
				"Slaughtered Melee Herald Volazj Hit -18404 (Physical)", -- [3]
				"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1850 (Physical)", -- [4]
				"Slaughtered Heart Strike Herald Volazj Hit -19517 (Physical)", -- [5]
				"Herald Volazj Melee Slaughtered Dodge", -- [6]
				"Slaughtered Rune Strike Herald Volazj Crit -55340 (Physical)", -- [7]
				"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1850 (Physical)", -- [8]
				"Slaughtered Heart Strike Herald Volazj Hit -18733 (Physical)", -- [9]
				"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1850 (Physical)", -- [10]
				"Slaughtered Melee Herald Volazj Hit -17525 (Physical)", -- [11]
				"Slaughtered Rune Strike Herald Volazj Hit -24900 (Physical)", -- [12]
				"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1716 (Physical)", -- [13]
				"Slaughtered Heart Strike Herald Volazj Hit -17213 (Physical)", -- [14]
				"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1716 (Physical)", -- [15]
				"Slaughtered Melee Herald Volazj Hit -14571 (Physical)", -- [16]
				"Bloodworm <Slaughtered> Melee Herald Volazj Hit -1716 (Physical)", -- [17]
				"Slaughtered Death Strike Herald Volazj Hit -44358 (Physical)", -- [18]
				"Herald Volazj dies.", -- [19]
			},
			["Name"] = "Herald Volazj",
			["LastEventIncoming"] = {
				false, -- [1]
				true, -- [2]
				true, -- [3]
				true, -- [4]
				true, -- [5]
				false, -- [6]
				true, -- [7]
				true, -- [8]
				true, -- [9]
				true, -- [10]
				true, -- [11]
				true, -- [12]
				true, -- [13]
				true, -- [14]
				true, -- [15]
				true, -- [16]
				true, -- [17]
				true, -- [18]
				true, -- [19]
			},
			["TimeLast"] = {
				["DeathCount"] = 1356576105,
				["ActiveTime"] = 1356576099,
				["OVERALL"] = 1356576105,
				["DamageTaken"] = 1356576104,
				["TimeDamage"] = 1356576099,
			},
			["Fights"] = {
				["Fight1"] = {
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 7,
						},
					},
					["PartialResist"] = {
						["Rune Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.52,
								},
							},
							["amount"] = 5.52,
						},
					},
					["DamageTaken"] = 286887,
					["TimeDamaging"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.52,
								},
							},
							["amount"] = 5.52,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 1,
					["PartialAbsorb"] = {
						["Rune Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 5.52,
					["WhoDamaged"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 80240,
								},
								["Heart Strike"] = {
									["count"] = 55463,
								},
								["Melee"] = {
									["count"] = 50500,
								},
								["Death Strike"] = {
									["count"] = 89986,
								},
							},
							["amount"] = 276189,
						},
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 10698,
								},
							},
							["amount"] = 10698,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 61198,
						["Physical"] = 225689,
					},
					["ActiveTime"] = 5.52,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
				},
				["LastFightData"] = {
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 7,
						},
					},
					["PartialResist"] = {
						["Rune Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.52,
								},
							},
							["amount"] = 5.52,
						},
					},
					["DamageTaken"] = 286887,
					["TimeDamaging"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.52,
								},
							},
							["amount"] = 5.52,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 1,
					["PartialAbsorb"] = {
						["Rune Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 5.52,
					["WhoDamaged"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 80240,
								},
								["Heart Strike"] = {
									["count"] = 55463,
								},
								["Melee"] = {
									["count"] = 50500,
								},
								["Death Strike"] = {
									["count"] = 89986,
								},
							},
							["amount"] = 276189,
						},
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 10698,
								},
							},
							["amount"] = 10698,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 61198,
						["Physical"] = 225689,
					},
					["ActiveTime"] = 5.52,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["Damage"] = 0,
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["ElementHitsDone"] = {
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
					},
					["DamagedWho"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["PartialAbsorb"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["ActiveTime"] = 0,
					["EnergyGained"] = {
					},
					["EnergyGain"] = 0,
					["Healing"] = 0,
					["Dispelled"] = 0,
					["RageGained"] = {
					},
					["Attacks"] = {
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 7,
						},
					},
					["PartialResist"] = {
						["Rune Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.52,
								},
							},
							["amount"] = 5.52,
						},
					},
					["DamageTaken"] = 286887,
					["TimeDamaging"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.52,
								},
							},
							["amount"] = 5.52,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 1,
					["PartialAbsorb"] = {
						["Rune Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Heart Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 0,
						},
						["Death Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 5.52,
					["WhoDamaged"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Rune Strike"] = {
									["count"] = 80240,
								},
								["Heart Strike"] = {
									["count"] = 55463,
								},
								["Melee"] = {
									["count"] = 50500,
								},
								["Death Strike"] = {
									["count"] = 89986,
								},
							},
							["amount"] = 276189,
						},
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 10698,
								},
							},
							["amount"] = 10698,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 61198,
						["Physical"] = 225689,
					},
					["ActiveTime"] = 5.52,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
				},
			},
			["UnitLockout"] = 1356576105,
			["LastActive"] = 1356576104,
		},
		["Bloodworm"] = {
			["GUID"] = "0xF1306D7100003F9B",
			["Name"] = "Bloodworm",
			["LastFightIn"] = 17,
			["Fights"] = {
			},
			["Owner"] = false,
			["UnitLockout"] = 1356576125,
			["LastAbility"] = 70545.014,
		},
		["Jedoga Shadowseeker"] = {
			["GUID"] = "0xF130727E00003EBA",
			["LastEventHealth"] = {
				"???", -- [1]
				"???", -- [2]
				"???", -- [3]
				"???", -- [4]
				"???", -- [5]
				"???", -- [6]
				"???", -- [7]
				"???", -- [8]
				"???", -- [9]
				"186434 (87%)", -- [10]
				"158474 (74%)", -- [11]
				"158474 (74%)", -- [12]
				"158474 (74%)", -- [13]
				"158474 (74%)", -- [14]
				"158474 (74%)", -- [15]
				"131631 (61%)", -- [16]
				"131631 (61%)", -- [17]
				"85783 (40%)", -- [18]
				"85783 (40%)", -- [19]
				"60352 (28%)", -- [20]
				"???", -- [21]
				"???", -- [22]
				"???", -- [23]
				"???", -- [24]
				"???", -- [25]
				"656 (0%)", -- [26]
				"0 (0%)", -- [27]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"MISC", -- [27]
			},
			["TimeWindows"] = {
				["DeathCount"] = {
					1, -- [1]
				},
				["ActiveTime"] = {
					21.81, -- [1]
				},
				["TimeDamage"] = {
					21.81, -- [1]
				},
				["DamageTaken"] = {
					229160, -- [1]
				},
				["Damage"] = {
					153, -- [1]
				},
			},
			["enClass"] = "MOB",
			["LastDamageTaken"] = 55724,
			["LastAbility"] = 70545.014,
			["level"] = -1,
			["LastDamageAbility"] = "Death Strike",
			["LastFightIn"] = 11,
			["LastEventNum"] = {
				[26] = 26.19840150446639,
				[14] = 1.05594734367654,
				[15] = 1.055007052186178,
				[16] = 12.62012223789375,
				[17] = 19.44428772919605,
				[18] = 1.055007052186178,
				[10] = 1.056417489421721,
				[20] = 11.95627644569817,
				[11] = 12.08885754583921,
			},
			["type"] = "Boss",
			["FightsSaved"] = 5,
			["LastEventTimes"] = {
				503694.91, -- [1]
				503697.428, -- [2]
				503699.445, -- [3]
				503700.165, -- [4]
				503701.749, -- [5]
				503703.432, -- [6]
				503704.155, -- [7]
				503704.995, -- [8]
				503705.445, -- [9]
				503706.295, -- [10]
				503706.975, -- [11]
				503706.975, -- [12]
				503706.975, -- [13]
				503707.585, -- [14]
				503707.787, -- [15]
				503707.787, -- [16]
				503707.845, -- [17]
				503708.665, -- [18]
				503708.995, -- [19]
				503708.995, -- [20]
				503725.085, -- [21]
				503725.085, -- [22]
				503725.914, -- [23]
				503725.95, -- [24]
				503726.294, -- [25]
				503726.324, -- [26]
				503726.714, -- [27]
			},
			["TimeLast"] = {
				["DeathCount"] = 1356575929,
				["ActiveTime"] = 1356575929,
				["TimeDamage"] = 1356575929,
				["OVERALL"] = 1356575929,
				["DamageTaken"] = 1356575929,
				["Damage"] = 1356575909,
			},
			["Owner"] = false,
			["DeathLogs"] = {
				{
					["MessageIncoming"] = {
						false, -- [1]
						false, -- [2]
						true, -- [3]
						true, -- [4]
						false, -- [5]
						true, -- [6]
						true, -- [7]
					},
					["Messages"] = {
						"Jedoga Shadowseeker Thundershock Bloodworm <Slaughtered> Miss (Nature)", -- [1]
						"Jedoga Shadowseeker Thundershock Slaughtered Miss (Nature)", -- [2]
						"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -1728 (Physical)", -- [3]
						"Slaughtered Melee Jedoga Shadowseeker Hit -17116 (Physical)", -- [4]
						"Jedoga Shadowseeker Melee Slaughtered Miss", -- [5]
						"Slaughtered Death Strike Jedoga Shadowseeker Hit -55724 (Physical)", -- [6]
						"Jedoga Shadowseeker dies.", -- [7]
					},
					["DeathAt"] = 1356575931,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0.30841560883874, -- [6]
						0, -- [7]
					},
					["MessageTimes"] = {
						-1.629000000015367, -- [1]
						-1.629000000015367, -- [2]
						-0.8000000000465661, -- [3]
						-0.7640000000246801, -- [4]
						-0.4200000000419095, -- [5]
						-0.3900000000139698, -- [6]
						0, -- [7]
					},
					["KilledBy"] = "Slaughtered",
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"656 (0%)", -- [6]
						"0 (0%)", -- [7]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						26.19840150446639, -- [6]
						0, -- [7]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"MISC", -- [7]
					},
				}, -- [1]
			},
			["NextEventNum"] = 28,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
				0, -- [5]
				0, -- [6]
				0, -- [7]
				0, -- [8]
				0, -- [9]
				87.65115185707569, -- [10]
				74.50587682181477, -- [11]
				74.50587682181477, -- [12]
				74.50587682181477, -- [13]
				74.50587682181477, -- [14]
				74.50587682181477, -- [15]
				61.88575458392101, -- [16]
				61.88575458392101, -- [17]
				40.33051245886225, -- [18]
				40.33051245886225, -- [19]
				28.37423601316408, -- [20]
				0, -- [21]
				0, -- [22]
				0, -- [23]
				0, -- [24]
				0, -- [25]
				0.30841560883874, -- [26]
				0, -- [27]
			},
			["LastEvents"] = {
				"Jedoga Shadowseeker Melee Slaughtered Absorb (923 Absorbed)", -- [1]
				"Jedoga Shadowseeker Melee Slaughtered Absorb (1229 Absorbed)", -- [2]
				"Jedoga Shadowseeker Melee Slaughtered Miss", -- [3]
				"Slaughtered Blood Boil Jedoga Shadowseeker Hit -7240 (Shadow)", -- [4]
				"Slaughtered Blood Boil Jedoga Shadowseeker Hit -8358 (Shadow)", -- [5]
				"Jedoga Shadowseeker Melee Slaughtered Absorb (942 Absorbed)", -- [6]
				"Slaughtered Blood Boil Jedoga Shadowseeker Hit -8421 (Shadow)", -- [7]
				"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2247 (Physical)", -- [8]
				"Jedoga Shadowseeker Melee Slaughtered Miss", -- [9]
				"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2247 (Physical)", -- [10]
				"Slaughtered Rune Strike Jedoga Shadowseeker Hit -25713 (Physical)", -- [11]
				"Jedoga Shadowseeker Cyclone Strike Slaughtered Absorb (1723 Absorbed) (Physical)", -- [12]
				"Jedoga Shadowseeker Cyclone Strike Bloodworm <Slaughtered> Hit -153 (Physical)", -- [13]
				"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2246 (Physical)", -- [14]
				"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2244 (Physical)", -- [15]
				"Slaughtered Rune Strike Jedoga Shadowseeker Hit -26843 (Physical)", -- [16]
				"Slaughtered Melee Jedoga Shadowseeker Crit -41358 (Physical)", -- [17]
				"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -2244 (Physical)", -- [18]
				"Jedoga Shadowseeker Melee Slaughtered Parry", -- [19]
				"Slaughtered Rune Strike Jedoga Shadowseeker Hit -25431 (Physical)", -- [20]
				"Jedoga Shadowseeker Thundershock Bloodworm <Slaughtered> Miss (Nature)", -- [21]
				"Jedoga Shadowseeker Thundershock Slaughtered Miss (Nature)", -- [22]
				"Bloodworm <Slaughtered> Melee Jedoga Shadowseeker Hit -1728 (Physical)", -- [23]
				"Slaughtered Melee Jedoga Shadowseeker Hit -17116 (Physical)", -- [24]
				"Jedoga Shadowseeker Melee Slaughtered Miss", -- [25]
				"Slaughtered Death Strike Jedoga Shadowseeker Hit -55724 (Physical)", -- [26]
				"Jedoga Shadowseeker dies.", -- [27]
			},
			["Name"] = "Jedoga Shadowseeker",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				true, -- [4]
				true, -- [5]
				false, -- [6]
				true, -- [7]
				true, -- [8]
				false, -- [9]
				true, -- [10]
				true, -- [11]
				false, -- [12]
				false, -- [13]
				true, -- [14]
				true, -- [15]
				true, -- [16]
				true, -- [17]
				true, -- [18]
				false, -- [19]
				true, -- [20]
				false, -- [21]
				false, -- [22]
				true, -- [23]
				true, -- [24]
				false, -- [25]
				true, -- [26]
				true, -- [27]
			},
			["unit"] = "party1target",
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["Damage"] = 0,
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["ElementHitsDone"] = {
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
					},
					["DamagedWho"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["PartialAbsorb"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["ActiveTime"] = 0,
					["EnergyGained"] = {
					},
					["EnergyGain"] = 0,
					["Healing"] = 0,
					["Dispelled"] = 0,
					["RageGained"] = {
					},
					["Attacks"] = {
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["TimeSpent"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Thundershock"] = {
									["count"] = 0,
								},
								["Cyclone Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Cyclone Strike"] = {
									["count"] = 0,
								},
								["Thundershock"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["ElementDoneAbsorb"] = {
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["PartialResist"] = {
						["Death Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Blood Boil"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["PartialAbsorb"] = {
						["Death Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Blood Boil"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["ElementTaken"] = {
						["Shadow"] = 0,
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["Damage"] = 0,
					["Attacks"] = {
						["Thundershock"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Cyclone Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Absorb"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Cyclone Strike"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["WhoDamaged"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 0,
								},
								["Rune Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
								["Blood Boil"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Physical"] = 0,
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamaging"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Thundershock"] = {
									["count"] = 0,
								},
								["Cyclone Strike"] = {
									["count"] = 0,
								},
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Cyclone Strike"] = {
									["count"] = 0,
								},
								["Thundershock"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
				},
				["OverallData"] = {
					["TimeSpent"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Thundershock"] = {
									["count"] = 0,
								},
								["Cyclone Strike"] = {
									["count"] = 1.53,
								},
								["Melee"] = {
									["count"] = 16.78,
								},
							},
							["amount"] = 18.31,
						},
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Cyclone Strike"] = {
									["count"] = 0,
								},
								["Thundershock"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["DamageTaken"] = 229160,
					["ElementDoneAbsorb"] = {
						["Melee"] = 3094,
						["Physical"] = 1723,
					},
					["PartialResist"] = {
						["Death Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Blood Boil"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 1,
					["PartialAbsorb"] = {
						["Death Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Rune Strike"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Blood Boil"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 21.81,
					["ElementTaken"] = {
						["Shadow"] = 24019,
						["Melee"] = 71430,
						["Physical"] = 133711,
					},
					["Damage"] = 153,
					["Attacks"] = {
						["Thundershock"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Cyclone Strike"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 153,
									["min"] = 153,
									["count"] = 1,
									["amount"] = 153,
								},
								["Absorb"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 153,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Cyclone Strike"] = {
									["count"] = 153,
								},
							},
							["amount"] = 153,
						},
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 3,
								},
								["Parry"] = {
									["count"] = 1,
								},
								["Miss"] = {
									["count"] = 3,
								},
							},
							["amount"] = 7,
						},
						["Nature"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["TimeDamage"] = 21.81,
					["WhoDamaged"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Death Strike"] = {
									["count"] = 55724,
								},
								["Rune Strike"] = {
									["count"] = 77987,
								},
								["Melee"] = {
									["count"] = 58474,
								},
								["Blood Boil"] = {
									["count"] = 24019,
								},
							},
							["amount"] = 216204,
						},
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 12956,
								},
							},
							["amount"] = 12956,
						},
					},
					["ElementDone"] = {
						["Physical"] = 153,
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 8,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
					},
					["TimeDamaging"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Thundershock"] = {
									["count"] = 0,
								},
								["Cyclone Strike"] = {
									["count"] = 1.53,
								},
								["Melee"] = {
									["count"] = 16.78,
								},
							},
							["amount"] = 18.31,
						},
						["Bloodworm <Slaughtered>"] = {
							["Details"] = {
								["Cyclone Strike"] = {
									["count"] = 0,
								},
								["Thundershock"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
				},
			},
			["UnitLockout"] = 1356575929,
			["LastActive"] = 1356575929,
		},
		["Skadooch"] = {
			["GUID"] = "0x010000000513BAA0",
			["LastEventHealth"] = {
				"0 (0%)", -- [1]
				"0 (0%)", -- [2]
				"0 (0%)", -- [3]
				"0 (0%)", -- [4]
				"11178 (93%)", -- [5]
				"10125 (85%)", -- [6]
				"11905 (100%)", -- [7]
				"11905 (100%)", -- [8]
				"11905 (100%)", -- [9]
				"11905 (100%)", -- [10]
				"11905 (100%)", -- [11]
				"11905 (100%)", -- [12]
				"11905 (100%)", -- [13]
				"11905 (100%)", -- [14]
				"11905 (100%)", -- [15]
				"11905 (100%)", -- [16]
				"11905 (100%)", -- [17]
				"11905 (100%)", -- [18]
				"11905 (100%)", -- [19]
				"11905 (100%)", -- [20]
				"11905 (100%)", -- [21]
				"11905 (100%)", -- [22]
				"11905 (100%)", -- [23]
				"11905 (100%)", -- [24]
				"11905 (100%)", -- [25]
				"11905 (100%)", -- [26]
				"11905 (100%)", -- [27]
				"11905 (100%)", -- [28]
				"11905 (100%)", -- [29]
				"11905 (100%)", -- [30]
				"11905 (100%)", -- [31]
				"11905 (100%)", -- [32]
				"11905 (100%)", -- [33]
				"11905 (100%)", -- [34]
				"11905 (100%)", -- [35]
				"11905 (100%)", -- [36]
				"11905 (100%)", -- [37]
				"9748 (81%)", -- [38]
				"9748 (81%)", -- [39]
				"9748 (81%)", -- [40]
				"2489 (20%)", -- [41]
				"2489 (20%)", -- [42]
				"2489 (20%)", -- [43]
				"0 (0%)", -- [44]
				"0 (0%)", -- [45]
				"0 (0%)", -- [46]
				"0 (0%)", -- [47]
				"0 (0%)", -- [48]
				"0 (0%)", -- [49]
				"0 (0%)", -- [50]
			},
			["LastAttackedBy"] = "Environment",
			["LastEventType"] = {
				"HEAL", -- [1]
				"HEAL", -- [2]
				"HEAL", -- [3]
				"HEAL", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"HEAL", -- [7]
				"HEAL", -- [8]
				"HEAL", -- [9]
				"HEAL", -- [10]
				"HEAL", -- [11]
				"HEAL", -- [12]
				"HEAL", -- [13]
				"HEAL", -- [14]
				"HEAL", -- [15]
				"HEAL", -- [16]
				"HEAL", -- [17]
				"HEAL", -- [18]
				"HEAL", -- [19]
				"HEAL", -- [20]
				"HEAL", -- [21]
				"HEAL", -- [22]
				"HEAL", -- [23]
				"HEAL", -- [24]
				"HEAL", -- [25]
				"HEAL", -- [26]
				"HEAL", -- [27]
				"HEAL", -- [28]
				"HEAL", -- [29]
				"HEAL", -- [30]
				"HEAL", -- [31]
				"HEAL", -- [32]
				"HEAL", -- [33]
				"HEAL", -- [34]
				"HEAL", -- [35]
				"HEAL", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"HEAL", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"MISC", -- [44]
				"HEAL", -- [45]
				"HEAL", -- [46]
				"HEAL", -- [47]
				"HEAL", -- [48]
				"HEAL", -- [49]
				"HEAL", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					37.52999999999999, -- [1]
				},
				["Dispelled"] = {
					1, -- [1]
				},
				["Dispels"] = {
					1, -- [1]
				},
				["Healing"] = {
					34174, -- [1]
				},
				["DamageTaken"] = {
					35011, -- [1]
				},
				["Absorbs"] = {
					10320, -- [1]
				},
				["HealingTaken"] = {
					19145, -- [1]
				},
				["Overhealing"] = {
					230893, -- [1]
				},
				["ActiveTime"] = {
					37.52999999999999, -- [1]
				},
				["DeathCount"] = {
					1, -- [1]
				},
				["HOT_Time"] = {
					231, -- [1]
				},
			},
			["enClass"] = "MONK",
			["unit"] = "Skadooch",
			["LastAbility"] = 70545.014,
			["LastEventTimes"] = {
				503704.805, -- [1]
				503706.785, -- [2]
				503708.765, -- [3]
				503710.775, -- [4]
				512473.434, -- [5]
				12285.205, -- [6]
				59144.437, -- [7]
				59146.403, -- [8]
				59148.386, -- [9]
				59150.33, -- [10]
				59152.237, -- [11]
				59154.295, -- [12]
				59156.289, -- [13]
				59158.23, -- [14]
				59160.141, -- [15]
				259104.279, -- [16]
				259106.266, -- [17]
				259108.201, -- [18]
				259110.167, -- [19]
				259112.2, -- [20]
				259114.249, -- [21]
				259116.157, -- [22]
				259118.129, -- [23]
				259120.085, -- [24]
				503670.486, -- [25]
				503671.327, -- [26]
				503671.476, -- [27]
				503672.466, -- [28]
				503673.288, -- [29]
				503673.449, -- [30]
				503674.435, -- [31]
				503675.282, -- [32]
				503675.422, -- [33]
				503677.269, -- [34]
				503679.232, -- [35]
				503681.222, -- [36]
				503692.493, -- [37]
				503692.988, -- [38]
				503692.988, -- [39]
				503692.988, -- [40]
				503693.699, -- [41]
				503694.219, -- [42]
				503694.511, -- [43]
				503694.511, -- [44]
				503694.698, -- [45]
				503694.89, -- [46]
				503696.879, -- [47]
				503698.846, -- [48]
				503700.845, -- [49]
				503702.812, -- [50]
			},
			["LastDamageTaken"] = 1780,
			["level"] = 72,
			["LastDamageAbility"] = "Falling",
			["LastFightIn"] = 17,
			["LastEventNum"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				nil, -- [4]
				6.106677866442671, -- [5]
				14.95170096598068, -- [6]
				13.83452330953381, -- [7]
				13.84292314153717, -- [8]
				13.84292314153717, -- [9]
				27.68584628307434, -- [10]
				13.84292314153717, -- [11]
				13.84292314153717, -- [12]
				13.84292314153717, -- [13]
				13.84292314153717, -- [14]
				27.68584628307434, -- [15]
				13.84292314153717, -- [16]
				13.84292314153717, -- [17]
				13.84292314153717, -- [18]
				13.84292314153717, -- [19]
				13.84292314153717, -- [20]
				13.83452330953381, -- [21]
				13.84292314153717, -- [22]
				27.68584628307434, -- [23]
				13.84292314153717, -- [24]
				26.29147417051659, -- [25]
				20.81478370432592, -- [26]
				52.58294834103318, -- [27]
				26.29147417051659, -- [28]
				41.62116757664847, -- [29]
				26.29147417051659, -- [30]
				26.29147417051659, -- [31]
				41.62116757664847, -- [32]
				26.29147417051659, -- [33]
				13.87652246955061, -- [34]
				13.87652246955061, -- [35]
				13.87652246955061, -- [36]
				18.11843763124737, -- [37]
				14.36371272574549, -- [38]
				18.45443091138177, -- [39]
				28.15623687526249, -- [40]
				[42] = 13.70012599748005,
				[43] = 16.39647207055859,
			},
			["type"] = "Self",
			["FightsSaved"] = 5,
			["GuardianReverseGUIDs"] = {
				["Jade Serpent Statue"] = {
					["LatestGuardian"] = 0,
					["GUIDs"] = {
						[0] = "0xF130EDB100003E0E",
					},
				},
				["Guild Battle Standard"] = {
					["LatestGuardian"] = 0,
					["GUIDs"] = {
						[0] = "0xF130BDFE00003D7D",
					},
				},
			},
			["TimeLast"] = {
				["TimeHeal"] = 1356575911,
				["Dispelled"] = 1356575851,
				["Dispels"] = 1356575851,
				["Healing"] = 1356575911,
				["DamageTaken"] = 1358751135,
				["Absorbs"] = 1356575707,
				["HealingTaken"] = 1356575870,
				["HOT_Time"] = 1356575913,
				["ActiveTime"] = 1356575911,
				["DeathCount"] = 1356575897,
				["Overhealing"] = 1356575913,
				["OVERALL"] = 1358751135,
			},
			["Owner"] = false,
			["Pet"] = {
				"Guild Battle Standard <Skadooch>", -- [1]
				"Jade Serpent Statue <Skadooch>", -- [2]
			},
			["NextEventNum"] = 25,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
				93.89332213355733, -- [5]
				85.04829903401932, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				100, -- [11]
				100, -- [12]
				100, -- [13]
				100, -- [14]
				100, -- [15]
				100, -- [16]
				100, -- [17]
				100, -- [18]
				100, -- [19]
				100, -- [20]
				100, -- [21]
				100, -- [22]
				100, -- [23]
				100, -- [24]
				100, -- [25]
				100, -- [26]
				100, -- [27]
				100, -- [28]
				100, -- [29]
				100, -- [30]
				100, -- [31]
				100, -- [32]
				100, -- [33]
				100, -- [34]
				100, -- [35]
				100, -- [36]
				100, -- [37]
				81.88156236875263, -- [38]
				81.88156236875263, -- [39]
				81.88156236875263, -- [40]
				20.90718185636287, -- [41]
				20.90718185636287, -- [42]
				20.90718185636287, -- [43]
				0, -- [44]
				0, -- [45]
				0, -- [46]
				0, -- [47]
				0, -- [48]
				0, -- [49]
				0, -- [50]
			},
			["LastEvents"] = {
				"Skadooch Renewing Mist Pawsnreflect Tick +1652 (1506 overheal)", -- [1]
				"Skadooch Renewing Mist Pawsnreflect Tick +1651 (1504 overheal)", -- [2]
				"Skadooch Renewing Mist Pawsnreflect Tick +1652 (1579 overheal)", -- [3]
				"Skadooch Renewing Mist Pawsnreflect Tick +1652 (1652 overheal)", -- [4]
				"Environment Falling Skadooch Hit -727 (Physical)", -- [5]
				"Environment Falling Skadooch Hit -1780 (Physical)", -- [6]
				"Skadooch Renewing Mist Skadooch Tick +1647 (1647 overheal)", -- [7]
				"Skadooch Renewing Mist Skadooch Tick +1648 (1648 overheal)", -- [8]
				"Skadooch Renewing Mist Skadooch Tick +1648 (1648 overheal)", -- [9]
				"Skadooch Renewing Mist Skadooch Crit +3296 (3296 overheal)", -- [10]
				"Skadooch Renewing Mist Skadooch Tick +1648 (1648 overheal)", -- [11]
				"Skadooch Renewing Mist Skadooch Tick +1648 (1648 overheal)", -- [12]
				"Skadooch Renewing Mist Skadooch Tick +1648 (1648 overheal)", -- [13]
				"Skadooch Renewing Mist Skadooch Tick +1648 (1648 overheal)", -- [14]
				"Skadooch Renewing Mist Skadooch Crit +3296 (3296 overheal)", -- [15]
				"Skadooch Renewing Mist Skadooch Tick +1648 (1648 overheal)", -- [16]
				"Skadooch Renewing Mist Skadooch Tick +1648 (1648 overheal)", -- [17]
				"Skadooch Renewing Mist Skadooch Tick +1648 (1648 overheal)", -- [18]
				"Skadooch Renewing Mist Skadooch Tick +1648 (1648 overheal)", -- [19]
				"Skadooch Renewing Mist Skadooch Tick +1648 (1648 overheal)", -- [20]
				"Skadooch Renewing Mist Skadooch Tick +1647 (1647 overheal)", -- [21]
				"Skadooch Renewing Mist Skadooch Tick +1648 (1648 overheal)", -- [22]
				"Skadooch Renewing Mist Skadooch Crit +3296 (3296 overheal)", -- [23]
				"Skadooch Renewing Mist Skadooch Tick +1648 (1648 overheal)", -- [24]
				"Skadooch Soothing Mist Skadooch Tick +3130 (3130 overheal)", -- [25]
				"Skadooch Renewing Mist Skadooch Tick +2478 (2478 overheal)", -- [26]
				"Skadooch Soothing Mist Skadooch Crit +6260 (6260 overheal)", -- [27]
				"Skadooch Soothing Mist Skadooch Tick +3130 (3130 overheal)", -- [28]
				"Skadooch Renewing Mist Skadooch Crit +4955 (4955 overheal)", -- [29]
				"Skadooch Soothing Mist Skadooch Tick +3130 (3130 overheal)", -- [30]
				"Skadooch Soothing Mist Skadooch Tick +3130 (3130 overheal)", -- [31]
				"Skadooch Renewing Mist Skadooch Crit +4955 (4955 overheal)", -- [32]
				"Skadooch Soothing Mist Skadooch Tick +3130 (3130 overheal)", -- [33]
				"Skadooch Renewing Mist Skadooch Tick +1652 (1652 overheal)", -- [34]
				"Skadooch Renewing Mist Skadooch Tick +1652 (1652 overheal)", -- [35]
				"Skadooch Renewing Mist Skadooch Tick +1652 (1652 overheal)", -- [36]
				"Twilight Worshipper Melee Skadooch Hit -2157 (Physical)", -- [37]
				"Twilight Worshipper Melee Skadooch Hit -1710 (Physical)", -- [38]
				"Twilight Worshipper Melee Skadooch Hit -2197 (Physical)", -- [39]
				"Twilight Worshipper Melee Skadooch Crit -3352 (Physical)", -- [40]
				"Skadooch Soothing Mist Pawsnreflect Tick +2133", -- [41]
				"Twilight Worshipper Melee Skadooch Hit -1631 (Physical)", -- [42]
				"Twilight Worshipper Melee Skadooch Hit -1952 (Physical)", -- [43]
				"Skadooch dies.", -- [44]
				"Skadooch Soothing Mist Pawsnreflect Tick +2132", -- [45]
				"Skadooch Renewing Mist Pawsnreflect Tick +1652", -- [46]
				"Skadooch Renewing Mist Pawsnreflect Tick +1652 (1646 overheal)", -- [47]
				"Skadooch Renewing Mist Pawsnreflect Tick +1652", -- [48]
				"Skadooch Renewing Mist Pawsnreflect Crit +3304", -- [49]
				"Skadooch Renewing Mist Pawsnreflect Crit +3304 (159 overheal)", -- [50]
			},
			["Name"] = "Skadooch",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				true, -- [5]
				true, -- [6]
				true, -- [7]
				true, -- [8]
				true, -- [9]
				true, -- [10]
				true, -- [11]
				true, -- [12]
				true, -- [13]
				true, -- [14]
				true, -- [15]
				true, -- [16]
				true, -- [17]
				true, -- [18]
				true, -- [19]
				true, -- [20]
				true, -- [21]
				true, -- [22]
				true, -- [23]
				true, -- [24]
				true, -- [25]
				true, -- [26]
				true, -- [27]
				true, -- [28]
				true, -- [29]
				true, -- [30]
				true, -- [31]
				true, -- [32]
				true, -- [33]
				true, -- [34]
				true, -- [35]
				true, -- [36]
				true, -- [37]
				true, -- [38]
				true, -- [39]
				true, -- [40]
				false, -- [41]
				true, -- [42]
				true, -- [43]
				true, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["DeathLogs"] = {
				{
					["MessageIncoming"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						false, -- [10]
						false, -- [11]
					},
					["Messages"] = {
						"Skadooch Renewing Mist Skadooch Tick +1652 (1652 overheal)", -- [1]
						"Twilight Worshipper Melee Skadooch Hit -2157 (Physical)", -- [2]
						"Twilight Worshipper Melee Skadooch Hit -1710 (Physical)", -- [3]
						"Twilight Worshipper Melee Skadooch Hit -2197 (Physical)", -- [4]
						"Twilight Worshipper Melee Skadooch Crit -3352 (Physical)", -- [5]
						"Skadooch Soothing Mist Pawsnreflect Tick +2133", -- [6]
						"Twilight Worshipper Melee Skadooch Hit -1631 (Physical)", -- [7]
						"Twilight Worshipper Melee Skadooch Hit -1952 (Physical)", -- [8]
						"Skadooch dies.", -- [9]
						"Skadooch Soothing Mist Pawsnreflect Tick +2132", -- [10]
						"Skadooch Renewing Mist Pawsnreflect Tick +1652", -- [11]
					},
					["DeathAt"] = 1356575899,
					["HealthNum"] = {
						100, -- [1]
						100, -- [2]
						81.88156236875263, -- [3]
						81.88156236875263, -- [4]
						81.88156236875263, -- [5]
						20.90718185636287, -- [6]
						20.90718185636287, -- [7]
						20.90718185636287, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
					},
					["MessageTimes"] = {
						-13.28899999998976, -- [1]
						-2.017999999981839, -- [2]
						-1.522999999986496, -- [3]
						-1.522999999986496, -- [4]
						-1.522999999986496, -- [5]
						-0.8119999999762513, -- [6]
						-0.2920000000158325, -- [7]
						0, -- [8]
						0, -- [9]
						0.1870000000344589, -- [10]
						0.3790000000153668, -- [11]
					},
					["KilledBy"] = "Twilight Worshipper",
					["Health"] = {
						"11905 (100%)", -- [1]
						"11905 (100%)", -- [2]
						"9748 (81%)", -- [3]
						"9748 (81%)", -- [4]
						"9748 (81%)", -- [5]
						"2489 (20%)", -- [6]
						"2489 (20%)", -- [7]
						"2489 (20%)", -- [8]
						"0 (0%)", -- [9]
						"0 (0%)", -- [10]
						"0 (0%)", -- [11]
					},
					["EventNum"] = {
						13.87652246955061, -- [1]
						18.11843763124737, -- [2]
						14.36371272574549, -- [3]
						18.45443091138177, -- [4]
						28.15623687526249, -- [5]
						0, -- [6]
						13.70012599748005, -- [7]
						16.39647207055859, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
					},
					["MessageType"] = {
						"HEAL", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"HEAL", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"MISC", -- [9]
						"HEAL", -- [10]
						"HEAL", -- [11]
					},
				}, -- [1]
			},
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["Damage"] = 0,
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["ElementHitsDone"] = {
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
					},
					["DamagedWho"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["PartialAbsorb"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["ActiveTime"] = 0,
					["EnergyGained"] = {
					},
					["EnergyGain"] = 0,
					["Healing"] = 0,
					["Dispelled"] = 0,
					["RageGained"] = {
					},
					["Attacks"] = {
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["Ressed"] = 0,
					["ElementDoneResist"] = {
					},
					["ElementHitsTaken"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["HOTs"] = {
						["Soothing Mist"] = {
							["Details"] = {
								["Skadooch"] = {
									["count"] = 0,
								},
								["Pawsnreflect"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Renewing Mist"] = {
							["Details"] = {
								["Skadooch"] = {
									["count"] = 0,
								},
								["Pawsnreflect"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["ElementTaken"] = {
						["Shadow"] = 0,
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["ShieldedWho"] = {
						["Skadooch"] = {
							["Details"] = {
								["Life Cocoon"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Dispels"] = 0,
					["FDamagedWho"] = {
					},
					["HealingTaken"] = 0,
					["FAttacks"] = {
					},
					["DamagedWho"] = {
					},
					["ElementDone"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["WhoDamaged"] = {
						["Twilight Worshipper"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Darkcaster"] = {
							["Details"] = {
								["Corruption (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Environment"] = {
							["Details"] = {
								["Falling"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Skadooch"] = {
							["Details"] = {
								["Soothing Mist"] = {
									["count"] = 0,
								},
								["Renewing Mist"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Pawsnreflect"] = {
							["Details"] = {
								["Soothing Mist"] = {
									["count"] = 0,
								},
								["Renewing Mist"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["Soothing Mist"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Renewing Mist"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["Skadooch"] = {
							["Details"] = {
								["Soothing Mist"] = {
									["count"] = 0,
								},
								["Renewing Mist"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
						["Falling"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Corruption (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Interrupts"] = 0,
					["PartialResist"] = {
						["Falling"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Corruption (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["ActiveTime"] = 0,
					["Overhealing"] = 0,
					["WhoDispelled"] = {
						["Skadooch"] = {
							["Details"] = {
								["Corruption (Detox)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["Skadooch"] = {
							["Details"] = {
								["Soothing Mist"] = {
									["count"] = 0,
								},
								["Renewing Mist"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Pawsnreflect"] = {
							["Details"] = {
								["Soothing Mist"] = {
									["count"] = 0,
								},
								["Renewing Mist"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["InterruptData"] = {
					},
					["RessedWho"] = {
					},
					["Heals"] = {
						["Soothing Mist"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Renewing Mist"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["EnergyGained"] = {
					},
					["HealedWho"] = {
						["Skadooch"] = {
							["Details"] = {
								["Soothing Mist"] = {
									["count"] = 0,
								},
								["Renewing Mist"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Pawsnreflect"] = {
							["Details"] = {
								["Soothing Mist"] = {
									["count"] = 0,
								},
								["Renewing Mist"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["RageGained"] = {
					},
					["ElementHitsDone"] = {
					},
					["Attacks"] = {
					},
					["RageGain"] = 0,
					["PartialBlock"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["ElementTakenResist"] = {
					},
					["DispelledWho"] = {
						["Skadooch"] = {
							["Details"] = {
								["Corruption (Detox)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
				},
				["OverallData"] = {
					["TimeHealing"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Soothing Mist"] = {
									["count"] = 3.5,
								},
								["Renewing Mist"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 7,
						},
						["Skadooch"] = {
							["Details"] = {
								["Surging Mist"] = {
									["count"] = 0.8,
								},
								["Soothing Mist"] = {
									["count"] = 5.39,
								},
								["Renewing Mist"] = {
									["count"] = 5.77,
								},
							},
							["amount"] = 11.96,
						},
						["Pawsnreflect"] = {
							["Details"] = {
								["Soothing Mist"] = {
									["count"] = 4.5,
								},
								["Renewing Mist"] = {
									["count"] = 14.07,
								},
							},
							["amount"] = 18.57,
						},
					},
					["OverHeals"] = {
						["Surging Mist"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 12951,
									["min"] = 6110,
									["count"] = 2,
									["amount"] = 19061,
								},
							},
							["count"] = 2,
							["amount"] = 19061,
						},
						["Enveloping Mist"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 15648,
									["min"] = 15648,
									["count"] = 2,
									["amount"] = 31296,
								},
								["Tick"] = {
									["max"] = 7825,
									["min"] = 7824,
									["count"] = 4,
									["amount"] = 31299,
								},
							},
							["count"] = 6,
							["amount"] = 62595,
						},
						["Soothing Mist"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6260,
									["min"] = 1987,
									["count"] = 4,
									["amount"] = 16604,
								},
								["Tick"] = {
									["max"] = 4083,
									["min"] = 432,
									["count"] = 22,
									["amount"] = 61574,
								},
							},
							["count"] = 26,
							["amount"] = 78178,
						},
						["Renewing Mist"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4955,
									["min"] = 159,
									["count"] = 6,
									["amount"] = 21059,
								},
								["Tick"] = {
									["max"] = 2478,
									["min"] = 1440,
									["count"] = 28,
									["amount"] = 50000,
								},
							},
							["count"] = 34,
							["amount"] = 71059,
						},
					},
					["TimeSpent"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Soothing Mist"] = {
									["count"] = 3.5,
								},
								["Renewing Mist"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 7,
						},
						["Skadooch"] = {
							["Details"] = {
								["Surging Mist"] = {
									["count"] = 0.8,
								},
								["Soothing Mist"] = {
									["count"] = 5.39,
								},
								["Renewing Mist"] = {
									["count"] = 5.77,
								},
							},
							["amount"] = 11.96,
						},
						["Pawsnreflect"] = {
							["Details"] = {
								["Soothing Mist"] = {
									["count"] = 4.5,
								},
								["Renewing Mist"] = {
									["count"] = 14.07,
								},
							},
							["amount"] = 18.57,
						},
					},
					["DamageTaken"] = 35011,
					["PartialResist"] = {
						["Falling"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Corruption (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 46,
									["amount"] = 0,
								},
							},
							["count"] = 46,
							["amount"] = 0,
						},
						["Plunder Health"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 1,
					["PartialAbsorb"] = {
						["Falling"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Corruption (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 32,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 937,
									["min"] = 450,
									["count"] = 14,
									["amount"] = 8043,
								},
							},
							["count"] = 46,
							["amount"] = 8043,
						},
						["Plunder Health"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 380,
									["min"] = 379,
									["count"] = 6,
									["amount"] = 2277,
								},
							},
							["count"] = 6,
							["amount"] = 2277,
						},
					},
					["ActiveTime"] = 37.52999999999999,
					["DispelledWho"] = {
						["Skadooch"] = {
							["Details"] = {
								["Corruption (Detox)"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementTaken"] = {
						["Shadow"] = 382,
						["Melee"] = 32122,
						["Physical"] = 2507,
					},
					["HOTs"] = {
						["Enveloping Mist"] = {
							["Details"] = {
								["Skadooch"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
						["Soothing Mist"] = {
							["Details"] = {
								["Slaughtered"] = {
									["count"] = 6,
								},
								["Skadooch"] = {
									["count"] = 69,
								},
								["Pawsnreflect"] = {
									["count"] = 18,
								},
							},
							["amount"] = 93,
						},
						["Renewing Mist"] = {
							["Details"] = {
								["Skadooch"] = {
									["count"] = 57,
								},
								["Slaughtered"] = {
									["count"] = 12,
								},
								["Pawsnreflect"] = {
									["count"] = 51,
								},
							},
							["amount"] = 120,
						},
					},
					["WhoDispelled"] = {
						["Skadooch"] = {
							["Details"] = {
								["Corruption (Detox)"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Dispelled"] = 1,
					["Heals"] = {
						["Surging Mist"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 7506,
									["min"] = 7506,
									["count"] = 1,
									["amount"] = 7506,
								},
							},
							["count"] = 1,
							["amount"] = 7506,
						},
						["Life Cocoon"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 10320,
									["min"] = 10320,
									["count"] = 1,
									["amount"] = 10320,
								},
							},
							["count"] = 1,
							["amount"] = 10320,
						},
						["Soothing Mist"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 2133,
									["min"] = 448,
									["count"] = 7,
									["amount"] = 9248,
								},
							},
							["count"] = 7,
							["amount"] = 9248,
						},
						["Renewing Mist"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3304,
									["min"] = 3145,
									["count"] = 2,
									["amount"] = 6449,
								},
								["Tick"] = {
									["max"] = 2478,
									["min"] = 6,
									["count"] = 11,
									["amount"] = 10971,
								},
							},
							["count"] = 13,
							["amount"] = 17420,
						},
					},
					["ShieldedWho"] = {
						["Skadooch"] = {
							["Details"] = {
								["Life Cocoon"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["Dispels"] = 1,
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 8,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 14,
								},
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 29,
								},
							},
							["amount"] = 46,
						},
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["Healing"] = 34174,
					["Absorbs"] = 10320,
					["ElementTakenAbsorb"] = {
						["Melee"] = 8043,
						["Physical"] = 2277,
					},
					["Overhealing"] = 230893,
					["HealingTaken"] = 19145,
					["WhoHealed"] = {
						["Skadooch"] = {
							["Details"] = {
								["Surging Mist"] = {
									["count"] = 7506,
								},
								["Soothing Mist"] = {
									["count"] = 4474,
								},
								["Renewing Mist"] = {
									["count"] = 7165,
								},
							},
							["amount"] = 19145,
						},
					},
					["HOT_Time"] = 231,
					["WhoDamaged"] = {
						["Twilight Darkcaster"] = {
							["Details"] = {
								["Corruption (DoT)"] = {
									["count"] = 382,
								},
							},
							["amount"] = 382,
						},
						["Plundering Geist"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13741,
								},
							},
							["amount"] = 13741,
						},
						["Twilight Worshipper"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 18381,
								},
							},
							["amount"] = 18381,
						},
						["Environment"] = {
							["Details"] = {
								["Falling"] = {
									["count"] = 2507,
								},
							},
							["amount"] = 2507,
						},
					},
					["TimeHeal"] = 37.52999999999999,
					["HealedWho"] = {
						["Slaughtered"] = {
							["Details"] = {
								["Soothing Mist"] = {
									["count"] = 509,
								},
								["Renewing Mist"] = {
									["count"] = 130,
								},
							},
							["amount"] = 639,
						},
						["Skadooch"] = {
							["Details"] = {
								["Surging Mist"] = {
									["count"] = 7506,
								},
								["Life Cocoon"] = {
									["count"] = 10320,
								},
								["Soothing Mist"] = {
									["count"] = 4474,
								},
								["Renewing Mist"] = {
									["count"] = 7165,
								},
							},
							["amount"] = 29465,
						},
						["Pawsnreflect"] = {
							["Details"] = {
								["Soothing Mist"] = {
									["count"] = 4265,
								},
								["Renewing Mist"] = {
									["count"] = 10125,
								},
							},
							["amount"] = 14390,
						},
					},
					["Absorbed"] = {
						["Life Cocoon"] = {
							["Details"] = {
								["Skadooch"] = {
									["max"] = 10320,
									["min"] = 10320,
									["count"] = 1,
									["amount"] = 10320,
								},
							},
							["count"] = 1,
							["amount"] = 10320,
						},
					},
				},
			},
			["UnitLockout"] = 1356575687,
			["LastActive"] = 1359875311,
		},
		["Pawsnreflect"] = {
			["GUID"] = "0x01000000051240AB",
			["LastEventHealth"] = {
				"13359 (99%)", -- [1]
				"13365 (100%)", -- [2]
				"13365 (100%)", -- [3]
				"13365 (100%)", -- [4]
				"13365 (100%)", -- [5]
				"10361 (77%)", -- [6]
				"10361 (77%)", -- [7]
				"12013 (89%)", -- [8]
				"11940 (89%)", -- [9]
				"11940 (89%)", -- [10]
				"11867 (88%)", -- [11]
				"11867 (88%)", -- [12]
				"9489 (70%)", -- [13]
				"7062 (52%)", -- [14]
				"10366 (77%)", -- [15]
				"10293 (77%)", -- [16]
				"10293 (77%)", -- [17]
				"10220 (76%)", -- [18]
				"10220 (76%)", -- [19]
				"13365 (100%)", -- [20]
				"13292 (99%)", -- [21]
				"13292 (99%)", -- [22]
				"13219 (98%)", -- [23]
				"13219 (98%)", -- [24]
				"13365 (100%)", -- [25]
				"13291 (99%)", -- [26]
				"13291 (99%)", -- [27]
				"13218 (98%)", -- [28]
				"13218 (98%)", -- [29]
				"13365 (100%)", -- [30]
				"13292 (99%)", -- [31]
				"13292 (99%)", -- [32]
				"13365 (100%)", -- [33]
				"13365 (100%)", -- [34]
				"10464 (78%)", -- [35]
				"10464 (78%)", -- [36]
				"10464 (78%)", -- [37]
				"3244 (24%)", -- [38]
				"3244 (24%)", -- [39]
				"3244 (24%)", -- [40]
				"3244 (24%)", -- [41]
				"2293 (17%)", -- [42]
				"2047 (15%)", -- [43]
				"2047 (15%)", -- [44]
				"2047 (15%)", -- [45]
				"2047 (15%)", -- [46]
				"0 (0%)", -- [47]
				"7442 (55%)", -- [48]
				"9575 (71%)", -- [49]
				"11707 (87%)", -- [50]
			},
			["LastAttackedBy"] = "Twilight Worshipper",
			["LastEventType"] = {
				"HEAL", -- [1]
				"HEAL", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"HEAL", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"HEAL", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"HEAL", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"HEAL", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"HEAL", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"HEAL", -- [33]
				"HEAL", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"MISC", -- [47]
				"DAMAGE", -- [48]
				"HEAL", -- [49]
				"HEAL", -- [50]
			},
			["TimeWindows"] = {
				["Dispelled"] = {
					1, -- [1]
				},
				["Dispels"] = {
					1, -- [1]
				},
				["Ressed"] = {
					1, -- [1]
				},
				["DamageTaken"] = {
					23025, -- [1]
				},
				["DeathCount"] = {
					1, -- [1]
				},
				["FDamage"] = {
					1486, -- [1]
				},
				["ActiveTime"] = {
					20.02, -- [1]
				},
				["HealingTaken"] = {
					14390, -- [1]
				},
				["DOT_Time"] = {
					45, -- [1]
				},
				["TimeDamage"] = {
					20.02, -- [1]
				},
			},
			["enClass"] = "MONK",
			["unit"] = "Pawsnreflect",
			["LastAbility"] = 70545.014,
			["LastEventTimes"] = {
				503694.89, -- [1]
				503696.879, -- [2]
				503697.336, -- [3]
				503697.336, -- [4]
				503697.336, -- [5]
				503698.318, -- [6]
				503698.318, -- [7]
				503698.846, -- [8]
				503699.325, -- [9]
				503699.325, -- [10]
				503700.335, -- [11]
				503700.335, -- [12]
				503700.475, -- [13]
				503700.575, -- [14]
				503700.845, -- [15]
				503701.335, -- [16]
				503701.335, -- [17]
				503702.317, -- [18]
				503702.317, -- [19]
				503702.812, -- [20]
				503703.337, -- [21]
				503703.337, -- [22]
				503704.315, -- [23]
				503704.315, -- [24]
				503704.805, -- [25]
				503705.355, -- [26]
				503705.355, -- [27]
				503706.325, -- [28]
				503706.325, -- [29]
				503706.785, -- [30]
				503707.325, -- [31]
				503707.325, -- [32]
				503708.765, -- [33]
				503710.775, -- [34]
				503661.694, -- [35]
				503661.906, -- [36]
				503661.906, -- [37]
				503662.7, -- [38]
				503662.7, -- [39]
				503662.7, -- [40]
				503662.7, -- [41]
				503663.199, -- [42]
				503663.681, -- [43]
				503663.681, -- [44]
				503663.907, -- [45]
				503663.907, -- [46]
				503664.314, -- [47]
				503691.692, -- [48]
				503693.699, -- [49]
				503694.698, -- [50]
			},
			["LastDamageTaken"] = 2427,
			["level"] = 72,
			["LastDamageAbility"] = "Fireball",
			["LastFightIn"] = 11,
			["LastEventNum"] = {
				12.36064347175458, -- [1]
				12.36064347175458, -- [2]
				6.958473625140292, -- [3]
				7.167976056864946, -- [4]
				7.803965581743359, -- [5]
				nil, -- [6]
				0.5462027684249906, -- [7]
				12.36064347175458, -- [8]
				nil, -- [9]
				0.5462027684249906, -- [10]
				nil, -- [11]
				0.5462027684249906, -- [12]
				17.79274223718668, -- [13]
				18.15937149270483, -- [14]
				24.72128694350917, -- [15]
				nil, -- [16]
				0.5462027684249906, -- [17]
				nil, -- [18]
				0.5462027684249906, -- [19]
				24.72128694350917, -- [20]
				nil, -- [21]
				0.5462027684249906, -- [22]
				nil, -- [23]
				0.5462027684249906, -- [24]
				12.36064347175458, -- [25]
				[30] = 12.35316124205013,
				[32] = 0.5462027684249906,
				[33] = 12.36064347175458,
				[34] = 12.36064347175458,
				[35] = 1.257014590347924,
				[36] = 9.337822671156005,
				[37] = 8.387579498690609,
				[39] = 1.571268237934905,
				[40] = 7.115600448933782,
				[42] = 9.66704077815189,
				[44] = 1.840628507295174,
				[45] = 7.931163486719043,
				[46] = 7.841376730265619,
				[48] = 4.30976430976431,
				[49] = 15.95959595959596,
				[50] = 15.95211372989151,
				[27] = 0.5536849981294426,
				[29] = 0.5462027684249906,
			},
			["type"] = "Ungrouped",
			["FightsSaved"] = 5,
			["GuardianReverseGUIDs"] = {
				["Guild Battle Standard"] = {
					["LatestGuardian"] = 1,
					["GUIDs"] = {
						"0xF130BDFD00003DE1", -- [1]
						[0] = "0xF130BDFE00003D5D",
					},
				},
			},
			["TimeLast"] = {
				["Dispelled"] = 1356575516,
				["Dispels"] = 1356575516,
				["OVERALL"] = 1356575943,
				["DamageTaken"] = 1356575903,
				["DeathCount"] = 1356575867,
				["FDamage"] = 1356575910,
				["ActiveTime"] = 1356575910,
				["Ressed"] = 1356575943,
				["HealingTaken"] = 1356575911,
				["DOT_Time"] = 1356575910,
				["TimeDamage"] = 1356575910,
			},
			["Owner"] = false,
			["Pet"] = {
				"Guild Battle Standard <Pawsnreflect>", -- [1]
			},
			["NextEventNum"] = 35,
			["LastEventHealthNum"] = {
				99.95510662177328, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				77.52338196782641, -- [6]
				77.52338196782641, -- [7]
				89.884025439581, -- [8]
				89.33782267115601, -- [9]
				89.33782267115601, -- [10]
				88.79161990273101, -- [11]
				88.79161990273101, -- [12]
				70.99887766554433, -- [13]
				52.83950617283951, -- [14]
				77.56079311634868, -- [15]
				77.01459034792369, -- [16]
				77.01459034792369, -- [17]
				76.4683875794987, -- [18]
				76.4683875794987, -- [19]
				100, -- [20]
				99.45379723157501, -- [21]
				99.45379723157501, -- [22]
				98.90759446315002, -- [23]
				98.90759446315002, -- [24]
				100, -- [25]
				99.44631500187056, -- [26]
				99.44631500187056, -- [27]
				98.90011223344557, -- [28]
				98.90011223344557, -- [29]
				100, -- [30]
				99.45379723157501, -- [31]
				99.45379723157501, -- [32]
				100, -- [33]
				100, -- [34]
				78.29405162738496, -- [35]
				78.29405162738496, -- [36]
				78.29405162738496, -- [37]
				24.27235316124205, -- [38]
				24.27235316124205, -- [39]
				24.27235316124205, -- [40]
				24.27235316124205, -- [41]
				17.15675271230827, -- [42]
				15.31612420501309, -- [43]
				15.31612420501309, -- [44]
				15.31612420501309, -- [45]
				15.31612420501309, -- [46]
				0, -- [47]
				55.68275346053124, -- [48]
				71.6423494201272, -- [49]
				87.59446315001871, -- [50]
			},
			["LastEvents"] = {
				"Skadooch Renewing Mist Pawsnreflect Tick +1652", -- [1]
				"Skadooch Renewing Mist Pawsnreflect Tick +1652 (1646 overheal)", -- [2]
				"Twilight Worshipper Melee Pawsnreflect Hit -930 (232 Absorbed) (Physical)", -- [3]
				"Twilight Worshipper Melee Pawsnreflect Hit -958 (239 Absorbed) (Physical)", -- [4]
				"Twilight Worshipper Melee Pawsnreflect Hit -1043 (260 Absorbed) (Physical)", -- [5]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -73 (Physical)", -- [6]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -73 (Physical)", -- [7]
				"Skadooch Renewing Mist Pawsnreflect Tick +1652", -- [8]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -73 (Physical)", -- [9]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -73 (Physical)", -- [10]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -73 (Physical)", -- [11]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -73 (Physical)", -- [12]
				"Twilight Worshipper Fireball Pawsnreflect Hit -2378 (Fire)", -- [13]
				"Twilight Worshipper Fireball Pawsnreflect Hit -2427 (Fire)", -- [14]
				"Skadooch Renewing Mist Pawsnreflect Crit +3304", -- [15]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -73 (Physical)", -- [16]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -73 (Physical)", -- [17]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -73 (Physical)", -- [18]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -73 (Physical)", -- [19]
				"Skadooch Renewing Mist Pawsnreflect Crit +3304 (159 overheal)", -- [20]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -73 (Physical)", -- [21]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -73 (Physical)", -- [22]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -73 (Physical)", -- [23]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -73 (Physical)", -- [24]
				"Skadooch Renewing Mist Pawsnreflect Tick +1652 (1506 overheal)", -- [25]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -74 (Physical)", -- [26]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -74 (Physical)", -- [27]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -73 (Physical)", -- [28]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -73 (Physical)", -- [29]
				"Skadooch Renewing Mist Pawsnreflect Tick +1651 (1504 overheal)", -- [30]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -73 (Physical)", -- [31]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -73 (Physical)", -- [32]
				"Skadooch Renewing Mist Pawsnreflect Tick +1652 (1579 overheal)", -- [33]
				"Skadooch Renewing Mist Pawsnreflect Tick +1652 (1652 overheal)", -- [34]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -168 (Physical)", -- [35]
				"Twilight Volunteer Melee Pawsnreflect Hit -1248 (312 Absorbed) (Physical)", -- [36]
				"Twilight Volunteer Melee Pawsnreflect Hit -1121 (280 Absorbed) (Physical)", -- [37]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -210 (Physical)", -- [38]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -210 (Physical)", -- [39]
				"Twilight Worshipper Melee Pawsnreflect Hit -951 (237 Absorbed) (Physical)", -- [40]
				"Twilight Worshipper Melee Pawsnreflect Dodge", -- [41]
				"Twilight Worshipper Melee Pawsnreflect Hit -1292 (322 Absorbed) (Physical)", -- [42]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -246 (Physical)", -- [43]
				"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -246 (Physical)", -- [44]
				"Twilight Volunteer Melee Pawsnreflect Hit -1060 (265 Absorbed) (Physical)", -- [45]
				"Twilight Volunteer Melee Pawsnreflect Hit -1048 (262 Absorbed) (Physical)", -- [46]
				"Pawsnreflect dies.", -- [47]
				"Bound Fire Elemental Fire Nova Pawsnreflect Hit -576 (Fire)", -- [48]
				"Skadooch Soothing Mist Pawsnreflect Tick +2133", -- [49]
				"Skadooch Soothing Mist Pawsnreflect Tick +2132", -- [50]
			},
			["Name"] = "Pawsnreflect",
			["LastEventIncoming"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
				true, -- [4]
				true, -- [5]
				false, -- [6]
				true, -- [7]
				true, -- [8]
				false, -- [9]
				true, -- [10]
				false, -- [11]
				true, -- [12]
				true, -- [13]
				true, -- [14]
				true, -- [15]
				false, -- [16]
				true, -- [17]
				false, -- [18]
				true, -- [19]
				true, -- [20]
				false, -- [21]
				true, -- [22]
				false, -- [23]
				true, -- [24]
				true, -- [25]
				false, -- [26]
				true, -- [27]
				false, -- [28]
				true, -- [29]
				true, -- [30]
				false, -- [31]
				true, -- [32]
				true, -- [33]
				true, -- [34]
				true, -- [35]
				true, -- [36]
				true, -- [37]
				false, -- [38]
				true, -- [39]
				true, -- [40]
				true, -- [41]
				true, -- [42]
				false, -- [43]
				true, -- [44]
				true, -- [45]
				true, -- [46]
				true, -- [47]
				true, -- [48]
				true, -- [49]
				true, -- [50]
			},
			["DeathLogs"] = {
				{
					["MessageIncoming"] = {
						true, -- [1]
						true, -- [2]
						false, -- [3]
						true, -- [4]
						false, -- [5]
						true, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						false, -- [11]
						true, -- [12]
						true, -- [13]
						true, -- [14]
						false, -- [15]
						true, -- [16]
						true, -- [17]
						true, -- [18]
						true, -- [19]
						false, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
					},
					["Messages"] = {
						"Twilight Volunteer Melee Pawsnreflect Hit -1308 (327 Absorbed) (Physical)", -- [1]
						"Twilight Volunteer Melee Pawsnreflect Hit -1294 (323 Absorbed) (Physical)", -- [2]
						"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -66 (Physical)", -- [3]
						"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -66 (Physical)", -- [4]
						"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -65 (Physical)", -- [5]
						"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -65 (Physical)", -- [6]
						"Twilight Volunteer Melee Pawsnreflect Hit -1312 (327 Absorbed) (Physical)", -- [7]
						"Twilight Volunteer Melee Pawsnreflect Hit -1260 (315 Absorbed) (Physical)", -- [8]
						"Twilight Volunteer Melee Pawsnreflect Hit -1103 (275 Absorbed) (Physical)", -- [9]
						"Twilight Volunteer Melee Pawsnreflect Hit -966 (241 Absorbed) (Physical)", -- [10]
						"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -168 (Physical)", -- [11]
						"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -168 (Physical)", -- [12]
						"Twilight Volunteer Melee Pawsnreflect Hit -1248 (312 Absorbed) (Physical)", -- [13]
						"Twilight Volunteer Melee Pawsnreflect Hit -1121 (280 Absorbed) (Physical)", -- [14]
						"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -210 (Physical)", -- [15]
						"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -210 (Physical)", -- [16]
						"Twilight Worshipper Melee Pawsnreflect Hit -951 (237 Absorbed) (Physical)", -- [17]
						"Twilight Worshipper Melee Pawsnreflect Dodge", -- [18]
						"Twilight Worshipper Melee Pawsnreflect Hit -1292 (322 Absorbed) (Physical)", -- [19]
						"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -246 (Physical)", -- [20]
						"Pawsnreflect Stagger (DoT) Pawsnreflect Tick -246 (Physical)", -- [21]
						"Twilight Volunteer Melee Pawsnreflect Hit -1060 (265 Absorbed) (Physical)", -- [22]
						"Twilight Volunteer Melee Pawsnreflect Hit -1048 (262 Absorbed) (Physical)", -- [23]
						"Pawsnreflect dies.", -- [24]
					},
					["DeathAt"] = 1356575869,
					["HealthNum"] = {
						100, -- [1]
						100, -- [2]
						80.03741114852225, -- [3]
						80.03741114852225, -- [4]
						79.55106621773288, -- [5]
						79.55106621773288, -- [6]
						79.55106621773288, -- [7]
						79.55106621773288, -- [8]
						79.55106621773288, -- [9]
						79.55106621773288, -- [10]
						78.29405162738496, -- [11]
						78.29405162738496, -- [12]
						78.29405162738496, -- [13]
						78.29405162738496, -- [14]
						24.27235316124205, -- [15]
						24.27235316124205, -- [16]
						24.27235316124205, -- [17]
						24.27235316124205, -- [18]
						17.15675271230827, -- [19]
						15.31612420501309, -- [20]
						15.31612420501309, -- [21]
						15.31612420501309, -- [22]
						15.31612420501309, -- [23]
						0, -- [24]
					},
					["MessageTimes"] = {
						-5.935999999986962, -- [1]
						-5.935999999986962, -- [2]
						-4.63900000002468, -- [3]
						-4.63900000002468, -- [4]
						-3.615999999979977, -- [5]
						-3.615999999979977, -- [6]
						-2.814000000013039, -- [7]
						-2.814000000013039, -- [8]
						-2.814000000013039, -- [9]
						-2.814000000013039, -- [10]
						-2.619999999995343, -- [11]
						-2.619999999995343, -- [12]
						-2.407999999995809, -- [13]
						-2.407999999995809, -- [14]
						-1.614000000001397, -- [15]
						-1.614000000001397, -- [16]
						-1.614000000001397, -- [17]
						-1.614000000001397, -- [18]
						-1.114999999990687, -- [19]
						-0.6330000000307336, -- [20]
						-0.6330000000307336, -- [21]
						-0.4070000000065193, -- [22]
						-0.4070000000065193, -- [23]
						0, -- [24]
					},
					["KilledBy"] = "Twilight Volunteer",
					["Health"] = {
						"13365 (100%)", -- [1]
						"13365 (100%)", -- [2]
						"10697 (80%)", -- [3]
						"10697 (80%)", -- [4]
						"10632 (79%)", -- [5]
						"10632 (79%)", -- [6]
						"10632 (79%)", -- [7]
						"10632 (79%)", -- [8]
						"10632 (79%)", -- [9]
						"10632 (79%)", -- [10]
						"10464 (78%)", -- [11]
						"10464 (78%)", -- [12]
						"10464 (78%)", -- [13]
						"10464 (78%)", -- [14]
						"3244 (24%)", -- [15]
						"3244 (24%)", -- [16]
						"3244 (24%)", -- [17]
						"3244 (24%)", -- [18]
						"2293 (17%)", -- [19]
						"2047 (15%)", -- [20]
						"2047 (15%)", -- [21]
						"2047 (15%)", -- [22]
						"2047 (15%)", -- [23]
						"0 (0%)", -- [24]
					},
					["EventNum"] = {
						9.78675645342312, -- [1]
						9.682005237560793, -- [2]
						0, -- [3]
						0.4938271604938271, -- [4]
						0, -- [5]
						0.4863449307893752, -- [6]
						9.816685372240928, -- [7]
						9.427609427609427, -- [8]
						8.252899364010474, -- [9]
						7.227833894500561, -- [10]
						0, -- [11]
						1.257014590347924, -- [12]
						9.337822671156005, -- [13]
						8.387579498690609, -- [14]
						0, -- [15]
						1.571268237934905, -- [16]
						7.115600448933782, -- [17]
						0, -- [18]
						9.66704077815189, -- [19]
						0, -- [20]
						1.840628507295174, -- [21]
						7.931163486719043, -- [22]
						7.841376730265619, -- [23]
						0, -- [24]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"MISC", -- [24]
					},
				}, -- [1]
			},
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["Damage"] = 0,
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["ElementHitsDone"] = {
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
					},
					["DamagedWho"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["PartialAbsorb"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["ActiveTime"] = 0,
					["EnergyGained"] = {
					},
					["EnergyGain"] = 0,
					["Healing"] = 0,
					["Dispelled"] = 0,
					["RageGained"] = {
					},
					["Attacks"] = {
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
						["Stagger (DoT)"] = {
							["Details"] = {
								["Pawsnreflect"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["Damage"] = 0,
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 0,
						["Fire"] = 0,
					},
					["DOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["ElementHitsDone"] = {
					},
					["FAttacks"] = {
						["Stagger (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
					},
					["DamagedWho"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["WhoDamaged"] = {
						["Bound Fire Elemental"] = {
							["Details"] = {
								["Fire Nova"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Volunteer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Twilight Worshipper"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 0,
								},
								["Fireball"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["WhoHealed"] = {
						["Skadooch"] = {
							["Details"] = {
								["Soothing Mist"] = {
									["count"] = 0,
								},
								["Renewing Mist"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
						["Melee"] = 0,
					},
					["PartialAbsorb"] = {
						["Fire Nova"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Fireball"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["Fire Nova"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Fireball"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Pawsnreflect"] = {
							["Details"] = {
								["Stagger (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["ActiveTime"] = 0,
					["EnergyGained"] = {
					},
					["EnergyGain"] = 0,
					["Healing"] = 0,
					["Dispelled"] = 0,
					["RageGained"] = {
					},
					["Attacks"] = {
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
						["Pawsnreflect"] = {
							["Details"] = {
								["Stagger (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["Pawsnreflect"] = {
							["Details"] = {
								["Stagger (DoT)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["Dispelled"] = 1,
					["TimeSpent"] = {
						["Pawsnreflect"] = {
							["Details"] = {
								["Stagger (DoT)"] = {
									["count"] = 20.02,
								},
							},
							["amount"] = 20.02,
						},
					},
					["DamageTaken"] = 23025,
					["PartialResist"] = {
						["Fire Nova"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Fireball"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Glutinous Poison"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 1,
					["PartialAbsorb"] = {
						["Fire Nova"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Fireball"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 327,
									["min"] = 232,
									["count"] = 15,
									["amount"] = 4217,
								},
							},
							["count"] = 16,
							["amount"] = 4217,
						},
						["Glutinous Poison"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 20.02,
					["ElementTaken"] = {
						["Fire"] = 5381,
						["Melee"] = 16894,
						["Nature"] = 750,
					},
					["DOT_Time"] = 45,
					["WhoDispelled"] = {
						["Pawsnreflect"] = {
							["Details"] = {
								["Glutinous Poison (Detox)"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Ressed"] = 1,
					["RessedWho"] = {
						["Skadooch"] = {
							["Details"] = {
								["Mass Resurrection"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Dispels"] = 1,
					["WhoHealed"] = {
						["Skadooch"] = {
							["Details"] = {
								["Soothing Mist"] = {
									["count"] = 4265,
								},
								["Renewing Mist"] = {
									["count"] = 10125,
								},
							},
							["amount"] = 14390,
						},
					},
					["DOTs"] = {
						["Stagger (DoT)"] = {
							["Details"] = {
								["Pawsnreflect"] = {
									["count"] = 45,
								},
							},
							["amount"] = 45,
						},
					},
					["FAttacks"] = {
						["Stagger (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 246,
									["min"] = 65,
									["count"] = 15,
									["amount"] = 1486,
								},
							},
							["count"] = 15,
							["amount"] = 1486,
						},
					},
					["TimeDamaging"] = {
						["Pawsnreflect"] = {
							["Details"] = {
								["Stagger (DoT)"] = {
									["count"] = 20.02,
								},
							},
							["amount"] = 20.02,
						},
					},
					["FDamage"] = 1486,
					["HealingTaken"] = 14390,
					["FDamagedWho"] = {
						["Pawsnreflect"] = {
							["Details"] = {
								["Stagger (DoT)"] = {
									["count"] = 1486,
								},
							},
							["amount"] = 1486,
						},
					},
					["TimeDamage"] = 20.02,
					["WhoDamaged"] = {
						["Bound Fire Elemental"] = {
							["Details"] = {
								["Fire Nova"] = {
									["count"] = 576,
								},
							},
							["amount"] = 576,
						},
						["Twilight Volunteer"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 11720,
								},
							},
							["amount"] = 11720,
						},
						["Twilight Worshipper"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5174,
								},
								["Fireball"] = {
									["count"] = 4805,
								},
							},
							["amount"] = 9979,
						},
						["Deep Crawler"] = {
							["Details"] = {
								["Glutinous Poison"] = {
									["count"] = 750,
								},
							},
							["amount"] = 750,
						},
					},
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 15,
								},
							},
							["amount"] = 16,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 4217,
					},
					["DispelledWho"] = {
						["Pawsnreflect"] = {
							["Details"] = {
								["Glutinous Poison (Detox)"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
				},
			},
			["UnitLockout"] = 1356575514,
			["LastActive"] = 1356575943,
		},
	},
	["FightNum"] = 17,
	["CombatTimes"] = {
		{
			1356575480, -- [1]
			1356575489, -- [2]
			"18:31:20", -- [3]
			"18:31:29", -- [4]
			"Deep Crawler", -- [5]
		}, -- [1]
		{
			1356575501, -- [1]
			1356575542, -- [2]
			"18:31:41", -- [3]
			"18:32:22", -- [4]
			"Ahn'kahar Web Winder", -- [5]
		}, -- [2]
		{
			1356575549, -- [1]
			1356575559, -- [2]
			"18:32:29", -- [3]
			"18:32:39", -- [4]
			"Plague Walker", -- [5]
		}, -- [3]
		{
			1356575564, -- [1]
			1356575573, -- [2]
			"18:32:44", -- [3]
			"18:32:53", -- [4]
			"Ahn'kahar Slasher", -- [5]
		}, -- [4]
		{
			1356575583, -- [1]
			1356575588, -- [2]
			"18:33:03", -- [3]
			"18:33:08", -- [4]
			"Elder Nadox", -- [5]
		}, -- [5]
		{
			1356575600, -- [1]
			1356575624, -- [2]
			"18:33:20", -- [3]
			"18:33:44", -- [4]
			"Ahn'kahar Spell Flinger", -- [5]
		}, -- [6]
		{
			1356575661, -- [1]
			1356575707, -- [2]
			"18:34:22", -- [3]
			"18:35:07", -- [4]
			"Plundering Geist", -- [5]
		}, -- [7]
		{
			1356575709, -- [1]
			1356575714, -- [2]
			"18:35:09", -- [3]
			"18:35:14", -- [4]
			"Bonegrinder", -- [5]
		}, -- [8]
		{
			1356575732, -- [1]
			1356575741, -- [2]
			"18:35:32", -- [3]
			"18:35:41", -- [4]
			"Eye of Taldaram", -- [5]
		}, -- [9]
		{
			1356575757, -- [1]
			1356575765, -- [2]
			"18:35:57", -- [3]
			"18:36:05", -- [4]
			"Eye of Taldaram", -- [5]
		}, -- [10]
		{
			1356575787, -- [1]
			1356575802, -- [2]
			"18:36:28", -- [3]
			"18:36:42", -- [4]
			"Prince Taldaram", -- [5]
		}, -- [11]
		{
			1356575830, -- [1]
			1356575931, -- [2]
			"18:37:10", -- [3]
			"18:38:51", -- [4]
			"Jedoga Shadowseeker", -- [5]
		}, -- [12]
		{
			1356575952, -- [1]
			1356575959, -- [2]
			"18:39:12", -- [3]
			"18:39:19", -- [4]
			"Twilight Darkcaster", -- [5]
		}, -- [13]
		{
			1356575976, -- [1]
			1356575981, -- [2]
			"18:39:36", -- [3]
			"18:39:41", -- [4]
			"Savage Cave Beast", -- [5]
		}, -- [14]
		{
			1356575988, -- [1]
			1356576013, -- [2]
			"18:39:48", -- [3]
			"18:40:13", -- [4]
			"Savage Cave Beast", -- [5]
		}, -- [15]
		{
			1356576080, -- [1]
			1356576095, -- [2]
			"18:41:20", -- [3]
			"18:41:35", -- [4]
			"Forgotten One", -- [5]
		}, -- [16]
		{
			1356576097, -- [1]
			1356576112, -- [2]
			"18:41:37", -- [3]
			"18:41:52", -- [4]
			"Herald Volazj", -- [5]
		}, -- [17]
	},
	["FoughtWho"] = {
		"Herald Volazj 18:41:37-18:41:52", -- [1]
		"Forgotten One 18:41:20-18:41:35", -- [2]
		"Savage Cave Beast 18:39:48-18:40:13", -- [3]
		"Savage Cave Beast 18:39:36-18:39:41", -- [4]
		"Twilight Darkcaster 18:39:12-18:39:19", -- [5]
	},
}
