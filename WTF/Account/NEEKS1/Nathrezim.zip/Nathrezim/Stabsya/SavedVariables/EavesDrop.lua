
EavesDropStatsDB = {
	["profileKeys"] = {
		["Stabsya - Nathrezim"] = "Stabsya - Nathrezim",
	},
	["profiles"] = {
		["Stabsya - Nathrezim"] = {
			{
				["hit"] = {
					["Mantid Poison"] = {
						[-2] = {
							["time"] = "|cffffffff11/26/12 03:06:19|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:128386:SPELL_PERIODIC_DAMAGE|h|cffffffffMantid Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130F37400632D79:Norvakess|hNorvakess|h |cffffffff9098|r |cffffffffNature|r. ",
							["amount"] = 9098,
						},
						[2] = {
							["time"] = "|cffffffff11/26/12 03:06:17|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:128386:SPELL_PERIODIC_DAMAGE|h|cffffffffMantid Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130F37400632D79:Norvakess|hNorvakess|h |cffffffff18195|r |cffffffffNature|r. (Critical) ",
							["amount"] = 18195,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_NullifyPoison",
					},
					["Deadly Poison"] = {
						[-2] = {
							["time"] = "|cffffffff11/26/12 02:18:40|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:2818:SPELL_PERIODIC_DAMAGE|h|cffffffffDeadly Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130EFBE0061B987:Krik'thik Deep-Scout|hKrik'thik Deep-Scout|h |cffffffff21462|r |cffffffffNature|r. ",
							["amount"] = 21462,
						},
						[2] = {
							["time"] = "|cffffffff12/01/12 07:51:08|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:2818:SPELL_PERIODIC_DAMAGE|h|cffffffffDeadly Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF13106C000001025:Broodmaster Noshi|hBroodmaster Noshi|h |cffffffff35573|r |cffffffffNature|r. (Critical) ",
							["amount"] = 35573,
						},
						["icon"] = "Interface\\Icons\\Ability_Rogue_DualWeild",
					},
					["Envenom"] = {
						[-2] = {
							["time"] = "|cffffffff12/01/12 07:52:35|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:32645:SPELL_DAMAGE|h|cffffffffEnvenom|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13106C000001025:Broodmaster Noshi|hBroodmaster Noshi|h |cffffffff43087|r |cffffffffNature|r. ",
							["amount"] = 43087,
						},
						[2] = {
							["time"] = "|cffffffff12/01/12 07:52:25|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:32645:SPELL_DAMAGE|h|cffffffffEnvenom|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13106C000001025:Broodmaster Noshi|hBroodmaster Noshi|h |cffffffff68938|r |cffffffffNature|r. (Critical) ",
							["amount"] = 68938,
						},
						["icon"] = "Interface\\Icons\\Ability_Rogue_Disembowel",
					},
					["Rupture"] = {
						[-2] = {
							["time"] = "|cffffffff11/26/12 02:23:51|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:1943:SPELL_PERIODIC_DAMAGE|h|cffffffffRupture|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130EFBE0061CC6B:Krik'thik Deep-Scout|hKrik'thik Deep-Scout|h |cffffffff3662|r |cffffffffPhysical|r. ",
							["amount"] = 3662,
						},
						[2] = {
							["time"] = "|cffffffff11/26/12 03:06:28|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:1943:SPELL_PERIODIC_DAMAGE|h|cffffffffRupture|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130F37400632D79:Norvakess|hNorvakess|h |cffffffff7309|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 7309,
						},
						["icon"] = "Interface\\Icons\\Ability_Rogue_Rupture",
					},
					["Venomous Wound"] = {
						[-2] = {
							["time"] = "|cffffffff11/26/12 02:18:41|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:79136:SPELL_DAMAGE|h|cffffffffVenomous Wound|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFBE0061B987:Krik'thik Deep-Scout|hKrik'thik Deep-Scout|h |cffffffff16714|r |cffffffffNature|r. ",
							["amount"] = 16714,
						},
						[2] = {
							["time"] = "|cffffffff11/26/12 01:32:57|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:79136:SPELL_DAMAGE|h|cffffffffVenomous Wound|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130ED190061CA0C:Osul Mist-Shaman|hOsul Mist-Shaman|h |cffffffff23856|r |cffffffffNature|r. (Critical) ",
							["amount"] = 23856,
						},
						["icon"] = "INTERFACE\\ICONS\\ability_rogue_venomouswounds",
					},
					["Dispatch"] = {
						[-2] = {
							["time"] = "|cffffffff11/26/12 03:06:28|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:111240:SPELL_DAMAGE|h|cffffffffDispatch|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F37400632D79:Norvakess|hNorvakess|h |cffffffff50520|r |cffffffffPhysical|r. ",
							["amount"] = 50520,
						},
						[2] = {
							["time"] = "|cffffffff12/06/12 11:42:40|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:111240:SPELL_DAMAGE|h|cffffffffDispatch|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F14600002431:Crypt Guardian|hCrypt Guardian|h |cffffffff87799|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 87799,
						},
						["icon"] = "Interface\\Icons\\Ability_BackStab",
					},
					["Mutilate Off-Hand"] = {
						[-2] = {
							["time"] = "|cffffffff11/26/12 03:06:36|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:27576:SPELL_DAMAGE|h|cffffffffMutilate Off-Hand|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F37400632D79:Norvakess|hNorvakess|h |cffffffff11476|r |cffffffffPhysical|r. ",
							["amount"] = 11476,
						},
						[2] = {
							["time"] = "|cffffffff12/01/12 07:42:26|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:27576:SPELL_DAMAGE|h|cffffffffMutilate Off-Hand|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13107DE00000766:Priestess Laralla|hPriestess Laralla|h |cffffffff22096|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 22096,
						},
						["icon"] = "Interface\\Icons\\Ability_DualWield",
					},
					["Ambush"] = {
						[-2] = {
							["time"] = "|cffffffff12/01/12 07:50:20|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:8676:SPELL_DAMAGE|h|cffffffffAmbush|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13106C000001025:Broodmaster Noshi|hBroodmaster Noshi|h |cffffffff59933|r |cffffffffPhysical|r. ",
							["amount"] = 59933,
						},
						[2] = {
							["time"] = "|cffffffff12/06/12 11:40:49|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:8676:SPELL_DAMAGE|h|cffffffffAmbush|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F1760000234B:Jin Ironfist|hJin Ironfist|h |cffffffff79159|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 79159,
						},
						["icon"] = "Interface\\Icons\\Ability_Rogue_Ambush",
					},
					["Fan of Knives"] = {
						[-2] = {
							["time"] = "|cffffffff12/01/12 08:18:02|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:51723:SPELL_DAMAGE|h|cffffffffFan of Knives|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F239000014B3:Shadows of Anger|hShadows of Anger|h |cffffffff9414|r |cffffffffPhysical|r. ",
							["amount"] = 9414,
						},
						[2] = {
							["time"] = "|cffffffff12/01/12 08:18:00|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:51723:SPELL_DAMAGE|h|cffffffffFan of Knives|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F239000014B3:Shadows of Anger|hShadows of Anger|h |cffffffff21186|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 21186,
						},
						["icon"] = "Interface\\Icons\\Ability_Rogue_FanofKnives",
					},
					["Mutilate"] = {
						[-2] = {
							["time"] = "|cffffffff12/01/12 08:14:54|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:5374:SPELL_DAMAGE|h|cffffffffMutilate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F14600001614:Crypt Guardian|hCrypt Guardian|h |cffffffff24559|r |cffffffffPhysical|r. ",
							["amount"] = 24559,
						},
						[2] = {
							["time"] = "|cffffffff12/06/12 11:42:37|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:5374:SPELL_DAMAGE|h|cffffffffMutilate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F14600002431:Crypt Guardian|hCrypt Guardian|h |cffffffff43157|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 43157,
						},
						["icon"] = "Interface\\Icons\\Ability_DualWield",
					},
					["Shiv"] = {
						[-2] = {
							["time"] = "|cffffffff12/01/12 08:18:11|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:5938:SPELL_DAMAGE|h|cffffffffShiv|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F239000014B3:Shadows of Anger|hShadows of Anger|h |cffffffff1441|r |cffffffffPhysical|r. ",
							["amount"] = 1441,
						},
						[2] = {
							["time"] = "|cffffffff12/06/12 11:03:27|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:5938:SPELL_DAMAGE|h|cffffffffShiv|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E59E00000DEB:Theramore Gryphon|hTheramore Gryphon|h |cffffffff1831|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 1831,
						},
						["icon"] = "Interface\\Icons\\INV_ThrowingKnife_04",
					},
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff12/01/12 08:18:10|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF130F239000014B3:Shadows of Anger|hShadows of Anger|h |cffffffff14904|r |cffffffffPhysical|r. ",
							["amount"] = 14904,
						},
						[2] = {
							["time"] = "|cffffffff12/01/12 07:51:33|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF13106C000001025:Broodmaster Noshi|hBroodmaster Noshi|h |cffffffff24613|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 24613,
						},
					},
					["Crimson Tempest"] = {
						[-2] = {
							["time"] = "|cffffffff12/01/12 07:50:52|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:121411:SPELL_DAMAGE|h|cffffffffCrimson Tempest|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13106C000001025:Broodmaster Noshi|hBroodmaster Noshi|h |cffffffff11552|r |cffffffffPhysical|r. ",
							["amount"] = 11552,
						},
						[2] = {
							["time"] = "|cffffffff12/01/12 07:49:30|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:121411:SPELL_DAMAGE|h|cffffffffCrimson Tempest|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13106B700000FFA:Darkhatched Shaman|hDarkhatched Shaman|h |cffffffff12508|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 12508,
						},
						["icon"] = "Interface\\Icons\\inv_knife_1h_cataclysm_c_05",
					},
					["Set Fire"] = {
						[-2] = {
							["time"] = "|cffffffff11/26/12 01:56:41|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:118103:SPELL_PERIODIC_DAMAGE|h|cffffffffSet Fire|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130EE0400624497:Ashfang Hyena|hAshfang Hyena|h |cffffffff13350|r |cffffffffFire|r. ",
							["amount"] = 13350,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Torch_Lit",
					},
					["Throw"] = {
						[-2] = {
							["time"] = "|cffffffff12/01/12 07:53:08|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Haction:RANGE_DAMAGE|h|cffffffffThrow|r|h |Haction:RANGE_DAMAGE|hhit|h |Hunit:0xF13106C000001025:Broodmaster Noshi|hBroodmaster Noshi|h |cffffffff627|r |cffffffffPhysical|r. ",
							["amount"] = 627,
						},
						[2] = {
							["time"] = "|cffffffff11/26/12 01:09:16|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Haction:RANGE_DAMAGE|h|cffffffffThrow|r|h |Haction:RANGE_DAMAGE|hhit|h |Hunit:0xF130ECE70061A4D9:Osul Sharphorn|hOsul Sharphorn|h |cffffffff1098|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 1098,
						},
					},
					["Wound Poison"] = {
						[-2] = {
							["time"] = "|cffffffff12/06/12 10:56:52|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:8680:SPELL_DAMAGE|h|cffffffffWound Poison|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E57300001415:Borokhula the Destroyer|hBorokhula the Destroyer|h |cffffffff7207|r |cffffffffNature|r. ",
							["amount"] = 7207,
						},
						[2] = {
							["time"] = "|cffffffff12/06/12 10:56:56|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:8680:SPELL_DAMAGE|h|cffffffffWound Poison|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E57300001415:Borokhula the Destroyer|hBorokhula the Destroyer|h |cffffffff14358|r |cffffffffNature|r. (Critical) ",
							["amount"] = 14358,
						},
						["icon"] = "Interface\\Icons\\INV_Misc_Herb_16",
					},
					["Garrote"] = {
						[-2] = {
							["time"] = "|cffffffff11/26/12 02:23:06|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:703:SPELL_PERIODIC_DAMAGE|h|cffffffffGarrote|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130EFBE006243D3:Krik'thik Deep-Scout|hKrik'thik Deep-Scout|h |cffffffff4688|r |cffffffffPhysical|r. ",
							["amount"] = 4688,
						},
						[2] = {
							["time"] = "|cffffffff11/26/12 01:34:27|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:703:SPELL_PERIODIC_DAMAGE|h|cffffffffGarrote|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130ED190061C254:Osul Mist-Shaman|hOsul Mist-Shaman|h |cffffffff8827|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 8827,
						},
						["icon"] = "Interface\\Icons\\Ability_Rogue_Garrote",
					},
					["Reaver Bombs"] = {
						[-2] = {
							["time"] = "|cffffffff12/01/12 08:41:49|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:135219:SPELL_DAMAGE|h|cffffffffReaver Bombs|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13106E900015678:Knight of the Lion|hKnight of the Lion|h |cffffffff83985|r |cffffffffFire|r. ",
							["amount"] = 83985,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Misc_Bomb_02",
					},
					["Touch of the Grave"] = {
						[-2] = {
							["time"] = "|cffffffff12/01/12 07:50:53|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:127802:SPELL_DAMAGE|h|cffffffffTouch of the Grave|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13106C000001025:Broodmaster Noshi|hBroodmaster Noshi|h |cffffffff38712|r |cffffffffShadow|r. ",
							["amount"] = 38712,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_FingerOfDeath",
					},
				},
				["heal"] = {
					["Touch of the Grave"] = {
						[-2] = {
							["time"] = "|cffffffff12/01/12 07:50:54|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:127802:SPELL_HEAL|h|cffffffffTouch of the Grave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffffffff0|r |cffffffffShadow|r. (38712 Overhealed) ",
							["amount"] = 38712,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_FingerOfDeath",
					},
					["Leech Vitality"] = {
						[-2] = {
							["time"] = "|cffffffff12/14/12 07:54:38|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:116921:SPELL_HEAL|h|cffffffffLeech Vitality|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffffffff0|r |cffffffffNature|r. (18096 Overhealed) ",
							["amount"] = 18096,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\rogue_leeching_poison",
					},
					["First Aid"] = {
						[-2] = {
							["time"] = "|cffffffff11/26/12 01:09:52|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:102695:SPELL_PERIODIC_HEAL|h|cffffffffFirst Aid|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffffffff19495|r |cffffffffPhysical|r. ",
							["amount"] = 19495,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Heal",
					},
					["Mogu Power"] = {
						[-2] = {
							["time"] = "|cffffffff12/01/12 07:49:19|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:133475:SPELL_PERIODIC_HEAL|h|cffffffffMogu Power|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffffffff20198|r |cffffffffNature|r. (8842 Overhealed) ",
							["amount"] = 29040,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\spell_mage_runeofpower",
					},
					["Hozenbane"] = {
						[-2] = {
							["time"] = "|cffffffff12/07/12 03:44:46|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:122373:SPELL_HEAL|h|cffffffffHozenbane|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffffffff0|r |cffffffffPhysical|r. (15228 Overhealed) ",
							["amount"] = 15228,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Achievement_BG_kill_flag_carrierEOS",
					},
					["Recuperate"] = {
						[-2] = {
							["time"] = "|cffffffff12/01/12 08:01:39|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:73651:SPELL_PERIODIC_HEAL|h|cffffffffRecuperate|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffffffff10455|r |cffffffffPhysical|r. ",
							["amount"] = 10455,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\ability_rogue_recuperate",
					},
					["Cintron-Infused Bandage"] = {
						[-2] = {
							["time"] = "|cffffffff11/26/12 02:44:36|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:120573:SPELL_PERIODIC_HEAL|h|cffffffffCintron-Infused Bandage|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0xF130F0FC0062E6E1:Injured Gao-Ran Blackguard|hInjured Gao-Ran Blackguard|h |cffffffff39395|r |cffffffffPhysical|r. ",
							["amount"] = 39395,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\inv_misc_bandage_frostweave",
					},
					["Leeching Poison"] = {
						[-2] = {
							["time"] = "|cffffffff12/06/12 11:42:41|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:112974:SPELL_HEAL|h|cffffffffLeeching Poison|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffffffff0|r |cffffffffNature|r. (8780 Overhealed) ",
							["amount"] = 8780,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\rogue_leeching_poison",
					},
					["Blanche's Elixir of Replenishment"] = {
						[-2] = {
							["time"] = "|cffffffff12/06/12 10:50:32|r\n|Hunit:0x01000000002DEE9B:Stabsya|hYour|h |Hspell:121951:SPELL_PERIODIC_HEAL|h|cffffffffBlanche's Elixir of Replenishment|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffffffff0|r |cffffffffPhysical|r. (30017 Overhealed) ",
							["amount"] = 30017,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_healthsphere",
					},
				},
			}, -- [1]
			[-1] = {
				["hit"] = {
					["Shadow"] = {
						[-2] = {
							["time"] = "|cffffffff11/26/12 02:07:17|r\n|Hunit:0xF130EE7E00628816:Seething Hatred|hSeething Hatred|h |Hspell:124690:SPELL_DAMAGE|h|cffff1313Pure Hate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffff131341482|r |cffff1313Shadow|r. ",
							["amount"] = 41482,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 01:02:32|r\n|Hunit:0x0580000007F5AF04:Xkayne-Kel'Thuzad|hXkayne-Kel'Thuzad|h |Hspell:15407:SPELL_PERIODIC_DAMAGE|h|cffff1313Mind Flay|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffff131310491|r |cffff1313Shadow|r. (Critical) ",
							["amount"] = 10491,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_PsychicHorrors",
					},
					["Holy"] = {
						[-2] = {
							["time"] = "|cffffffff12/07/12 12:13:49|r\n|Hunit:0xF1310D8C00023436:Lion's Faithful|hLion's Faithful|h |Hspell:136098:SPELL_DAMAGE|h|cffff1313Holy Smite|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffff131322210|r |cffff1313Holy|r. ",
							["amount"] = 22210,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 12:01:00|r\n|Hunit:0x04800000020319EA:Mudkiipz-Agamaggan|hMudkiipz-Agamaggan|h |Hspell:31803:SPELL_PERIODIC_DAMAGE|h|cffff1313Censure|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffff13132264|r |cffff1313Holy|r. (Critical) ",
							["amount"] = 2264,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolySmite",
					},
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff11/30/12 11:29:38|r\n|Hunit:0xF130E5A800004377:Sabotaged Tank|hSabotaged Tank|h |Hspell:39531:SPELL_DAMAGE|h|cff82f4ffTank Explosion|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff100000|r |cff82f4ffFlamestrike|r. ",
							["amount"] = 100000,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 12:25:17|r\n|Hunit:0x0200000003D55566:Defiiled-Skullcrusher|hDefiiled-Skullcrusher|h |Hspell:44614:SPELL_DAMAGE|h|cffff1313Frostfire Bolt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffff131330035|r |cffff1313Frostfire|r. (Critical) ",
							["amount"] = 30035,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_shaman_improvedfirenova",
					},
					["Arcane"] = {
						[-2] = {
							["time"] = "|cffffffff12/06/12 11:10:01|r\n|Hunit:0xF130E8CC00000BC5:Theramore Arcanist|hTheramore Arcanist|h |Hspell:114683:SPELL_DAMAGE|h|cffff1313Arcane Blast|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffff131321666|r |cffff1313Arcane|r. ",
							["amount"] = 21666,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 12:45:21|r\n|Hunit:0x0200000006737C95:Kuotog-Elune|hKuotog-Elune|h |Hspell:3044:SPELL_DAMAGE|h|cffff1313Arcane Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffff131310373|r |cffff1313Arcane|r. (Critical) ",
							["amount"] = 10373,
						},
						["icon"] = "Interface\\Icons\\Spell_Arcane_Blast",
					},
					["Physical"] = {
						[-2] = {
							["time"] = "|cffffffff11/26/12 02:52:07|r\n|Haction:ENVIRONMENTAL_DAMAGE|h|cffffffffFalling|r|h |Haction:ENVIRONMENTAL_DAMAGE|hdamaged|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffffffff215953|r |cffffffffPhysical|r. ",
							["amount"] = 215953,
						},
						[2] = {
							["time"] = "|cffffffff12/01/12 07:40:19|r\n|Hunit:0xF13106E900000782:Knight of the Lion|hKnight of the Lion|h |Haction:SWING_DAMAGE|h|cffff1313Melee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffff131340364|r |cffff1313Physical|r. (Critical) ",
							["amount"] = 40364,
						},
					},
					["Fire"] = {
						[-2] = {
							["time"] = "|cffffffff12/01/12 08:37:07|r\n|Hunit:0xF1310D9000013417:A.C.E. Beamgunner|hA.C.E. Beamgunner|h |Hspell:135967:SPELL_DAMAGE|h|cffff1313Beam Rifle|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffff1313158707|r |cffff1313Fire|r. ",
							["amount"] = 158707,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 12:29:07|r\n|Hunit:0x0580000008097579:Astromus-Kel'Thuzad|hAstromus-Kel'Thuzad|h |Hspell:11366:SPELL_DAMAGE|h|cffff1313Pyroblast|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffff131340688|r |cffff1313Fire|r. (Critical) ",
							["amount"] = 40688,
						},
						["icon"] = "Interface\\Icons\\Spell_Arcane_ArcaneTorrent",
					},
					["Frost"] = {
						[-2] = {
							["time"] = "|cffffffff12/14/12 07:53:12|r\n|Hunit:0xF130DC80000171E5:Wise Mari|hWise Mari|h |Hspell:106334:SPELL_DAMAGE|h|cffff1313Wash Away|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffff131389936|r |cffff1313Frost|r. ",
							["amount"] = 89936,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 12:55:33|r\n|Hunit:0x0300000006D2387F:Valenzx-Tichondrius|hValenzx-Tichondrius|h |Hspell:113092:SPELL_DAMAGE|h|cffff1313Frost Bomb|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffff131336283|r |cffff1313Frost|r. (Critical) ",
							["amount"] = 36283,
						},
						["icon"] = "Interface\\Icons\\Spell_Frost_SummonWaterElemental",
					},
					["Nature"] = {
						[-2] = {
							["time"] = "|cffffffff12/01/12 08:16:24|r\n|Hspell:119748:SPELL_DAMAGE|h|cffff1313Lightning Trap|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffff1313118979|r |cffff1313Nature|r. ",
							["amount"] = 118979,
						},
						[2] = {
							["time"] = "|cffffffff12/17/12 05:47:18|r\n|Hspell:131143:SPELL_PERIODIC_DAMAGE|h|cffffffffBrew Bubble|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffffffff25010|r |cffffffffNature|r. (Critical) ",
							["amount"] = 25010,
						},
						["icon"] = "Interface\\Icons\\INV_Elemental_Primal_Life",
					},
				},
				["heal"] = {
					["Renew"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 09:12:13|r\n|Hunit:0x030000000789CCCC:Tanklord-Tichondrius|hTanklord-Tichondrius|h |Hspell:139:SPELL_PERIODIC_HEAL|h|cff82f4ffRenew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff11089|r |cff82f4ffHoly|r. ",
							["amount"] = 11089,
						},
						[2] = {
							["time"] = "|cffffffff02/10/13 09:12:18|r\n|Hunit:0x030000000789CCCC:Tanklord-Tichondrius|hTanklord-Tichondrius|h |Hspell:139:SPELL_PERIODIC_HEAL|h|cff82f4ffRenew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (22177 Overhealed) (Critical) ",
							["amount"] = 22177,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Renew",
					},
					["Holy Light"] = {
						[-2] = {
							["time"] = "|cffffffff11/21/12 11:47:37|r\n|Hunit:0x0680000004C4D4C0:Mythblaze-Quel'dorei|hMythblaze-Quel'dorei|h |Hspell:635:SPELL_HEAL|h|cff82f4ffHoly Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff18430|r |cff82f4ffHoly|r. ",
							["amount"] = 18430,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolyBolt",
					},
					["Holy Prism"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 12:58:53|r\n|Hunit:0x0180000004E5D38C:Lilithice-Feathermoon|hLilithice-Feathermoon|h |Hspell:114852:SPELL_HEAL|h|cff82f4ffHoly Prism|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (30390 Overhealed) ",
							["amount"] = 30390,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\spell_paladin_holyprism",
					},
					["Glyph of Power Word: Shield"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 09:12:10|r\n|Hunit:0x030000000789CCCC:Tanklord-Tichondrius|hTanklord-Tichondrius|h |Hspell:56160:SPELL_HEAL|h|cff82f4ffGlyph of Power Word: Shield|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff16761|r |cff82f4ffHoly|r. ",
							["amount"] = 16761,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Prayer of Mending"] = {
						[-2] = {
							["time"] = "|cffffffff12/14/12 07:50:27|r\n|Hunit:0x0300000006D8AA0F:Fuzzytaco-Kil'jaeden|hFuzzytaco-Kil'jaeden|h |Hspell:33110:SPELL_HEAL|h|cff82f4ffPrayer of Mending|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff14796|r |cff82f4ffHoly|r. ",
							["amount"] = 14796,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfMendingtga",
					},
					["Spinning Crane Kick"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 12:53:03|r\n|Hunit:0x030000000762D20B:Juicypoos-Tichondrius|hJuicypoos-Tichondrius|h |Hspell:117640:SPELL_HEAL|h|cff82f4ffSpinning Crane Kick|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (4739 Overhealed) ",
							["amount"] = 4739,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_cranekick_new",
					},
					["Surrounding Mist"] = {
						[-2] = {
							["time"] = "|cffffffff11/26/12 01:32:39|r\n|Hspell:125668:SPELL_PERIODIC_HEAL|h|cffffffffSurrounding Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffffffff3375|r |cffffffffPhysical|r. ",
							["amount"] = 3375,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_renewingmists",
					},
					["Blood Burst"] = {
						[-2] = {
							["time"] = "|cffffffff12/06/12 11:39:41|r\n|Hunit:0xF1306D7100009E9C:Bloodworm|hBloodworm|h |Hspell:81280:SPELL_HEAL|h|cff82f4ffBlood Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff32565|r |cff82f4ffShadow|r. ",
							["amount"] = 32565,
						},
						[2] = {
							["time"] = "|cffffffff12/01/12 07:52:24|r\n|Hunit:0xF1306D710000156E:Bloodworm|hBloodworm|h |Hspell:81280:SPELL_HEAL|h|cff82f4ffBlood Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff0|r |cff82f4ffShadow|r. (38237 Overhealed) (Critical) ",
							["amount"] = 38237,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_BloodNova",
					},
					["Mind Games"] = {
						[-2] = {
							["time"] = "|cffffffff12/07/12 12:15:04|r\n|Hunit:0xF13107DE0002342A:Priestess Laralla|hPriestess Laralla|h |Hspell:135507:SPELL_HEAL|h|cffff1313Mind Games|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cffff1313244|r |cffff1313Shadow|r. (318079 Overhealed) ",
							["amount"] = 318323,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_MentalQuickness",
					},
					["Halo"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 12:58:55|r\n|Hunit:0x0180000002448CCE:Evralla-Darkspear|hEvralla-Darkspear|h |Hspell:120692:SPELL_HEAL|h|cff82f4ffHalo|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (47150 Overhealed) ",
							["amount"] = 47150,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_priest_halo",
					},
					["Healing Rain"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 01:00:12|r\n|Hunit:0x03000000064E6EC8:Imasadpanda-Ner'zhul|hImasadpanda-Ner'zhul|h |Hspell:73921:SPELL_HEAL|h|cff82f4ffHealing Rain|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (3034 Overhealed) ",
							["amount"] = 3034,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 01:00:04|r\n|Hunit:0x03000000064E6EC8:Imasadpanda-Ner'zhul|hImasadpanda-Ner'zhul|h |Hspell:73921:SPELL_HEAL|h|cff82f4ffHealing Rain|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (5689 Overhealed) (Critical) ",
							["amount"] = 5689,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_GiftoftheWaterSpirit",
					},
					["Unleash Life"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 12:23:15|r\n|Hunit:0x0300000006D6F6F5:Mirathas-Frostmourne|hMirathas-Frostmourne|h |Hspell:73685:SPELL_HEAL|h|cff82f4ffUnleash Life|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff8225|r |cff82f4ffNature|r. ",
							["amount"] = 8225,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\spell_shaman_unleashweapon_life",
					},
					["Ancestral Awakening"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 12:25:58|r\n|Hunit:0x0300000006D6F6F5:Mirathas-Frostmourne|hMirathas-Frostmourne|h |Hspell:52752:SPELL_HEAL|h|cff82f4ffAncestral Awakening|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff8798|r |cff82f4ffNature|r. ",
							["amount"] = 8798,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_AncestralAwakening",
					},
					["Flash of Light"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 01:03:44|r\n|Hunit:0x020000000483B3FB:Lootitall-BleedingHollow|hLootitall-BleedingHollow|h |Hspell:19750:SPELL_HEAL|h|cff82f4ffFlash of Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff26717|r |cff82f4ffHoly|r. ",
							["amount"] = 26717,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 01:03:52|r\n|Hunit:0x020000000483B3FB:Lootitall-BleedingHollow|hLootitall-BleedingHollow|h |Hspell:19750:SPELL_HEAL|h|cff82f4ffFlash of Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff39733|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 39733,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Regrowth"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 12:57:21|r\n|Hunit:0x03000000060D764E:Talysmyn-Tichondrius|hTalysmyn-Tichondrius|h |Hspell:8936:SPELL_PERIODIC_HEAL|h|cff82f4ffRegrowth|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff1790|r |cff82f4ffNature|r. (945 Overhealed) ",
							["amount"] = 2735,
						},
						[2] = {
							["time"] = "|cffffffff02/10/13 12:57:19|r\n|Hunit:0x03000000060D764E:Talysmyn-Tichondrius|hTalysmyn-Tichondrius|h |Hspell:8936:SPELL_HEAL|h|cff82f4ffRegrowth|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff47261|r |cff82f4ffNature|r. (23330 Overhealed) (Critical) ",
							["amount"] = 70591,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_ResistNature",
					},
					["Healing Tide"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 01:03:21|r\n|Hunit:0x03000000064E6EC8:Imasadpanda-Ner'zhul|hImasadpanda-Ner'zhul|h |Hspell:114942:SPELL_HEAL|h|cff82f4ffHealing Tide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff0|r |cff82f4ffPhysical|r. (23218 Overhealed) ",
							["amount"] = 23218,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_shaman_healingtide",
					},
					["Holy Shock"] = {
						[-2] = {
							["time"] = "|cffffffff11/21/12 11:47:50|r\n|Hunit:0x0680000004C4D4C0:Mythblaze-Quel'dorei|hMythblaze-Quel'dorei|h |Hspell:25914:SPELL_HEAL|h|cff82f4ffHoly Shock|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff9419|r |cff82f4ffHoly|r. ",
							["amount"] = 9419,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 01:03:42|r\n|Hunit:0x020000000483B3FB:Lootitall-BleedingHollow|hLootitall-BleedingHollow|h |Hspell:25914:SPELL_HEAL|h|cff82f4ffHoly Shock|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff30224|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 30224,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SearingLight",
					},
					["Swiftmend"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 12:58:35|r\n|Hunit:0x03000000060D764E:Talysmyn-Tichondrius|hTalysmyn-Tichondrius|h |Hspell:81269:SPELL_HEAL|h|cff82f4ffSwiftmend|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff3233|r |cff82f4ffNature|r. (2590 Overhealed) ",
							["amount"] = 5823,
						},
						[2] = {
							["time"] = "|cffffffff02/10/13 12:58:31|r\n|Hunit:0x03000000060D764E:Talysmyn-Tichondrius|hTalysmyn-Tichondrius|h |Hspell:81269:SPELL_HEAL|h|cff82f4ffSwiftmend|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff1865|r |cff82f4ffNature|r. (9780 Overhealed) (Critical) ",
							["amount"] = 11645,
						},
						["icon"] = "Interface\\Icons\\INV_Misc_Herb_TalandrasRose",
					},
					["Revival"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 12:54:09|r\n|Hunit:0x030000000762D20B:Juicypoos-Tichondrius|hJuicypoos-Tichondrius|h |Hspell:115310:SPELL_HEAL|h|cff82f4ffRevival|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff19761|r |cff82f4ffNature|r. (36023 Overhealed) ",
							["amount"] = 55784,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_BlessingOfEternals",
					},
					["Healing Wave"] = {
						[-2] = {
							["time"] = "|cffffffff12/01/12 07:44:48|r\n|Hunit:0xF131075600000CA0:Vol'jin|hVol'jin|h |Hspell:133033:SPELL_HEAL|h|cff82f4ffHealing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff87118|r |cff82f4ffNature|r. ",
							["amount"] = 87118,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 12:25:56|r\n|Hunit:0x0300000006D6F6F5:Mirathas-Frostmourne|hMirathas-Frostmourne|h |Hspell:331:SPELL_HEAL|h|cff82f4ffHealing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff34504|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 34504,
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_TidalWaves",
					},
					["Prayer of Healing"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 09:13:27|r\n|Hunit:0x030000000789CCCC:Tanklord-Tichondrius|hTanklord-Tichondrius|h |Hspell:596:SPELL_HEAL|h|cff82f4ffPrayer of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff447|r |cff82f4ffHoly|r. (28985 Overhealed) ",
							["amount"] = 29432,
						},
						[2] = {
							["time"] = "|cffffffff02/10/13 09:13:40|r\n|Hunit:0x030000000789CCCC:Tanklord-Tichondrius|hTanklord-Tichondrius|h |Hspell:596:SPELL_HEAL|h|cff82f4ffPrayer of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (61338 Overhealed) (Critical) ",
							["amount"] = 61338,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfHealing02",
					},
					["Mistweaving"] = {
						[-2] = {
							["time"] = "|cffffffff12/01/12 08:07:25|r\n|Hunit:0xF130FF0F00001B7C:Mistweaver Nian|hMistweaver Nian|h |Hspell:125125:SPELL_PERIODIC_HEAL|h|cff82f4ffMistweaving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff8599|r |cff82f4ffNature|r. (34960 Overhealed) ",
							["amount"] = 43559,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_soothingmists",
					},
					["Wild Growth"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 12:58:45|r\n|Hunit:0x03000000060D764E:Talysmyn-Tichondrius|hTalysmyn-Tichondrius|h |Hspell:48438:SPELL_PERIODIC_HEAL|h|cff82f4ffWild Growth|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff3926|r |cff82f4ffNature|r. ",
							["amount"] = 3926,
						},
						[2] = {
							["time"] = "|cffffffff02/10/13 12:58:20|r\n|Hunit:0x03000000060D764E:Talysmyn-Tichondrius|hTalysmyn-Tichondrius|h |Hspell:48438:SPELL_PERIODIC_HEAL|h|cff82f4ffWild Growth|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff7850|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 7850,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Flourish",
					},
					["Renewing Mist"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 12:53:11|r\n|Hunit:0x030000000762D20B:Juicypoos-Tichondrius|hJuicypoos-Tichondrius|h |Hspell:119611:SPELL_PERIODIC_HEAL|h|cff82f4ffRenewing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff7497|r |cff82f4ffNature|r. ",
							["amount"] = 7497,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 12:56:18|r\n|Hunit:0x030000000762D20B:Juicypoos-Tichondrius|hJuicypoos-Tichondrius|h |Hspell:119611:SPELL_PERIODIC_HEAL|h|cff82f4ffRenewing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff2931|r |cff82f4ffNature|r. (9443 Overhealed) (Critical) ",
							["amount"] = 12374,
						},
						["icon"] = "Interface\\Icons\\ability_monk_renewingmists",
					},
					["Earthliving"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 12:23:18|r\n|Hunit:0x0300000006D6F6F5:Mirathas-Frostmourne|hMirathas-Frostmourne|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff2342|r |cff82f4ffNature|r. ",
							["amount"] = 2342,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 12:27:56|r\n|Hunit:0x0300000006D6F6F5:Mirathas-Frostmourne|hMirathas-Frostmourne|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (3195 Overhealed) (Critical) ",
							["amount"] = 3195,
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_GiftEarthmother",
					},
					["Soothing Mist"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 12:56:10|r\n|Hunit:0x030000000762D20B:Juicypoos-Tichondrius|hJuicypoos-Tichondrius|h |Hspell:115175:SPELL_PERIODIC_HEAL|h|cff82f4ffSoothing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff6934|r |cff82f4ffNature|r. ",
							["amount"] = 6934,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 12:46:24|r\n|Hunit:0x030000000762D20B:Juicypoos-Tichondrius|hJuicypoos-Tichondrius|h |Hspell:115175:SPELL_PERIODIC_HEAL|h|cff82f4ffSoothing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff9742|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 9742,
						},
						["icon"] = "Interface\\Icons\\ability_monk_soothingmists",
					},
					["Word of Glory"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 01:03:49|r\n|Hunit:0x020000000483B3FB:Lootitall-BleedingHollow|hLootitall-BleedingHollow|h |Hspell:130551:SPELL_HEAL|h|cff82f4ffWord of Glory|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff26383|r |cff82f4ffHoly|r. ",
							["amount"] = 26383,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\inv_helmet_96",
					},
					["Riptide"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 12:53:42|r\n|Hunit:0x0300000006D6F6F5:Mirathas-Frostmourne|hMirathas-Frostmourne|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff7001|r |cff82f4ffNature|r. ",
							["amount"] = 7001,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 12:28:03|r\n|Hunit:0x0300000006D6F6F5:Mirathas-Frostmourne|hMirathas-Frostmourne|h |Hspell:61295:SPELL_PERIODIC_HEAL|h|cff82f4ffRiptide|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (7261 Overhealed) (Critical) ",
							["amount"] = 7261,
						},
						["icon"] = "Interface\\Icons\\spell_nature_riptide",
					},
					["Vampiric Embrace"] = {
						[-2] = {
							["time"] = "|cffffffff11/21/12 11:55:38|r\n|Hunit:0x0480000004B58AF0:Welfarechild-EmeraldDream|hWelfarechild-EmeraldDream|h |Hspell:15290:SPELL_PERIODIC_HEAL|h|cff82f4ffVampiric Embrace|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff3723|r |cff82f4ffShadow|r. ",
							["amount"] = 3723,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_UnsummonBuilding",
					},
					["Bandage"] = {
						[-2] = {
							["time"] = "|cffffffff12/07/12 12:13:25|r\n|Hunit:0xF1310D8800022E41:Shademaster Kiryn|hShademaster Kiryn|h |Hspell:36348:SPELL_PERIODIC_HEAL|h|cff82f4ffBandage|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff17083|r |cff82f4ffPhysical|r. ",
							["amount"] = 17083,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Heal",
					},
					["Enveloping Mist"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 12:56:21|r\n|Hunit:0x030000000762D20B:Juicypoos-Tichondrius|hJuicypoos-Tichondrius|h |Hspell:132120:SPELL_PERIODIC_HEAL|h|cff82f4ffEnveloping Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (19201 Overhealed) ",
							["amount"] = 19201,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_SpiritLink",
					},
					["Surging Mist"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 12:56:10|r\n|Hunit:0x030000000762D20B:Juicypoos-Tichondrius|hJuicypoos-Tichondrius|h |Hspell:116995:SPELL_HEAL|h|cff82f4ffSurging Mist|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff59004|r |cff82f4ffNature|r. ",
							["amount"] = 59004,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_surgingmist",
					},
					["Rejuvenation"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 12:58:24|r\n|Hunit:0x03000000060D764E:Talysmyn-Tichondrius|hTalysmyn-Tichondrius|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cff82f4ffRejuvenation|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff3440|r |cff82f4ffNature|r. (11259 Overhealed) ",
							["amount"] = 14699,
						},
						[2] = {
							["time"] = "|cffffffff02/10/13 12:57:58|r\n|Hunit:0x03000000060D764E:Talysmyn-Tichondrius|hTalysmyn-Tichondrius|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cff82f4ffRejuvenation|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff29397|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 29397,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Rejuvenation",
					},
					["Atonement"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 12:57:50|r\n|Hunit:0x0180000002448CCE:Evralla-Darkspear|hEvralla-Darkspear|h |Hspell:81751:SPELL_HEAL|h|cff82f4ffAtonement|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff40704|r |cff82f4ffHoly|r. (18749 Overhealed) ",
							["amount"] = 59453,
						},
						[2] = {
							["time"] = "|cffffffff11/21/12 11:41:13|r\n|Hunit:0x0380000005901DEB:Sublimé-Draka|hSublimé-Draka|h |Hspell:94472:SPELL_HEAL|h|cff82f4ffAtonement|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (13730 Overhealed) (Critical) ",
							["amount"] = 13730,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_CircleOfRenewal",
					},
					["Living Seed"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 12:57:24|r\n|Hunit:0x03000000060D764E:Talysmyn-Tichondrius|hTalysmyn-Tichondrius|h |Hspell:48503:SPELL_HEAL|h|cff82f4ffLiving Seed|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000002DEE9B:Stabsya|hYou|h |cff82f4ff20099|r |cff82f4ffNature|r. (2137 Overhealed) ",
							["amount"] = 22236,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_GiftoftheEarthmother",
					},
				},
			},
		},
	},
}
