
FishingBuddy_Player = {
	["MinimapData"] = {
		["minimapPos"] = 94.80400730438629,
		["hide"] = false,
	},
	["Settings"] = {
		["ResetWatcher"] = 1,
		["OutfitManager"] = "None",
	},
	["WasWearing"] = {
	},
	["Outfit"] = {
	},
}
