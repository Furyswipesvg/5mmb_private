
REFDatabase = {
	{
		["MapInfo"] = "ArathiBasin",
		["HK"] = 9,
		["SpecialFields"] = {
			0, -- [1]
			0, -- [2]
		},
		["HordeNum"] = 15,
		["PlaceKB"] = 11,
		["PlaceFactionDamage"] = 10,
		["MMRChange"] = 0,
		["KB"] = 1,
		["PlaceFactionKB"] = 7,
		["PlaceHonor"] = 8,
		["PlaceFactionHonor"] = 8,
		["AllianceNum"] = 15,
		["PlaceHK"] = 18,
		["DataVersion"] = 18,
		["MapName"] = "Arathi Basin",
		["Honor"] = 29,
		["TalentSet"] = 1,
		["Healing"] = 5604,
		["PlaceDamage"] = 17,
		["PlaceHealing"] = 28,
		["PlaceFactionHealing"] = 14,
		["DurationRaw"] = 623,
		["PreMMR"] = 0,
		["IsRated"] = false,
		["PlaceFactionHK"] = 9,
		["Winner"] = "Horde",
		["Damage"] = 552165,
		["TimeRaw"] = 1353570210,
	}, -- [1]
	{
		["MapInfo"] = "ArathiBasin",
		["HK"] = 53,
		["SpecialFields"] = {
			0, -- [1]
			0, -- [2]
		},
		["HordeNum"] = 15,
		["PlaceKB"] = 5,
		["PlaceFactionDamage"] = 7,
		["MMRChange"] = 0,
		["KB"] = 6,
		["PlaceFactionKB"] = 4,
		["PlaceHonor"] = 1,
		["PlaceFactionHonor"] = 1,
		["AllianceNum"] = 15,
		["PlaceHK"] = 1,
		["DataVersion"] = 18,
		["MapName"] = "Arathi Basin",
		["Honor"] = 64,
		["TalentSet"] = 1,
		["Healing"] = 96537,
		["PlaceDamage"] = 17,
		["PlaceHealing"] = 22,
		["PlaceFactionHealing"] = 12,
		["DurationRaw"] = 1297,
		["PreMMR"] = 0,
		["IsRated"] = false,
		["PlaceFactionHK"] = 1,
		["Winner"] = "Horde",
		["Damage"] = 1228718,
		["TimeRaw"] = 1353571550,
	}, -- [2]
	{
		["MapInfo"] = "ArathiBasin",
		["HK"] = 62,
		["PlaceFactionKB"] = 5,
		["HordeNum"] = 15,
		["AllianceNum"] = 15,
		["DataVersion"] = 18,
		["MMRChange"] = 0,
		["KB"] = 6,
		["SpecialFields"] = {
			0, -- [1]
			0, -- [2]
		},
		["PlaceHonor"] = 2,
		["PlaceFactionHonor"] = 1,
		["Damage"] = 961860,
		["PlaceDamage"] = 19,
		["PlaceFactionDamage"] = 9,
		["PlaceFactionHK"] = 1,
		["Honor"] = 50,
		["TalentSet"] = 1,
		["Healing"] = 12614,
		["MapName"] = "Arathi Basin",
		["PlaceHealing"] = 29,
		["DurationRaw"] = 1130,
		["PlaceFactionHealing"] = 14,
		["PreMMR"] = 0,
		["IsRated"] = false,
		["PlaceHK"] = 1,
		["Winner"] = "Alliance",
		["PlaceKB"] = 6,
		["TimeRaw"] = 1353573449,
	}, -- [3]
	{
		["MapInfo"] = "ArathiBasin",
		["HK"] = 40,
		["PlaceFactionKB"] = 5,
		["HordeNum"] = 15,
		["AllianceNum"] = 15,
		["DataVersion"] = 18,
		["MMRChange"] = 0,
		["KB"] = 5,
		["SpecialFields"] = {
			2, -- [1]
			0, -- [2]
		},
		["PlaceHonor"] = 6,
		["PlaceFactionHonor"] = 1,
		["Damage"] = 1024753,
		["PlaceDamage"] = 21,
		["PlaceFactionDamage"] = 11,
		["PlaceFactionHK"] = 1,
		["Honor"] = 51,
		["TalentSet"] = 1,
		["Healing"] = 100806,
		["MapName"] = "Arathi Basin",
		["PlaceHealing"] = 26,
		["DurationRaw"] = 1204,
		["PlaceFactionHealing"] = 14,
		["PreMMR"] = 0,
		["IsRated"] = false,
		["PlaceHK"] = 9,
		["Winner"] = "Alliance",
		["PlaceKB"] = 10,
		["TimeRaw"] = 1353574725,
	}, -- [4]
}
REFSettings = {
	["ArenaSupport"] = true,
	["MiniBarScale"] = 1,
	["MiniBarAnchor"] = "CENTER",
	["OnlyNew"] = false,
	["LastDay"] = "10",
	["LastDayStats"] = {
		["MMR"] = 0,
		["MMRBG"] = 0,
		["RBG"] = 0,
		["Honor"] = 3866,
		["5v5"] = 0,
		["CP"] = 100,
		["3v3"] = 0,
		["2v2"] = 0,
	},
	["RBGListFirstTime"] = true,
	["ShowMiniBar"] = false,
	["LDBBGMorph"] = true,
	["RBGSupport"] = true,
	["CurrentMMR"] = 0,
	["UNBGSupport"] = true,
	["LDBHK"] = false,
	["MinimapPos"] = 45,
	["MiniBarVisible"] = {
		{
			["HonorKills"] = 1,
			["KillingBlows"] = 1,
			["Healing"] = 2,
			["Damage"] = 2,
		}, -- [1]
		{
			["HonorKills"] = 1,
			["KillingBlows"] = 1,
			["Healing"] = 2,
			["Damage"] = 2,
		}, -- [2]
	},
	["AllowQuery"] = true,
	["ShowDetectedBuilds"] = true,
	["LDBShowTotalBG"] = false,
	["LDBCPCap"] = true,
	["CurrentMMRBG"] = 0,
	["LDBShowTotalArena"] = false,
	["MiniBarX"] = 0,
	["ArenasListFirstTime"] = true,
	["ShowMinimapButton"] = true,
	["LDBShowQueues"] = true,
	["Version"] = 19,
	["MiniBarY"] = 0,
	["LDBShowPlace"] = false,
	["MiniBarOrder"] = {
		{
			"KillingBlows", -- [1]
			"HonorKills", -- [2]
			"Damage", -- [3]
			"Healing", -- [4]
			"Deaths", -- [5]
			"KDRatio", -- [6]
			"Honor", -- [7]
		}, -- [1]
		{
			"KillingBlows", -- [1]
			"HonorKills", -- [2]
			"Damage", -- [3]
			"Healing", -- [4]
			"Deaths", -- [5]
			"KDRatio", -- [6]
			"Honor", -- [7]
		}, -- [2]
	},
}
REFDatabaseA = {
}
