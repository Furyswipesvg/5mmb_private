
RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
		["Müu-Jubei'Thos"] = {
			["GUID"] = "0x03800000049F242F",
			["LastEventHealth"] = {
				"398666 (100%)", -- [1]
				"398666 (100%)", -- [2]
				"398666 (100%)", -- [3]
				"398666 (100%)", -- [4]
				"398666 (100%)", -- [5]
				"398666 (100%)", -- [6]
				"398666 (100%)", -- [7]
				"398666 (100%)", -- [8]
				"398666 (100%)", -- [9]
				"398666 (100%)", -- [10]
				"398666 (100%)", -- [11]
				"398666 (100%)", -- [12]
				"398459 (99%)", -- [13]
				"398459 (99%)", -- [14]
				"398666 (100%)", -- [15]
				"398666 (100%)", -- [16]
				"398666 (100%)", -- [17]
				"398666 (100%)", -- [18]
				"398666 (100%)", -- [19]
				"398666 (100%)", -- [20]
				"398666 (100%)", -- [21]
				"398666 (100%)", -- [22]
				"398666 (100%)", -- [23]
				"398666 (100%)", -- [24]
				"398666 (100%)", -- [25]
				"398666 (100%)", -- [26]
				"398666 (100%)", -- [27]
				"398666 (100%)", -- [28]
				"396243 (99%)", -- [29]
				"396243 (99%)", -- [30]
				"396243 (99%)", -- [31]
				"384251 (96%)", -- [32]
				"381665 (95%)", -- [33]
				"381665 (95%)", -- [34]
				"379305 (95%)", -- [35]
				"379305 (95%)", -- [36]
				"379305 (95%)", -- [37]
				"379305 (95%)", -- [38]
				"398666 (100%)", -- [39]
				"398666 (100%)", -- [40]
				"398666 (100%)", -- [41]
				"398666 (100%)", -- [42]
				"398666 (100%)", -- [43]
				"398666 (100%)", -- [44]
				"398666 (100%)", -- [45]
				"398666 (100%)", -- [46]
				"398666 (100%)", -- [47]
				"398666 (100%)", -- [48]
				"398666 (100%)", -- [49]
				"398666 (100%)", -- [50]
			},
			["LastAttackedBy"] = "Apothecary Frye",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"HEAL", -- [15]
				"DAMAGE", -- [16]
				"HEAL", -- [17]
				"HEAL", -- [18]
				"HEAL", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"HEAL", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					4.3, -- [1]
				},
				["Healing"] = {
					146633, -- [1]
				},
				["DamageTaken"] = {
					343271, -- [1]
				},
				["HealingTaken"] = {
					401285, -- [1]
				},
				["Overhealing"] = {
					124460, -- [1]
				},
				["ActiveTime"] = {
					106.97, -- [1]
				},
				["FDamage"] = {
					99666, -- [1]
				},
				["TimeDamage"] = {
					102.67, -- [1]
				},
				["DOT_Time"] = {
					207, -- [1]
				},
				["Damage"] = {
					3985963, -- [1]
				},
			},
			["enClass"] = "DEATHKNIGHT",
			["unit"] = "Müu",
			["TimeLast"] = {
				["TimeHeal"] = 1360559620,
				["OVERALL"] = 1360559620,
				["DamageTaken"] = 1360559604,
				["FDamage"] = 1360559558,
				["HealingTaken"] = 1360559620,
				["Overhealing"] = 1360559620,
				["TimeDamage"] = 1360559620,
				["Healing"] = 1360559620,
				["ActiveTime"] = 1360559620,
				["DOT_Time"] = 1360559617,
				["Damage"] = 1360559620,
			},
			["LastDamageTaken"] = 11992,
			["level"] = 90,
			["LastDamageAbility"] = "Melee",
			["LastFightIn"] = 1,
			["LastEventNum"] = {
				[33] = 0.6486632920790838,
				[35] = 0.5919742340706256,
				[39] = 6.992821058229194,
				[29] = 0.6077769360818329,
				[31] = 3.008031786006331,
				[17] = 0.2287629243527163,
				[18] = 14.65211480286756,
				[19] = 3.000005016730797,
				[15] = 3.000005016730797,
				[13] = 0.05192316375110995,
			},
			["type"] = "Ungrouped",
			["FightsSaved"] = 2,
			["GuardianReverseGUIDs"] = {
				["Risen Ally"] = {
					["LatestGuardian"] = 0,
					["GUIDs"] = {
						[0] = "0xF130660D0000CE8A",
					},
				},
			},
			["LastAbility"] = 19802.975,
			["Owner"] = false,
			["Pet"] = {
				"Risen Ally <Müu-Jubei'Thos>", -- [1]
			},
			["NextEventNum"] = 19,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				100, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				100, -- [11]
				100, -- [12]
				99.94807683624889, -- [13]
				99.94807683624889, -- [14]
				100, -- [15]
				100, -- [16]
				100, -- [17]
				100, -- [18]
				100, -- [19]
				100, -- [20]
				100, -- [21]
				100, -- [22]
				100, -- [23]
				100, -- [24]
				100, -- [25]
				100, -- [26]
				100, -- [27]
				100, -- [28]
				99.39222306391817, -- [29]
				99.39222306391817, -- [30]
				99.39222306391817, -- [31]
				96.38419127791184, -- [32]
				95.73552798583275, -- [33]
				95.73552798583275, -- [34]
				95.14355375176213, -- [35]
				95.14355375176213, -- [36]
				95.14355375176213, -- [37]
				95.14355375176213, -- [38]
				100, -- [39]
				100, -- [40]
				100, -- [41]
				100, -- [42]
				100, -- [43]
				100, -- [44]
				100, -- [45]
				100, -- [46]
				100, -- [47]
				100, -- [48]
				100, -- [49]
				100, -- [50]
			},
			["LastEvents"] = {
				"Müu-Jubei'Thos Frost Fever (DoT) Apothecary Frye Tick -5825 (Frost)", -- [1]
				"No One Concentrated Irresistible Cologne Spill Müu-Jubei'Thos Absorb (2456 Absorbed) (Nature)", -- [2]
				"Müu-Jubei'Thos Frost Strike Apothecary Frye Crit -59898 (Frost)", -- [3]
				"Müu-Jubei'Thos Melee Apothecary Frye Crit -28818 (Physical)", -- [4]
				"No One Concentrated Irresistible Cologne Spill Müu-Jubei'Thos Absorb (2576 Absorbed) (Nature)", -- [5]
				"No One Concentrated Irresistible Cologne Spill Müu-Jubei'Thos Absorb (2438 Absorbed) (Nature)", -- [6]
				"Müu-Jubei'Thos Frost Fever (DoT) Apothecary Frye Crit -12000 (Frost)", -- [7]
				"Müu-Jubei'Thos Howling Blast Apothecary Frye Hit -24834 (Frost)", -- [8]
				"Müu-Jubei'Thos Melee Apothecary Frye Hit -14929 (Physical)", -- [9]
				"No One Concentrated Irresistible Cologne Spill Müu-Jubei'Thos Absorb (2369 Absorbed) (Nature)", -- [10]
				"Müu-Jubei'Thos Soul Reaper Apothecary Frye Hit -83260 (Shadow)", -- [11]
				"Müu-Jubei'Thos Frost Strike Apothecary Frye Crit -54941 (Frost)", -- [12]
				"No One Concentrated Irresistible Cologne Spill Müu-Jubei'Thos Hit -207 (2272 Absorbed) (Nature)", -- [13]
				"Müu-Jubei'Thos Howling Blast Apothecary Frye Miss (Frost)", -- [14]
				"Müu-Jubei'Thos Unholy Strength Müu-Jubei'Thos Hit +11960 (11753 overheal)", -- [15]
				"Müu-Jubei'Thos Melee Apothecary Frye Hit -16768 (Physical)", -- [16]
				"Tanklord-Tichondrius Atonement Müu-Jubei'Thos Hit +912 (912 overheal)", -- [17]
				"Tanklord-Tichondrius Prayer of Healing Müu-Jubei'Thos Crit +58413 (58413 overheal)", -- [18]
				"Müu-Jubei'Thos Unholy Strength Müu-Jubei'Thos Hit +11960 (1158 overheal)", -- [19]
				"Müu-Jubei'Thos Melee Apothecary Frye Crit -36164 (Physical)", -- [20]
				"Müu-Jubei'Thos Frost Fever (DoT) Apothecary Frye Tick -5548 (Frost)", -- [21]
				"Müu-Jubei'Thos Soul Reaper Apothecary Frye Hit -18009 (Physical)", -- [22]
				"Müu-Jubei'Thos Melee Apothecary Frye Hit -19936 (Physical)", -- [23]
				"Müu-Jubei'Thos Frost Strike Apothecary Frye Hit -37274 (Frost)", -- [24]
				"Müu-Jubei'Thos Obliterate Apothecary Frye Crit -126497 (Physical)", -- [25]
				"Müu-Jubei'Thos Frost Fever (DoT) Apothecary Frye Tick -5826 (Frost)", -- [26]
				"Müu-Jubei'Thos Melee Apothecary Frye Hit -16595 (Physical)", -- [27]
				"Müu-Jubei'Thos Frost Strike Apothecary Frye Hit -33156 (Frost)", -- [28]
				"No One Concentrated Irresistible Cologne Spill Müu-Jubei'Thos Hit -2423 (Nature)", -- [29]
				"Müu-Jubei'Thos Frost Strike Apothecary Frye Crit -66769 (Frost)", -- [30]
				"Apothecary Frye Melee Müu-Jubei'Thos Hit -11992 (Physical)", -- [31]
				"Müu-Jubei'Thos Melee Apothecary Frye Glancing -15769 (Physical)", -- [32]
				"No One Concentrated Irresistible Cologne Spill Müu-Jubei'Thos Hit -2586 (Nature)", -- [33]
				"Müu-Jubei'Thos Frost Fever (DoT) Apothecary Frye Tick -5825 (Frost)", -- [34]
				"No One Concentrated Irresistible Cologne Spill Müu-Jubei'Thos Hit -2360 (Nature)", -- [35]
				"Müu-Jubei'Thos Soul Reaper Apothecary Frye Hit -16932 (Physical)", -- [36]
				"Müu-Jubei'Thos Melee Apothecary Frye Hit -19809 (Physical)", -- [37]
				"Müu-Jubei'Thos Obliterate Apothecary Frye Hit -67503 (Physical)", -- [38]
				"Tanklord-Tichondrius Prayer of Healing Müu-Jubei'Thos Hit +27878 (8517 overheal)", -- [39]
				"Müu-Jubei'Thos Frost Strike Apothecary Frye Hit -33156 (Frost)", -- [40]
				"Müu-Jubei'Thos Frost Fever (DoT) Apothecary Frye Tick -5826 (Frost)", -- [41]
				"No One Concentrated Alluring Perfume Spill Müu-Jubei'Thos Absorb (2380 Absorbed) (Nature)", -- [42]
				"No One Concentrated Alluring Perfume Spill Müu-Jubei'Thos Absorb (2509 Absorbed) (Nature)", -- [43]
				"Müu-Jubei'Thos Melee Apothecary Frye Crit -30126 (Physical)", -- [44]
				"No One Concentrated Alluring Perfume Spill Müu-Jubei'Thos Absorb (2396 Absorbed) (Nature)", -- [45]
				"Müu-Jubei'Thos Howling Blast Apothecary Frye Hit -28429 (Frost)", -- [46]
				"Müu-Jubei'Thos Frost Fever (DoT) Apothecary Frye Tick -5825 (Frost)", -- [47]
				"Müu-Jubei'Thos Soul Reaper Apothecary Frye Crit -170771 (Shadow)", -- [48]
				"Müu-Jubei'Thos Soul Reaper Apothecary Frye Hit -16432 (Physical)", -- [49]
				"Müu-Jubei'Thos Melee Apothecary Frye Crit -33915 (Physical)", -- [50]
			},
			["Name"] = "Müu-Jubei'Thos",
			["LastEventIncoming"] = {
				false, -- [1]
				true, -- [2]
				false, -- [3]
				false, -- [4]
				true, -- [5]
				true, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				true, -- [10]
				false, -- [11]
				false, -- [12]
				true, -- [13]
				false, -- [14]
				true, -- [15]
				false, -- [16]
				true, -- [17]
				true, -- [18]
				true, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				true, -- [29]
				false, -- [30]
				true, -- [31]
				false, -- [32]
				true, -- [33]
				false, -- [34]
				true, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				true, -- [39]
				false, -- [40]
				false, -- [41]
				true, -- [42]
				true, -- [43]
				false, -- [44]
				true, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				19797.304, -- [1]
				19797.51, -- [2]
				19797.909, -- [3]
				19798.023, -- [4]
				19798.718, -- [5]
				19799.52, -- [6]
				19800.314, -- [7]
				19800.335, -- [8]
				19800.5, -- [9]
				19800.729, -- [10]
				19801.15, -- [11]
				19801.15, -- [12]
				19801.532, -- [13]
				19802.113, -- [14]
				19802.975, -- [15]
				19802.975, -- [16]
				19803.136, -- [17]
				19803.136, -- [18]
				19782.196, -- [19]
				19782.196, -- [20]
				19782.311, -- [21]
				19782.987, -- [22]
				19784.103, -- [23]
				19784.21, -- [24]
				19785.012, -- [25]
				19785.305, -- [26]
				19786.001, -- [27]
				19786.215, -- [28]
				19787.017, -- [29]
				19787.017, -- [30]
				19787.273, -- [31]
				19787.897, -- [32]
				19788.229, -- [33]
				19788.299, -- [34]
				19789.033, -- [35]
				19789.033, -- [36]
				19789.788, -- [37]
				19790.249, -- [38]
				19790.249, -- [39]
				19791.064, -- [40]
				19791.299, -- [41]
				19791.447, -- [42]
				19792.255, -- [43]
				19793.076, -- [44]
				19793.482, -- [45]
				19793.482, -- [46]
				19794.3, -- [47]
				19794.685, -- [48]
				19795.496, -- [49]
				19795.548, -- [50]
			},
			["Fights"] = {
				["Fight2"] = {
					["TimeSpent"] = {
						["Corpse Eater"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 23373,
								},
							},
							["amount"] = 23373,
						},
					},
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["Attacks"] = {
						["Howling Blast"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 21594,
									["min"] = 17275,
									["count"] = 2,
									["amount"] = 38869,
								},
							},
							["count"] = 2,
							["amount"] = 38869,
						},
					},
					["HealingTaken"] = 23373,
					["DamagedWho"] = {
						["Corpse Eater"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 17275,
								},
							},
							["amount"] = 17275,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 21594,
								},
							},
							["amount"] = 21594,
						},
					},
					["ActiveTime"] = 3.5,
					["TimeDamaging"] = {
						["Corpse Eater"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Frost"] = 38869,
					},
					["TimeDamage"] = 3.5,
					["Damage"] = 38869,
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 66,
								},
								["Apothecary Hummel"] = {
									["count"] = 66,
								},
								["Apothecary Baxter"] = {
									["count"] = 45,
								},
							},
							["amount"] = 177,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Apothecary Hummel"] = {
									["count"] = 30,
								},
							},
							["amount"] = 30,
						},
					},
					["ShieldedWho"] = {
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Anti-Magic Shell"] = {
									["count"] = 1,
								},
								["Pillar of Frost"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 343271,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 3,
						},
						["Nature"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Absorb"] = {
									["count"] = 22,
								},
								["Tick"] = {
									["count"] = 11,
								},
								["Hit"] = {
									["count"] = 38,
								},
							},
							["amount"] = 72,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 12,
								},
							},
							["amount"] = 16,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 39,
								},
								["Miss"] = {
									["count"] = 2,
								},
								["Tick"] = {
									["count"] = 54,
								},
								["Crit"] = {
									["count"] = 15,
								},
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 111,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 6,
								},
								["Miss"] = {
									["count"] = 3,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 19,
								},
							},
							["amount"] = 34,
						},
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 10,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 27,
								},
							},
							["amount"] = 43,
						},
					},
					["ElementTakenAbsorb"] = {
						["Nature"] = 70739,
					},
					["ElementTaken"] = {
						["Melee"] = 27066,
						["Nature"] = 316205,
					},
					["DOT_Time"] = 207,
					["Damage"] = 3919669,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 4.3,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
						["Death Pact"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 99666,
									["min"] = 99666,
									["count"] = 1,
									["amount"] = 99666,
								},
							},
							["count"] = 1,
							["amount"] = 99666,
						},
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Physical"] = 839246,
						["Frost"] = 2063358,
						["Melee"] = 613471,
						["Shadow"] = 403594,
					},
					["PartialAbsorb"] = {
						["Alluring Perfume"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 17,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1944,
									["min"] = 1620,
									["count"] = 5,
									["amount"] = 9290,
								},
							},
							["count"] = 22,
							["amount"] = 9290,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 2595,
									["min"] = 2369,
									["count"] = 6,
									["amount"] = 14978,
								},
							},
							["count"] = 6,
							["amount"] = 14978,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 2509,
									["min"] = 2380,
									["count"] = 3,
									["amount"] = 7285,
								},
							},
							["count"] = 3,
							["amount"] = 7285,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 21,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1950,
									["min"] = 1636,
									["count"] = 7,
									["amount"] = 12647,
								},
							},
							["count"] = 28,
							["amount"] = 12647,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 21945,
									["min"] = 21945,
									["count"] = 1,
									["amount"] = 21945,
								},
							},
							["count"] = 2,
							["amount"] = 21945,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 4594,
									["min"] = 4594,
									["count"] = 1,
									["amount"] = 4594,
								},
							},
							["count"] = 8,
							["amount"] = 4594,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Soul Reaper"] = {
									["count"] = 305404,
								},
								["Howling Blast"] = {
									["count"] = 241149,
								},
								["Melee"] = {
									["count"] = 232829,
								},
								["Death and Decay"] = {
									["count"] = 27007,
								},
								["Obliterate"] = {
									["count"] = 194000,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 135847,
								},
								["Frost Strike"] = {
									["count"] = 285194,
								},
							},
							["amount"] = 1421430,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Soul Reaper"] = {
									["count"] = 14194,
								},
								["Howling Blast"] = {
									["count"] = 338715,
								},
								["Melee"] = {
									["count"] = 183942,
								},
								["Death and Decay"] = {
									["count"] = 34053,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 61325,
								},
								["Obliterate"] = {
									["count"] = 280783,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 143666,
								},
								["Frost Strike"] = {
									["count"] = 242685,
								},
							},
							["amount"] = 1299363,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 231924,
								},
								["Melee"] = {
									["count"] = 196700,
								},
								["Death and Decay"] = {
									["count"] = 27178,
								},
								["Obliterate"] = {
									["count"] = 298896,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 82323,
								},
								["Frost Strike"] = {
									["count"] = 361855,
								},
							},
							["amount"] = 1198876,
						},
						["Baron Ashbury"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 27066,
								},
							},
							["amount"] = 27066,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Alluring Perfume"] = {
									["count"] = 30472,
								},
								["Alluring Perfume Spray (DoT)"] = {
									["count"] = 71770,
								},
							},
							["amount"] = 102242,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Irresistible Cologne Spray (DoT)"] = {
									["count"] = 176640,
								},
								["Irresistible Cologne"] = {
									["count"] = 37323,
								},
							},
							["amount"] = 213963,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Alluring Perfume"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 22,
									["amount"] = 0,
								},
							},
							["count"] = 22,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 28,
									["amount"] = 0,
								},
							},
							["count"] = 28,
							["amount"] = 0,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 0,
								},
								["Unholy Strength"] = {
									["count"] = 4.3,
								},
							},
							["amount"] = 4.3,
						},
					},
					["OverHeals"] = {
						["Death Pact"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 98667,
									["min"] = 98667,
									["count"] = 1,
									["amount"] = 98667,
								},
							},
							["count"] = 1,
							["amount"] = 98667,
						},
						["Unholy Strength"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 11753,
									["min"] = 1158,
									["count"] = 4,
									["amount"] = 25793,
								},
							},
							["count"] = 4,
							["amount"] = 25793,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 100666,
								},
								["Unholy Strength"] = {
									["count"] = 45967,
								},
							},
							["amount"] = 146633,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 99666,
					["Interrupts"] = 0,
					["Overhealing"] = 124460,
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Soul Reaper"] = {
									["count"] = 3.26,
								},
								["Howling Blast"] = {
									["count"] = 6.279999999999999,
								},
								["Melee"] = {
									["count"] = 5.57,
								},
								["Death and Decay"] = {
									["count"] = 2.66,
								},
								["Obliterate"] = {
									["count"] = 1.26,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 12.18,
								},
								["Frost Strike"] = {
									["count"] = 2.54,
								},
							},
							["amount"] = 33.75,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Soul Reaper"] = {
									["count"] = 0,
								},
								["Howling Blast"] = {
									["count"] = 1.9,
								},
								["Melee"] = {
									["count"] = 6.09,
								},
								["Death and Decay"] = {
									["count"] = 9.370000000000001,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 8.869999999999999,
								},
								["Obliterate"] = {
									["count"] = 1.83,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 15.23,
								},
								["Frost Strike"] = {
									["count"] = 1.85,
								},
							},
							["amount"] = 45.14000000000001,
						},
						["Baron Ashbury"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 0.03,
								},
							},
							["amount"] = 0.03,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 0,
								},
								["Unholy Strength"] = {
									["count"] = 4.3,
								},
							},
							["amount"] = 4.3,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 1.29,
								},
								["Melee"] = {
									["count"] = 6.12,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Obliterate"] = {
									["count"] = 3.27,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 3.14,
								},
								["Frost Strike"] = {
									["count"] = 2.93,
								},
							},
							["amount"] = 16.75,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["Death Pact"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 100666,
									["min"] = 100666,
									["count"] = 1,
									["amount"] = 100666,
								},
							},
							["count"] = 1,
							["amount"] = 100666,
						},
						["Unholy Strength"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 11960,
									["min"] = 207,
									["count"] = 6,
									["amount"] = 45967,
								},
							},
							["count"] = 6,
							["amount"] = 45967,
						},
					},
					["WhoHealed"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 16437,
								},
								["Prayer of Healing"] = {
									["count"] = 22957,
								},
								["Atonement"] = {
									["count"] = 136915,
								},
								["Flash Heal"] = {
									["count"] = 54970,
								},
							},
							["amount"] = 231279,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 100666,
								},
								["Unholy Strength"] = {
									["count"] = 45967,
								},
							},
							["amount"] = 146633,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 99.97000000000001,
					["Healing"] = 146633,
					["FDamagedWho"] = {
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 99666,
								},
							},
							["amount"] = 99666,
						},
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Soul Reaper"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 170771,
									["min"] = 170771,
									["count"] = 1,
									["amount"] = 170771,
								},
								["Hit"] = {
									["max"] = 83260,
									["min"] = 14194,
									["count"] = 5,
									["amount"] = 148827,
								},
							},
							["count"] = 6,
							["amount"] = 319598,
						},
						["Howling Blast"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 51158,
									["min"] = 46851,
									["count"] = 2,
									["amount"] = 98009,
								},
								["Hit"] = {
									["max"] = 43234,
									["min"] = 0,
									["count"] = 28,
									["amount"] = 713779,
								},
							},
							["count"] = 31,
							["amount"] = 811788,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 16235,
									["min"] = 11584,
									["count"] = 6,
									["amount"] = 88037,
								},
								["Miss"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 37927,
									["min"] = 28818,
									["count"] = 6,
									["amount"] = 200537,
								},
								["Hit"] = {
									["max"] = 20532,
									["min"] = 14188,
									["count"] = 19,
									["amount"] = 324897,
								},
							},
							["count"] = 34,
							["amount"] = 613471,
						},
						["Death and Decay"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6644,
									["min"] = 4374,
									["count"] = 5,
									["amount"] = 26670,
								},
								["Hit"] = {
									["max"] = 2814,
									["min"] = 1768,
									["count"] = 26,
									["amount"] = 61568,
								},
							},
							["count"] = 31,
							["amount"] = 88238,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 6133,
									["min"] = 6132,
									["count"] = 10,
									["amount"] = 61325,
								},
							},
							["count"] = 10,
							["amount"] = 61325,
						},
						["Obliterate"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 155117,
									["min"] = 126497,
									["count"] = 2,
									["amount"] = 281614,
								},
								["Hit"] = {
									["max"] = 67682,
									["min"] = 51245,
									["count"] = 8,
									["amount"] = 492065,
								},
							},
							["count"] = 12,
							["amount"] = 773679,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 15872,
									["min"] = 9999,
									["count"] = 5,
									["amount"] = 60370,
								},
								["Tick"] = {
									["max"] = 8826,
									["min"] = 4853,
									["count"] = 54,
									["amount"] = 301466,
								},
							},
							["count"] = 59,
							["amount"] = 361836,
						},
						["Frost Strike"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 74351,
									["min"] = 54941,
									["count"] = 8,
									["amount"] = 512517,
								},
								["Hit"] = {
									["max"] = 38087,
									["min"] = 26903,
									["count"] = 11,
									["amount"] = 377217,
								},
							},
							["count"] = 21,
							["amount"] = 889734,
						},
					},
					["HealingTaken"] = 377912,
					["RageGain"] = 0,
					["TimeDamage"] = 95.67000000000002,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Soul Reaper"] = {
									["count"] = 3.26,
								},
								["Howling Blast"] = {
									["count"] = 6.279999999999999,
								},
								["Melee"] = {
									["count"] = 5.57,
								},
								["Death and Decay"] = {
									["count"] = 2.66,
								},
								["Obliterate"] = {
									["count"] = 1.26,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 12.18,
								},
								["Frost Strike"] = {
									["count"] = 2.54,
								},
							},
							["amount"] = 33.75,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Soul Reaper"] = {
									["count"] = 0,
								},
								["Howling Blast"] = {
									["count"] = 1.9,
								},
								["Melee"] = {
									["count"] = 6.09,
								},
								["Death and Decay"] = {
									["count"] = 9.370000000000001,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 8.869999999999999,
								},
								["Obliterate"] = {
									["count"] = 1.83,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 15.23,
								},
								["Frost Strike"] = {
									["count"] = 1.85,
								},
							},
							["amount"] = 45.14000000000001,
						},
						["Baron Ashbury"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 0.03,
								},
							},
							["amount"] = 0.03,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 1.29,
								},
								["Melee"] = {
									["count"] = 6.12,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Obliterate"] = {
									["count"] = 3.27,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 3.14,
								},
								["Frost Strike"] = {
									["count"] = 2.93,
								},
							},
							["amount"] = 16.75,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["DOTs"] = {
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 66,
								},
								["Apothecary Hummel"] = {
									["count"] = 66,
								},
								["Apothecary Baxter"] = {
									["count"] = 45,
								},
							},
							["amount"] = 177,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Apothecary Hummel"] = {
									["count"] = 30,
								},
							},
							["amount"] = 30,
						},
					},
					["ShieldedWho"] = {
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Anti-Magic Shell"] = {
									["count"] = 1,
								},
								["Pillar of Frost"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 343271,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 3,
						},
						["Nature"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Absorb"] = {
									["count"] = 22,
								},
								["Tick"] = {
									["count"] = 11,
								},
								["Hit"] = {
									["count"] = 38,
								},
							},
							["amount"] = 72,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 12,
								},
							},
							["amount"] = 16,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 39,
								},
								["Miss"] = {
									["count"] = 2,
								},
								["Tick"] = {
									["count"] = 54,
								},
								["Crit"] = {
									["count"] = 15,
								},
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 111,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 6,
								},
								["Miss"] = {
									["count"] = 3,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 19,
								},
							},
							["amount"] = 34,
						},
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 10,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 27,
								},
							},
							["amount"] = 43,
						},
					},
					["ElementTakenAbsorb"] = {
						["Nature"] = 70739,
					},
					["ElementTaken"] = {
						["Melee"] = 27066,
						["Nature"] = 316205,
					},
					["DOT_Time"] = 207,
					["Damage"] = 3919669,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 4.3,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
						["Death Pact"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 99666,
									["min"] = 99666,
									["count"] = 1,
									["amount"] = 99666,
								},
							},
							["count"] = 1,
							["amount"] = 99666,
						},
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Physical"] = 839246,
						["Frost"] = 2063358,
						["Melee"] = 613471,
						["Shadow"] = 403594,
					},
					["PartialAbsorb"] = {
						["Alluring Perfume"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 17,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1944,
									["min"] = 1620,
									["count"] = 5,
									["amount"] = 9290,
								},
							},
							["count"] = 22,
							["amount"] = 9290,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 2595,
									["min"] = 2369,
									["count"] = 6,
									["amount"] = 14978,
								},
							},
							["count"] = 6,
							["amount"] = 14978,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 2509,
									["min"] = 2380,
									["count"] = 3,
									["amount"] = 7285,
								},
							},
							["count"] = 3,
							["amount"] = 7285,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 21,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1950,
									["min"] = 1636,
									["count"] = 7,
									["amount"] = 12647,
								},
							},
							["count"] = 28,
							["amount"] = 12647,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 21945,
									["min"] = 21945,
									["count"] = 1,
									["amount"] = 21945,
								},
							},
							["count"] = 2,
							["amount"] = 21945,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 4594,
									["min"] = 4594,
									["count"] = 1,
									["amount"] = 4594,
								},
							},
							["count"] = 8,
							["amount"] = 4594,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Soul Reaper"] = {
									["count"] = 305404,
								},
								["Howling Blast"] = {
									["count"] = 241149,
								},
								["Melee"] = {
									["count"] = 232829,
								},
								["Death and Decay"] = {
									["count"] = 27007,
								},
								["Obliterate"] = {
									["count"] = 194000,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 135847,
								},
								["Frost Strike"] = {
									["count"] = 285194,
								},
							},
							["amount"] = 1421430,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Soul Reaper"] = {
									["count"] = 14194,
								},
								["Howling Blast"] = {
									["count"] = 338715,
								},
								["Melee"] = {
									["count"] = 183942,
								},
								["Death and Decay"] = {
									["count"] = 34053,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 61325,
								},
								["Obliterate"] = {
									["count"] = 280783,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 143666,
								},
								["Frost Strike"] = {
									["count"] = 242685,
								},
							},
							["amount"] = 1299363,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 231924,
								},
								["Melee"] = {
									["count"] = 196700,
								},
								["Death and Decay"] = {
									["count"] = 27178,
								},
								["Obliterate"] = {
									["count"] = 298896,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 82323,
								},
								["Frost Strike"] = {
									["count"] = 361855,
								},
							},
							["amount"] = 1198876,
						},
						["Baron Ashbury"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 27066,
								},
							},
							["amount"] = 27066,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Alluring Perfume"] = {
									["count"] = 30472,
								},
								["Alluring Perfume Spray (DoT)"] = {
									["count"] = 71770,
								},
							},
							["amount"] = 102242,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Irresistible Cologne Spray (DoT)"] = {
									["count"] = 176640,
								},
								["Irresistible Cologne"] = {
									["count"] = 37323,
								},
							},
							["amount"] = 213963,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Alluring Perfume"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 22,
									["amount"] = 0,
								},
							},
							["count"] = 22,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 28,
									["amount"] = 0,
								},
							},
							["count"] = 28,
							["amount"] = 0,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 0,
								},
								["Unholy Strength"] = {
									["count"] = 4.3,
								},
							},
							["amount"] = 4.3,
						},
					},
					["OverHeals"] = {
						["Death Pact"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 98667,
									["min"] = 98667,
									["count"] = 1,
									["amount"] = 98667,
								},
							},
							["count"] = 1,
							["amount"] = 98667,
						},
						["Unholy Strength"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 11753,
									["min"] = 1158,
									["count"] = 4,
									["amount"] = 25793,
								},
							},
							["count"] = 4,
							["amount"] = 25793,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 100666,
								},
								["Unholy Strength"] = {
									["count"] = 45967,
								},
							},
							["amount"] = 146633,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 99666,
					["Interrupts"] = 0,
					["Overhealing"] = 124460,
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Soul Reaper"] = {
									["count"] = 3.26,
								},
								["Howling Blast"] = {
									["count"] = 6.279999999999999,
								},
								["Melee"] = {
									["count"] = 5.57,
								},
								["Death and Decay"] = {
									["count"] = 2.66,
								},
								["Obliterate"] = {
									["count"] = 1.26,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 12.18,
								},
								["Frost Strike"] = {
									["count"] = 2.54,
								},
							},
							["amount"] = 33.75,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Soul Reaper"] = {
									["count"] = 0,
								},
								["Howling Blast"] = {
									["count"] = 1.9,
								},
								["Melee"] = {
									["count"] = 6.09,
								},
								["Death and Decay"] = {
									["count"] = 9.370000000000001,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 8.869999999999999,
								},
								["Obliterate"] = {
									["count"] = 1.83,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 15.23,
								},
								["Frost Strike"] = {
									["count"] = 1.85,
								},
							},
							["amount"] = 45.14000000000001,
						},
						["Baron Ashbury"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 0.03,
								},
							},
							["amount"] = 0.03,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 0,
								},
								["Unholy Strength"] = {
									["count"] = 4.3,
								},
							},
							["amount"] = 4.3,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 1.29,
								},
								["Melee"] = {
									["count"] = 6.12,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Obliterate"] = {
									["count"] = 3.27,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 3.14,
								},
								["Frost Strike"] = {
									["count"] = 2.93,
								},
							},
							["amount"] = 16.75,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["Death Pact"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 100666,
									["min"] = 100666,
									["count"] = 1,
									["amount"] = 100666,
								},
							},
							["count"] = 1,
							["amount"] = 100666,
						},
						["Unholy Strength"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 11960,
									["min"] = 207,
									["count"] = 6,
									["amount"] = 45967,
								},
							},
							["count"] = 6,
							["amount"] = 45967,
						},
					},
					["WhoHealed"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 16437,
								},
								["Prayer of Healing"] = {
									["count"] = 22957,
								},
								["Atonement"] = {
									["count"] = 136915,
								},
								["Flash Heal"] = {
									["count"] = 54970,
								},
							},
							["amount"] = 231279,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 100666,
								},
								["Unholy Strength"] = {
									["count"] = 45967,
								},
							},
							["amount"] = 146633,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 99.97000000000001,
					["Healing"] = 146633,
					["FDamagedWho"] = {
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 99666,
								},
							},
							["amount"] = 99666,
						},
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Soul Reaper"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 170771,
									["min"] = 170771,
									["count"] = 1,
									["amount"] = 170771,
								},
								["Hit"] = {
									["max"] = 83260,
									["min"] = 14194,
									["count"] = 5,
									["amount"] = 148827,
								},
							},
							["count"] = 6,
							["amount"] = 319598,
						},
						["Howling Blast"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 51158,
									["min"] = 46851,
									["count"] = 2,
									["amount"] = 98009,
								},
								["Hit"] = {
									["max"] = 43234,
									["min"] = 0,
									["count"] = 28,
									["amount"] = 713779,
								},
							},
							["count"] = 31,
							["amount"] = 811788,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 16235,
									["min"] = 11584,
									["count"] = 6,
									["amount"] = 88037,
								},
								["Miss"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 37927,
									["min"] = 28818,
									["count"] = 6,
									["amount"] = 200537,
								},
								["Hit"] = {
									["max"] = 20532,
									["min"] = 14188,
									["count"] = 19,
									["amount"] = 324897,
								},
							},
							["count"] = 34,
							["amount"] = 613471,
						},
						["Death and Decay"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6644,
									["min"] = 4374,
									["count"] = 5,
									["amount"] = 26670,
								},
								["Hit"] = {
									["max"] = 2814,
									["min"] = 1768,
									["count"] = 26,
									["amount"] = 61568,
								},
							},
							["count"] = 31,
							["amount"] = 88238,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 6133,
									["min"] = 6132,
									["count"] = 10,
									["amount"] = 61325,
								},
							},
							["count"] = 10,
							["amount"] = 61325,
						},
						["Obliterate"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 155117,
									["min"] = 126497,
									["count"] = 2,
									["amount"] = 281614,
								},
								["Hit"] = {
									["max"] = 67682,
									["min"] = 51245,
									["count"] = 8,
									["amount"] = 492065,
								},
							},
							["count"] = 12,
							["amount"] = 773679,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 15872,
									["min"] = 9999,
									["count"] = 5,
									["amount"] = 60370,
								},
								["Tick"] = {
									["max"] = 8826,
									["min"] = 4853,
									["count"] = 54,
									["amount"] = 301466,
								},
							},
							["count"] = 59,
							["amount"] = 361836,
						},
						["Frost Strike"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 74351,
									["min"] = 54941,
									["count"] = 8,
									["amount"] = 512517,
								},
								["Hit"] = {
									["max"] = 38087,
									["min"] = 26903,
									["count"] = 11,
									["amount"] = 377217,
								},
							},
							["count"] = 21,
							["amount"] = 889734,
						},
					},
					["HealingTaken"] = 377912,
					["RageGain"] = 0,
					["TimeDamage"] = 95.67000000000002,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Soul Reaper"] = {
									["count"] = 3.26,
								},
								["Howling Blast"] = {
									["count"] = 6.279999999999999,
								},
								["Melee"] = {
									["count"] = 5.57,
								},
								["Death and Decay"] = {
									["count"] = 2.66,
								},
								["Obliterate"] = {
									["count"] = 1.26,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 12.18,
								},
								["Frost Strike"] = {
									["count"] = 2.54,
								},
							},
							["amount"] = 33.75,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Soul Reaper"] = {
									["count"] = 0,
								},
								["Howling Blast"] = {
									["count"] = 1.9,
								},
								["Melee"] = {
									["count"] = 6.09,
								},
								["Death and Decay"] = {
									["count"] = 9.370000000000001,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 8.869999999999999,
								},
								["Obliterate"] = {
									["count"] = 1.83,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 15.23,
								},
								["Frost Strike"] = {
									["count"] = 1.85,
								},
							},
							["amount"] = 45.14000000000001,
						},
						["Baron Ashbury"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 0.03,
								},
							},
							["amount"] = 0.03,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 1.29,
								},
								["Melee"] = {
									["count"] = 6.12,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Obliterate"] = {
									["count"] = 3.27,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 3.14,
								},
								["Frost Strike"] = {
									["count"] = 2.93,
								},
							},
							["amount"] = 16.75,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeHealing"] = {
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 0,
								},
								["Unholy Strength"] = {
									["count"] = 4.3,
								},
							},
							["amount"] = 4.3,
						},
					},
					["DOTs"] = {
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 66,
								},
								["Apothecary Hummel"] = {
									["count"] = 66,
								},
								["Apothecary Baxter"] = {
									["count"] = 45,
								},
							},
							["amount"] = 177,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Apothecary Hummel"] = {
									["count"] = 30,
								},
							},
							["amount"] = 30,
						},
					},
					["FDamagedWho"] = {
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 99666,
								},
							},
							["amount"] = 99666,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 3,
						},
						["Nature"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Absorb"] = {
									["count"] = 22,
								},
								["Tick"] = {
									["count"] = 11,
								},
								["Hit"] = {
									["count"] = 38,
								},
							},
							["amount"] = 72,
						},
					},
					["TimeSpent"] = {
						["Corpse Eater"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Soul Reaper"] = {
									["count"] = 0,
								},
								["Howling Blast"] = {
									["count"] = 1.9,
								},
								["Melee"] = {
									["count"] = 6.09,
								},
								["Death and Decay"] = {
									["count"] = 9.370000000000001,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 8.869999999999999,
								},
								["Obliterate"] = {
									["count"] = 1.83,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 15.23,
								},
								["Frost Strike"] = {
									["count"] = 1.85,
								},
							},
							["amount"] = 45.14000000000001,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 0.03,
								},
							},
							["amount"] = 0.03,
						},
						["Baron Ashbury"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 0,
								},
								["Unholy Strength"] = {
									["count"] = 4.3,
								},
							},
							["amount"] = 4.3,
						},
						["Apothecary Frye"] = {
							["Details"] = {
								["Soul Reaper"] = {
									["count"] = 3.26,
								},
								["Howling Blast"] = {
									["count"] = 6.279999999999999,
								},
								["Melee"] = {
									["count"] = 5.57,
								},
								["Death and Decay"] = {
									["count"] = 2.66,
								},
								["Obliterate"] = {
									["count"] = 1.26,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 12.18,
								},
								["Frost Strike"] = {
									["count"] = 2.54,
								},
							},
							["amount"] = 33.75,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 1.29,
								},
								["Melee"] = {
									["count"] = 6.12,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Obliterate"] = {
									["count"] = 3.27,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 3.14,
								},
								["Frost Strike"] = {
									["count"] = 2.93,
								},
							},
							["amount"] = 16.75,
						},
					},
					["WhoHealed"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 16437,
								},
								["Prayer of Healing"] = {
									["count"] = 46330,
								},
								["Atonement"] = {
									["count"] = 136915,
								},
								["Flash Heal"] = {
									["count"] = 54970,
								},
							},
							["amount"] = 254652,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 100666,
								},
								["Unholy Strength"] = {
									["count"] = 45967,
								},
							},
							["amount"] = 146633,
						},
					},
					["FDamage"] = 99666,
					["PartialResist"] = {
						["Alluring Perfume"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 22,
									["amount"] = 0,
								},
							},
							["count"] = 22,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 28,
									["amount"] = 0,
								},
							},
							["count"] = 28,
							["amount"] = 0,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
						["Nature"] = 70739,
					},
					["PartialAbsorb"] = {
						["Alluring Perfume"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 17,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1944,
									["min"] = 1620,
									["count"] = 5,
									["amount"] = 9290,
								},
							},
							["count"] = 22,
							["amount"] = 9290,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 2595,
									["min"] = 2369,
									["count"] = 6,
									["amount"] = 14978,
								},
							},
							["count"] = 6,
							["amount"] = 14978,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 2509,
									["min"] = 2380,
									["count"] = 3,
									["amount"] = 7285,
								},
							},
							["count"] = 3,
							["amount"] = 7285,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 21,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1950,
									["min"] = 1636,
									["count"] = 7,
									["amount"] = 12647,
								},
							},
							["count"] = 28,
							["amount"] = 12647,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 21945,
									["min"] = 21945,
									["count"] = 1,
									["amount"] = 21945,
								},
							},
							["count"] = 2,
							["amount"] = 21945,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 4594,
									["min"] = 4594,
									["count"] = 1,
									["amount"] = 4594,
								},
							},
							["count"] = 8,
							["amount"] = 4594,
						},
					},
					["ActiveTime"] = 106.97,
					["OverHeals"] = {
						["Death Pact"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 98667,
									["min"] = 98667,
									["count"] = 1,
									["amount"] = 98667,
								},
							},
							["count"] = 1,
							["amount"] = 98667,
						},
						["Unholy Strength"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 11753,
									["min"] = 1158,
									["count"] = 4,
									["amount"] = 25793,
								},
							},
							["count"] = 4,
							["amount"] = 25793,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 27066,
						["Nature"] = 316205,
					},
					["DOT_Time"] = 207,
					["Damage"] = 3985963,
					["Overhealing"] = 124460,
					["TimeHeal"] = 4.3,
					["ShieldedWho"] = {
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Anti-Magic Shell"] = {
									["count"] = 1,
								},
								["Pillar of Frost"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
					},
					["HealedWho"] = {
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 100666,
								},
								["Unholy Strength"] = {
									["count"] = 45967,
								},
							},
							["amount"] = 146633,
						},
					},
					["Heals"] = {
						["Death Pact"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 100666,
									["min"] = 100666,
									["count"] = 1,
									["amount"] = 100666,
								},
							},
							["count"] = 1,
							["amount"] = 100666,
						},
						["Unholy Strength"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 11960,
									["min"] = 207,
									["count"] = 6,
									["amount"] = 45967,
								},
							},
							["count"] = 6,
							["amount"] = 45967,
						},
					},
					["Healing"] = 146633,
					["FAttacks"] = {
						["Death Pact"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 99666,
									["min"] = 99666,
									["count"] = 1,
									["amount"] = 99666,
								},
							},
							["count"] = 1,
							["amount"] = 99666,
						},
					},
					["ElementDone"] = {
						["Physical"] = 839246,
						["Frost"] = 2129652,
						["Melee"] = 613471,
						["Shadow"] = 403594,
					},
					["Attacks"] = {
						["Soul Reaper"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 170771,
									["min"] = 170771,
									["count"] = 1,
									["amount"] = 170771,
								},
								["Hit"] = {
									["max"] = 83260,
									["min"] = 14194,
									["count"] = 5,
									["amount"] = 148827,
								},
							},
							["count"] = 6,
							["amount"] = 319598,
						},
						["Howling Blast"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 51158,
									["min"] = 46851,
									["count"] = 2,
									["amount"] = 98009,
								},
								["Hit"] = {
									["max"] = 43234,
									["min"] = 17275,
									["count"] = 31,
									["amount"] = 780073,
								},
							},
							["count"] = 34,
							["amount"] = 878082,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 16235,
									["min"] = 11584,
									["count"] = 6,
									["amount"] = 88037,
								},
								["Miss"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 37927,
									["min"] = 28818,
									["count"] = 6,
									["amount"] = 200537,
								},
								["Hit"] = {
									["max"] = 20532,
									["min"] = 14188,
									["count"] = 19,
									["amount"] = 324897,
								},
							},
							["count"] = 34,
							["amount"] = 613471,
						},
						["Death and Decay"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6644,
									["min"] = 4374,
									["count"] = 5,
									["amount"] = 26670,
								},
								["Hit"] = {
									["max"] = 2814,
									["min"] = 1768,
									["count"] = 26,
									["amount"] = 61568,
								},
							},
							["count"] = 31,
							["amount"] = 88238,
						},
						["Blood Plague (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 6133,
									["min"] = 6132,
									["count"] = 10,
									["amount"] = 61325,
								},
							},
							["count"] = 10,
							["amount"] = 61325,
						},
						["Obliterate"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 2,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 155117,
									["min"] = 126497,
									["count"] = 2,
									["amount"] = 281614,
								},
								["Hit"] = {
									["max"] = 67682,
									["min"] = 51245,
									["count"] = 8,
									["amount"] = 492065,
								},
							},
							["count"] = 12,
							["amount"] = 773679,
						},
						["Frost Fever (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 15872,
									["min"] = 9999,
									["count"] = 5,
									["amount"] = 60370,
								},
								["Tick"] = {
									["max"] = 8826,
									["min"] = 4853,
									["count"] = 54,
									["amount"] = 301466,
								},
							},
							["count"] = 59,
							["amount"] = 361836,
						},
						["Frost Strike"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 74351,
									["min"] = 54941,
									["count"] = 8,
									["amount"] = 512517,
								},
								["Hit"] = {
									["max"] = 38087,
									["min"] = 26903,
									["count"] = 11,
									["amount"] = 377217,
								},
							},
							["count"] = 21,
							["amount"] = 889734,
						},
					},
					["HealingTaken"] = 401285,
					["DamagedWho"] = {
						["Corpse Eater"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 17275,
								},
							},
							["amount"] = 17275,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Soul Reaper"] = {
									["count"] = 14194,
								},
								["Howling Blast"] = {
									["count"] = 338715,
								},
								["Melee"] = {
									["count"] = 183942,
								},
								["Death and Decay"] = {
									["count"] = 34053,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 61325,
								},
								["Obliterate"] = {
									["count"] = 280783,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 143666,
								},
								["Frost Strike"] = {
									["count"] = 242685,
								},
							},
							["amount"] = 1299363,
						},
						["Baron Ashbury"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 27425,
								},
							},
							["amount"] = 27425,
						},
						["Apothecary Frye"] = {
							["Details"] = {
								["Soul Reaper"] = {
									["count"] = 305404,
								},
								["Howling Blast"] = {
									["count"] = 241149,
								},
								["Melee"] = {
									["count"] = 232829,
								},
								["Death and Decay"] = {
									["count"] = 27007,
								},
								["Obliterate"] = {
									["count"] = 194000,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 135847,
								},
								["Frost Strike"] = {
									["count"] = 285194,
								},
							},
							["amount"] = 1421430,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 21594,
								},
							},
							["amount"] = 21594,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 231924,
								},
								["Melee"] = {
									["count"] = 196700,
								},
								["Death and Decay"] = {
									["count"] = 27178,
								},
								["Obliterate"] = {
									["count"] = 298896,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 82323,
								},
								["Frost Strike"] = {
									["count"] = 361855,
								},
							},
							["amount"] = 1198876,
						},
					},
					["TimeDamage"] = 102.67,
					["TimeDamaging"] = {
						["Corpse Eater"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Soul Reaper"] = {
									["count"] = 0,
								},
								["Howling Blast"] = {
									["count"] = 1.9,
								},
								["Melee"] = {
									["count"] = 6.09,
								},
								["Death and Decay"] = {
									["count"] = 9.370000000000001,
								},
								["Blood Plague (DoT)"] = {
									["count"] = 8.869999999999999,
								},
								["Obliterate"] = {
									["count"] = 1.83,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 15.23,
								},
								["Frost Strike"] = {
									["count"] = 1.85,
								},
							},
							["amount"] = 45.14000000000001,
						},
						["Baron Ashbury"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Death Pact"] = {
									["count"] = 0.03,
								},
							},
							["amount"] = 0.03,
						},
						["Apothecary Frye"] = {
							["Details"] = {
								["Soul Reaper"] = {
									["count"] = 3.26,
								},
								["Howling Blast"] = {
									["count"] = 6.279999999999999,
								},
								["Melee"] = {
									["count"] = 5.57,
								},
								["Death and Decay"] = {
									["count"] = 2.66,
								},
								["Obliterate"] = {
									["count"] = 1.26,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 12.18,
								},
								["Frost Strike"] = {
									["count"] = 2.54,
								},
							},
							["amount"] = 33.75,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 1.29,
								},
								["Melee"] = {
									["count"] = 6.12,
								},
								["Death and Decay"] = {
									["count"] = 0,
								},
								["Obliterate"] = {
									["count"] = 3.27,
								},
								["Frost Fever (DoT)"] = {
									["count"] = 3.14,
								},
								["Frost Strike"] = {
									["count"] = 2.93,
								},
							},
							["amount"] = 16.75,
						},
					},
					["WhoDamaged"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 27066,
								},
							},
							["amount"] = 27066,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Alluring Perfume"] = {
									["count"] = 30472,
								},
								["Alluring Perfume Spray (DoT)"] = {
									["count"] = 71770,
								},
							},
							["amount"] = 102242,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Irresistible Cologne Spray (DoT)"] = {
									["count"] = 176640,
								},
								["Irresistible Cologne"] = {
									["count"] = 37323,
								},
							},
							["amount"] = 213963,
						},
					},
					["DamageTaken"] = 343271,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 12,
								},
							},
							["amount"] = 16,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 42,
								},
								["Miss"] = {
									["count"] = 2,
								},
								["Tick"] = {
									["count"] = 54,
								},
								["Crit"] = {
									["count"] = 15,
								},
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 114,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 6,
								},
								["Miss"] = {
									["count"] = 3,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 19,
								},
							},
							["amount"] = 34,
						},
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 10,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 27,
								},
							},
							["amount"] = 43,
						},
					},
				},
			},
			["UnitLockout"] = 1360559620,
			["LastActive"] = 1360559620,
		},
		["Stabsya"] = {
			["GUID"] = "0x01000000002DEE9B",
			["LastEventHealth"] = {
				"344691 (100%)", -- [1]
				"344691 (100%)", -- [2]
				"344691 (100%)", -- [3]
				"344691 (100%)", -- [4]
				"344691 (100%)", -- [5]
				"344691 (100%)", -- [6]
				"344691 (100%)", -- [7]
				"344691 (100%)", -- [8]
				"344691 (100%)", -- [9]
				"344691 (100%)", -- [10]
				"344691 (100%)", -- [11]
				"344691 (100%)", -- [12]
				"344691 (100%)", -- [13]
				"344691 (100%)", -- [14]
				"344691 (100%)", -- [15]
				"344691 (100%)", -- [16]
				"344691 (100%)", -- [17]
				"344691 (100%)", -- [18]
				"344691 (100%)", -- [19]
				"344691 (100%)", -- [20]
				"344691 (100%)", -- [21]
				"344691 (100%)", -- [22]
				"344691 (100%)", -- [23]
				"344691 (100%)", -- [24]
				"344691 (100%)", -- [25]
				"344691 (100%)", -- [26]
				"344691 (100%)", -- [27]
				"344691 (100%)", -- [28]
				"344691 (100%)", -- [29]
				"344691 (100%)", -- [30]
				"344691 (100%)", -- [31]
				"344691 (100%)", -- [32]
				"344691 (100%)", -- [33]
				"344691 (100%)", -- [34]
				"344691 (100%)", -- [35]
				"344691 (100%)", -- [36]
				"344691 (100%)", -- [37]
				"344691 (100%)", -- [38]
				"344691 (100%)", -- [39]
				"344691 (100%)", -- [40]
				"344691 (100%)", -- [41]
				"344691 (100%)", -- [42]
				"344691 (100%)", -- [43]
				"344691 (100%)", -- [44]
				"344691 (100%)", -- [45]
				"344691 (100%)", -- [46]
				"344691 (100%)", -- [47]
				"344691 (100%)", -- [48]
				"344691 (100%)", -- [49]
				"344691 (100%)", -- [50]
			},
			["LastAttackedBy"] = "Apothecary Baxter",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"HEAL", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"HEAL", -- [14]
				"DAMAGE", -- [15]
				"HEAL", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"HEAL", -- [22]
				"HEAL", -- [23]
				"HEAL", -- [24]
				"HEAL", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"HEAL", -- [31]
				"HEAL", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"HEAL", -- [36]
				"DAMAGE", -- [37]
				"HEAL", -- [38]
				"HEAL", -- [39]
				"HEAL", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"HEAL", -- [46]
				"HEAL", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					15.56000000000001, -- [1]
				},
				["Healing"] = {
					76787, -- [1]
				},
				["DamageTaken"] = {
					125783, -- [1]
				},
				["EnergyGain"] = {
					125, -- [1]
				},
				["HealingTaken"] = {
					165770, -- [1]
				},
				["Overhealing"] = {
					148754, -- [1]
				},
				["ActiveTime"] = {
					102.87, -- [1]
				},
				["TimeDamage"] = {
					87.31000000000009, -- [1]
				},
				["DOT_Time"] = {
					144, -- [1]
				},
				["Damage"] = {
					1976963, -- [1]
				},
			},
			["enClass"] = "ROGUE",
			["unit"] = "Stabsya",
			["level"] = 90,
			["LastDamageAbility"] = "Irresistible Cologne",
			["LastFightIn"] = 1,
			["LastEventNum"] = {
				[46] = 0.1485388362330319,
				[25] = 0.1604335477282552,
				[14] = 0.1450574572588202,
				[39] = 0.162174237215361,
				[4] = 0.07920137166331584,
				[32] = 0.1676864205911962,
				[31] = 0.07688045234717472,
				[47] = 0.1354836650797381,
				[24] = 0.1465080318314084,
				[36] = 0.6553695918953497,
				[38] = 17.79506862668303,
				[40] = 0.2909852592611933,
				[22] = 0.125039528157103,
				[23] = 0.3991981223762732,
				[16] = 0.2030804401623483,
			},
			["type"] = "Self",
			["FightsSaved"] = 2,
			["LastDamageTaken"] = 1922,
			["TimeLast"] = {
				["TimeHeal"] = 1360559606,
				["OVERALL"] = 1360559620,
				["DamageTaken"] = 1360559596,
				["EnergyGain"] = 1360559608,
				["HealingTaken"] = 1360559607,
				["Overhealing"] = 1360559620,
				["TimeDamage"] = 1360559620,
				["ActiveTime"] = 1360559620,
				["Healing"] = 1360559606,
				["DOT_Time"] = 1360559618,
				["Damage"] = 1360559620,
			},
			["Owner"] = false,
			["LastAbility"] = 19803.136,
			["NextEventNum"] = 40,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				100, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				100, -- [11]
				100, -- [12]
				100, -- [13]
				100, -- [14]
				100, -- [15]
				100, -- [16]
				100, -- [17]
				100, -- [18]
				100, -- [19]
				100, -- [20]
				100, -- [21]
				100, -- [22]
				100, -- [23]
				100, -- [24]
				100, -- [25]
				100, -- [26]
				100, -- [27]
				100, -- [28]
				100, -- [29]
				100, -- [30]
				100, -- [31]
				100, -- [32]
				100, -- [33]
				100, -- [34]
				100, -- [35]
				100, -- [36]
				100, -- [37]
				100, -- [38]
				100, -- [39]
				100, -- [40]
				100, -- [41]
				100, -- [42]
				100, -- [43]
				100, -- [44]
				100, -- [45]
				100, -- [46]
				100, -- [47]
				100, -- [48]
				100, -- [49]
				100, -- [50]
			},
			["LastEvents"] = {
				"Stabsya Melee Apothecary Frye Miss", -- [1]
				"Stabsya Melee Apothecary Frye Hit -2596 (Physical)", -- [2]
				"Stabsya Deadly Poison Apothecary Frye Hit -4967 (Nature)", -- [3]
				"Stabsya Leeching Poison Stabsya Hit +273 (273 overheal)", -- [4]
				"Stabsya Deadly Poison (DoT) Apothecary Frye Tick -9733 (Nature)", -- [5]
				"Stabsya Crimson Tempest (DoT) Apothecary Frye Tick -4384 (Physical)", -- [6]
				"Apothecary Frye Melee Stabsya Absorb (14455 Absorbed)", -- [7]
				"Stabsya Crimson Tempest (DoT) Apothecary Frye Tick -4384 (Physical)", -- [8]
				"Stabsya Melee Apothecary Frye Crit -4765 (Physical)", -- [9]
				"Stabsya Deadly Poison (DoT) Apothecary Frye Crit -19465 (Nature)", -- [10]
				"Stabsya Deadly Poison Apothecary Frye Hit -5086 (Nature)", -- [11]
				"Apothecary Frye Melee Stabsya Absorb (17193 Absorbed)", -- [12]
				"Stabsya Melee Apothecary Frye Hit -6672 (Physical)", -- [13]
				"Stabsya Leeching Poison Stabsya Hit +500 (500 overheal)", -- [14]
				"Stabsya Deadly Poison Apothecary Frye Hit -4901 (Nature)", -- [15]
				"Stabsya Leeching Poison Stabsya Hit +700 (700 overheal)", -- [16]
				"Stabsya Melee Apothecary Frye Crit -4102 (Physical)", -- [17]
				"Stabsya Melee Apothecary Frye Hit -5272 (Physical)", -- [18]
				"Stabsya Deadly Poison Apothecary Frye Hit -4911 (Nature)", -- [19]
				"Stabsya Mutilate Apothecary Frye Hit -13107 (Physical)", -- [20]
				"Stabsya Mutilate Off-Hand Apothecary Frye Hit -4809 (Physical)", -- [21]
				"Stabsya Leeching Poison Stabsya Hit +431 (431 overheal)", -- [22]
				"Stabsya Leeching Poison Stabsya Hit +1376 (1376 overheal)", -- [23]
				"Stabsya Leeching Poison Stabsya Hit +505 (505 overheal)", -- [24]
				"Stabsya Leeching Poison Stabsya Hit +553 (553 overheal)", -- [25]
				"Stabsya Melee Apothecary Frye Hit -2519 (Physical)", -- [26]
				"Stabsya Deadly Poison (DoT) Apothecary Frye Tick -9732 (Nature)", -- [27]
				"Apothecary Frye Melee Stabsya Dodge", -- [28]
				"Stabsya Melee Apothecary Frye Glancing -5506 (Physical)", -- [29]
				"Stabsya Deadly Poison Apothecary Frye Hit -5084 (Nature)", -- [30]
				"Stabsya Leeching Poison Stabsya Hit +265 (265 overheal)", -- [31]
				"Stabsya Leeching Poison Stabsya Hit +578 (578 overheal)", -- [32]
				"Stabsya Dispatch Apothecary Frye Hit -21516 (Physical)", -- [33]
				"Stabsya Melee Apothecary Frye Crit -5321 (Physical)", -- [34]
				"Stabsya Melee Apothecary Frye Miss", -- [35]
				"Stabsya Leeching Poison Stabsya Hit +2259 (2259 overheal)", -- [36]
				"Stabsya Deadly Poison Apothecary Frye Hit -4971 (Nature)", -- [37]
				"Tanklord-Tichondrius Prayer of Healing Stabsya Crit +61338 (61338 overheal)", -- [38]
				"Stabsya Leeching Poison Stabsya Hit +559 (559 overheal)", -- [39]
				"Stabsya Leeching Poison Stabsya Hit +1003 (1003 overheal)", -- [40]
				"Stabsya Debilitation Apothecary Frye Immune (Physical)", -- [41]
				"Stabsya Melee Apothecary Frye Crit -4455 (Physical)", -- [42]
				"Stabsya Envenom Apothecary Frye Hit -4878 (Nature)", -- [43]
				"Stabsya Deadly Poison Apothecary Frye Hit -4952 (Nature)", -- [44]
				"Stabsya Deadly Poison Apothecary Frye Hit -4923 (Nature)", -- [45]
				"Stabsya Leeching Poison Stabsya Hit +512 (512 overheal)", -- [46]
				"Stabsya Leeching Poison Stabsya Hit +467 (467 overheal)", -- [47]
				"Stabsya Crimson Tempest (DoT) Apothecary Frye Tick -4384 (Physical)", -- [48]
				"No One Concentrated Irresistible Cologne Spill Stabsya Absorb (3228 Absorbed) (Nature)", -- [49]
				"Stabsya Gouge Apothecary Frye Immune (Physical)", -- [50]
			},
			["Name"] = "Stabsya",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				true, -- [4]
				false, -- [5]
				false, -- [6]
				true, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				true, -- [12]
				false, -- [13]
				true, -- [14]
				false, -- [15]
				true, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				true, -- [22]
				true, -- [23]
				true, -- [24]
				true, -- [25]
				false, -- [26]
				false, -- [27]
				true, -- [28]
				false, -- [29]
				false, -- [30]
				true, -- [31]
				true, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				true, -- [36]
				false, -- [37]
				true, -- [38]
				true, -- [39]
				true, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				true, -- [46]
				true, -- [47]
				false, -- [48]
				true, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				19794.368, -- [1]
				19794.406, -- [2]
				19794.685, -- [3]
				19795.082, -- [4]
				19795.224, -- [5]
				19795.812, -- [6]
				19796.336, -- [7]
				19797.814, -- [8]
				19798.023, -- [9]
				19798.217, -- [10]
				19798.307, -- [11]
				19798.344, -- [12]
				19798.401, -- [13]
				19798.718, -- [14]
				19798.718, -- [15]
				19799.128, -- [16]
				19799.614, -- [17]
				19799.914, -- [18]
				19799.939, -- [19]
				19799.939, -- [20]
				19799.939, -- [21]
				19800.335, -- [22]
				19800.335, -- [23]
				19800.335, -- [24]
				19800.335, -- [25]
				19801.215, -- [26]
				19801.215, -- [27]
				19801.364, -- [28]
				19801.419, -- [29]
				19801.532, -- [30]
				19801.945, -- [31]
				19801.945, -- [32]
				19802.722, -- [33]
				19802.805, -- [34]
				19802.933, -- [35]
				19803.136, -- [36]
				19803.136, -- [37]
				19803.136, -- [38]
				19803.543, -- [39]
				19792.659, -- [40]
				19792.711, -- [41]
				19792.801, -- [42]
				19793.076, -- [43]
				19793.076, -- [44]
				19793.076, -- [45]
				19793.482, -- [46]
				19793.482, -- [47]
				19793.828, -- [48]
				19793.886, -- [49]
				19794.368, -- [50]
			},
			["Fights"] = {
				["Fight2"] = {
					["DamagedWho"] = {
						["Frantic Geist"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 7808,
								},
								["Mutilate"] = {
									["count"] = 16923,
								},
							},
							["amount"] = 24731,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 7808,
									["min"] = 7808,
									["count"] = 1,
									["amount"] = 7808,
								},
							},
							["count"] = 1,
							["amount"] = 7808,
						},
						["Mutilate"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16923,
									["min"] = 16923,
									["count"] = 1,
									["amount"] = 16923,
								},
							},
							["count"] = 1,
							["amount"] = 16923,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 11,
								},
							},
							["amount"] = 11,
						},
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
					},
					["WhoHealed"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 17361,
								},
							},
							["amount"] = 17361,
						},
					},
					["ElementDone"] = {
						["Melee"] = 7808,
						["Physical"] = 16923,
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Slashing Claws"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 17361,
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Slashing Claws"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 3.79,
					["TimeDamaging"] = {
						["Frantic Geist"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
								["Mutilate"] = {
									["count"] = 0.29,
								},
							},
							["amount"] = 3.79,
						},
					},
					["TimeSpent"] = {
						["Frantic Geist"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
								["Mutilate"] = {
									["count"] = 0.29,
								},
							},
							["amount"] = 3.79,
						},
					},
					["ActiveTime"] = 3.79,
					["Damage"] = 24731,
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
						["Deadly Poison (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 36,
								},
								["Apothecary Hummel"] = {
									["count"] = 51,
								},
								["Apothecary Baxter"] = {
									["count"] = 15,
								},
							},
							["amount"] = 102,
						},
						["Crimson Tempest (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Apothecary Baxter"] = {
									["count"] = 12,
								},
								["Apothecary Hummel"] = {
									["count"] = 12,
								},
							},
							["amount"] = 24,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 125783,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 1,
								},
								["Absorb"] = {
									["count"] = 3,
								},
							},
							["amount"] = 4,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 25,
								},
								["Tick"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 29,
								},
							},
							["amount"] = 57,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 13,
								},
								["Hit"] = {
									["count"] = 31,
								},
								["Tick"] = {
									["count"] = 6,
								},
								["Block"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 4,
								},
								["Dodge"] = {
									["count"] = 1,
								},
							},
							["amount"] = 56,
						},
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 16,
								},
								["Hit"] = {
									["count"] = 45,
								},
								["Miss"] = {
									["count"] = 17,
								},
								["Dodge"] = {
									["count"] = 3,
								},
								["Crit"] = {
									["count"] = 17,
								},
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 99,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 35,
								},
								["Crit"] = {
									["count"] = 19,
								},
								["Hit"] = {
									["count"] = 55,
								},
							},
							["amount"] = 109,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 45144,
						["Nature"] = 106852,
					},
					["ElementTaken"] = {
						["Nature"] = 125783,
					},
					["DOT_Time"] = 144,
					["Damage"] = 1952232,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 15.56000000000001,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Physical"] = 394694,
						["Shadow"] = 107030,
						["Melee"] = 417787,
						["Nature"] = 1032721,
					},
					["PartialAbsorb"] = {
						["Alluring Perfume"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 13,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1956,
									["min"] = 1651,
									["count"] = 21,
									["amount"] = 37750,
								},
							},
							["count"] = 34,
							["amount"] = 37750,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 3228,
									["min"] = 3228,
									["count"] = 1,
									["amount"] = 3228,
								},
							},
							["count"] = 1,
							["amount"] = 3228,
						},
						["Alluring Perfume Spray"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 21958,
									["min"] = 21958,
									["count"] = 3,
									["amount"] = 65874,
								},
							},
							["count"] = 3,
							["amount"] = 65874,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 17193,
									["min"] = 13496,
									["count"] = 3,
									["amount"] = 45144,
								},
							},
							["count"] = 4,
							["amount"] = 45144,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 133033,
								},
								["Deadly Poison"] = {
									["count"] = 99417,
								},
								["Envenom"] = {
									["count"] = 68292,
								},
								["Crimson Tempest"] = {
									["count"] = 10960,
								},
								["Dispatch"] = {
									["count"] = 42371,
								},
								["Crimson Tempest (DoT)"] = {
									["count"] = 26304,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 126519,
								},
								["Touch of the Grave"] = {
									["count"] = 34773,
								},
								["Mutilate"] = {
									["count"] = 59774,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 39003,
								},
							},
							["amount"] = 640446,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 184846,
								},
								["Touch of the Grave"] = {
									["count"] = 54476,
								},
								["Envenom"] = {
									["count"] = 82435,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 23325,
								},
								["Mutilate"] = {
									["count"] = 82614,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 243120,
								},
								["Dispatch"] = {
									["count"] = 17019,
								},
								["Deadly Poison"] = {
									["count"] = 193638,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 37979,
								},
							},
							["amount"] = 919452,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 99908,
								},
								["Deadly Poison"] = {
									["count"] = 89397,
								},
								["Shiv"] = {
									["count"] = 720,
								},
								["Envenom"] = {
									["count"] = 22477,
								},
								["Touch of the Grave"] = {
									["count"] = 17781,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 65441,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 18660,
								},
								["Mutilate"] = {
									["count"] = 49900,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 28050,
								},
							},
							["amount"] = 392334,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Apothecary Baxter"] = {
							["Details"] = {
								["Irresistible Cologne"] = {
									["count"] = 28724,
								},
							},
							["amount"] = 28724,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Alluring Perfume"] = {
									["count"] = 23586,
								},
								["Alluring Perfume Spray (DoT)"] = {
									["count"] = 73473,
								},
							},
							["amount"] = 97059,
						},
					},
					["EnergyGainedFrom"] = {
						["Stabsya"] = {
							["Details"] = {
								["Relentless Strikes"] = {
									["count"] = 125,
								},
							},
							["amount"] = 125,
						},
					},
					["PartialResist"] = {
						["Alluring Perfume"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 34,
									["amount"] = 0,
								},
							},
							["count"] = 34,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Alluring Perfume Spray"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
						["Melee"] = 2690,
						["Physical"] = 11508,
					},
					["TimeHealing"] = {
						["Stabsya"] = {
							["Details"] = {
								["Leeching Poison"] = {
									["count"] = 14.74000000000001,
								},
								["Leech Vitality"] = {
									["count"] = 0.31,
								},
								["Touch of the Grave"] = {
									["count"] = 0.51,
								},
							},
							["amount"] = 15.56000000000001,
						},
					},
					["OverHeals"] = {
						["Leeching Poison"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2950,
									["min"] = 35,
									["count"] = 48,
									["amount"] = 41576,
								},
							},
							["count"] = 48,
							["amount"] = 41576,
						},
						["Leech Vitality"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16131,
									["min"] = 16131,
									["count"] = 1,
									["amount"] = 16131,
								},
							},
							["count"] = 1,
							["amount"] = 16131,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 18868,
									["min"] = 6806,
									["count"] = 6,
									["amount"] = 91047,
								},
							},
							["count"] = 6,
							["amount"] = 91047,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Stabsya"] = {
							["Details"] = {
								["Leeching Poison"] = {
									["count"] = 53490,
								},
								["Leech Vitality"] = {
									["count"] = 1965,
								},
								["Touch of the Grave"] = {
									["count"] = 21332,
								},
							},
							["amount"] = 76787,
						},
					},
					["EnergyGain"] = 125,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 148754,
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 14.07,
								},
								["Deadly Poison"] = {
									["count"] = 1.56,
								},
								["Gouge"] = {
									["count"] = 2.79,
								},
								["Envenom"] = {
									["count"] = 0.3100000000000001,
								},
								["Debilitation"] = {
									["count"] = 1.41,
								},
								["Crimson Tempest"] = {
									["count"] = 0.47,
								},
								["Dispatch"] = {
									["count"] = 1.19,
								},
								["Crimson Tempest (DoT)"] = {
									["count"] = 4.65,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 3.64,
								},
								["Touch of the Grave"] = {
									["count"] = 0.6800000000000001,
								},
								["Mutilate"] = {
									["count"] = 0.1,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 0,
								},
							},
							["amount"] = 30.87000000000001,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 17.64,
								},
								["Mutilate"] = {
									["count"] = 1.26,
								},
								["Gouge"] = {
									["count"] = 0.12,
								},
								["Envenom"] = {
									["count"] = 0.7,
								},
								["Debilitation"] = {
									["count"] = 3.01,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 1.72,
								},
								["Dispatch"] = {
									["count"] = 0.03,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 12.32,
								},
								["Deadly Poison"] = {
									["count"] = 1.69,
								},
								["Touch of the Grave"] = {
									["count"] = 1.59,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 0.03,
								},
							},
							["amount"] = 40.11000000000001,
						},
						["Stabsya"] = {
							["Details"] = {
								["Leeching Poison"] = {
									["count"] = 14.74000000000001,
								},
								["Leech Vitality"] = {
									["count"] = 0.31,
								},
								["Touch of the Grave"] = {
									["count"] = 0.51,
								},
							},
							["amount"] = 15.56000000000001,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 7.719999999999999,
								},
								["Deadly Poison"] = {
									["count"] = 1.16,
								},
								["Shiv"] = {
									["count"] = 0.1,
								},
								["Envenom"] = {
									["count"] = 0.03,
								},
								["Debilitation"] = {
									["count"] = 0.23,
								},
								["Touch of the Grave"] = {
									["count"] = 0.24,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 2.16,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.12,
								},
								["Mutilate"] = {
									["count"] = 0.78,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 0,
								},
							},
							["amount"] = 12.54,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["Leeching Poison"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 3073,
									["min"] = 75,
									["count"] = 70,
									["amount"] = 53490,
								},
							},
							["count"] = 70,
							["amount"] = 53490,
						},
						["Leech Vitality"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1965,
									["min"] = 1965,
									["count"] = 1,
									["amount"] = 1965,
								},
							},
							["count"] = 1,
							["amount"] = 1965,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 11864,
									["min"] = 2947,
									["count"] = 3,
									["amount"] = 21332,
								},
							},
							["count"] = 3,
							["amount"] = 21332,
						},
					},
					["WhoHealed"] = {
						["Stabsya"] = {
							["Details"] = {
								["Leeching Poison"] = {
									["count"] = 53490,
								},
								["Leech Vitality"] = {
									["count"] = 1965,
								},
								["Touch of the Grave"] = {
									["count"] = 21332,
								},
							},
							["amount"] = 76787,
						},
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Renew"] = {
									["count"] = 22178,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 16761,
								},
								["Prayer of Healing"] = {
									["count"] = 27622,
								},
								["Halo"] = {
									["count"] = 5061,
								},
							},
							["amount"] = 71622,
						},
					},
					["EnergyGained"] = {
						["Relentless Strikes"] = {
							["Details"] = {
								["Stabsya"] = {
									["count"] = 125,
								},
							},
							["amount"] = 125,
						},
					},
					["ActiveTime"] = 99.08000000000004,
					["Healing"] = 76787,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 6076,
									["min"] = 2121,
									["count"] = 16,
									["amount"] = 64560,
								},
								["Crit (Blocked)"] = {
									["max"] = 4102,
									["min"] = 4102,
									["count"] = 1,
									["amount"] = 4102,
								},
								["Miss"] = {
									["count"] = 17,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 9067,
									["min"] = 2316,
									["count"] = 44,
									["amount"] = 221064,
								},
								["Hit (Blocked)"] = {
									["max"] = 2174,
									["min"] = 2174,
									["count"] = 1,
									["amount"] = 2174,
								},
								["Dodge"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 15754,
									["min"] = 4455,
									["count"] = 16,
									["amount"] = 125887,
								},
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 99,
							["amount"] = 417787,
						},
						["Mutilate"] = {
							["Details"] = {
								["Hit (Blocked)"] = {
									["max"] = 9832,
									["min"] = 9832,
									["count"] = 1,
									["amount"] = 9832,
								},
								["Dodge"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 16802,
									["min"] = 10196,
									["count"] = 14,
									["amount"] = 182456,
								},
							},
							["count"] = 16,
							["amount"] = 192288,
						},
						["Gouge"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Block"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Crimson Tempest (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 4384,
									["min"] = 4384,
									["count"] = 6,
									["amount"] = 26304,
								},
							},
							["count"] = 6,
							["amount"] = 26304,
						},
						["Envenom"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 29268,
									["min"] = 28096,
									["count"] = 2,
									["amount"] = 57364,
								},
								["Hit"] = {
									["max"] = 28096,
									["min"] = 4878,
									["count"] = 8,
									["amount"] = 115840,
								},
							},
							["count"] = 10,
							["amount"] = 173204,
						},
						["Shiv"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 720,
									["min"] = 720,
									["count"] = 1,
									["amount"] = 720,
								},
							},
							["count"] = 1,
							["amount"] = 720,
						},
						["Debilitation"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Crimson Tempest"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 10960,
									["min"] = 10960,
									["count"] = 1,
									["amount"] = 10960,
								},
							},
							["count"] = 1,
							["amount"] = 10960,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9330,
									["min"] = 9330,
									["count"] = 1,
									["amount"] = 9330,
								},
								["Tick"] = {
									["max"] = 4665,
									["min"] = 4665,
									["count"] = 7,
									["amount"] = 32655,
								},
							},
							["count"] = 8,
							["amount"] = 41985,
						},
						["Dispatch"] = {
							["Details"] = {
								["Hit (Blocked)"] = {
									["max"] = 17019,
									["min"] = 17019,
									["count"] = 1,
									["amount"] = 17019,
								},
								["Hit"] = {
									["max"] = 21516,
									["min"] = 20855,
									["count"] = 2,
									["amount"] = 42371,
								},
							},
							["count"] = 3,
							["amount"] = 59390,
						},
						["Deadly Poison (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 27854,
									["min"] = 19464,
									["count"] = 6,
									["amount"] = 127995,
								},
								["Tick"] = {
									["max"] = 13927,
									["min"] = 9732,
									["count"] = 28,
									["amount"] = 307085,
								},
							},
							["count"] = 34,
							["amount"] = 435080,
						},
						["Deadly Poison"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 14391,
									["min"] = 9784,
									["count"] = 10,
									["amount"] = 113193,
								},
								["Hit"] = {
									["max"] = 7264,
									["min"] = 4901,
									["count"] = 47,
									["amount"] = 269259,
								},
							},
							["count"] = 57,
							["amount"] = 382452,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 19454,
									["min"] = 16803,
									["count"] = 6,
									["amount"] = 107030,
								},
							},
							["count"] = 6,
							["amount"] = 107030,
						},
						["Mutilate Off-Hand"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 11844,
									["min"] = 10804,
									["count"] = 3,
									["amount"] = 34098,
								},
								["Hit"] = {
									["max"] = 7026,
									["min"] = 4809,
									["count"] = 12,
									["amount"] = 70934,
								},
							},
							["count"] = 15,
							["amount"] = 105032,
						},
					},
					["HealingTaken"] = 148409,
					["RageGain"] = 0,
					["TimeDamage"] = 83.52000000000008,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 14.07,
								},
								["Deadly Poison"] = {
									["count"] = 1.56,
								},
								["Gouge"] = {
									["count"] = 2.79,
								},
								["Envenom"] = {
									["count"] = 0.3100000000000001,
								},
								["Debilitation"] = {
									["count"] = 1.41,
								},
								["Crimson Tempest"] = {
									["count"] = 0.47,
								},
								["Dispatch"] = {
									["count"] = 1.19,
								},
								["Crimson Tempest (DoT)"] = {
									["count"] = 4.65,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 3.64,
								},
								["Touch of the Grave"] = {
									["count"] = 0.6800000000000001,
								},
								["Mutilate"] = {
									["count"] = 0.1,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 0,
								},
							},
							["amount"] = 30.87000000000001,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 17.64,
								},
								["Mutilate"] = {
									["count"] = 1.26,
								},
								["Gouge"] = {
									["count"] = 0.12,
								},
								["Envenom"] = {
									["count"] = 0.7,
								},
								["Debilitation"] = {
									["count"] = 3.01,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 1.72,
								},
								["Dispatch"] = {
									["count"] = 0.03,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 12.32,
								},
								["Deadly Poison"] = {
									["count"] = 1.69,
								},
								["Touch of the Grave"] = {
									["count"] = 1.59,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 0.03,
								},
							},
							["amount"] = 40.11000000000001,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 7.719999999999999,
								},
								["Deadly Poison"] = {
									["count"] = 1.16,
								},
								["Shiv"] = {
									["count"] = 0.1,
								},
								["Envenom"] = {
									["count"] = 0.03,
								},
								["Debilitation"] = {
									["count"] = 0.23,
								},
								["Touch of the Grave"] = {
									["count"] = 0.24,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 2.16,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.12,
								},
								["Mutilate"] = {
									["count"] = 0.78,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 0,
								},
							},
							["amount"] = 12.54,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["DOTs"] = {
						["Deadly Poison (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 36,
								},
								["Apothecary Hummel"] = {
									["count"] = 51,
								},
								["Apothecary Baxter"] = {
									["count"] = 15,
								},
							},
							["amount"] = 102,
						},
						["Crimson Tempest (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Apothecary Baxter"] = {
									["count"] = 12,
								},
								["Apothecary Hummel"] = {
									["count"] = 12,
								},
							},
							["amount"] = 24,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 125783,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 1,
								},
								["Absorb"] = {
									["count"] = 3,
								},
							},
							["amount"] = 4,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 25,
								},
								["Tick"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 29,
								},
							},
							["amount"] = 57,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 13,
								},
								["Hit"] = {
									["count"] = 31,
								},
								["Tick"] = {
									["count"] = 6,
								},
								["Block"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 4,
								},
								["Dodge"] = {
									["count"] = 1,
								},
							},
							["amount"] = 56,
						},
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 16,
								},
								["Hit"] = {
									["count"] = 45,
								},
								["Miss"] = {
									["count"] = 17,
								},
								["Dodge"] = {
									["count"] = 3,
								},
								["Crit"] = {
									["count"] = 17,
								},
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 99,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 35,
								},
								["Crit"] = {
									["count"] = 19,
								},
								["Hit"] = {
									["count"] = 55,
								},
							},
							["amount"] = 109,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 45144,
						["Nature"] = 106852,
					},
					["ElementTaken"] = {
						["Nature"] = 125783,
					},
					["DOT_Time"] = 144,
					["Damage"] = 1952232,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 15.56000000000001,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Physical"] = 394694,
						["Shadow"] = 107030,
						["Melee"] = 417787,
						["Nature"] = 1032721,
					},
					["PartialAbsorb"] = {
						["Alluring Perfume"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 13,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1956,
									["min"] = 1651,
									["count"] = 21,
									["amount"] = 37750,
								},
							},
							["count"] = 34,
							["amount"] = 37750,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 3228,
									["min"] = 3228,
									["count"] = 1,
									["amount"] = 3228,
								},
							},
							["count"] = 1,
							["amount"] = 3228,
						},
						["Alluring Perfume Spray"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 21958,
									["min"] = 21958,
									["count"] = 3,
									["amount"] = 65874,
								},
							},
							["count"] = 3,
							["amount"] = 65874,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 17193,
									["min"] = 13496,
									["count"] = 3,
									["amount"] = 45144,
								},
							},
							["count"] = 4,
							["amount"] = 45144,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 133033,
								},
								["Deadly Poison"] = {
									["count"] = 99417,
								},
								["Envenom"] = {
									["count"] = 68292,
								},
								["Crimson Tempest"] = {
									["count"] = 10960,
								},
								["Dispatch"] = {
									["count"] = 42371,
								},
								["Crimson Tempest (DoT)"] = {
									["count"] = 26304,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 126519,
								},
								["Touch of the Grave"] = {
									["count"] = 34773,
								},
								["Mutilate"] = {
									["count"] = 59774,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 39003,
								},
							},
							["amount"] = 640446,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 184846,
								},
								["Touch of the Grave"] = {
									["count"] = 54476,
								},
								["Envenom"] = {
									["count"] = 82435,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 23325,
								},
								["Mutilate"] = {
									["count"] = 82614,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 243120,
								},
								["Dispatch"] = {
									["count"] = 17019,
								},
								["Deadly Poison"] = {
									["count"] = 193638,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 37979,
								},
							},
							["amount"] = 919452,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 99908,
								},
								["Deadly Poison"] = {
									["count"] = 89397,
								},
								["Shiv"] = {
									["count"] = 720,
								},
								["Envenom"] = {
									["count"] = 22477,
								},
								["Touch of the Grave"] = {
									["count"] = 17781,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 65441,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 18660,
								},
								["Mutilate"] = {
									["count"] = 49900,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 28050,
								},
							},
							["amount"] = 392334,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Apothecary Baxter"] = {
							["Details"] = {
								["Irresistible Cologne"] = {
									["count"] = 28724,
								},
							},
							["amount"] = 28724,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Alluring Perfume"] = {
									["count"] = 23586,
								},
								["Alluring Perfume Spray (DoT)"] = {
									["count"] = 73473,
								},
							},
							["amount"] = 97059,
						},
					},
					["EnergyGainedFrom"] = {
						["Stabsya"] = {
							["Details"] = {
								["Relentless Strikes"] = {
									["count"] = 125,
								},
							},
							["amount"] = 125,
						},
					},
					["PartialResist"] = {
						["Alluring Perfume"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 34,
									["amount"] = 0,
								},
							},
							["count"] = 34,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Alluring Perfume Spray"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
						["Melee"] = 2690,
						["Physical"] = 11508,
					},
					["TimeHealing"] = {
						["Stabsya"] = {
							["Details"] = {
								["Leeching Poison"] = {
									["count"] = 14.74000000000001,
								},
								["Leech Vitality"] = {
									["count"] = 0.31,
								},
								["Touch of the Grave"] = {
									["count"] = 0.51,
								},
							},
							["amount"] = 15.56000000000001,
						},
					},
					["OverHeals"] = {
						["Leeching Poison"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2950,
									["min"] = 35,
									["count"] = 48,
									["amount"] = 41576,
								},
							},
							["count"] = 48,
							["amount"] = 41576,
						},
						["Leech Vitality"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16131,
									["min"] = 16131,
									["count"] = 1,
									["amount"] = 16131,
								},
							},
							["count"] = 1,
							["amount"] = 16131,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 18868,
									["min"] = 6806,
									["count"] = 6,
									["amount"] = 91047,
								},
							},
							["count"] = 6,
							["amount"] = 91047,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Stabsya"] = {
							["Details"] = {
								["Leeching Poison"] = {
									["count"] = 53490,
								},
								["Leech Vitality"] = {
									["count"] = 1965,
								},
								["Touch of the Grave"] = {
									["count"] = 21332,
								},
							},
							["amount"] = 76787,
						},
					},
					["EnergyGain"] = 125,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 148754,
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 14.07,
								},
								["Deadly Poison"] = {
									["count"] = 1.56,
								},
								["Gouge"] = {
									["count"] = 2.79,
								},
								["Envenom"] = {
									["count"] = 0.3100000000000001,
								},
								["Debilitation"] = {
									["count"] = 1.41,
								},
								["Crimson Tempest"] = {
									["count"] = 0.47,
								},
								["Dispatch"] = {
									["count"] = 1.19,
								},
								["Crimson Tempest (DoT)"] = {
									["count"] = 4.65,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 3.64,
								},
								["Touch of the Grave"] = {
									["count"] = 0.6800000000000001,
								},
								["Mutilate"] = {
									["count"] = 0.1,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 0,
								},
							},
							["amount"] = 30.87000000000001,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 17.64,
								},
								["Mutilate"] = {
									["count"] = 1.26,
								},
								["Gouge"] = {
									["count"] = 0.12,
								},
								["Envenom"] = {
									["count"] = 0.7,
								},
								["Debilitation"] = {
									["count"] = 3.01,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 1.72,
								},
								["Dispatch"] = {
									["count"] = 0.03,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 12.32,
								},
								["Deadly Poison"] = {
									["count"] = 1.69,
								},
								["Touch of the Grave"] = {
									["count"] = 1.59,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 0.03,
								},
							},
							["amount"] = 40.11000000000001,
						},
						["Stabsya"] = {
							["Details"] = {
								["Leeching Poison"] = {
									["count"] = 14.74000000000001,
								},
								["Leech Vitality"] = {
									["count"] = 0.31,
								},
								["Touch of the Grave"] = {
									["count"] = 0.51,
								},
							},
							["amount"] = 15.56000000000001,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 7.719999999999999,
								},
								["Deadly Poison"] = {
									["count"] = 1.16,
								},
								["Shiv"] = {
									["count"] = 0.1,
								},
								["Envenom"] = {
									["count"] = 0.03,
								},
								["Debilitation"] = {
									["count"] = 0.23,
								},
								["Touch of the Grave"] = {
									["count"] = 0.24,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 2.16,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.12,
								},
								["Mutilate"] = {
									["count"] = 0.78,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 0,
								},
							},
							["amount"] = 12.54,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["Leeching Poison"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 3073,
									["min"] = 75,
									["count"] = 70,
									["amount"] = 53490,
								},
							},
							["count"] = 70,
							["amount"] = 53490,
						},
						["Leech Vitality"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1965,
									["min"] = 1965,
									["count"] = 1,
									["amount"] = 1965,
								},
							},
							["count"] = 1,
							["amount"] = 1965,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 11864,
									["min"] = 2947,
									["count"] = 3,
									["amount"] = 21332,
								},
							},
							["count"] = 3,
							["amount"] = 21332,
						},
					},
					["WhoHealed"] = {
						["Stabsya"] = {
							["Details"] = {
								["Leeching Poison"] = {
									["count"] = 53490,
								},
								["Leech Vitality"] = {
									["count"] = 1965,
								},
								["Touch of the Grave"] = {
									["count"] = 21332,
								},
							},
							["amount"] = 76787,
						},
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Renew"] = {
									["count"] = 22178,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 16761,
								},
								["Prayer of Healing"] = {
									["count"] = 27622,
								},
								["Halo"] = {
									["count"] = 5061,
								},
							},
							["amount"] = 71622,
						},
					},
					["EnergyGained"] = {
						["Relentless Strikes"] = {
							["Details"] = {
								["Stabsya"] = {
									["count"] = 125,
								},
							},
							["amount"] = 125,
						},
					},
					["ActiveTime"] = 99.08000000000004,
					["Healing"] = 76787,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 6076,
									["min"] = 2121,
									["count"] = 16,
									["amount"] = 64560,
								},
								["Crit (Blocked)"] = {
									["max"] = 4102,
									["min"] = 4102,
									["count"] = 1,
									["amount"] = 4102,
								},
								["Miss"] = {
									["count"] = 17,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 9067,
									["min"] = 2316,
									["count"] = 44,
									["amount"] = 221064,
								},
								["Hit (Blocked)"] = {
									["max"] = 2174,
									["min"] = 2174,
									["count"] = 1,
									["amount"] = 2174,
								},
								["Dodge"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 15754,
									["min"] = 4455,
									["count"] = 16,
									["amount"] = 125887,
								},
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 99,
							["amount"] = 417787,
						},
						["Mutilate"] = {
							["Details"] = {
								["Hit (Blocked)"] = {
									["max"] = 9832,
									["min"] = 9832,
									["count"] = 1,
									["amount"] = 9832,
								},
								["Dodge"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 16802,
									["min"] = 10196,
									["count"] = 14,
									["amount"] = 182456,
								},
							},
							["count"] = 16,
							["amount"] = 192288,
						},
						["Gouge"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Block"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Crimson Tempest (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 4384,
									["min"] = 4384,
									["count"] = 6,
									["amount"] = 26304,
								},
							},
							["count"] = 6,
							["amount"] = 26304,
						},
						["Envenom"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 29268,
									["min"] = 28096,
									["count"] = 2,
									["amount"] = 57364,
								},
								["Hit"] = {
									["max"] = 28096,
									["min"] = 4878,
									["count"] = 8,
									["amount"] = 115840,
								},
							},
							["count"] = 10,
							["amount"] = 173204,
						},
						["Shiv"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 720,
									["min"] = 720,
									["count"] = 1,
									["amount"] = 720,
								},
							},
							["count"] = 1,
							["amount"] = 720,
						},
						["Debilitation"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Crimson Tempest"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 10960,
									["min"] = 10960,
									["count"] = 1,
									["amount"] = 10960,
								},
							},
							["count"] = 1,
							["amount"] = 10960,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9330,
									["min"] = 9330,
									["count"] = 1,
									["amount"] = 9330,
								},
								["Tick"] = {
									["max"] = 4665,
									["min"] = 4665,
									["count"] = 7,
									["amount"] = 32655,
								},
							},
							["count"] = 8,
							["amount"] = 41985,
						},
						["Dispatch"] = {
							["Details"] = {
								["Hit (Blocked)"] = {
									["max"] = 17019,
									["min"] = 17019,
									["count"] = 1,
									["amount"] = 17019,
								},
								["Hit"] = {
									["max"] = 21516,
									["min"] = 20855,
									["count"] = 2,
									["amount"] = 42371,
								},
							},
							["count"] = 3,
							["amount"] = 59390,
						},
						["Deadly Poison (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 27854,
									["min"] = 19464,
									["count"] = 6,
									["amount"] = 127995,
								},
								["Tick"] = {
									["max"] = 13927,
									["min"] = 9732,
									["count"] = 28,
									["amount"] = 307085,
								},
							},
							["count"] = 34,
							["amount"] = 435080,
						},
						["Deadly Poison"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 14391,
									["min"] = 9784,
									["count"] = 10,
									["amount"] = 113193,
								},
								["Hit"] = {
									["max"] = 7264,
									["min"] = 4901,
									["count"] = 47,
									["amount"] = 269259,
								},
							},
							["count"] = 57,
							["amount"] = 382452,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 19454,
									["min"] = 16803,
									["count"] = 6,
									["amount"] = 107030,
								},
							},
							["count"] = 6,
							["amount"] = 107030,
						},
						["Mutilate Off-Hand"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 11844,
									["min"] = 10804,
									["count"] = 3,
									["amount"] = 34098,
								},
								["Hit"] = {
									["max"] = 7026,
									["min"] = 4809,
									["count"] = 12,
									["amount"] = 70934,
								},
							},
							["count"] = 15,
							["amount"] = 105032,
						},
					},
					["HealingTaken"] = 148409,
					["RageGain"] = 0,
					["TimeDamage"] = 83.52000000000008,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 14.07,
								},
								["Deadly Poison"] = {
									["count"] = 1.56,
								},
								["Gouge"] = {
									["count"] = 2.79,
								},
								["Envenom"] = {
									["count"] = 0.3100000000000001,
								},
								["Debilitation"] = {
									["count"] = 1.41,
								},
								["Crimson Tempest"] = {
									["count"] = 0.47,
								},
								["Dispatch"] = {
									["count"] = 1.19,
								},
								["Crimson Tempest (DoT)"] = {
									["count"] = 4.65,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 3.64,
								},
								["Touch of the Grave"] = {
									["count"] = 0.6800000000000001,
								},
								["Mutilate"] = {
									["count"] = 0.1,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 0,
								},
							},
							["amount"] = 30.87000000000001,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 17.64,
								},
								["Mutilate"] = {
									["count"] = 1.26,
								},
								["Gouge"] = {
									["count"] = 0.12,
								},
								["Envenom"] = {
									["count"] = 0.7,
								},
								["Debilitation"] = {
									["count"] = 3.01,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 1.72,
								},
								["Dispatch"] = {
									["count"] = 0.03,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 12.32,
								},
								["Deadly Poison"] = {
									["count"] = 1.69,
								},
								["Touch of the Grave"] = {
									["count"] = 1.59,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 0.03,
								},
							},
							["amount"] = 40.11000000000001,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 7.719999999999999,
								},
								["Deadly Poison"] = {
									["count"] = 1.16,
								},
								["Shiv"] = {
									["count"] = 0.1,
								},
								["Envenom"] = {
									["count"] = 0.03,
								},
								["Debilitation"] = {
									["count"] = 0.23,
								},
								["Touch of the Grave"] = {
									["count"] = 0.24,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 2.16,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.12,
								},
								["Mutilate"] = {
									["count"] = 0.78,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 0,
								},
							},
							["amount"] = 12.54,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["ElementDoneBlock"] = {
						["Melee"] = 2690,
						["Physical"] = 11508,
					},
					["TimeHealing"] = {
						["Stabsya"] = {
							["Details"] = {
								["Leeching Poison"] = {
									["count"] = 14.74000000000001,
								},
								["Leech Vitality"] = {
									["count"] = 0.31,
								},
								["Touch of the Grave"] = {
									["count"] = 0.51,
								},
							},
							["amount"] = 15.56000000000001,
						},
					},
					["OverHeals"] = {
						["Leeching Poison"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2950,
									["min"] = 35,
									["count"] = 48,
									["amount"] = 41576,
								},
							},
							["count"] = 48,
							["amount"] = 41576,
						},
						["Leech Vitality"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16131,
									["min"] = 16131,
									["count"] = 1,
									["amount"] = 16131,
								},
							},
							["count"] = 1,
							["amount"] = 16131,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 18868,
									["min"] = 6806,
									["count"] = 6,
									["amount"] = 91047,
								},
							},
							["count"] = 6,
							["amount"] = 91047,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 133033,
								},
								["Deadly Poison"] = {
									["count"] = 99417,
								},
								["Envenom"] = {
									["count"] = 68292,
								},
								["Crimson Tempest"] = {
									["count"] = 10960,
								},
								["Dispatch"] = {
									["count"] = 42371,
								},
								["Crimson Tempest (DoT)"] = {
									["count"] = 26304,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 126519,
								},
								["Touch of the Grave"] = {
									["count"] = 34773,
								},
								["Mutilate"] = {
									["count"] = 59774,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 39003,
								},
							},
							["amount"] = 640446,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 184846,
								},
								["Touch of the Grave"] = {
									["count"] = 54476,
								},
								["Envenom"] = {
									["count"] = 82435,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 23325,
								},
								["Mutilate"] = {
									["count"] = 82614,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 243120,
								},
								["Dispatch"] = {
									["count"] = 17019,
								},
								["Deadly Poison"] = {
									["count"] = 193638,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 37979,
								},
							},
							["amount"] = 919452,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 7808,
								},
								["Mutilate"] = {
									["count"] = 16923,
								},
							},
							["amount"] = 24731,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 99908,
								},
								["Deadly Poison"] = {
									["count"] = 89397,
								},
								["Shiv"] = {
									["count"] = 720,
								},
								["Envenom"] = {
									["count"] = 22477,
								},
								["Touch of the Grave"] = {
									["count"] = 17781,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 65441,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 18660,
								},
								["Mutilate"] = {
									["count"] = 49900,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 28050,
								},
							},
							["amount"] = 392334,
						},
					},
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 14.07,
								},
								["Deadly Poison"] = {
									["count"] = 1.56,
								},
								["Gouge"] = {
									["count"] = 2.79,
								},
								["Envenom"] = {
									["count"] = 0.3100000000000001,
								},
								["Debilitation"] = {
									["count"] = 1.41,
								},
								["Crimson Tempest"] = {
									["count"] = 0.47,
								},
								["Dispatch"] = {
									["count"] = 1.19,
								},
								["Crimson Tempest (DoT)"] = {
									["count"] = 4.65,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 3.64,
								},
								["Touch of the Grave"] = {
									["count"] = 0.6800000000000001,
								},
								["Mutilate"] = {
									["count"] = 0.1,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 0,
								},
							},
							["amount"] = 30.87000000000001,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 17.64,
								},
								["Mutilate"] = {
									["count"] = 1.26,
								},
								["Gouge"] = {
									["count"] = 0.12,
								},
								["Envenom"] = {
									["count"] = 0.7,
								},
								["Debilitation"] = {
									["count"] = 3.01,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 1.72,
								},
								["Dispatch"] = {
									["count"] = 0.03,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 12.32,
								},
								["Deadly Poison"] = {
									["count"] = 1.69,
								},
								["Touch of the Grave"] = {
									["count"] = 1.59,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 0.03,
								},
							},
							["amount"] = 40.11000000000001,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
								["Mutilate"] = {
									["count"] = 0.29,
								},
							},
							["amount"] = 3.79,
						},
						["Stabsya"] = {
							["Details"] = {
								["Leeching Poison"] = {
									["count"] = 14.74000000000001,
								},
								["Leech Vitality"] = {
									["count"] = 0.31,
								},
								["Touch of the Grave"] = {
									["count"] = 0.51,
								},
							},
							["amount"] = 15.56000000000001,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 7.719999999999999,
								},
								["Deadly Poison"] = {
									["count"] = 1.16,
								},
								["Shiv"] = {
									["count"] = 0.1,
								},
								["Envenom"] = {
									["count"] = 0.03,
								},
								["Debilitation"] = {
									["count"] = 0.23,
								},
								["Touch of the Grave"] = {
									["count"] = 0.24,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 2.16,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.12,
								},
								["Mutilate"] = {
									["count"] = 0.78,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 0,
								},
							},
							["amount"] = 12.54,
						},
					},
					["WhoHealed"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Renew"] = {
									["count"] = 22178,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 16761,
								},
								["Prayer of Healing"] = {
									["count"] = 44983,
								},
								["Halo"] = {
									["count"] = 5061,
								},
							},
							["amount"] = 88983,
						},
						["Stabsya"] = {
							["Details"] = {
								["Leeching Poison"] = {
									["count"] = 53490,
								},
								["Leech Vitality"] = {
									["count"] = 1965,
								},
								["Touch of the Grave"] = {
									["count"] = 21332,
								},
							},
							["amount"] = 76787,
						},
					},
					["HealedWho"] = {
						["Stabsya"] = {
							["Details"] = {
								["Leeching Poison"] = {
									["count"] = 53490,
								},
								["Leech Vitality"] = {
									["count"] = 1965,
								},
								["Touch of the Grave"] = {
									["count"] = 21332,
								},
							},
							["amount"] = 76787,
						},
					},
					["PartialResist"] = {
						["Alluring Perfume"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 34,
									["amount"] = 0,
								},
							},
							["count"] = 34,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 15,
									["amount"] = 0,
								},
							},
							["count"] = 15,
							["amount"] = 0,
						},
						["Slashing Claws"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Alluring Perfume Spray"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
					},
					["EnergyGain"] = 125,
					["PartialAbsorb"] = {
						["Alluring Perfume"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 13,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1956,
									["min"] = 1651,
									["count"] = 21,
									["amount"] = 37750,
								},
							},
							["count"] = 34,
							["amount"] = 37750,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 3228,
									["min"] = 3228,
									["count"] = 1,
									["amount"] = 3228,
								},
							},
							["count"] = 1,
							["amount"] = 3228,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 12,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 17193,
									["min"] = 13496,
									["count"] = 3,
									["amount"] = 45144,
								},
							},
							["count"] = 15,
							["amount"] = 45144,
						},
						["Slashing Claws"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 16,
									["amount"] = 0,
								},
							},
							["count"] = 16,
							["amount"] = 0,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Alluring Perfume Spray"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 21958,
									["min"] = 21958,
									["count"] = 3,
									["amount"] = 65874,
								},
							},
							["count"] = 3,
							["amount"] = 65874,
						},
					},
					["ActiveTime"] = 102.87,
					["ElementTakenAbsorb"] = {
						["Melee"] = 45144,
						["Nature"] = 106852,
					},
					["ElementTaken"] = {
						["Nature"] = 125783,
					},
					["DOT_Time"] = 144,
					["Damage"] = 1976963,
					["DOTs"] = {
						["Deadly Poison (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 36,
								},
								["Apothecary Hummel"] = {
									["count"] = 51,
								},
								["Apothecary Baxter"] = {
									["count"] = 15,
								},
							},
							["amount"] = 102,
						},
						["Crimson Tempest (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Apothecary Baxter"] = {
									["count"] = 12,
								},
								["Apothecary Hummel"] = {
									["count"] = 12,
								},
							},
							["amount"] = 24,
						},
					},
					["TimeHeal"] = 15.56000000000001,
					["Overhealing"] = 148754,
					["EnergyGained"] = {
						["Relentless Strikes"] = {
							["Details"] = {
								["Stabsya"] = {
									["count"] = 125,
								},
							},
							["amount"] = 125,
						},
					},
					["Heals"] = {
						["Leeching Poison"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 3073,
									["min"] = 75,
									["count"] = 70,
									["amount"] = 53490,
								},
							},
							["count"] = 70,
							["amount"] = 53490,
						},
						["Leech Vitality"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1965,
									["min"] = 1965,
									["count"] = 1,
									["amount"] = 1965,
								},
							},
							["count"] = 1,
							["amount"] = 1965,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 11864,
									["min"] = 2947,
									["count"] = 3,
									["amount"] = 21332,
								},
							},
							["count"] = 3,
							["amount"] = 21332,
						},
					},
					["Healing"] = 76787,
					["WhoDamaged"] = {
						["Apothecary Baxter"] = {
							["Details"] = {
								["Irresistible Cologne"] = {
									["count"] = 28724,
								},
							},
							["amount"] = 28724,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Alluring Perfume"] = {
									["count"] = 23586,
								},
								["Alluring Perfume Spray (DoT)"] = {
									["count"] = 73473,
								},
							},
							["amount"] = 97059,
						},
					},
					["DamageTaken"] = 125783,
					["ElementDone"] = {
						["Shadow"] = 107030,
						["Physical"] = 411617,
						["Melee"] = 425595,
						["Nature"] = 1032721,
					},
					["HealingTaken"] = 165770,
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 13,
								},
								["Hit"] = {
									["count"] = 32,
								},
								["Tick"] = {
									["count"] = 6,
								},
								["Block"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 4,
								},
								["Dodge"] = {
									["count"] = 1,
								},
							},
							["amount"] = 57,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 16,
								},
								["Hit"] = {
									["count"] = 46,
								},
								["Miss"] = {
									["count"] = 17,
								},
								["Dodge"] = {
									["count"] = 3,
								},
								["Crit"] = {
									["count"] = 17,
								},
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 100,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 35,
								},
								["Crit"] = {
									["count"] = 19,
								},
								["Hit"] = {
									["count"] = 55,
								},
							},
							["amount"] = 109,
						},
					},
					["TimeDamage"] = 87.31000000000009,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 14.07,
								},
								["Deadly Poison"] = {
									["count"] = 1.56,
								},
								["Gouge"] = {
									["count"] = 2.79,
								},
								["Envenom"] = {
									["count"] = 0.3100000000000001,
								},
								["Debilitation"] = {
									["count"] = 1.41,
								},
								["Crimson Tempest"] = {
									["count"] = 0.47,
								},
								["Dispatch"] = {
									["count"] = 1.19,
								},
								["Crimson Tempest (DoT)"] = {
									["count"] = 4.65,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 3.64,
								},
								["Touch of the Grave"] = {
									["count"] = 0.6800000000000001,
								},
								["Mutilate"] = {
									["count"] = 0.1,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 0,
								},
							},
							["amount"] = 30.87000000000001,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 17.64,
								},
								["Mutilate"] = {
									["count"] = 1.26,
								},
								["Gouge"] = {
									["count"] = 0.12,
								},
								["Envenom"] = {
									["count"] = 0.7,
								},
								["Debilitation"] = {
									["count"] = 3.01,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 1.72,
								},
								["Dispatch"] = {
									["count"] = 0.03,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 12.32,
								},
								["Deadly Poison"] = {
									["count"] = 1.69,
								},
								["Touch of the Grave"] = {
									["count"] = 1.59,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 0.03,
								},
							},
							["amount"] = 40.11000000000001,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
								["Mutilate"] = {
									["count"] = 0.29,
								},
							},
							["amount"] = 3.79,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 7.719999999999999,
								},
								["Deadly Poison"] = {
									["count"] = 1.16,
								},
								["Shiv"] = {
									["count"] = 0.1,
								},
								["Envenom"] = {
									["count"] = 0.03,
								},
								["Debilitation"] = {
									["count"] = 0.23,
								},
								["Touch of the Grave"] = {
									["count"] = 0.24,
								},
								["Deadly Poison (DoT)"] = {
									["count"] = 2.16,
								},
								["Mantid Poison (DoT)"] = {
									["count"] = 0.12,
								},
								["Mutilate"] = {
									["count"] = 0.78,
								},
								["Mutilate Off-Hand"] = {
									["count"] = 0,
								},
							},
							["amount"] = 12.54,
						},
					},
					["EnergyGainedFrom"] = {
						["Stabsya"] = {
							["Details"] = {
								["Relentless Strikes"] = {
									["count"] = 125,
								},
							},
							["amount"] = 125,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 6076,
									["min"] = 2121,
									["count"] = 16,
									["amount"] = 64560,
								},
								["Crit (Blocked)"] = {
									["max"] = 4102,
									["min"] = 4102,
									["count"] = 1,
									["amount"] = 4102,
								},
								["Miss"] = {
									["count"] = 17,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 9067,
									["min"] = 2316,
									["count"] = 45,
									["amount"] = 228872,
								},
								["Hit (Blocked)"] = {
									["max"] = 2174,
									["min"] = 2174,
									["count"] = 1,
									["amount"] = 2174,
								},
								["Dodge"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 15754,
									["min"] = 4455,
									["count"] = 16,
									["amount"] = 125887,
								},
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 100,
							["amount"] = 425595,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 19454,
									["min"] = 16803,
									["count"] = 6,
									["amount"] = 107030,
								},
							},
							["count"] = 6,
							["amount"] = 107030,
						},
						["Gouge"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Block"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Crimson Tempest (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 4384,
									["min"] = 4384,
									["count"] = 6,
									["amount"] = 26304,
								},
							},
							["count"] = 6,
							["amount"] = 26304,
						},
						["Envenom"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 29268,
									["min"] = 28096,
									["count"] = 2,
									["amount"] = 57364,
								},
								["Hit"] = {
									["max"] = 28096,
									["min"] = 4878,
									["count"] = 8,
									["amount"] = 115840,
								},
							},
							["count"] = 10,
							["amount"] = 173204,
						},
						["Shiv"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 720,
									["min"] = 720,
									["count"] = 1,
									["amount"] = 720,
								},
							},
							["count"] = 1,
							["amount"] = 720,
						},
						["Debilitation"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Crimson Tempest"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 10960,
									["min"] = 10960,
									["count"] = 1,
									["amount"] = 10960,
								},
							},
							["count"] = 1,
							["amount"] = 10960,
						},
						["Mantid Poison (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9330,
									["min"] = 9330,
									["count"] = 1,
									["amount"] = 9330,
								},
								["Tick"] = {
									["max"] = 4665,
									["min"] = 4665,
									["count"] = 7,
									["amount"] = 32655,
								},
							},
							["count"] = 8,
							["amount"] = 41985,
						},
						["Dispatch"] = {
							["Details"] = {
								["Hit (Blocked)"] = {
									["max"] = 17019,
									["min"] = 17019,
									["count"] = 1,
									["amount"] = 17019,
								},
								["Hit"] = {
									["max"] = 21516,
									["min"] = 20855,
									["count"] = 2,
									["amount"] = 42371,
								},
							},
							["count"] = 3,
							["amount"] = 59390,
						},
						["Deadly Poison (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 27854,
									["min"] = 19464,
									["count"] = 6,
									["amount"] = 127995,
								},
								["Tick"] = {
									["max"] = 13927,
									["min"] = 9732,
									["count"] = 28,
									["amount"] = 307085,
								},
							},
							["count"] = 34,
							["amount"] = 435080,
						},
						["Mutilate"] = {
							["Details"] = {
								["Hit (Blocked)"] = {
									["max"] = 9832,
									["min"] = 9832,
									["count"] = 1,
									["amount"] = 9832,
								},
								["Dodge"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 16923,
									["min"] = 10196,
									["count"] = 15,
									["amount"] = 199379,
								},
							},
							["count"] = 17,
							["amount"] = 209211,
						},
						["Deadly Poison"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 14391,
									["min"] = 9784,
									["count"] = 10,
									["amount"] = 113193,
								},
								["Hit"] = {
									["max"] = 7264,
									["min"] = 4901,
									["count"] = 47,
									["amount"] = 269259,
								},
							},
							["count"] = 57,
							["amount"] = 382452,
						},
						["Mutilate Off-Hand"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 11844,
									["min"] = 10804,
									["count"] = 3,
									["amount"] = 34098,
								},
								["Hit"] = {
									["max"] = 7026,
									["min"] = 4809,
									["count"] = 12,
									["amount"] = 70934,
								},
							},
							["count"] = 15,
							["amount"] = 105032,
						},
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 3,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Miss"] = {
									["count"] = 11,
								},
							},
							["amount"] = 15,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 25,
								},
								["Tick"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 29,
								},
							},
							["amount"] = 57,
						},
					},
				},
			},
			["UnitLockout"] = 1360559350,
			["LastActive"] = 1360559620,
		},
		["Tanklord-Tichondrius"] = {
			["GUID"] = "0x030000000789CCCC",
			["LastEventHealth"] = {
				"360527 (96%)", -- [1]
				"374723 (100%)", -- [2]
				"374723 (100%)", -- [3]
				"374723 (100%)", -- [4]
				"374723 (100%)", -- [5]
				"374723 (100%)", -- [6]
				"374723 (100%)", -- [7]
				"374723 (100%)", -- [8]
				"374723 (100%)", -- [9]
				"374723 (100%)", -- [10]
				"374723 (100%)", -- [11]
				"374723 (100%)", -- [12]
				"374723 (100%)", -- [13]
				"374723 (100%)", -- [14]
				"374723 (100%)", -- [15]
				"374723 (100%)", -- [16]
				"374723 (100%)", -- [17]
				"374723 (100%)", -- [18]
				"374723 (100%)", -- [19]
				"374723 (100%)", -- [20]
				"374723 (100%)", -- [21]
				"374723 (100%)", -- [22]
				"374723 (100%)", -- [23]
				"374723 (100%)", -- [24]
				"374723 (100%)", -- [25]
				"374723 (100%)", -- [26]
				"374723 (100%)", -- [27]
				"374723 (100%)", -- [28]
				"374723 (100%)", -- [29]
				"374723 (100%)", -- [30]
				"374723 (100%)", -- [31]
				"374723 (100%)", -- [32]
				"374723 (100%)", -- [33]
				"374723 (100%)", -- [34]
				"374723 (100%)", -- [35]
				"374723 (100%)", -- [36]
				"374723 (100%)", -- [37]
				"374723 (100%)", -- [38]
				"374723 (100%)", -- [39]
				"374723 (100%)", -- [40]
				"374723 (100%)", -- [41]
				"374723 (100%)", -- [42]
				"374723 (100%)", -- [43]
				"360527 (96%)", -- [44]
				"360527 (96%)", -- [45]
				"360527 (96%)", -- [46]
				"360527 (96%)", -- [47]
				"360527 (96%)", -- [48]
				"360527 (96%)", -- [49]
				"360527 (96%)", -- [50]
			},
			["LastAttackedBy"] = "Apothecary Frye",
			["LastEventType"] = {
				"HEAL", -- [1]
				"HEAL", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"HEAL", -- [6]
				"HEAL", -- [7]
				"HEAL", -- [8]
				"HEAL", -- [9]
				"HEAL", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"HEAL", -- [14]
				"HEAL", -- [15]
				"DAMAGE", -- [16]
				"HEAL", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"HEAL", -- [23]
				"DAMAGE", -- [24]
				"HEAL", -- [25]
				"DAMAGE", -- [26]
				"HEAL", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"HEAL", -- [30]
				"DAMAGE", -- [31]
				"HEAL", -- [32]
				"DAMAGE", -- [33]
				"HEAL", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"HEAL", -- [38]
				"HEAL", -- [39]
				"HEAL", -- [40]
				"HEAL", -- [41]
				"HEAL", -- [42]
				"HEAL", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"HEAL", -- [46]
				"HEAL", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					39.67000000000002, -- [1]
				},
				["Healing"] = {
					1518460, -- [1]
				},
				["DamageTaken"] = {
					79627, -- [1]
				},
				["ActiveTime"] = {
					102.59, -- [1]
				},
				["Absorbs"] = {
					388307, -- [1]
				},
				["HealingTaken"] = {
					79627, -- [1]
				},
				["Overhealing"] = {
					1293387, -- [1]
				},
				["TimeDamage"] = {
					62.92, -- [1]
				},
				["HOT_Time"] = {
					12, -- [1]
				},
				["ManaGain"] = {
					26000, -- [1]
				},
				["DOT_Time"] = {
					255, -- [1]
				},
				["Damage"] = {
					1209246, -- [1]
				},
			},
			["enClass"] = "PRIEST",
			["unit"] = "Tanklord",
			["level"] = 90,
			["LastDamageAbility"] = "Melee",
			["LastFightIn"] = 1,
			["LastEventNum"] = {
				[6] = 8.613295687748016,
				[2] = 15.43433416150063,
				[38] = 8.185513032293187,
				[14] = 4.459293931784278,
			},
			["type"] = "Ungrouped",
			["FightsSaved"] = 2,
			["LastDamageTaken"] = 15368,
			["TimeLast"] = {
				["TimeHeal"] = 1360559613,
				["ActiveTime"] = 1360559619,
				["OVERALL"] = 1360559620,
				["DamageTaken"] = 1360559590,
				["HOT_Time"] = 1360559540,
				["Absorbs"] = 1360559618,
				["HealingTaken"] = 1360559602,
				["Overhealing"] = 1360559620,
				["TimeDamage"] = 1360559619,
				["Healing"] = 1360559613,
				["ManaGain"] = 1360559571,
				["DOT_Time"] = 1360559619,
				["Damage"] = 1360559619,
			},
			["Owner"] = false,
			["LastAbility"] = 19802.39,
			["NextEventNum"] = 44,
			["LastEventHealthNum"] = {
				96.21160163640876, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				100, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				100, -- [11]
				100, -- [12]
				100, -- [13]
				100, -- [14]
				100, -- [15]
				100, -- [16]
				100, -- [17]
				100, -- [18]
				100, -- [19]
				100, -- [20]
				100, -- [21]
				100, -- [22]
				100, -- [23]
				100, -- [24]
				100, -- [25]
				100, -- [26]
				100, -- [27]
				100, -- [28]
				100, -- [29]
				100, -- [30]
				100, -- [31]
				100, -- [32]
				100, -- [33]
				100, -- [34]
				100, -- [35]
				100, -- [36]
				100, -- [37]
				100, -- [38]
				100, -- [39]
				100, -- [40]
				100, -- [41]
				100, -- [42]
				100, -- [43]
				96.21160163640876, -- [44]
				96.21160163640876, -- [45]
				96.21160163640876, -- [46]
				96.21160163640876, -- [47]
				96.21160163640876, -- [48]
				96.21160163640876, -- [49]
				96.21160163640876, -- [50]
			},
			["LastEvents"] = {
				"Tanklord-Tichondrius Flash Heal Metalica-Jubei'Thos Hit +58285", -- [1]
				"Tanklord-Tichondrius Flash Heal Tanklord-Tichondrius Hit +57836 (43640 overheal)", -- [2]
				"Tanklord-Tichondrius Shadow Word: Pain (DoT) Apothecary Frye Tick -8090 (Shadow)", -- [3]
				"Tanklord-Tichondrius Shadow Word: Pain (DoT) Apothecary Frye Tick -8090 (Shadow)", -- [4]
				"Tanklord-Tichondrius Shadow Word: Pain (DoT) Apothecary Frye Tick -8090 (Shadow)", -- [5]
				"Tanklord-Tichondrius Prayer of Healing Tanklord-Tichondrius Hit +32276 (32276 overheal)", -- [6]
				"Tanklord-Tichondrius Prayer of Healing Acindor-Jubei'Thos Hit +29131 (29131 overheal)", -- [7]
				"Tanklord-Tichondrius Prayer of Healing Stabsya Hit +29432 (28985 overheal)", -- [8]
				"Tanklord-Tichondrius Prayer of Healing Müu-Jubei'Thos Hit +27878 (8517 overheal)", -- [9]
				"Tanklord-Tichondrius Prayer of Healing Metalica-Jubei'Thos Hit +32046 (26488 overheal)", -- [10]
				"Tanklord-Tichondrius Shadow Word: Pain (DoT) Apothecary Frye Tick -8090 (Shadow)", -- [11]
				"Tanklord-Tichondrius Touch of the Grave Apothecary Frye Hit -15915 (Shadow)", -- [12]
				"Tanklord-Tichondrius Penance Apothecary Frye Hit -32841 (Holy)", -- [13]
				"Tanklord-Tichondrius Touch of the Grave Tanklord-Tichondrius Hit +16710 (16710 overheal)", -- [14]
				"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +32841 (19886 overheal)", -- [15]
				"Tanklord-Tichondrius Penance Apothecary Frye Hit -32740 (Holy)", -- [16]
				"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +32740 (32501 overheal)", -- [17]
				"Tanklord-Tichondrius Shadow Word: Pain (DoT) Apothecary Frye Crit -16180 (Shadow)", -- [18]
				"Tanklord-Tichondrius Holy Fire Apothecary Frye Crit -62360 (Holy)", -- [19]
				"Tanklord-Tichondrius Shadow Word: Pain (DoT) Apothecary Frye Tick -7235 (Shadow)", -- [20]
				"No One Concentrated Alluring Perfume Spill Tanklord-Tichondrius Absorb (2873 Absorbed) (Nature)", -- [21]
				"Tanklord-Tichondrius Shadow Word: Pain (DoT) Apothecary Frye Tick -7236 (Shadow)", -- [22]
				"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Crit +62360 (61573 overheal)", -- [23]
				"Tanklord-Tichondrius Holy Fire (DoT) Apothecary Frye Tick -913 (Holy)", -- [24]
				"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +913 (913 overheal)", -- [25]
				"Tanklord-Tichondrius Holy Fire (DoT) Apothecary Frye Tick -913 (Holy)", -- [26]
				"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +913 (913 overheal)", -- [27]
				"Tanklord-Tichondrius Holy Fire (DoT) Apothecary Frye Tick -912 (Holy)", -- [28]
				"Tanklord-Tichondrius Shadow Word: Pain (DoT) Apothecary Frye Tick -7236 (Shadow)", -- [29]
				"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +912 (912 overheal)", -- [30]
				"Tanklord-Tichondrius Holy Fire (DoT) Apothecary Frye Tick -912 (Holy)", -- [31]
				"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +912 (912 overheal)", -- [32]
				"Tanklord-Tichondrius Holy Fire (DoT) Apothecary Frye Tick -912 (Holy)", -- [33]
				"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +912 (912 overheal)", -- [34]
				"Tanklord-Tichondrius Holy Fire (DoT) Apothecary Frye Tick -912 (Holy)", -- [35]
				"Tanklord-Tichondrius Shadow Word: Pain (DoT) Apothecary Frye Tick -7235 (Shadow)", -- [36]
				"Tanklord-Tichondrius Holy Fire (DoT) Apothecary Frye Tick -912 (Holy)", -- [37]
				"Tanklord-Tichondrius Prayer of Healing Tanklord-Tichondrius Hit +30673 (30673 overheal)", -- [38]
				"Tanklord-Tichondrius Atonement Müu-Jubei'Thos Hit +912 (912 overheal)", -- [39]
				"Tanklord-Tichondrius Prayer of Healing Acindor-Jubei'Thos Hit +31075 (31075 overheal)", -- [40]
				"Tanklord-Tichondrius Prayer of Healing Stabsya Crit +61338 (61338 overheal)", -- [41]
				"Tanklord-Tichondrius Prayer of Healing Müu-Jubei'Thos Crit +58413 (58413 overheal)", -- [42]
				"Tanklord-Tichondrius Prayer of Healing Metalica-Jubei'Thos Hit +30785 (30785 overheal)", -- [43]
				"Tanklord-Tichondrius Smite Apothecary Frye Hit -24780 (Holy)", -- [44]
				"Tanklord-Tichondrius Holy Fire (DoT) Apothecary Frye Tick -839 (Holy)", -- [45]
				"Tanklord-Tichondrius Atonement Mirror Image <Acindor-Jubei'Thos> Hit +24780 (22356 overheal)", -- [46]
				"Tanklord-Tichondrius Atonement Mirror Image <Acindor-Jubei'Thos> Hit +839 (839 overheal)", -- [47]
				"Tanklord-Tichondrius Shadow Word: Pain (DoT) Apothecary Frye Tick -7704 (Shadow)", -- [48]
				"Tanklord-Tichondrius Shadow Word: Pain (DoT) Apothecary Frye Crit -15410 (Shadow)", -- [49]
				"Tanklord-Tichondrius Shadow Word: Pain (DoT) Apothecary Frye Tick -7705 (Shadow)", -- [50]
			},
			["Name"] = "Tanklord-Tichondrius",
			["LastEventIncoming"] = {
				false, -- [1]
				true, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				true, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				true, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				true, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				true, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				19784.21, -- [1]
				19784.981, -- [2]
				19785.588, -- [3]
				19787.67, -- [4]
				19789.735, -- [5]
				19790.089, -- [6]
				19790.249, -- [7]
				19790.249, -- [8]
				19790.249, -- [9]
				19790.249, -- [10]
				19791.816, -- [11]
				19792.255, -- [12]
				19792.442, -- [13]
				19792.659, -- [14]
				19793.076, -- [15]
				19793.371, -- [16]
				19793.886, -- [17]
				19793.886, -- [18]
				19795.895, -- [19]
				19795.895, -- [20]
				19795.895, -- [21]
				19795.958, -- [22]
				19796.711, -- [23]
				19796.818, -- [24]
				19797.51, -- [25]
				19797.747, -- [26]
				19798.307, -- [27]
				19798.681, -- [28]
				19798.736, -- [29]
				19799.128, -- [30]
				19799.614, -- [31]
				19800.335, -- [32]
				19800.527, -- [33]
				19801.15, -- [34]
				19801.458, -- [35]
				19801.532, -- [36]
				19802.39, -- [37]
				19802.832, -- [38]
				19803.136, -- [39]
				19803.136, -- [40]
				19803.136, -- [41]
				19803.136, -- [42]
				19803.136, -- [43]
				19778.158, -- [44]
				19778.239, -- [45]
				19778.958, -- [46]
				19778.958, -- [47]
				19779.367, -- [48]
				19781.442, -- [49]
				19783.511, -- [50]
			},
			["Fights"] = {
				["Fight2"] = {
					["TimeHealing"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Stabsya"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["Prayer of Healing"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 32925,
									["min"] = 32925,
									["count"] = 1,
									["amount"] = 32925,
								},
								["Hit"] = {
									["max"] = 25056,
									["min"] = 1757,
									["count"] = 4,
									["amount"] = 58383,
								},
							},
							["count"] = 5,
							["amount"] = 91308,
						},
					},
					["TimeSpent"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Corpse Eater"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Stabsya"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 2.03,
								},
							},
							["amount"] = 2.03,
						},
					},
					["HealedWho"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 18277,
								},
							},
							["amount"] = 18277,
						},
						["Stabsya"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 17361,
								},
							},
							["amount"] = 17361,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 23373,
								},
							},
							["amount"] = 23373,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["Overhealing"] = 91308,
					["ActiveTime"] = 9.029999999999999,
					["DOT_Time"] = 9,
					["Damage"] = 18546,
					["TimeHeal"] = 3.5,
					["ShieldedWho"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Acindor-Jubei'Thos"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Stabsya"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Healing"] = 59011,
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Shadow"] = 18546,
					},
					["Heals"] = {
						["Prayer of Healing"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 17361,
									["min"] = 17361,
									["count"] = 1,
									["amount"] = 17361,
								},
								["Hit"] = {
									["max"] = 23373,
									["min"] = 18277,
									["count"] = 2,
									["amount"] = 41650,
								},
							},
							["count"] = 3,
							["amount"] = 59011,
						},
					},
					["DamagedWho"] = {
						["Corpse Eater"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 6182,
								},
							},
							["amount"] = 6182,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 12364,
								},
							},
							["amount"] = 12364,
						},
					},
					["TimeDamage"] = 5.529999999999999,
					["TimeDamaging"] = {
						["Corpse Eater"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 2.03,
								},
							},
							["amount"] = 2.03,
						},
					},
					["DOTs"] = {
						["Shadow Word: Pain (DoT)"] = {
							["Details"] = {
								["Corpse Eater"] = {
									["count"] = 3,
								},
								["Frantic Geist"] = {
									["count"] = 6,
								},
							},
							["amount"] = 9,
						},
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["Attacks"] = {
						["Shadow Word: Pain (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 6182,
									["min"] = 6182,
									["count"] = 3,
									["amount"] = 18546,
								},
							},
							["count"] = 3,
							["amount"] = 18546,
						},
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["Absorbed"] = {
						["Divine Aegis"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["max"] = 41981,
									["min"] = 1485,
									["count"] = 6,
									["amount"] = 131129,
								},
								["Müu-Jubei'Thos"] = {
									["max"] = 30373,
									["min"] = 17787,
									["count"] = 3,
									["amount"] = 67557,
								},
								["Tanklord-Tichondrius"] = {
									["max"] = 14533,
									["min"] = 14533,
									["count"] = 1,
									["amount"] = 14533,
								},
								["Risen Ally"] = {
									["max"] = 2176,
									["min"] = 2176,
									["count"] = 1,
									["amount"] = 2176,
								},
								["Stabsya"] = {
									["max"] = 20866,
									["min"] = 18908,
									["count"] = 2,
									["amount"] = 39774,
								},
								["Acindor-Jubei'Thos"] = {
									["max"] = 5434,
									["min"] = 5434,
									["count"] = 1,
									["amount"] = 5434,
								},
							},
							["count"] = 14,
							["amount"] = 260603,
						},
						["Power Word: Shield"] = {
							["Details"] = {
								["Stabsya"] = {
									["max"] = 63852,
									["min"] = 63852,
									["count"] = 1,
									["amount"] = 63852,
								},
								["Metalica-Jubei'Thos"] = {
									["max"] = 63852,
									["min"] = 63852,
									["count"] = 1,
									["amount"] = 63852,
								},
							},
							["count"] = 2,
							["amount"] = 127704,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 7,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DOTs"] = {
						["Shadow Word: Pain (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 87,
								},
								["Apothecary Hummel"] = {
									["count"] = 24,
								},
								["Apothecary Baxter"] = {
									["count"] = 27,
								},
							},
							["amount"] = 138,
						},
						["Holy Fire (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 51,
								},
								["Apothecary Hummel"] = {
									["count"] = 24,
								},
								["Apothecary Baxter"] = {
									["count"] = 33,
								},
							},
							["amount"] = 108,
						},
					},
					["ShieldedWho"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["Acindor-Jubei'Thos"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Risen Ally"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["Stabsya"] = {
							["Details"] = {
								["Power Word: Shield"] = {
									["count"] = 1,
								},
								["Divine Aegis"] = {
									["count"] = 3,
								},
							},
							["amount"] = 4,
						},
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 7,
								},
								["Power Word: Shield"] = {
									["count"] = 1,
								},
							},
							["amount"] = 8,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 79627,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 388307,
					["DeathCount"] = 0,
					["HOT_Time"] = 12,
					["ElementHitsDone"] = {
						["Holy"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 31,
								},
								["Crit"] = {
									["count"] = 8,
								},
								["Hit"] = {
									["count"] = 19,
								},
							},
							["amount"] = 58,
						},
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 5,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Tick"] = {
									["count"] = 40,
								},
							},
							["amount"] = 51,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 31019,
						["Nature"] = 2873,
					},
					["ElementTaken"] = {
						["Melee"] = 79627,
					},
					["DOT_Time"] = 246,
					["Damage"] = 1190700,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 36.17000000000001,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Holy"] = 723736,
						["Shadow"] = 466964,
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 16486,
									["min"] = 1807,
									["count"] = 3,
									["amount"] = 31019,
								},
							},
							["count"] = 7,
							["amount"] = 31019,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 2873,
									["min"] = 2873,
									["count"] = 1,
									["amount"] = 2873,
								},
							},
							["count"] = 1,
							["amount"] = 2873,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 92463,
								},
								["Penance"] = {
									["count"] = 65581,
								},
								["Smite"] = {
									["count"] = 397907,
								},
								["Halo"] = {
									["count"] = 61577,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 16756,
								},
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 250463,
								},
								["Touch of the Grave"] = {
									["count"] = 45106,
								},
							},
							["amount"] = 929853,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 72810,
								},
								["Holy Fire"] = {
									["count"] = 29206,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 6808,
								},
								["Touch of the Grave"] = {
									["count"] = 15060,
								},
							},
							["amount"] = 123884,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 26862,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 10946,
								},
								["Halo"] = {
									["count"] = 15630,
								},
								["Touch of the Grave"] = {
									["count"] = 13584,
								},
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 69941,
								},
							},
							["amount"] = 136963,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 65961,
								},
							},
							["amount"] = 65961,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13666,
								},
							},
							["amount"] = 13666,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Flash Heal"] = {
									["count"] = 0.77,
								},
								["Prayer of Healing"] = {
									["count"] = 0.89,
								},
								["Atonement"] = {
									["count"] = 0.73,
								},
								["Touch of the Grave"] = {
									["count"] = 0.38,
								},
							},
							["amount"] = 2.77,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 5.05,
								},
								["Halo"] = {
									["count"] = 0.4,
								},
							},
							["amount"] = 5.449999999999999,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 0,
								},
								["Prayer of Healing"] = {
									["count"] = 2.55,
								},
								["Atonement"] = {
									["count"] = 2.12,
								},
								["Flash Heal"] = {
									["count"] = 0.42,
								},
							},
							["amount"] = 5.090000000000002,
						},
						["Mirror Image <Acindor-Jubei'Thos>"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 0,
								},
								["Atonement"] = {
									["count"] = 1.38,
								},
							},
							["amount"] = 1.38,
						},
						["Stabsya"] = {
							["Details"] = {
								["Renew"] = {
									["count"] = 4.23,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 0.8,
								},
								["Prayer of Healing"] = {
									["count"] = 0.51,
								},
								["Halo"] = {
									["count"] = 0,
								},
							},
							["amount"] = 5.54,
						},
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 0,
								},
								["Flash Heal"] = {
									["count"] = 1.66,
								},
								["Halo"] = {
									["count"] = 0.4,
								},
								["Atonement"] = {
									["count"] = 6.65,
								},
								["Penance"] = {
									["count"] = 7.23,
								},
							},
							["amount"] = 15.94,
						},
					},
					["OverHeals"] = {
						["Renew"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 22177,
									["min"] = 22177,
									["count"] = 1,
									["amount"] = 22177,
								},
								["Tick"] = {
									["max"] = 11088,
									["min"] = 11088,
									["count"] = 1,
									["amount"] = 11088,
								},
							},
							["count"] = 2,
							["amount"] = 33265,
						},
						["Flash Heal"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 55610,
									["min"] = 7415,
									["count"] = 3,
									["amount"] = 106665,
								},
							},
							["count"] = 3,
							["amount"] = 106665,
						},
						["Prayer of Healing"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 61338,
									["min"] = 8647,
									["count"] = 3,
									["amount"] = 128398,
								},
								["Hit"] = {
									["max"] = 34700,
									["min"] = 8517,
									["count"] = 16,
									["amount"] = 421273,
								},
							},
							["count"] = 19,
							["amount"] = 549671,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16710,
									["min"] = 14263,
									["count"] = 4,
									["amount"] = 62127,
								},
							},
							["count"] = 4,
							["amount"] = 62127,
						},
						["Halo"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 20888,
									["min"] = 20888,
									["count"] = 1,
									["amount"] = 20888,
								},
								["Hit"] = {
									["max"] = 32226,
									["min"] = 8687,
									["count"] = 8,
									["amount"] = 184425,
								},
							},
							["count"] = 9,
							["amount"] = 205313,
						},
						["Glyph of Power Word: Shield"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16761,
									["min"] = 16761,
									["count"] = 1,
									["amount"] = 16761,
								},
							},
							["count"] = 1,
							["amount"] = 16761,
						},
						["Atonement"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 61573,
									["min"] = 61573,
									["count"] = 1,
									["amount"] = 61573,
								},
								["Hit"] = {
									["max"] = 32501,
									["min"] = 839,
									["count"] = 12,
									["amount"] = 127671,
								},
							},
							["count"] = 13,
							["amount"] = 189244,
						},
						["Penance"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 21250,
									["min"] = 1297,
									["count"] = 4,
									["amount"] = 39033,
								},
							},
							["count"] = 4,
							["amount"] = 39033,
						},
					},
					["ManaGainedFrom"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Rapture"] = {
									["count"] = 26000,
								},
							},
							["amount"] = 26000,
						},
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 14533,
								},
								["Touch of the Grave"] = {
									["count"] = 15307,
								},
								["Flash Heal"] = {
									["count"] = 14196,
								},
								["Atonement"] = {
									["count"] = 36458,
								},
								["Prayer of Healing"] = {
									["count"] = 13666,
								},
							},
							["amount"] = 94160,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 100973,
								},
								["Halo"] = {
									["count"] = 9007,
								},
							},
							["amount"] = 109980,
						},
						["Risen Ally"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 2176,
								},
							},
							["amount"] = 2176,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 22957,
								},
								["Flash Heal"] = {
									["count"] = 54970,
								},
								["Halo"] = {
									["count"] = 16437,
								},
								["Atonement"] = {
									["count"] = 136915,
								},
								["Divine Aegis"] = {
									["count"] = 67557,
								},
							},
							["amount"] = 298836,
						},
						["Mirror Image <Acindor-Jubei'Thos>"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 242,
								},
								["Atonement"] = {
									["count"] = 23988,
								},
							},
							["amount"] = 24230,
						},
						["Acindor-Jubei'Thos"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 5434,
								},
							},
							["amount"] = 5434,
						},
						["Stabsya"] = {
							["Details"] = {
								["Renew"] = {
									["count"] = 22178,
								},
								["Divine Aegis"] = {
									["count"] = 39774,
								},
								["Halo"] = {
									["count"] = 5061,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 16761,
								},
								["Power Word: Shield"] = {
									["count"] = 63852,
								},
								["Prayer of Healing"] = {
									["count"] = 27622,
								},
							},
							["amount"] = 175248,
						},
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Power Word: Shield"] = {
									["count"] = 63852,
								},
								["Penance"] = {
									["count"] = 244944,
								},
								["Flash Heal"] = {
									["count"] = 386532,
								},
								["Halo"] = {
									["count"] = 20662,
								},
								["Divine Aegis"] = {
									["count"] = 131129,
								},
								["Atonement"] = {
									["count"] = 223489,
								},
								["Prayer of Healing"] = {
									["count"] = 67084,
								},
							},
							["amount"] = 1137692,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
						["Rapture"] = {
							["Details"] = {
								["Tanklord-Tichondrius"] = {
									["count"] = 26000,
								},
							},
							["amount"] = 26000,
						},
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 1202079,
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 2.82,
								},
								["Penance"] = {
									["count"] = 0.48,
								},
								["Smite"] = {
									["count"] = 2.810000000000001,
								},
								["Halo"] = {
									["count"] = 0.41,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 8.17,
								},
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 22.4,
								},
								["Touch of the Grave"] = {
									["count"] = 0.9,
								},
							},
							["amount"] = 37.99000000000001,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 7.810000000000001,
								},
								["Holy Fire"] = {
									["count"] = 0.52,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 1.69,
								},
								["Touch of the Grave"] = {
									["count"] = 0.11,
								},
							},
							["amount"] = 10.13,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 0,
								},
								["Prayer of Healing"] = {
									["count"] = 2.55,
								},
								["Atonement"] = {
									["count"] = 2.12,
								},
								["Flash Heal"] = {
									["count"] = 0.42,
								},
							},
							["amount"] = 5.090000000000002,
						},
						["Stabsya"] = {
							["Details"] = {
								["Renew"] = {
									["count"] = 4.23,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 0.8,
								},
								["Prayer of Healing"] = {
									["count"] = 0.51,
								},
								["Halo"] = {
									["count"] = 0,
								},
							},
							["amount"] = 5.54,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 3.2,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 2.42,
								},
								["Halo"] = {
									["count"] = 0,
								},
								["Touch of the Grave"] = {
									["count"] = 0.6800000000000001,
								},
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 2.970000000000001,
								},
							},
							["amount"] = 9.27,
						},
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 0,
								},
								["Flash Heal"] = {
									["count"] = 1.66,
								},
								["Halo"] = {
									["count"] = 0.4,
								},
								["Atonement"] = {
									["count"] = 6.65,
								},
								["Penance"] = {
									["count"] = 7.23,
								},
							},
							["amount"] = 15.94,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 5.05,
								},
								["Halo"] = {
									["count"] = 0.4,
								},
							},
							["amount"] = 5.449999999999999,
						},
						["Mirror Image <Acindor-Jubei'Thos>"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 0,
								},
								["Atonement"] = {
									["count"] = 1.38,
								},
							},
							["amount"] = 1.38,
						},
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Flash Heal"] = {
									["count"] = 0.77,
								},
								["Prayer of Healing"] = {
									["count"] = 0.89,
								},
								["Atonement"] = {
									["count"] = 0.73,
								},
								["Touch of the Grave"] = {
									["count"] = 0.38,
								},
							},
							["amount"] = 2.77,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["Renew"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 11089,
									["min"] = 11089,
									["count"] = 2,
									["amount"] = 22178,
								},
							},
							["count"] = 2,
							["amount"] = 22178,
						},
						["Prayer of Healing"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 61357,
									["min"] = 61357,
									["count"] = 1,
									["amount"] = 61357,
								},
								["Hit"] = {
									["max"] = 27175,
									["min"] = 169,
									["count"] = 8,
									["amount"] = 69972,
								},
							},
							["count"] = 9,
							["amount"] = 131329,
						},
						["Flash Heal"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 108278,
									["min"] = 14196,
									["count"] = 7,
									["amount"] = 455698,
								},
							},
							["count"] = 7,
							["amount"] = 455698,
						},
						["Halo"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 20662,
									["min"] = 242,
									["count"] = 5,
									["amount"] = 51409,
								},
							},
							["count"] = 5,
							["amount"] = 51409,
						},
						["Glyph of Power Word: Shield"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16761,
									["min"] = 16761,
									["count"] = 1,
									["amount"] = 16761,
								},
							},
							["count"] = 1,
							["amount"] = 16761,
						},
						["Penance"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 60336,
									["min"] = 53329,
									["count"] = 2,
									["amount"] = 113665,
								},
								["Hit"] = {
									["max"] = 27497,
									["min"] = 846,
									["count"] = 7,
									["amount"] = 131279,
								},
							},
							["count"] = 9,
							["amount"] = 244944,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 15307,
									["min"] = 15307,
									["count"] = 1,
									["amount"] = 15307,
								},
							},
							["count"] = 1,
							["amount"] = 15307,
						},
						["Divine Aegis"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 41981,
									["min"] = 1485,
									["count"] = 14,
									["amount"] = 260603,
								},
							},
							["count"] = 14,
							["amount"] = 260603,
						},
						["Atonement"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 51184,
									["min"] = 787,
									["count"] = 8,
									["amount"] = 95108,
								},
								["Hit"] = {
									["max"] = 37679,
									["min"] = 239,
									["count"] = 40,
									["amount"] = 426715,
								},
							},
							["count"] = 48,
							["amount"] = 521823,
						},
						["Power Word: Shield"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 63852,
									["min"] = 63852,
									["count"] = 2,
									["amount"] = 127704,
								},
							},
							["count"] = 2,
							["amount"] = 127704,
						},
					},
					["WhoHealed"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Flash Heal"] = {
									["count"] = 14196,
								},
								["Prayer of Healing"] = {
									["count"] = 13666,
								},
								["Atonement"] = {
									["count"] = 36458,
								},
								["Touch of the Grave"] = {
									["count"] = 15307,
								},
							},
							["amount"] = 79627,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 93.56,
					["Healing"] = 1459449,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Holy Fire"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 62360,
									["min"] = 62360,
									["count"] = 1,
									["amount"] = 62360,
								},
								["Hit"] = {
									["max"] = 30103,
									["min"] = 26862,
									["count"] = 3,
									["amount"] = 86171,
								},
							},
							["count"] = 4,
							["amount"] = 148531,
						},
						["Penance"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 32841,
									["min"] = 32740,
									["count"] = 2,
									["amount"] = 65581,
								},
							},
							["count"] = 2,
							["amount"] = 65581,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 15915,
									["min"] = 13584,
									["count"] = 5,
									["amount"] = 73750,
								},
							},
							["count"] = 5,
							["amount"] = 73750,
						},
						["Shadow Word: Pain (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 16180,
									["min"] = 13782,
									["count"] = 6,
									["amount"] = 92370,
								},
								["Tick"] = {
									["max"] = 8090,
									["min"] = 6890,
									["count"] = 40,
									["amount"] = 300844,
								},
							},
							["count"] = 46,
							["amount"] = 393214,
						},
						["Halo"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 61577,
									["min"] = 15630,
									["count"] = 2,
									["amount"] = 77207,
								},
							},
							["count"] = 2,
							["amount"] = 77207,
						},
						["Smite"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 52070,
									["min"] = 51184,
									["count"] = 2,
									["amount"] = 103254,
								},
								["Hit"] = {
									["max"] = 26162,
									["min"] = 21853,
									["count"] = 12,
									["amount"] = 294653,
								},
							},
							["count"] = 14,
							["amount"] = 397907,
						},
						["Holy Fire (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1764,
									["min"] = 1563,
									["count"] = 5,
									["amount"] = 8218,
								},
								["Tick"] = {
									["max"] = 913,
									["min"] = 781,
									["count"] = 31,
									["amount"] = 26292,
								},
							},
							["count"] = 36,
							["amount"] = 34510,
						},
					},
					["HealingTaken"] = 79627,
					["RageGain"] = 0,
					["TimeDamage"] = 57.38999999999999,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 2.82,
								},
								["Penance"] = {
									["count"] = 0.48,
								},
								["Smite"] = {
									["count"] = 2.810000000000001,
								},
								["Halo"] = {
									["count"] = 0.41,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 8.17,
								},
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 22.4,
								},
								["Touch of the Grave"] = {
									["count"] = 0.9,
								},
							},
							["amount"] = 37.99000000000001,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 7.810000000000001,
								},
								["Holy Fire"] = {
									["count"] = 0.52,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 1.69,
								},
								["Touch of the Grave"] = {
									["count"] = 0.11,
								},
							},
							["amount"] = 10.13,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 3.2,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 2.42,
								},
								["Halo"] = {
									["count"] = 0,
								},
								["Touch of the Grave"] = {
									["count"] = 0.6800000000000001,
								},
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 2.970000000000001,
								},
							},
							["amount"] = 9.27,
						},
					},
					["ManaGain"] = 26000,
					["HOTs"] = {
						["Renew"] = {
							["Details"] = {
								["Stabsya"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["Absorbed"] = {
						["Divine Aegis"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["max"] = 41981,
									["min"] = 1485,
									["count"] = 6,
									["amount"] = 131129,
								},
								["Müu-Jubei'Thos"] = {
									["max"] = 30373,
									["min"] = 17787,
									["count"] = 3,
									["amount"] = 67557,
								},
								["Tanklord-Tichondrius"] = {
									["max"] = 14533,
									["min"] = 14533,
									["count"] = 1,
									["amount"] = 14533,
								},
								["Risen Ally"] = {
									["max"] = 2176,
									["min"] = 2176,
									["count"] = 1,
									["amount"] = 2176,
								},
								["Stabsya"] = {
									["max"] = 20866,
									["min"] = 18908,
									["count"] = 2,
									["amount"] = 39774,
								},
								["Acindor-Jubei'Thos"] = {
									["max"] = 5434,
									["min"] = 5434,
									["count"] = 1,
									["amount"] = 5434,
								},
							},
							["count"] = 14,
							["amount"] = 260603,
						},
						["Power Word: Shield"] = {
							["Details"] = {
								["Stabsya"] = {
									["max"] = 63852,
									["min"] = 63852,
									["count"] = 1,
									["amount"] = 63852,
								},
								["Metalica-Jubei'Thos"] = {
									["max"] = 63852,
									["min"] = 63852,
									["count"] = 1,
									["amount"] = 63852,
								},
							},
							["count"] = 2,
							["amount"] = 127704,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 7,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DOTs"] = {
						["Shadow Word: Pain (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 87,
								},
								["Apothecary Hummel"] = {
									["count"] = 24,
								},
								["Apothecary Baxter"] = {
									["count"] = 27,
								},
							},
							["amount"] = 138,
						},
						["Holy Fire (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 51,
								},
								["Apothecary Hummel"] = {
									["count"] = 24,
								},
								["Apothecary Baxter"] = {
									["count"] = 33,
								},
							},
							["amount"] = 108,
						},
					},
					["ShieldedWho"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["Acindor-Jubei'Thos"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Risen Ally"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["Stabsya"] = {
							["Details"] = {
								["Power Word: Shield"] = {
									["count"] = 1,
								},
								["Divine Aegis"] = {
									["count"] = 3,
								},
							},
							["amount"] = 4,
						},
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 7,
								},
								["Power Word: Shield"] = {
									["count"] = 1,
								},
							},
							["amount"] = 8,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 79627,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 388307,
					["DeathCount"] = 0,
					["HOT_Time"] = 12,
					["ElementHitsDone"] = {
						["Holy"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 31,
								},
								["Crit"] = {
									["count"] = 8,
								},
								["Hit"] = {
									["count"] = 19,
								},
							},
							["amount"] = 58,
						},
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 5,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Tick"] = {
									["count"] = 40,
								},
							},
							["amount"] = 51,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 31019,
						["Nature"] = 2873,
					},
					["ElementTaken"] = {
						["Melee"] = 79627,
					},
					["DOT_Time"] = 246,
					["Damage"] = 1190700,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 36.17000000000001,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Holy"] = 723736,
						["Shadow"] = 466964,
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 16486,
									["min"] = 1807,
									["count"] = 3,
									["amount"] = 31019,
								},
							},
							["count"] = 7,
							["amount"] = 31019,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 2873,
									["min"] = 2873,
									["count"] = 1,
									["amount"] = 2873,
								},
							},
							["count"] = 1,
							["amount"] = 2873,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 92463,
								},
								["Penance"] = {
									["count"] = 65581,
								},
								["Smite"] = {
									["count"] = 397907,
								},
								["Halo"] = {
									["count"] = 61577,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 16756,
								},
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 250463,
								},
								["Touch of the Grave"] = {
									["count"] = 45106,
								},
							},
							["amount"] = 929853,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 72810,
								},
								["Holy Fire"] = {
									["count"] = 29206,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 6808,
								},
								["Touch of the Grave"] = {
									["count"] = 15060,
								},
							},
							["amount"] = 123884,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 26862,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 10946,
								},
								["Halo"] = {
									["count"] = 15630,
								},
								["Touch of the Grave"] = {
									["count"] = 13584,
								},
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 69941,
								},
							},
							["amount"] = 136963,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 65961,
								},
							},
							["amount"] = 65961,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13666,
								},
							},
							["amount"] = 13666,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Flash Heal"] = {
									["count"] = 0.77,
								},
								["Prayer of Healing"] = {
									["count"] = 0.89,
								},
								["Atonement"] = {
									["count"] = 0.73,
								},
								["Touch of the Grave"] = {
									["count"] = 0.38,
								},
							},
							["amount"] = 2.77,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 5.05,
								},
								["Halo"] = {
									["count"] = 0.4,
								},
							},
							["amount"] = 5.449999999999999,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 0,
								},
								["Prayer of Healing"] = {
									["count"] = 2.55,
								},
								["Atonement"] = {
									["count"] = 2.12,
								},
								["Flash Heal"] = {
									["count"] = 0.42,
								},
							},
							["amount"] = 5.090000000000002,
						},
						["Mirror Image <Acindor-Jubei'Thos>"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 0,
								},
								["Atonement"] = {
									["count"] = 1.38,
								},
							},
							["amount"] = 1.38,
						},
						["Stabsya"] = {
							["Details"] = {
								["Renew"] = {
									["count"] = 4.23,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 0.8,
								},
								["Prayer of Healing"] = {
									["count"] = 0.51,
								},
								["Halo"] = {
									["count"] = 0,
								},
							},
							["amount"] = 5.54,
						},
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 0,
								},
								["Flash Heal"] = {
									["count"] = 1.66,
								},
								["Halo"] = {
									["count"] = 0.4,
								},
								["Atonement"] = {
									["count"] = 6.65,
								},
								["Penance"] = {
									["count"] = 7.23,
								},
							},
							["amount"] = 15.94,
						},
					},
					["OverHeals"] = {
						["Renew"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 22177,
									["min"] = 22177,
									["count"] = 1,
									["amount"] = 22177,
								},
								["Tick"] = {
									["max"] = 11088,
									["min"] = 11088,
									["count"] = 1,
									["amount"] = 11088,
								},
							},
							["count"] = 2,
							["amount"] = 33265,
						},
						["Flash Heal"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 55610,
									["min"] = 7415,
									["count"] = 3,
									["amount"] = 106665,
								},
							},
							["count"] = 3,
							["amount"] = 106665,
						},
						["Prayer of Healing"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 61338,
									["min"] = 8647,
									["count"] = 3,
									["amount"] = 128398,
								},
								["Hit"] = {
									["max"] = 34700,
									["min"] = 8517,
									["count"] = 16,
									["amount"] = 421273,
								},
							},
							["count"] = 19,
							["amount"] = 549671,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16710,
									["min"] = 14263,
									["count"] = 4,
									["amount"] = 62127,
								},
							},
							["count"] = 4,
							["amount"] = 62127,
						},
						["Halo"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 20888,
									["min"] = 20888,
									["count"] = 1,
									["amount"] = 20888,
								},
								["Hit"] = {
									["max"] = 32226,
									["min"] = 8687,
									["count"] = 8,
									["amount"] = 184425,
								},
							},
							["count"] = 9,
							["amount"] = 205313,
						},
						["Glyph of Power Word: Shield"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16761,
									["min"] = 16761,
									["count"] = 1,
									["amount"] = 16761,
								},
							},
							["count"] = 1,
							["amount"] = 16761,
						},
						["Atonement"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 61573,
									["min"] = 61573,
									["count"] = 1,
									["amount"] = 61573,
								},
								["Hit"] = {
									["max"] = 32501,
									["min"] = 839,
									["count"] = 12,
									["amount"] = 127671,
								},
							},
							["count"] = 13,
							["amount"] = 189244,
						},
						["Penance"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 21250,
									["min"] = 1297,
									["count"] = 4,
									["amount"] = 39033,
								},
							},
							["count"] = 4,
							["amount"] = 39033,
						},
					},
					["ManaGainedFrom"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Rapture"] = {
									["count"] = 26000,
								},
							},
							["amount"] = 26000,
						},
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 14533,
								},
								["Touch of the Grave"] = {
									["count"] = 15307,
								},
								["Flash Heal"] = {
									["count"] = 14196,
								},
								["Atonement"] = {
									["count"] = 36458,
								},
								["Prayer of Healing"] = {
									["count"] = 13666,
								},
							},
							["amount"] = 94160,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 100973,
								},
								["Halo"] = {
									["count"] = 9007,
								},
							},
							["amount"] = 109980,
						},
						["Risen Ally"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 2176,
								},
							},
							["amount"] = 2176,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 22957,
								},
								["Flash Heal"] = {
									["count"] = 54970,
								},
								["Halo"] = {
									["count"] = 16437,
								},
								["Atonement"] = {
									["count"] = 136915,
								},
								["Divine Aegis"] = {
									["count"] = 67557,
								},
							},
							["amount"] = 298836,
						},
						["Mirror Image <Acindor-Jubei'Thos>"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 242,
								},
								["Atonement"] = {
									["count"] = 23988,
								},
							},
							["amount"] = 24230,
						},
						["Acindor-Jubei'Thos"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 5434,
								},
							},
							["amount"] = 5434,
						},
						["Stabsya"] = {
							["Details"] = {
								["Renew"] = {
									["count"] = 22178,
								},
								["Divine Aegis"] = {
									["count"] = 39774,
								},
								["Halo"] = {
									["count"] = 5061,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 16761,
								},
								["Power Word: Shield"] = {
									["count"] = 63852,
								},
								["Prayer of Healing"] = {
									["count"] = 27622,
								},
							},
							["amount"] = 175248,
						},
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Power Word: Shield"] = {
									["count"] = 63852,
								},
								["Penance"] = {
									["count"] = 244944,
								},
								["Flash Heal"] = {
									["count"] = 386532,
								},
								["Halo"] = {
									["count"] = 20662,
								},
								["Divine Aegis"] = {
									["count"] = 131129,
								},
								["Atonement"] = {
									["count"] = 223489,
								},
								["Prayer of Healing"] = {
									["count"] = 67084,
								},
							},
							["amount"] = 1137692,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
						["Rapture"] = {
							["Details"] = {
								["Tanklord-Tichondrius"] = {
									["count"] = 26000,
								},
							},
							["amount"] = 26000,
						},
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 1202079,
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 2.82,
								},
								["Penance"] = {
									["count"] = 0.48,
								},
								["Smite"] = {
									["count"] = 2.810000000000001,
								},
								["Halo"] = {
									["count"] = 0.41,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 8.17,
								},
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 22.4,
								},
								["Touch of the Grave"] = {
									["count"] = 0.9,
								},
							},
							["amount"] = 37.99000000000001,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 7.810000000000001,
								},
								["Holy Fire"] = {
									["count"] = 0.52,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 1.69,
								},
								["Touch of the Grave"] = {
									["count"] = 0.11,
								},
							},
							["amount"] = 10.13,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 0,
								},
								["Prayer of Healing"] = {
									["count"] = 2.55,
								},
								["Atonement"] = {
									["count"] = 2.12,
								},
								["Flash Heal"] = {
									["count"] = 0.42,
								},
							},
							["amount"] = 5.090000000000002,
						},
						["Stabsya"] = {
							["Details"] = {
								["Renew"] = {
									["count"] = 4.23,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 0.8,
								},
								["Prayer of Healing"] = {
									["count"] = 0.51,
								},
								["Halo"] = {
									["count"] = 0,
								},
							},
							["amount"] = 5.54,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 3.2,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 2.42,
								},
								["Halo"] = {
									["count"] = 0,
								},
								["Touch of the Grave"] = {
									["count"] = 0.6800000000000001,
								},
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 2.970000000000001,
								},
							},
							["amount"] = 9.27,
						},
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 0,
								},
								["Flash Heal"] = {
									["count"] = 1.66,
								},
								["Halo"] = {
									["count"] = 0.4,
								},
								["Atonement"] = {
									["count"] = 6.65,
								},
								["Penance"] = {
									["count"] = 7.23,
								},
							},
							["amount"] = 15.94,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 5.05,
								},
								["Halo"] = {
									["count"] = 0.4,
								},
							},
							["amount"] = 5.449999999999999,
						},
						["Mirror Image <Acindor-Jubei'Thos>"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 0,
								},
								["Atonement"] = {
									["count"] = 1.38,
								},
							},
							["amount"] = 1.38,
						},
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Flash Heal"] = {
									["count"] = 0.77,
								},
								["Prayer of Healing"] = {
									["count"] = 0.89,
								},
								["Atonement"] = {
									["count"] = 0.73,
								},
								["Touch of the Grave"] = {
									["count"] = 0.38,
								},
							},
							["amount"] = 2.77,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["Renew"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 11089,
									["min"] = 11089,
									["count"] = 2,
									["amount"] = 22178,
								},
							},
							["count"] = 2,
							["amount"] = 22178,
						},
						["Prayer of Healing"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 61357,
									["min"] = 61357,
									["count"] = 1,
									["amount"] = 61357,
								},
								["Hit"] = {
									["max"] = 27175,
									["min"] = 169,
									["count"] = 8,
									["amount"] = 69972,
								},
							},
							["count"] = 9,
							["amount"] = 131329,
						},
						["Flash Heal"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 108278,
									["min"] = 14196,
									["count"] = 7,
									["amount"] = 455698,
								},
							},
							["count"] = 7,
							["amount"] = 455698,
						},
						["Halo"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 20662,
									["min"] = 242,
									["count"] = 5,
									["amount"] = 51409,
								},
							},
							["count"] = 5,
							["amount"] = 51409,
						},
						["Glyph of Power Word: Shield"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16761,
									["min"] = 16761,
									["count"] = 1,
									["amount"] = 16761,
								},
							},
							["count"] = 1,
							["amount"] = 16761,
						},
						["Penance"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 60336,
									["min"] = 53329,
									["count"] = 2,
									["amount"] = 113665,
								},
								["Hit"] = {
									["max"] = 27497,
									["min"] = 846,
									["count"] = 7,
									["amount"] = 131279,
								},
							},
							["count"] = 9,
							["amount"] = 244944,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 15307,
									["min"] = 15307,
									["count"] = 1,
									["amount"] = 15307,
								},
							},
							["count"] = 1,
							["amount"] = 15307,
						},
						["Divine Aegis"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 41981,
									["min"] = 1485,
									["count"] = 14,
									["amount"] = 260603,
								},
							},
							["count"] = 14,
							["amount"] = 260603,
						},
						["Atonement"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 51184,
									["min"] = 787,
									["count"] = 8,
									["amount"] = 95108,
								},
								["Hit"] = {
									["max"] = 37679,
									["min"] = 239,
									["count"] = 40,
									["amount"] = 426715,
								},
							},
							["count"] = 48,
							["amount"] = 521823,
						},
						["Power Word: Shield"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 63852,
									["min"] = 63852,
									["count"] = 2,
									["amount"] = 127704,
								},
							},
							["count"] = 2,
							["amount"] = 127704,
						},
					},
					["WhoHealed"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Flash Heal"] = {
									["count"] = 14196,
								},
								["Prayer of Healing"] = {
									["count"] = 13666,
								},
								["Atonement"] = {
									["count"] = 36458,
								},
								["Touch of the Grave"] = {
									["count"] = 15307,
								},
							},
							["amount"] = 79627,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 93.56,
					["Healing"] = 1459449,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Holy Fire"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 62360,
									["min"] = 62360,
									["count"] = 1,
									["amount"] = 62360,
								},
								["Hit"] = {
									["max"] = 30103,
									["min"] = 26862,
									["count"] = 3,
									["amount"] = 86171,
								},
							},
							["count"] = 4,
							["amount"] = 148531,
						},
						["Penance"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 32841,
									["min"] = 32740,
									["count"] = 2,
									["amount"] = 65581,
								},
							},
							["count"] = 2,
							["amount"] = 65581,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 15915,
									["min"] = 13584,
									["count"] = 5,
									["amount"] = 73750,
								},
							},
							["count"] = 5,
							["amount"] = 73750,
						},
						["Shadow Word: Pain (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 16180,
									["min"] = 13782,
									["count"] = 6,
									["amount"] = 92370,
								},
								["Tick"] = {
									["max"] = 8090,
									["min"] = 6890,
									["count"] = 40,
									["amount"] = 300844,
								},
							},
							["count"] = 46,
							["amount"] = 393214,
						},
						["Halo"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 61577,
									["min"] = 15630,
									["count"] = 2,
									["amount"] = 77207,
								},
							},
							["count"] = 2,
							["amount"] = 77207,
						},
						["Smite"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 52070,
									["min"] = 51184,
									["count"] = 2,
									["amount"] = 103254,
								},
								["Hit"] = {
									["max"] = 26162,
									["min"] = 21853,
									["count"] = 12,
									["amount"] = 294653,
								},
							},
							["count"] = 14,
							["amount"] = 397907,
						},
						["Holy Fire (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1764,
									["min"] = 1563,
									["count"] = 5,
									["amount"] = 8218,
								},
								["Tick"] = {
									["max"] = 913,
									["min"] = 781,
									["count"] = 31,
									["amount"] = 26292,
								},
							},
							["count"] = 36,
							["amount"] = 34510,
						},
					},
					["HealingTaken"] = 79627,
					["RageGain"] = 0,
					["TimeDamage"] = 57.38999999999999,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 2.82,
								},
								["Penance"] = {
									["count"] = 0.48,
								},
								["Smite"] = {
									["count"] = 2.810000000000001,
								},
								["Halo"] = {
									["count"] = 0.41,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 8.17,
								},
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 22.4,
								},
								["Touch of the Grave"] = {
									["count"] = 0.9,
								},
							},
							["amount"] = 37.99000000000001,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 7.810000000000001,
								},
								["Holy Fire"] = {
									["count"] = 0.52,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 1.69,
								},
								["Touch of the Grave"] = {
									["count"] = 0.11,
								},
							},
							["amount"] = 10.13,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 3.2,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 2.42,
								},
								["Halo"] = {
									["count"] = 0,
								},
								["Touch of the Grave"] = {
									["count"] = 0.6800000000000001,
								},
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 2.970000000000001,
								},
							},
							["amount"] = 9.27,
						},
					},
					["ManaGain"] = 26000,
					["HOTs"] = {
						["Renew"] = {
							["Details"] = {
								["Stabsya"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["DOTs"] = {
						["Shadow Word: Pain (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 87,
								},
								["Apothecary Hummel"] = {
									["count"] = 24,
								},
								["Corpse Eater"] = {
									["count"] = 3,
								},
								["Frantic Geist"] = {
									["count"] = 6,
								},
								["Apothecary Baxter"] = {
									["count"] = 27,
								},
							},
							["amount"] = 147,
						},
						["Holy Fire (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 51,
								},
								["Apothecary Hummel"] = {
									["count"] = 24,
								},
								["Apothecary Baxter"] = {
									["count"] = 33,
								},
							},
							["amount"] = 108,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 4,
								},
								["Absorb"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 8,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DamageTaken"] = 79627,
					["Absorbs"] = 388307,
					["HOT_Time"] = 12,
					["ElementTaken"] = {
						["Melee"] = 79627,
					},
					["DOT_Time"] = 255,
					["Damage"] = 1209246,
					["TimeHeal"] = 39.67000000000002,
					["ShieldedWho"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 8,
								},
								["Power Word: Shield"] = {
									["count"] = 1,
								},
							},
							["amount"] = 9,
						},
						["Acindor-Jubei'Thos"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Risen Ally"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 5,
								},
							},
							["amount"] = 5,
						},
						["Stabsya"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 4,
								},
								["Power Word: Shield"] = {
									["count"] = 1,
								},
							},
							["amount"] = 5,
						},
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 5,
								},
							},
							["amount"] = 5,
						},
					},
					["ElementDone"] = {
						["Holy"] = 723736,
						["Shadow"] = 485510,
					},
					["ElementHitsDone"] = {
						["Holy"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 31,
								},
								["Crit"] = {
									["count"] = 8,
								},
								["Hit"] = {
									["count"] = 19,
								},
							},
							["amount"] = 58,
						},
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 5,
								},
								["Crit"] = {
									["count"] = 6,
								},
								["Tick"] = {
									["count"] = 43,
								},
							},
							["amount"] = 54,
						},
					},
					["WhoDamaged"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 65961,
								},
							},
							["amount"] = 65961,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 13666,
								},
							},
							["amount"] = 13666,
						},
					},
					["Absorbed"] = {
						["Divine Aegis"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["max"] = 41981,
									["min"] = 1485,
									["count"] = 6,
									["amount"] = 131129,
								},
								["Müu-Jubei'Thos"] = {
									["max"] = 30373,
									["min"] = 17787,
									["count"] = 3,
									["amount"] = 67557,
								},
								["Tanklord-Tichondrius"] = {
									["max"] = 14533,
									["min"] = 14533,
									["count"] = 1,
									["amount"] = 14533,
								},
								["Risen Ally"] = {
									["max"] = 2176,
									["min"] = 2176,
									["count"] = 1,
									["amount"] = 2176,
								},
								["Stabsya"] = {
									["max"] = 20866,
									["min"] = 18908,
									["count"] = 2,
									["amount"] = 39774,
								},
								["Acindor-Jubei'Thos"] = {
									["max"] = 5434,
									["min"] = 5434,
									["count"] = 1,
									["amount"] = 5434,
								},
							},
							["count"] = 14,
							["amount"] = 260603,
						},
						["Power Word: Shield"] = {
							["Details"] = {
								["Stabsya"] = {
									["max"] = 63852,
									["min"] = 63852,
									["count"] = 1,
									["amount"] = 63852,
								},
								["Metalica-Jubei'Thos"] = {
									["max"] = 63852,
									["min"] = 63852,
									["count"] = 1,
									["amount"] = 63852,
								},
							},
							["count"] = 2,
							["amount"] = 127704,
						},
					},
					["TimeHealing"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Flash Heal"] = {
									["count"] = 0.77,
								},
								["Prayer of Healing"] = {
									["count"] = 0.89,
								},
								["Atonement"] = {
									["count"] = 0.73,
								},
								["Touch of the Grave"] = {
									["count"] = 0.38,
								},
							},
							["amount"] = 2.77,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 5.05,
								},
								["Halo"] = {
									["count"] = 0.4,
								},
							},
							["amount"] = 5.449999999999999,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 0,
								},
								["Prayer of Healing"] = {
									["count"] = 2.55,
								},
								["Atonement"] = {
									["count"] = 2.12,
								},
								["Flash Heal"] = {
									["count"] = 0.42,
								},
							},
							["amount"] = 5.090000000000002,
						},
						["Mirror Image <Acindor-Jubei'Thos>"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 0,
								},
								["Atonement"] = {
									["count"] = 1.38,
								},
							},
							["amount"] = 1.38,
						},
						["Stabsya"] = {
							["Details"] = {
								["Renew"] = {
									["count"] = 4.23,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 0.8,
								},
								["Prayer of Healing"] = {
									["count"] = 4.01,
								},
								["Halo"] = {
									["count"] = 0,
								},
							},
							["amount"] = 9.039999999999999,
						},
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Penance"] = {
									["count"] = 7.23,
								},
								["Flash Heal"] = {
									["count"] = 1.66,
								},
								["Halo"] = {
									["count"] = 0.4,
								},
								["Atonement"] = {
									["count"] = 6.65,
								},
								["Prayer of Healing"] = {
									["count"] = 0,
								},
							},
							["amount"] = 15.94,
						},
					},
					["OverHeals"] = {
						["Renew"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 22177,
									["min"] = 22177,
									["count"] = 1,
									["amount"] = 22177,
								},
								["Tick"] = {
									["max"] = 11088,
									["min"] = 11088,
									["count"] = 1,
									["amount"] = 11088,
								},
							},
							["count"] = 2,
							["amount"] = 33265,
						},
						["Flash Heal"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 55610,
									["min"] = 7415,
									["count"] = 3,
									["amount"] = 106665,
								},
							},
							["count"] = 3,
							["amount"] = 106665,
						},
						["Penance"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 21250,
									["min"] = 1297,
									["count"] = 4,
									["amount"] = 39033,
								},
							},
							["count"] = 4,
							["amount"] = 39033,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16710,
									["min"] = 14263,
									["count"] = 4,
									["amount"] = 62127,
								},
							},
							["count"] = 4,
							["amount"] = 62127,
						},
						["Halo"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 20888,
									["min"] = 20888,
									["count"] = 1,
									["amount"] = 20888,
								},
								["Hit"] = {
									["max"] = 32226,
									["min"] = 8687,
									["count"] = 8,
									["amount"] = 184425,
								},
							},
							["count"] = 9,
							["amount"] = 205313,
						},
						["Glyph of Power Word: Shield"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16761,
									["min"] = 16761,
									["count"] = 1,
									["amount"] = 16761,
								},
							},
							["count"] = 1,
							["amount"] = 16761,
						},
						["Atonement"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 61573,
									["min"] = 61573,
									["count"] = 1,
									["amount"] = 61573,
								},
								["Hit"] = {
									["max"] = 32501,
									["min"] = 839,
									["count"] = 12,
									["amount"] = 127671,
								},
							},
							["count"] = 13,
							["amount"] = 189244,
						},
						["Prayer of Healing"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 61338,
									["min"] = 8647,
									["count"] = 4,
									["amount"] = 161323,
								},
								["Hit"] = {
									["max"] = 34700,
									["min"] = 1757,
									["count"] = 20,
									["amount"] = 479656,
								},
							},
							["count"] = 24,
							["amount"] = 640979,
						},
					},
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
						["Rapture"] = {
							["Details"] = {
								["Tanklord-Tichondrius"] = {
									["count"] = 26000,
								},
							},
							["amount"] = 26000,
						},
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 16486,
									["min"] = 1807,
									["count"] = 3,
									["amount"] = 31019,
								},
							},
							["count"] = 8,
							["amount"] = 31019,
						},
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 2873,
									["min"] = 2873,
									["count"] = 1,
									["amount"] = 2873,
								},
							},
							["count"] = 1,
							["amount"] = 2873,
						},
					},
					["ActiveTime"] = 102.59,
					["Heals"] = {
						["Renew"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 11089,
									["min"] = 11089,
									["count"] = 2,
									["amount"] = 22178,
								},
							},
							["count"] = 2,
							["amount"] = 22178,
						},
						["Prayer of Healing"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 61357,
									["min"] = 17361,
									["count"] = 2,
									["amount"] = 78718,
								},
								["Hit"] = {
									["max"] = 27175,
									["min"] = 169,
									["count"] = 10,
									["amount"] = 111622,
								},
							},
							["count"] = 12,
							["amount"] = 190340,
						},
						["Flash Heal"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 108278,
									["min"] = 14196,
									["count"] = 7,
									["amount"] = 455698,
								},
							},
							["count"] = 7,
							["amount"] = 455698,
						},
						["Halo"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 20662,
									["min"] = 242,
									["count"] = 5,
									["amount"] = 51409,
								},
							},
							["count"] = 5,
							["amount"] = 51409,
						},
						["Glyph of Power Word: Shield"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16761,
									["min"] = 16761,
									["count"] = 1,
									["amount"] = 16761,
								},
							},
							["count"] = 1,
							["amount"] = 16761,
						},
						["Penance"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 60336,
									["min"] = 53329,
									["count"] = 2,
									["amount"] = 113665,
								},
								["Hit"] = {
									["max"] = 27497,
									["min"] = 846,
									["count"] = 7,
									["amount"] = 131279,
								},
							},
							["count"] = 9,
							["amount"] = 244944,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 15307,
									["min"] = 15307,
									["count"] = 1,
									["amount"] = 15307,
								},
							},
							["count"] = 1,
							["amount"] = 15307,
						},
						["Divine Aegis"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 41981,
									["min"] = 1485,
									["count"] = 14,
									["amount"] = 260603,
								},
							},
							["count"] = 14,
							["amount"] = 260603,
						},
						["Atonement"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 51184,
									["min"] = 787,
									["count"] = 8,
									["amount"] = 95108,
								},
								["Hit"] = {
									["max"] = 37679,
									["min"] = 239,
									["count"] = 40,
									["amount"] = 426715,
								},
							},
							["count"] = 48,
							["amount"] = 521823,
						},
						["Power Word: Shield"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 63852,
									["min"] = 63852,
									["count"] = 2,
									["amount"] = 127704,
								},
							},
							["count"] = 2,
							["amount"] = 127704,
						},
					},
					["ManaGainedFrom"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Rapture"] = {
									["count"] = 26000,
								},
							},
							["amount"] = 26000,
						},
					},
					["Overhealing"] = 1293387,
					["HealedWho"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 14533,
								},
								["Touch of the Grave"] = {
									["count"] = 15307,
								},
								["Flash Heal"] = {
									["count"] = 14196,
								},
								["Atonement"] = {
									["count"] = 36458,
								},
								["Prayer of Healing"] = {
									["count"] = 13666,
								},
							},
							["amount"] = 94160,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 100973,
								},
								["Halo"] = {
									["count"] = 9007,
								},
							},
							["amount"] = 109980,
						},
						["Risen Ally"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 2176,
								},
							},
							["amount"] = 2176,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 46330,
								},
								["Flash Heal"] = {
									["count"] = 54970,
								},
								["Halo"] = {
									["count"] = 16437,
								},
								["Atonement"] = {
									["count"] = 136915,
								},
								["Divine Aegis"] = {
									["count"] = 67557,
								},
							},
							["amount"] = 322209,
						},
						["Mirror Image <Acindor-Jubei'Thos>"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 242,
								},
								["Atonement"] = {
									["count"] = 23988,
								},
							},
							["amount"] = 24230,
						},
						["Acindor-Jubei'Thos"] = {
							["Details"] = {
								["Divine Aegis"] = {
									["count"] = 5434,
								},
							},
							["amount"] = 5434,
						},
						["Stabsya"] = {
							["Details"] = {
								["Renew"] = {
									["count"] = 22178,
								},
								["Divine Aegis"] = {
									["count"] = 39774,
								},
								["Halo"] = {
									["count"] = 5061,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 16761,
								},
								["Power Word: Shield"] = {
									["count"] = 63852,
								},
								["Prayer of Healing"] = {
									["count"] = 44983,
								},
							},
							["amount"] = 192609,
						},
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Power Word: Shield"] = {
									["count"] = 63852,
								},
								["Prayer of Healing"] = {
									["count"] = 85361,
								},
								["Flash Heal"] = {
									["count"] = 386532,
								},
								["Halo"] = {
									["count"] = 20662,
								},
								["Divine Aegis"] = {
									["count"] = 131129,
								},
								["Atonement"] = {
									["count"] = 223489,
								},
								["Penance"] = {
									["count"] = 244944,
								},
							},
							["amount"] = 1155969,
						},
					},
					["Healing"] = 1518460,
					["ElementTakenAbsorb"] = {
						["Melee"] = 31019,
						["Nature"] = 2873,
					},
					["TimeSpent"] = {
						["Corpse Eater"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 7.810000000000001,
								},
								["Holy Fire"] = {
									["count"] = 0.52,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 1.69,
								},
								["Touch of the Grave"] = {
									["count"] = 0.11,
								},
							},
							["amount"] = 10.13,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 0,
								},
								["Prayer of Healing"] = {
									["count"] = 2.55,
								},
								["Atonement"] = {
									["count"] = 2.12,
								},
								["Flash Heal"] = {
									["count"] = 0.42,
								},
							},
							["amount"] = 5.090000000000002,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 2.03,
								},
							},
							["amount"] = 2.03,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 3.2,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 2.42,
								},
								["Halo"] = {
									["count"] = 0,
								},
								["Touch of the Grave"] = {
									["count"] = 0.6800000000000001,
								},
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 2.970000000000001,
								},
							},
							["amount"] = 9.27,
						},
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Flash Heal"] = {
									["count"] = 0.77,
								},
								["Prayer of Healing"] = {
									["count"] = 0.89,
								},
								["Atonement"] = {
									["count"] = 0.73,
								},
								["Touch of the Grave"] = {
									["count"] = 0.38,
								},
							},
							["amount"] = 2.77,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 5.05,
								},
								["Halo"] = {
									["count"] = 0.4,
								},
							},
							["amount"] = 5.449999999999999,
						},
						["Mirror Image <Acindor-Jubei'Thos>"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 0,
								},
								["Atonement"] = {
									["count"] = 1.38,
								},
							},
							["amount"] = 1.38,
						},
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Penance"] = {
									["count"] = 7.23,
								},
								["Flash Heal"] = {
									["count"] = 1.66,
								},
								["Halo"] = {
									["count"] = 0.4,
								},
								["Atonement"] = {
									["count"] = 6.65,
								},
								["Prayer of Healing"] = {
									["count"] = 0,
								},
							},
							["amount"] = 15.94,
						},
						["Apothecary Frye"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 2.82,
								},
								["Penance"] = {
									["count"] = 0.48,
								},
								["Smite"] = {
									["count"] = 2.810000000000001,
								},
								["Halo"] = {
									["count"] = 0.41,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 8.17,
								},
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 22.4,
								},
								["Touch of the Grave"] = {
									["count"] = 0.9,
								},
							},
							["amount"] = 37.99000000000001,
						},
						["Stabsya"] = {
							["Details"] = {
								["Renew"] = {
									["count"] = 4.23,
								},
								["Glyph of Power Word: Shield"] = {
									["count"] = 0.8,
								},
								["Prayer of Healing"] = {
									["count"] = 4.01,
								},
								["Halo"] = {
									["count"] = 0,
								},
							},
							["amount"] = 9.039999999999999,
						},
					},
					["Attacks"] = {
						["Holy Fire"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 62360,
									["min"] = 62360,
									["count"] = 1,
									["amount"] = 62360,
								},
								["Hit"] = {
									["max"] = 30103,
									["min"] = 26862,
									["count"] = 3,
									["amount"] = 86171,
								},
							},
							["count"] = 4,
							["amount"] = 148531,
						},
						["Penance"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 32841,
									["min"] = 32740,
									["count"] = 2,
									["amount"] = 65581,
								},
							},
							["count"] = 2,
							["amount"] = 65581,
						},
						["Touch of the Grave"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 15915,
									["min"] = 13584,
									["count"] = 5,
									["amount"] = 73750,
								},
							},
							["count"] = 5,
							["amount"] = 73750,
						},
						["Shadow Word: Pain (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 16180,
									["min"] = 13782,
									["count"] = 6,
									["amount"] = 92370,
								},
								["Tick"] = {
									["max"] = 8090,
									["min"] = 6182,
									["count"] = 43,
									["amount"] = 319390,
								},
							},
							["count"] = 49,
							["amount"] = 411760,
						},
						["Halo"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 61577,
									["min"] = 15630,
									["count"] = 2,
									["amount"] = 77207,
								},
							},
							["count"] = 2,
							["amount"] = 77207,
						},
						["Smite"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 52070,
									["min"] = 51184,
									["count"] = 2,
									["amount"] = 103254,
								},
								["Hit"] = {
									["max"] = 26162,
									["min"] = 21853,
									["count"] = 12,
									["amount"] = 294653,
								},
							},
							["count"] = 14,
							["amount"] = 397907,
						},
						["Holy Fire (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1764,
									["min"] = 1563,
									["count"] = 5,
									["amount"] = 8218,
								},
								["Tick"] = {
									["max"] = 913,
									["min"] = 781,
									["count"] = 31,
									["amount"] = 26292,
								},
							},
							["count"] = 36,
							["amount"] = 34510,
						},
					},
					["HealingTaken"] = 79627,
					["WhoHealed"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Flash Heal"] = {
									["count"] = 14196,
								},
								["Prayer of Healing"] = {
									["count"] = 13666,
								},
								["Atonement"] = {
									["count"] = 36458,
								},
								["Touch of the Grave"] = {
									["count"] = 15307,
								},
							},
							["amount"] = 79627,
						},
					},
					["TimeDamage"] = 62.92,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 2.82,
								},
								["Penance"] = {
									["count"] = 0.48,
								},
								["Smite"] = {
									["count"] = 2.810000000000001,
								},
								["Halo"] = {
									["count"] = 0.41,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 8.17,
								},
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 22.4,
								},
								["Touch of the Grave"] = {
									["count"] = 0.9,
								},
							},
							["amount"] = 37.99000000000001,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 7.810000000000001,
								},
								["Holy Fire"] = {
									["count"] = 0.52,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 1.69,
								},
								["Touch of the Grave"] = {
									["count"] = 0.11,
								},
							},
							["amount"] = 10.13,
						},
						["Corpse Eater"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 2.03,
								},
							},
							["amount"] = 2.03,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 3.2,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 2.42,
								},
								["Halo"] = {
									["count"] = 0,
								},
								["Touch of the Grave"] = {
									["count"] = 0.6800000000000001,
								},
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 2.970000000000001,
								},
							},
							["amount"] = 9.27,
						},
					},
					["ManaGain"] = 26000,
					["HOTs"] = {
						["Renew"] = {
							["Details"] = {
								["Stabsya"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 92463,
								},
								["Penance"] = {
									["count"] = 65581,
								},
								["Smite"] = {
									["count"] = 397907,
								},
								["Halo"] = {
									["count"] = 61577,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 16756,
								},
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 250463,
								},
								["Touch of the Grave"] = {
									["count"] = 45106,
								},
							},
							["amount"] = 929853,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 72810,
								},
								["Holy Fire"] = {
									["count"] = 29206,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 6808,
								},
								["Touch of the Grave"] = {
									["count"] = 15060,
								},
							},
							["amount"] = 123884,
						},
						["Corpse Eater"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 6182,
								},
							},
							["amount"] = 6182,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 12364,
								},
							},
							["amount"] = 12364,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Holy Fire"] = {
									["count"] = 26862,
								},
								["Holy Fire (DoT)"] = {
									["count"] = 10946,
								},
								["Halo"] = {
									["count"] = 15630,
								},
								["Touch of the Grave"] = {
									["count"] = 13584,
								},
								["Shadow Word: Pain (DoT)"] = {
									["count"] = 69941,
								},
							},
							["amount"] = 136963,
						},
					},
				},
			},
			["UnitLockout"] = 1360559619,
			["LastActive"] = 1360559620,
		},
		["Risen Ally <Müu-Jubei'Thos>"] = {
			["GUID"] = "0xF130660D0000CE8A",
			["LastEventHealth"] = {
				"???", -- [1]
				"???", -- [2]
				"???", -- [3]
				"???", -- [4]
				"???", -- [5]
				"???", -- [6]
				"???", -- [7]
				"???", -- [8]
				"???", -- [9]
				"???", -- [10]
				"???", -- [11]
				"???", -- [12]
				"???", -- [13]
				"???", -- [14]
				"???", -- [15]
				"???", -- [16]
				"???", -- [17]
				"???", -- [18]
				"???", -- [19]
				"???", -- [20]
				"???", -- [21]
				"???", -- [22]
				"???", -- [23]
				"???", -- [24]
				"???", -- [25]
				"???", -- [26]
				"???", -- [27]
				"???", -- [28]
				"???", -- [29]
				"???", -- [30]
				"???", -- [31]
				"???", -- [32]
				"???", -- [33]
				"???", -- [34]
				"???", -- [35]
				"???", -- [36]
				"???", -- [37]
				"???", -- [38]
				"???", -- [39]
				"???", -- [40]
				"???", -- [41]
				"???", -- [42]
				"???", -- [43]
				"???", -- [44]
				"???", -- [45]
				"???", -- [46]
				"???", -- [47]
				"???", -- [48]
				"???", -- [49]
				"???", -- [50]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"HEAL", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"HEAL", -- [10]
				"HEAL", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"HEAL", -- [14]
				"HEAL", -- [15]
				"DAMAGE", -- [16]
				"HEAL", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"HEAL", -- [20]
				"MISC", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"HEAL", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["HealingTaken"] = {
					109980, -- [1]
				},
				["ActiveTime"] = {
					55.75000000000001, -- [1]
				},
				["DeathCount"] = {
					1, -- [1]
				},
				["TimeDamage"] = {
					55.75000000000001, -- [1]
				},
				["DamageTaken"] = {
					9416, -- [1]
				},
				["Damage"] = {
					286720, -- [1]
				},
			},
			["enClass"] = "PET",
			["LastDamageTaken"] = 9416,
			["DeathLogs"] = {
				{
					["MessageIncoming"] = {
						true, -- [1]
						false, -- [2]
						true, -- [3]
						false, -- [4]
						false, -- [5]
						false, -- [6]
						true, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
						true, -- [11]
						false, -- [12]
						true, -- [13]
						true, -- [14]
						false, -- [15]
						false, -- [16]
						true, -- [17]
						false, -- [18]
						false, -- [19]
						true, -- [20]
						false, -- [21]
						true, -- [22]
						false, -- [23]
						true, -- [24]
						true, -- [25]
						false, -- [26]
						false, -- [27]
						true, -- [28]
						true, -- [29]
						false, -- [30]
						true, -- [31]
						false, -- [32]
						false, -- [33]
						true, -- [34]
						true, -- [35]
					},
					["Messages"] = {
						"No One Concentrated Irresistible Cologne Spill Risen Ally <Müu-Jubei'Thos> Hit -247 (Nature)", -- [1]
						"Risen Ally <Müu-Jubei'Thos> Claw Apothecary Frye Crit -9530 (Physical)", -- [2]
						"No One Concentrated Alluring Perfume Spill Risen Ally <Müu-Jubei'Thos> Crit -489 (Nature)", -- [3]
						"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Hit -3812 (Physical)", -- [4]
						"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Glancing -3203 (Physical)", -- [5]
						"Risen Ally <Müu-Jubei'Thos> Claw Apothecary Frye Hit -4765 (Physical)", -- [6]
						"No One Concentrated Alluring Perfume Spill Risen Ally <Müu-Jubei'Thos> Hit -256 (Nature)", -- [7]
						"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Crit -7624 (Physical)", -- [8]
						"Risen Ally <Müu-Jubei'Thos> Claw Apothecary Frye Hit -4765 (Physical)", -- [9]
						"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Hit -3812 (Physical)", -- [10]
						"No One Concentrated Alluring Perfume Spill Risen Ally <Müu-Jubei'Thos> Hit -248 (Nature)", -- [11]
						"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Dodge", -- [12]
						"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +32841 (19886 overheal)", -- [13]
						"No One Concentrated Irresistible Cologne Spill Risen Ally <Müu-Jubei'Thos> Hit -239 (Nature)", -- [14]
						"Risen Ally <Müu-Jubei'Thos> Claw Apothecary Frye Hit -4765 (Physical)", -- [15]
						"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Hit -3812 (Physical)", -- [16]
						"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +32740 (32501 overheal)", -- [17]
						"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Hit -3812 (Physical)", -- [18]
						"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Hit -3132 (Physical)", -- [19]
						"No One Concentrated Irresistible Cologne Spill Risen Ally <Müu-Jubei'Thos> Hit -262 (Nature)", -- [20]
						"Risen Ally <Müu-Jubei'Thos> Claw Apothecary Frye Hit -3916 (Physical)", -- [21]
						"No One Concentrated Irresistible Cologne Spill Risen Ally <Müu-Jubei'Thos> Crit -525 (Nature)", -- [22]
						"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Crit -6264 (Physical)", -- [23]
						"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Crit +62360 (61573 overheal)", -- [24]
						"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +913 (913 overheal)", -- [25]
						"Risen Ally <Müu-Jubei'Thos> Claw Apothecary Frye Hit -3915 (Physical)", -- [26]
						"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Crit -6264 (Physical)", -- [27]
						"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +913 (913 overheal)", -- [28]
						"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +912 (912 overheal)", -- [29]
						"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Hit -3132 (Physical)", -- [30]
						"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +912 (912 overheal)", -- [31]
						"Risen Ally <Müu-Jubei'Thos> Claw Apothecary Frye Hit -3521 (Physical)", -- [32]
						"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Glancing -2365 (Physical)", -- [33]
						"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +912 (912 overheal)", -- [34]
						"Risen Ally <Müu-Jubei'Thos> dies.", -- [35]
					},
					["DeathAt"] = 1360559621,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
					},
					["MessageTimes"] = {
						-14.5010000000002, -- [1]
						-14.5010000000002, -- [2]
						-14.09899999999834, -- [3]
						-14.09899999999834, -- [4]
						-13.04599999999846, -- [5]
						-12.89300000000003, -- [6]
						-12.08499999999913, -- [7]
						-11.97199999999793, -- [8]
						-11.27200000000084, -- [9]
						-10.92099999999846, -- [10]
						-10.86199999999735, -- [11]
						-9.867999999998574, -- [12]
						-8.849999999998545, -- [13]
						-8.849999999998545, -- [14]
						-8.849999999998545, -- [15]
						-8.812999999998283, -- [16]
						-8.040000000000873, -- [17]
						-7.757999999997992, -- [18]
						-6.701999999997497, -- [19]
						-6.430000000000291, -- [20]
						-6.430000000000291, -- [21]
						-5.639999999999418, -- [22]
						-5.324000000000524, -- [23]
						-5.215000000000146, -- [24]
						-4.415999999997439, -- [25]
						-4.016999999999825, -- [26]
						-3.943999999999505, -- [27]
						-3.618999999998778, -- [28]
						-2.797999999998865, -- [29]
						-2.593000000000757, -- [30]
						-1.591000000000349, -- [31]
						-1.591000000000349, -- [32]
						-1.197000000000116, -- [33]
						-0.7759999999980209, -- [34]
						0, -- [35]
					},
					["KilledBy"] = "Apothecary Baxter",
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"HEAL", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"HEAL", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"HEAL", -- [24]
						"HEAL", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"HEAL", -- [28]
						"HEAL", -- [29]
						"DAMAGE", -- [30]
						"HEAL", -- [31]
						"DAMAGE", -- [32]
						"DAMAGE", -- [33]
						"HEAL", -- [34]
						"MISC", -- [35]
					},
				}, -- [1]
			},
			["level"] = 1,
			["LastDamageAbility"] = "Chain Reaction",
			["LastFightIn"] = 1,
			["type"] = "Pet",
			["FightsSaved"] = 1,
			["TimeLast"] = {
				["HealingTaken"] = 1360559613,
				["DeathCount"] = 1360559619,
				["ActiveTime"] = 1360559617,
				["TimeDamage"] = 1360559617,
				["OVERALL"] = 1360559619,
				["DamageTaken"] = 1360559585,
				["Damage"] = 1360559617,
			},
			["Owner"] = "Müu-Jubei'Thos",
			["LastAbility"] = 19800.729,
			["NextEventNum"] = 22,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
				0, -- [5]
				0, -- [6]
				0, -- [7]
				0, -- [8]
				0, -- [9]
				0, -- [10]
				0, -- [11]
				0, -- [12]
				0, -- [13]
				0, -- [14]
				0, -- [15]
				0, -- [16]
				0, -- [17]
				0, -- [18]
				0, -- [19]
				0, -- [20]
				0, -- [21]
				0, -- [22]
				0, -- [23]
				0, -- [24]
				0, -- [25]
				0, -- [26]
				0, -- [27]
				0, -- [28]
				0, -- [29]
				0, -- [30]
				0, -- [31]
				0, -- [32]
				0, -- [33]
				0, -- [34]
				0, -- [35]
				0, -- [36]
				0, -- [37]
				0, -- [38]
				0, -- [39]
				0, -- [40]
				0, -- [41]
				0, -- [42]
				0, -- [43]
				0, -- [44]
				0, -- [45]
				0, -- [46]
				0, -- [47]
				0, -- [48]
				0, -- [49]
				0, -- [50]
			},
			["LastEvents"] = {
				"Risen Ally <Müu-Jubei'Thos> Claw Apothecary Frye Hit -4765 (Physical)", -- [1]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Hit -3812 (Physical)", -- [2]
				"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +32740 (32501 overheal)", -- [3]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Hit -3812 (Physical)", -- [4]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Hit -3132 (Physical)", -- [5]
				"No One Concentrated Irresistible Cologne Spill Risen Ally <Müu-Jubei'Thos> Hit -262 (Nature)", -- [6]
				"Risen Ally <Müu-Jubei'Thos> Claw Apothecary Frye Hit -3916 (Physical)", -- [7]
				"No One Concentrated Irresistible Cologne Spill Risen Ally <Müu-Jubei'Thos> Crit -525 (Nature)", -- [8]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Crit -6264 (Physical)", -- [9]
				"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Crit +62360 (61573 overheal)", -- [10]
				"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +913 (913 overheal)", -- [11]
				"Risen Ally <Müu-Jubei'Thos> Claw Apothecary Frye Hit -3915 (Physical)", -- [12]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Crit -6264 (Physical)", -- [13]
				"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +913 (913 overheal)", -- [14]
				"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +912 (912 overheal)", -- [15]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Hit -3132 (Physical)", -- [16]
				"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +912 (912 overheal)", -- [17]
				"Risen Ally <Müu-Jubei'Thos> Claw Apothecary Frye Hit -3521 (Physical)", -- [18]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Glancing -2365 (Physical)", -- [19]
				"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +912 (912 overheal)", -- [20]
				"Risen Ally <Müu-Jubei'Thos> dies.", -- [21]
				"Risen Ally <Müu-Jubei'Thos> Claw Apothecary Baxter Crit -8520 (Physical)", -- [22]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Baxter Hit -3408 (Physical)", -- [23]
				"No One Concentrated Alluring Perfume Spill Risen Ally <Müu-Jubei'Thos> Hit -272 (Nature)", -- [24]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Baxter Crit -6816 (Physical)", -- [25]
				"No One Concentrated Alluring Perfume Spill Risen Ally <Müu-Jubei'Thos> Crit -491 (Nature)", -- [26]
				"No One Concentrated Alluring Perfume Spill Risen Ally <Müu-Jubei'Thos> Hit -233 (Nature)", -- [27]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Hit -3812 (Physical)", -- [28]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Hit -3812 (Physical)", -- [29]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Hit -3812 (Physical)", -- [30]
				"Risen Ally <Müu-Jubei'Thos> Claw Apothecary Frye Crit -9530 (Physical)", -- [31]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Glancing -3387 (Physical)", -- [32]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Hit -3812 (Physical)", -- [33]
				"Risen Ally <Müu-Jubei'Thos> Claw Apothecary Frye Hit -4765 (Physical)", -- [34]
				"No One Concentrated Irresistible Cologne Spill Risen Ally <Müu-Jubei'Thos> Crit -522 (Nature)", -- [35]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Crit -7624 (Physical)", -- [36]
				"No One Concentrated Irresistible Cologne Spill Risen Ally <Müu-Jubei'Thos> Hit -247 (Nature)", -- [37]
				"Risen Ally <Müu-Jubei'Thos> Claw Apothecary Frye Crit -9530 (Physical)", -- [38]
				"No One Concentrated Alluring Perfume Spill Risen Ally <Müu-Jubei'Thos> Crit -489 (Nature)", -- [39]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Hit -3812 (Physical)", -- [40]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Glancing -3203 (Physical)", -- [41]
				"Risen Ally <Müu-Jubei'Thos> Claw Apothecary Frye Hit -4765 (Physical)", -- [42]
				"No One Concentrated Alluring Perfume Spill Risen Ally <Müu-Jubei'Thos> Hit -256 (Nature)", -- [43]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Crit -7624 (Physical)", -- [44]
				"Risen Ally <Müu-Jubei'Thos> Claw Apothecary Frye Hit -4765 (Physical)", -- [45]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Hit -3812 (Physical)", -- [46]
				"No One Concentrated Alluring Perfume Spill Risen Ally <Müu-Jubei'Thos> Hit -248 (Nature)", -- [47]
				"Risen Ally <Müu-Jubei'Thos> Melee Apothecary Frye Dodge", -- [48]
				"Tanklord-Tichondrius Atonement Risen Ally <Müu-Jubei'Thos> Hit +32841 (19886 overheal)", -- [49]
				"No One Concentrated Irresistible Cologne Spill Risen Ally <Müu-Jubei'Thos> Hit -239 (Nature)", -- [50]
			},
			["Name"] = "Risen Ally",
			["Fights"] = {
				["Fight1"] = {
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 18.31,
								},
								["Claw"] = {
									["count"] = 5.83,
								},
							},
							["amount"] = 24.14,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 25.61,
								},
								["Claw"] = {
									["count"] = 6,
								},
							},
							["amount"] = 31.61,
						},
					},
					["WhoHealed"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 100973,
								},
								["Halo"] = {
									["count"] = 9007,
								},
							},
							["amount"] = 109980,
						},
					},
					["PartialResist"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 1,
					["ElementTakenAbsorb"] = {
						["Nature"] = 2050,
					},
					["ActiveTime"] = 55.75000000000001,
					["ElementTaken"] = {
						["Fire"] = 9416,
					},
					["Damage"] = 286720,
					["WhoDamaged"] = {
						["Apothecary Baxter"] = {
							["Details"] = {
								["Chain Reaction"] = {
									["count"] = 9416,
								},
							},
							["amount"] = 9416,
						},
					},
					["DamageTaken"] = 9416,
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 7,
								},
							},
							["amount"] = 7,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 3387,
									["min"] = 2365,
									["count"] = 4,
									["amount"] = 11697,
								},
								["Hit"] = {
									["max"] = 3812,
									["min"] = 2816,
									["count"] = 30,
									["amount"] = 98020,
								},
								["Dodge"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 7624,
									["min"] = 5633,
									["count"] = 9,
									["amount"] = 58387,
								},
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 45,
							["amount"] = 168104,
						},
						["Claw"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9530,
									["min"] = 7042,
									["count"] = 5,
									["amount"] = 42453,
								},
								["Hit"] = {
									["max"] = 4765,
									["min"] = 3521,
									["count"] = 19,
									["amount"] = 76163,
								},
							},
							["count"] = 24,
							["amount"] = 118616,
						},
					},
					["HealingTaken"] = 109980,
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 79755,
								},
								["Claw"] = {
									["count"] = 53387,
								},
							},
							["amount"] = 133142,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 88349,
								},
								["Claw"] = {
									["count"] = 65229,
								},
							},
							["amount"] = 153578,
						},
					},
					["TimeDamage"] = 55.75000000000001,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 18.31,
								},
								["Claw"] = {
									["count"] = 5.83,
								},
							},
							["amount"] = 24.14,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 25.61,
								},
								["Claw"] = {
									["count"] = 6,
								},
							},
							["amount"] = 31.61,
						},
					},
					["PartialAbsorb"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 479,
									["min"] = 245,
									["count"] = 7,
									["amount"] = 2050,
								},
							},
							["count"] = 7,
							["amount"] = 2050,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 30,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 9,
								},
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 45,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 19,
								},
							},
							["amount"] = 24,
						},
					},
					["ElementDone"] = {
						["Melee"] = 168104,
						["Physical"] = 118616,
					},
				},
				["LastFightData"] = {
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 18.31,
								},
								["Claw"] = {
									["count"] = 5.83,
								},
							},
							["amount"] = 24.14,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 25.61,
								},
								["Claw"] = {
									["count"] = 6,
								},
							},
							["amount"] = 31.61,
						},
					},
					["WhoHealed"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 100973,
								},
								["Halo"] = {
									["count"] = 9007,
								},
							},
							["amount"] = 109980,
						},
					},
					["PartialResist"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 1,
					["ElementTakenAbsorb"] = {
						["Nature"] = 2050,
					},
					["ActiveTime"] = 55.75000000000001,
					["ElementTaken"] = {
						["Fire"] = 9416,
					},
					["Damage"] = 286720,
					["WhoDamaged"] = {
						["Apothecary Baxter"] = {
							["Details"] = {
								["Chain Reaction"] = {
									["count"] = 9416,
								},
							},
							["amount"] = 9416,
						},
					},
					["DamageTaken"] = 9416,
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 7,
								},
							},
							["amount"] = 7,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 3387,
									["min"] = 2365,
									["count"] = 4,
									["amount"] = 11697,
								},
								["Hit"] = {
									["max"] = 3812,
									["min"] = 2816,
									["count"] = 30,
									["amount"] = 98020,
								},
								["Dodge"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 7624,
									["min"] = 5633,
									["count"] = 9,
									["amount"] = 58387,
								},
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 45,
							["amount"] = 168104,
						},
						["Claw"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9530,
									["min"] = 7042,
									["count"] = 5,
									["amount"] = 42453,
								},
								["Hit"] = {
									["max"] = 4765,
									["min"] = 3521,
									["count"] = 19,
									["amount"] = 76163,
								},
							},
							["count"] = 24,
							["amount"] = 118616,
						},
					},
					["HealingTaken"] = 109980,
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 79755,
								},
								["Claw"] = {
									["count"] = 53387,
								},
							},
							["amount"] = 133142,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 88349,
								},
								["Claw"] = {
									["count"] = 65229,
								},
							},
							["amount"] = 153578,
						},
					},
					["TimeDamage"] = 55.75000000000001,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 18.31,
								},
								["Claw"] = {
									["count"] = 5.83,
								},
							},
							["amount"] = 24.14,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 25.61,
								},
								["Claw"] = {
									["count"] = 6,
								},
							},
							["amount"] = 31.61,
						},
					},
					["PartialAbsorb"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 479,
									["min"] = 245,
									["count"] = 7,
									["amount"] = 2050,
								},
							},
							["count"] = 7,
							["amount"] = 2050,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 30,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 9,
								},
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 45,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 19,
								},
							},
							["amount"] = 24,
						},
					},
					["ElementDone"] = {
						["Melee"] = 168104,
						["Physical"] = 118616,
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 18.31,
								},
								["Claw"] = {
									["count"] = 5.83,
								},
							},
							["amount"] = 24.14,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 25.61,
								},
								["Claw"] = {
									["count"] = 6,
								},
							},
							["amount"] = 31.61,
						},
					},
					["WhoHealed"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Atonement"] = {
									["count"] = 100973,
								},
								["Halo"] = {
									["count"] = 9007,
								},
							},
							["amount"] = 109980,
						},
					},
					["PartialResist"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 1,
					["ElementTakenAbsorb"] = {
						["Nature"] = 2050,
					},
					["ActiveTime"] = 55.75000000000001,
					["ElementTaken"] = {
						["Fire"] = 9416,
					},
					["Damage"] = 286720,
					["WhoDamaged"] = {
						["Apothecary Baxter"] = {
							["Details"] = {
								["Chain Reaction"] = {
									["count"] = 9416,
								},
							},
							["amount"] = 9416,
						},
					},
					["DamageTaken"] = 9416,
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 7,
								},
							},
							["amount"] = 7,
						},
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 3387,
									["min"] = 2365,
									["count"] = 4,
									["amount"] = 11697,
								},
								["Hit"] = {
									["max"] = 3812,
									["min"] = 2816,
									["count"] = 30,
									["amount"] = 98020,
								},
								["Dodge"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 7624,
									["min"] = 5633,
									["count"] = 9,
									["amount"] = 58387,
								},
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 45,
							["amount"] = 168104,
						},
						["Claw"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 9530,
									["min"] = 7042,
									["count"] = 5,
									["amount"] = 42453,
								},
								["Hit"] = {
									["max"] = 4765,
									["min"] = 3521,
									["count"] = 19,
									["amount"] = 76163,
								},
							},
							["count"] = 24,
							["amount"] = 118616,
						},
					},
					["HealingTaken"] = 109980,
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 79755,
								},
								["Claw"] = {
									["count"] = 53387,
								},
							},
							["amount"] = 133142,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 88349,
								},
								["Claw"] = {
									["count"] = 65229,
								},
							},
							["amount"] = 153578,
						},
					},
					["TimeDamage"] = 55.75000000000001,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 18.31,
								},
								["Claw"] = {
									["count"] = 5.83,
								},
							},
							["amount"] = 24.14,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 25.61,
								},
								["Claw"] = {
									["count"] = 6,
								},
							},
							["amount"] = 31.61,
						},
					},
					["PartialAbsorb"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 479,
									["min"] = 245,
									["count"] = 7,
									["amount"] = 2050,
								},
							},
							["count"] = 7,
							["amount"] = 2050,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 30,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 9,
								},
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 45,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 19,
								},
							},
							["amount"] = 24,
						},
					},
					["ElementDone"] = {
						["Melee"] = 168104,
						["Physical"] = 118616,
					},
				},
			},
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				true, -- [3]
				false, -- [4]
				false, -- [5]
				true, -- [6]
				false, -- [7]
				true, -- [8]
				false, -- [9]
				true, -- [10]
				true, -- [11]
				false, -- [12]
				false, -- [13]
				true, -- [14]
				true, -- [15]
				false, -- [16]
				true, -- [17]
				false, -- [18]
				false, -- [19]
				true, -- [20]
				true, -- [21]
				false, -- [22]
				false, -- [23]
				true, -- [24]
				false, -- [25]
				true, -- [26]
				true, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				true, -- [35]
				false, -- [36]
				true, -- [37]
				false, -- [38]
				true, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				true, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				true, -- [47]
				false, -- [48]
				true, -- [49]
				true, -- [50]
			},
			["LastEventTimes"] = {
				19793.076, -- [1]
				19793.113, -- [2]
				19793.886, -- [3]
				19794.168, -- [4]
				19795.224, -- [5]
				19795.496, -- [6]
				19795.496, -- [7]
				19796.286, -- [8]
				19796.602, -- [9]
				19796.711, -- [10]
				19797.51, -- [11]
				19797.909, -- [12]
				19797.982, -- [13]
				19798.307, -- [14]
				19799.128, -- [15]
				19799.333, -- [16]
				19800.335, -- [17]
				19800.335, -- [18]
				19800.729, -- [19]
				19801.15, -- [20]
				19801.926, -- [21]
				19777.755, -- [22]
				19778.158, -- [23]
				19778.559, -- [24]
				19779.203, -- [25]
				19779.76, -- [26]
				19780.579, -- [27]
				19780.957, -- [28]
				19782.025, -- [29]
				19783.59, -- [30]
				19784.21, -- [31]
				19784.653, -- [32]
				19785.713, -- [33]
				19785.818, -- [34]
				19786.623, -- [35]
				19786.765, -- [36]
				19787.425, -- [37]
				19787.425, -- [38]
				19787.827, -- [39]
				19787.827, -- [40]
				19788.88, -- [41]
				19789.033, -- [42]
				19789.841, -- [43]
				19789.954, -- [44]
				19790.654, -- [45]
				19791.005, -- [46]
				19791.064, -- [47]
				19792.058, -- [48]
				19793.076, -- [49]
				19793.076, -- [50]
			},
			["UnitLockout"] = 1360559619,
			["LastActive"] = 1360559618,
		},
		["Mirror Image <Acindor-Jubei'Thos>"] = {
			["GUID"] = "0xF13079F00000CEAB",
			["LastEventHealth"] = {
				"???", -- [1]
				"???", -- [2]
				"???", -- [3]
				"???", -- [4]
				"???", -- [5]
				"???", -- [6]
				"???", -- [7]
				"???", -- [8]
				"???", -- [9]
				"???", -- [10]
				"???", -- [11]
				"???", -- [12]
				"???", -- [13]
				"???", -- [14]
				"???", -- [15]
				"???", -- [16]
				"???", -- [17]
				"???", -- [18]
				"???", -- [19]
				"???", -- [20]
				"???", -- [21]
				"???", -- [22]
				"???", -- [23]
				"???", -- [24]
				"???", -- [25]
				"???", -- [26]
				"???", -- [27]
				"???", -- [28]
				"???", -- [29]
				"???", -- [30]
				"???", -- [31]
				"???", -- [32]
				"???", -- [33]
				"???", -- [34]
				"???", -- [35]
				"???", -- [36]
				"???", -- [37]
				"???", -- [38]
				"???", -- [39]
				"???", -- [40]
				"???", -- [41]
				"???", -- [42]
				"???", -- [43]
				"???", -- [44]
				"???", -- [45]
				"???", -- [46]
				"???", -- [47]
				"???", -- [48]
				"???", -- [49]
				"???", -- [50]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"HEAL", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"HEAL", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"HEAL", -- [30]
				"HEAL", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"MISC", -- [41]
				"MISC", -- [42]
				"MISC", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["HealingTaken"] = {
					24230, -- [1]
				},
				["ActiveTime"] = {
					33.05, -- [1]
				},
				["DeathCount"] = {
					3, -- [1]
				},
				["TimeDamage"] = {
					33.05, -- [1]
				},
				["DamageTaken"] = {
					17596, -- [1]
				},
				["Damage"] = {
					190815, -- [1]
				},
			},
			["enClass"] = "PET",
			["LastDamageTaken"] = 9029,
			["DeathLogs"] = {
				{
					["MessageTimes"] = {
						-13.69100000000253, -- [1]
						-13.69100000000253, -- [2]
						-13.69100000000253, -- [3]
						-12.92699999999968, -- [4]
						-12.87000000000262, -- [5]
						-12.84800000000178, -- [6]
						-12.74500000000262, -- [7]
						-11.65999999999985, -- [8]
						-11.33100000000195, -- [9]
						-11.26200000000245, -- [10]
						-11.21000000000277, -- [11]
						-11.14700000000084, -- [12]
						-10.86100000000079, -- [13]
						-9.647000000000844, -- [14]
						-9.647000000000844, -- [15]
						-8.847000000001572, -- [16]
						-8.355999999999767, -- [17]
						-8.335999999999331, -- [18]
						-8.17699999999968, -- [19]
						-8.056000000000495, -- [20]
						-8.056000000000495, -- [21]
						-8.056000000000495, -- [22]
						-7.626000000000204, -- [23]
						-6.845000000001164, -- [24]
						-5.638000000002648, -- [25]
						-5.567999999999302, -- [26]
						-5.478000000002794, -- [27]
						-5.395000000000437, -- [28]
						-4.829000000001543, -- [29]
						-4.075000000000728, -- [30]
						-3.975000000002183, -- [31]
						-3.898000000001048, -- [32]
						-3.617000000002008, -- [33]
						-2.817000000002736, -- [34]
						-2.817000000002736, -- [35]
						-2.817000000002736, -- [36]
						-2.43500000000131, -- [37]
						-2.361000000000786, -- [38]
						-2.259000000001834, -- [39]
						-1.598000000001775, -- [40]
						-1.598000000001775, -- [41]
						-1.598000000001775, -- [42]
						-1.598000000001775, -- [43]
						-0.7990000000027067, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0.4660000000003493, -- [48]
						0.488999999997759, -- [49]
						0.6309999999975844, -- [50]
					},
					["MessageIncoming"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						false, -- [4]
						true, -- [5]
						false, -- [6]
						false, -- [7]
						true, -- [8]
						false, -- [9]
						true, -- [10]
						false, -- [11]
						false, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						true, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						false, -- [26]
						false, -- [27]
						false, -- [28]
						true, -- [29]
						false, -- [30]
						false, -- [31]
						false, -- [32]
						true, -- [33]
						true, -- [34]
						true, -- [35]
						true, -- [36]
						false, -- [37]
						false, -- [38]
						false, -- [39]
						true, -- [40]
						false, -- [41]
						false, -- [42]
						false, -- [43]
						true, -- [44]
						true, -- [45]
						true, -- [46]
						true, -- [47]
						false, -- [48]
						false, -- [49]
						false, -- [50]
					},
					["Messages"] = {
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -249 (Nature)", -- [1]
						"Apothecary Baxter Chain Reaction Mirror Image <Acindor-Jubei'Thos> Hit -8567 (Fire)", -- [2]
						"Apothecary Baxter Chain Reaction Mirror Image <Acindor-Jubei'Thos> Hit -9029 (Fire)", -- [3]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2790 (Frost)", -- [4]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -234 (Nature)", -- [5]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2778 (Frost)", -- [6]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Crit -5549 (Frost)", -- [7]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -451 (Nature)", -- [8]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2725 (Frost)", -- [9]
						"Tanklord-Tichondrius Atonement Mirror Image <Acindor-Jubei'Thos> Hit +30550 (17553 overheal)", -- [10]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2755 (Frost)", -- [11]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2746 (Frost)", -- [12]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -260 (Nature)", -- [13]
						"Tanklord-Tichondrius Atonement Mirror Image <Acindor-Jubei'Thos> Hit +37629 (29062 overheal)", -- [14]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -465 (Nature)", -- [15]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -253 (Nature)", -- [16]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2827 (Frost)", -- [17]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2829 (Frost)", -- [18]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Crit -5773 (Frost)", -- [19]
						"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2861 (Fire)", -- [20]
						"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Crit -5585 (Fire)", -- [21]
						"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2848 (Fire)", -- [22]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -269 (Nature)", -- [23]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -230 (Nature)", -- [24]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -234 (Nature)", -- [25]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2770 (Frost)", -- [26]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Crit -5456 (Frost)", -- [27]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Crit -5428 (Frost)", -- [28]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -245 (Nature)", -- [29]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2831 (Frost)", -- [30]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2923 (Frost)", -- [31]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2854 (Frost)", -- [32]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -468 (Nature)", -- [33]
						"Tanklord-Tichondrius Atonement Mirror Image <Acindor-Jubei'Thos> Hit +24780 (22356 overheal)", -- [34]
						"Tanklord-Tichondrius Atonement Mirror Image <Acindor-Jubei'Thos> Hit +839 (839 overheal)", -- [35]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -473 (Nature)", -- [36]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2852 (Frost)", -- [37]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2891 (Frost)", -- [38]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Crit -5687 (Frost)", -- [39]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -255 (Nature)", -- [40]
						"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2711 (Fire)", -- [41]
						"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2668 (Fire)", -- [42]
						"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2736 (Fire)", -- [43]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -470 (Nature)", -- [44]
						"Mirror Image <Acindor-Jubei'Thos> dies.", -- [45]
						"Mirror Image <Acindor-Jubei'Thos> dies.", -- [46]
						"Mirror Image <Acindor-Jubei'Thos> dies.", -- [47]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2786 (Frost)", -- [48]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Crit -5388 (Frost)", -- [49]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2727 (Frost)", -- [50]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["DeathAt"] = 1360559600,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
						"???", -- [45]
						"???", -- [46]
						"???", -- [47]
						"???", -- [48]
						"???", -- [49]
						"???", -- [50]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"HEAL", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"HEAL", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"DAMAGE", -- [33]
						"HEAL", -- [34]
						"HEAL", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"DAMAGE", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"MISC", -- [45]
						"MISC", -- [46]
						"MISC", -- [47]
						"DAMAGE", -- [48]
						"DAMAGE", -- [49]
						"DAMAGE", -- [50]
					},
				}, -- [1]
				{
					["MessageTimes"] = {
						-13.69100000000253, -- [1]
						-13.69100000000253, -- [2]
						-13.69100000000253, -- [3]
						-12.92699999999968, -- [4]
						-12.87000000000262, -- [5]
						-12.84800000000178, -- [6]
						-12.74500000000262, -- [7]
						-11.65999999999985, -- [8]
						-11.33100000000195, -- [9]
						-11.26200000000245, -- [10]
						-11.21000000000277, -- [11]
						-11.14700000000084, -- [12]
						-10.86100000000079, -- [13]
						-9.647000000000844, -- [14]
						-9.647000000000844, -- [15]
						-8.847000000001572, -- [16]
						-8.355999999999767, -- [17]
						-8.335999999999331, -- [18]
						-8.17699999999968, -- [19]
						-8.056000000000495, -- [20]
						-8.056000000000495, -- [21]
						-8.056000000000495, -- [22]
						-7.626000000000204, -- [23]
						-6.845000000001164, -- [24]
						-5.638000000002648, -- [25]
						-5.567999999999302, -- [26]
						-5.478000000002794, -- [27]
						-5.395000000000437, -- [28]
						-4.829000000001543, -- [29]
						-4.075000000000728, -- [30]
						-3.975000000002183, -- [31]
						-3.898000000001048, -- [32]
						-3.617000000002008, -- [33]
						-2.817000000002736, -- [34]
						-2.817000000002736, -- [35]
						-2.817000000002736, -- [36]
						-2.43500000000131, -- [37]
						-2.361000000000786, -- [38]
						-2.259000000001834, -- [39]
						-1.598000000001775, -- [40]
						-1.598000000001775, -- [41]
						-1.598000000001775, -- [42]
						-1.598000000001775, -- [43]
						-0.7990000000027067, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0.4660000000003493, -- [48]
						0.488999999997759, -- [49]
						0.6309999999975844, -- [50]
					},
					["MessageIncoming"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						false, -- [4]
						true, -- [5]
						false, -- [6]
						false, -- [7]
						true, -- [8]
						false, -- [9]
						true, -- [10]
						false, -- [11]
						false, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						true, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						false, -- [26]
						false, -- [27]
						false, -- [28]
						true, -- [29]
						false, -- [30]
						false, -- [31]
						false, -- [32]
						true, -- [33]
						true, -- [34]
						true, -- [35]
						true, -- [36]
						false, -- [37]
						false, -- [38]
						false, -- [39]
						true, -- [40]
						false, -- [41]
						false, -- [42]
						false, -- [43]
						true, -- [44]
						true, -- [45]
						true, -- [46]
						true, -- [47]
						false, -- [48]
						false, -- [49]
						false, -- [50]
					},
					["Messages"] = {
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -249 (Nature)", -- [1]
						"Apothecary Baxter Chain Reaction Mirror Image <Acindor-Jubei'Thos> Hit -8567 (Fire)", -- [2]
						"Apothecary Baxter Chain Reaction Mirror Image <Acindor-Jubei'Thos> Hit -9029 (Fire)", -- [3]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2790 (Frost)", -- [4]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -234 (Nature)", -- [5]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2778 (Frost)", -- [6]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Crit -5549 (Frost)", -- [7]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -451 (Nature)", -- [8]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2725 (Frost)", -- [9]
						"Tanklord-Tichondrius Atonement Mirror Image <Acindor-Jubei'Thos> Hit +30550 (17553 overheal)", -- [10]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2755 (Frost)", -- [11]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2746 (Frost)", -- [12]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -260 (Nature)", -- [13]
						"Tanklord-Tichondrius Atonement Mirror Image <Acindor-Jubei'Thos> Hit +37629 (29062 overheal)", -- [14]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -465 (Nature)", -- [15]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -253 (Nature)", -- [16]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2827 (Frost)", -- [17]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2829 (Frost)", -- [18]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Crit -5773 (Frost)", -- [19]
						"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2861 (Fire)", -- [20]
						"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Crit -5585 (Fire)", -- [21]
						"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2848 (Fire)", -- [22]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -269 (Nature)", -- [23]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -230 (Nature)", -- [24]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -234 (Nature)", -- [25]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2770 (Frost)", -- [26]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Crit -5456 (Frost)", -- [27]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Crit -5428 (Frost)", -- [28]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -245 (Nature)", -- [29]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2831 (Frost)", -- [30]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2923 (Frost)", -- [31]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2854 (Frost)", -- [32]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -468 (Nature)", -- [33]
						"Tanklord-Tichondrius Atonement Mirror Image <Acindor-Jubei'Thos> Hit +24780 (22356 overheal)", -- [34]
						"Tanklord-Tichondrius Atonement Mirror Image <Acindor-Jubei'Thos> Hit +839 (839 overheal)", -- [35]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -473 (Nature)", -- [36]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2852 (Frost)", -- [37]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2891 (Frost)", -- [38]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Crit -5687 (Frost)", -- [39]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -255 (Nature)", -- [40]
						"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2711 (Fire)", -- [41]
						"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2668 (Fire)", -- [42]
						"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2736 (Fire)", -- [43]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -470 (Nature)", -- [44]
						"Mirror Image <Acindor-Jubei'Thos> dies.", -- [45]
						"Mirror Image <Acindor-Jubei'Thos> dies.", -- [46]
						"Mirror Image <Acindor-Jubei'Thos> dies.", -- [47]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2786 (Frost)", -- [48]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Crit -5388 (Frost)", -- [49]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2727 (Frost)", -- [50]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["DeathAt"] = 1360559600,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
						"???", -- [45]
						"???", -- [46]
						"???", -- [47]
						"???", -- [48]
						"???", -- [49]
						"???", -- [50]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"HEAL", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"HEAL", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"DAMAGE", -- [33]
						"HEAL", -- [34]
						"HEAL", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"DAMAGE", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"MISC", -- [45]
						"MISC", -- [46]
						"MISC", -- [47]
						"DAMAGE", -- [48]
						"DAMAGE", -- [49]
						"DAMAGE", -- [50]
					},
				}, -- [2]
				{
					["MessageIncoming"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						false, -- [4]
						true, -- [5]
						false, -- [6]
						false, -- [7]
						true, -- [8]
						false, -- [9]
						true, -- [10]
						false, -- [11]
						false, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						true, -- [16]
						false, -- [17]
						false, -- [18]
						false, -- [19]
						false, -- [20]
						false, -- [21]
						false, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						false, -- [26]
						false, -- [27]
						false, -- [28]
						true, -- [29]
						false, -- [30]
						false, -- [31]
						false, -- [32]
						true, -- [33]
						true, -- [34]
						true, -- [35]
						true, -- [36]
						false, -- [37]
						false, -- [38]
						false, -- [39]
						true, -- [40]
						false, -- [41]
						false, -- [42]
						false, -- [43]
						true, -- [44]
						true, -- [45]
						true, -- [46]
						true, -- [47]
						false, -- [48]
						false, -- [49]
						false, -- [50]
					},
					["Messages"] = {
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -249 (Nature)", -- [1]
						"Apothecary Baxter Chain Reaction Mirror Image <Acindor-Jubei'Thos> Hit -8567 (Fire)", -- [2]
						"Apothecary Baxter Chain Reaction Mirror Image <Acindor-Jubei'Thos> Hit -9029 (Fire)", -- [3]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2790 (Frost)", -- [4]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -234 (Nature)", -- [5]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2778 (Frost)", -- [6]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Crit -5549 (Frost)", -- [7]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -451 (Nature)", -- [8]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2725 (Frost)", -- [9]
						"Tanklord-Tichondrius Atonement Mirror Image <Acindor-Jubei'Thos> Hit +30550 (17553 overheal)", -- [10]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2755 (Frost)", -- [11]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2746 (Frost)", -- [12]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -260 (Nature)", -- [13]
						"Tanklord-Tichondrius Atonement Mirror Image <Acindor-Jubei'Thos> Hit +37629 (29062 overheal)", -- [14]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -465 (Nature)", -- [15]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -253 (Nature)", -- [16]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2827 (Frost)", -- [17]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2829 (Frost)", -- [18]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Crit -5773 (Frost)", -- [19]
						"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2861 (Fire)", -- [20]
						"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Crit -5585 (Fire)", -- [21]
						"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2848 (Fire)", -- [22]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -269 (Nature)", -- [23]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -230 (Nature)", -- [24]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -234 (Nature)", -- [25]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2770 (Frost)", -- [26]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Crit -5456 (Frost)", -- [27]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Crit -5428 (Frost)", -- [28]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -245 (Nature)", -- [29]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2831 (Frost)", -- [30]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2923 (Frost)", -- [31]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2854 (Frost)", -- [32]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -468 (Nature)", -- [33]
						"Tanklord-Tichondrius Atonement Mirror Image <Acindor-Jubei'Thos> Hit +24780 (22356 overheal)", -- [34]
						"Tanklord-Tichondrius Atonement Mirror Image <Acindor-Jubei'Thos> Hit +839 (839 overheal)", -- [35]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -473 (Nature)", -- [36]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2852 (Frost)", -- [37]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2891 (Frost)", -- [38]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Crit -5687 (Frost)", -- [39]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -255 (Nature)", -- [40]
						"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2711 (Fire)", -- [41]
						"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2668 (Fire)", -- [42]
						"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2736 (Fire)", -- [43]
						"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -470 (Nature)", -- [44]
						"Mirror Image <Acindor-Jubei'Thos> dies.", -- [45]
						"Mirror Image <Acindor-Jubei'Thos> dies.", -- [46]
						"Mirror Image <Acindor-Jubei'Thos> dies.", -- [47]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2786 (Frost)", -- [48]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Crit -5388 (Frost)", -- [49]
						"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2727 (Frost)", -- [50]
					},
					["DeathAt"] = 1360559600,
					["HealthNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["MessageTimes"] = {
						-13.69100000000253, -- [1]
						-13.69100000000253, -- [2]
						-13.69100000000253, -- [3]
						-12.92699999999968, -- [4]
						-12.87000000000262, -- [5]
						-12.84800000000178, -- [6]
						-12.74500000000262, -- [7]
						-11.65999999999985, -- [8]
						-11.33100000000195, -- [9]
						-11.26200000000245, -- [10]
						-11.21000000000277, -- [11]
						-11.14700000000084, -- [12]
						-10.86100000000079, -- [13]
						-9.647000000000844, -- [14]
						-9.647000000000844, -- [15]
						-8.847000000001572, -- [16]
						-8.355999999999767, -- [17]
						-8.335999999999331, -- [18]
						-8.17699999999968, -- [19]
						-8.056000000000495, -- [20]
						-8.056000000000495, -- [21]
						-8.056000000000495, -- [22]
						-7.626000000000204, -- [23]
						-6.845000000001164, -- [24]
						-5.638000000002648, -- [25]
						-5.567999999999302, -- [26]
						-5.478000000002794, -- [27]
						-5.395000000000437, -- [28]
						-4.829000000001543, -- [29]
						-4.075000000000728, -- [30]
						-3.975000000002183, -- [31]
						-3.898000000001048, -- [32]
						-3.617000000002008, -- [33]
						-2.817000000002736, -- [34]
						-2.817000000002736, -- [35]
						-2.817000000002736, -- [36]
						-2.43500000000131, -- [37]
						-2.361000000000786, -- [38]
						-2.259000000001834, -- [39]
						-1.598000000001775, -- [40]
						-1.598000000001775, -- [41]
						-1.598000000001775, -- [42]
						-1.598000000001775, -- [43]
						-0.7990000000027067, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0.4660000000003493, -- [48]
						0.488999999997759, -- [49]
						0.6309999999975844, -- [50]
					},
					["KilledBy"] = "Apothecary Baxter",
					["Health"] = {
						"???", -- [1]
						"???", -- [2]
						"???", -- [3]
						"???", -- [4]
						"???", -- [5]
						"???", -- [6]
						"???", -- [7]
						"???", -- [8]
						"???", -- [9]
						"???", -- [10]
						"???", -- [11]
						"???", -- [12]
						"???", -- [13]
						"???", -- [14]
						"???", -- [15]
						"???", -- [16]
						"???", -- [17]
						"???", -- [18]
						"???", -- [19]
						"???", -- [20]
						"???", -- [21]
						"???", -- [22]
						"???", -- [23]
						"???", -- [24]
						"???", -- [25]
						"???", -- [26]
						"???", -- [27]
						"???", -- [28]
						"???", -- [29]
						"???", -- [30]
						"???", -- [31]
						"???", -- [32]
						"???", -- [33]
						"???", -- [34]
						"???", -- [35]
						"???", -- [36]
						"???", -- [37]
						"???", -- [38]
						"???", -- [39]
						"???", -- [40]
						"???", -- [41]
						"???", -- [42]
						"???", -- [43]
						"???", -- [44]
						"???", -- [45]
						"???", -- [46]
						"???", -- [47]
						"???", -- [48]
						"???", -- [49]
						"???", -- [50]
					},
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"HEAL", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"HEAL", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"DAMAGE", -- [33]
						"HEAL", -- [34]
						"HEAL", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"DAMAGE", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"MISC", -- [45]
						"MISC", -- [46]
						"MISC", -- [47]
						"DAMAGE", -- [48]
						"DAMAGE", -- [49]
						"DAMAGE", -- [50]
					},
				}, -- [3]
			},
			["level"] = 1,
			["LastDamageAbility"] = "Chain Reaction",
			["LastFightIn"] = 1,
			["type"] = "Pet",
			["FightsSaved"] = 1,
			["TimeLast"] = {
				["HealingTaken"] = 1360559596,
				["DeathCount"] = 1360559598,
				["ActiveTime"] = 1360559599,
				["TimeDamage"] = 1360559599,
				["OVERALL"] = 1360559599,
				["DamageTaken"] = 1360559585,
				["Damage"] = 1360559599,
			},
			["Owner"] = "Acindor-Jubei'Thos",
			["LastAbility"] = 19782.406,
			["NextEventNum"] = 47,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
				0, -- [5]
				0, -- [6]
				0, -- [7]
				0, -- [8]
				0, -- [9]
				0, -- [10]
				0, -- [11]
				0, -- [12]
				0, -- [13]
				0, -- [14]
				0, -- [15]
				0, -- [16]
				0, -- [17]
				0, -- [18]
				0, -- [19]
				0, -- [20]
				0, -- [21]
				0, -- [22]
				0, -- [23]
				0, -- [24]
				0, -- [25]
				0, -- [26]
				0, -- [27]
				0, -- [28]
				0, -- [29]
				0, -- [30]
				0, -- [31]
				0, -- [32]
				0, -- [33]
				0, -- [34]
				0, -- [35]
				0, -- [36]
				0, -- [37]
				0, -- [38]
				0, -- [39]
				0, -- [40]
				0, -- [41]
				0, -- [42]
				0, -- [43]
				0, -- [44]
				0, -- [45]
				0, -- [46]
				0, -- [47]
				0, -- [48]
				0, -- [49]
				0, -- [50]
			},
			["LastEvents"] = {
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -234 (Nature)", -- [1]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2778 (Frost)", -- [2]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Crit -5549 (Frost)", -- [3]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -451 (Nature)", -- [4]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2725 (Frost)", -- [5]
				"Tanklord-Tichondrius Atonement Mirror Image <Acindor-Jubei'Thos> Hit +30550 (17553 overheal)", -- [6]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2755 (Frost)", -- [7]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2746 (Frost)", -- [8]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -260 (Nature)", -- [9]
				"Tanklord-Tichondrius Atonement Mirror Image <Acindor-Jubei'Thos> Hit +37629 (29062 overheal)", -- [10]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -465 (Nature)", -- [11]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -253 (Nature)", -- [12]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2827 (Frost)", -- [13]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2829 (Frost)", -- [14]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Crit -5773 (Frost)", -- [15]
				"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2861 (Fire)", -- [16]
				"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Crit -5585 (Fire)", -- [17]
				"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2848 (Fire)", -- [18]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -269 (Nature)", -- [19]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -230 (Nature)", -- [20]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -234 (Nature)", -- [21]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2770 (Frost)", -- [22]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Crit -5456 (Frost)", -- [23]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Crit -5428 (Frost)", -- [24]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -245 (Nature)", -- [25]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2831 (Frost)", -- [26]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2923 (Frost)", -- [27]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2854 (Frost)", -- [28]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -468 (Nature)", -- [29]
				"Tanklord-Tichondrius Atonement Mirror Image <Acindor-Jubei'Thos> Hit +24780 (22356 overheal)", -- [30]
				"Tanklord-Tichondrius Atonement Mirror Image <Acindor-Jubei'Thos> Hit +839 (839 overheal)", -- [31]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -473 (Nature)", -- [32]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2852 (Frost)", -- [33]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2891 (Frost)", -- [34]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Crit -5687 (Frost)", -- [35]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -255 (Nature)", -- [36]
				"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2711 (Fire)", -- [37]
				"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2668 (Fire)", -- [38]
				"Mirror Image <Acindor-Jubei'Thos> Fire Blast Apothecary Frye Hit -2736 (Fire)", -- [39]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -470 (Nature)", -- [40]
				"Mirror Image <Acindor-Jubei'Thos> dies.", -- [41]
				"Mirror Image <Acindor-Jubei'Thos> dies.", -- [42]
				"Mirror Image <Acindor-Jubei'Thos> dies.", -- [43]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2786 (Frost)", -- [44]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Crit -5388 (Frost)", -- [45]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Frye Hit -2727 (Frost)", -- [46]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -249 (Nature)", -- [47]
				"Apothecary Baxter Chain Reaction Mirror Image <Acindor-Jubei'Thos> Hit -8567 (Fire)", -- [48]
				"Apothecary Baxter Chain Reaction Mirror Image <Acindor-Jubei'Thos> Hit -9029 (Fire)", -- [49]
				"Mirror Image <Acindor-Jubei'Thos> Frostbolt Apothecary Baxter Hit -2790 (Frost)", -- [50]
			},
			["Name"] = "Mirror Image",
			["LastEventIncoming"] = {
				true, -- [1]
				false, -- [2]
				false, -- [3]
				true, -- [4]
				false, -- [5]
				true, -- [6]
				false, -- [7]
				false, -- [8]
				true, -- [9]
				true, -- [10]
				true, -- [11]
				true, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				true, -- [19]
				true, -- [20]
				true, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				true, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				true, -- [29]
				true, -- [30]
				true, -- [31]
				true, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				true, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				true, -- [40]
				true, -- [41]
				true, -- [42]
				true, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				true, -- [47]
				true, -- [48]
				true, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				19768.905, -- [1]
				19768.927, -- [2]
				19769.03, -- [3]
				19770.115, -- [4]
				19770.444, -- [5]
				19770.513, -- [6]
				19770.565, -- [7]
				19770.628, -- [8]
				19770.914, -- [9]
				19772.128, -- [10]
				19772.128, -- [11]
				19772.928, -- [12]
				19773.419, -- [13]
				19773.439, -- [14]
				19773.598, -- [15]
				19773.719, -- [16]
				19773.719, -- [17]
				19773.719, -- [18]
				19774.149, -- [19]
				19774.93, -- [20]
				19776.137, -- [21]
				19776.207, -- [22]
				19776.297, -- [23]
				19776.38, -- [24]
				19776.946, -- [25]
				19777.7, -- [26]
				19777.8, -- [27]
				19777.877, -- [28]
				19778.158, -- [29]
				19778.958, -- [30]
				19778.958, -- [31]
				19778.958, -- [32]
				19779.34, -- [33]
				19779.414, -- [34]
				19779.516, -- [35]
				19780.177, -- [36]
				19780.177, -- [37]
				19780.177, -- [38]
				19780.177, -- [39]
				19780.976, -- [40]
				19781.775, -- [41]
				19781.775, -- [42]
				19781.775, -- [43]
				19782.241, -- [44]
				19782.264, -- [45]
				19782.406, -- [46]
				19768.084, -- [47]
				19768.084, -- [48]
				19768.084, -- [49]
				19768.848, -- [50]
			},
			["Fights"] = {
				["Fight1"] = {
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 0.78,
								},
								["Frostbolt"] = {
									["count"] = 7.850000000000001,
								},
							},
							["amount"] = 8.630000000000001,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Frostbolt"] = {
									["count"] = 20.81,
								},
								["Fire Blast"] = {
									["count"] = 3.61,
								},
							},
							["amount"] = 24.42,
						},
					},
					["WhoHealed"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 242,
								},
								["Atonement"] = {
									["count"] = 23988,
								},
							},
							["amount"] = 24230,
						},
					},
					["PartialResist"] = {
						["Chain Reaction"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 3,
					["PartialAbsorb"] = {
						["Chain Reaction"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 33.05,
					["ElementTaken"] = {
						["Fire"] = 17596,
					},
					["Damage"] = 190815,
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["Attacks"] = {
						["Frostbolt"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5773,
									["min"] = 4692,
									["count"] = 11,
									["amount"] = 58751,
								},
								["Hit"] = {
									["max"] = 2923,
									["min"] = 2335,
									["count"] = 34,
									["amount"] = 90088,
								},
							},
							["count"] = 45,
							["amount"] = 148839,
						},
						["Fire Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5585,
									["min"] = 5585,
									["count"] = 1,
									["amount"] = 5585,
								},
								["Hit"] = {
									["max"] = 2861,
									["min"] = 2352,
									["count"] = 14,
									["amount"] = 36391,
								},
							},
							["count"] = 15,
							["amount"] = 41976,
						},
					},
					["ElementDone"] = {
						["Frost"] = 148839,
						["Fire"] = 41976,
					},
					["HealingTaken"] = 24230,
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 19409,
								},
								["Frostbolt"] = {
									["count"] = 35984,
								},
							},
							["amount"] = 55393,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Frostbolt"] = {
									["count"] = 112855,
								},
								["Fire Blast"] = {
									["count"] = 22567,
								},
							},
							["amount"] = 135422,
						},
					},
					["TimeDamage"] = 33.05,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 0.78,
								},
								["Frostbolt"] = {
									["count"] = 7.850000000000001,
								},
							},
							["amount"] = 8.630000000000001,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Frostbolt"] = {
									["count"] = 20.81,
								},
								["Fire Blast"] = {
									["count"] = 3.61,
								},
							},
							["amount"] = 24.42,
						},
					},
					["WhoDamaged"] = {
						["Apothecary Baxter"] = {
							["Details"] = {
								["Chain Reaction"] = {
									["count"] = 17596,
								},
							},
							["amount"] = 17596,
						},
					},
					["DamageTaken"] = 17596,
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 11,
								},
								["Hit"] = {
									["count"] = 34,
								},
							},
							["amount"] = 45,
						},
						["Fire"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 14,
								},
							},
							["amount"] = 15,
						},
					},
				},
				["LastFightData"] = {
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 0.78,
								},
								["Frostbolt"] = {
									["count"] = 7.850000000000001,
								},
							},
							["amount"] = 8.630000000000001,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Frostbolt"] = {
									["count"] = 20.81,
								},
								["Fire Blast"] = {
									["count"] = 3.61,
								},
							},
							["amount"] = 24.42,
						},
					},
					["WhoHealed"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 242,
								},
								["Atonement"] = {
									["count"] = 23988,
								},
							},
							["amount"] = 24230,
						},
					},
					["PartialResist"] = {
						["Chain Reaction"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 3,
					["PartialAbsorb"] = {
						["Chain Reaction"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 33.05,
					["ElementTaken"] = {
						["Fire"] = 17596,
					},
					["Damage"] = 190815,
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["Attacks"] = {
						["Frostbolt"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5773,
									["min"] = 4692,
									["count"] = 11,
									["amount"] = 58751,
								},
								["Hit"] = {
									["max"] = 2923,
									["min"] = 2335,
									["count"] = 34,
									["amount"] = 90088,
								},
							},
							["count"] = 45,
							["amount"] = 148839,
						},
						["Fire Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5585,
									["min"] = 5585,
									["count"] = 1,
									["amount"] = 5585,
								},
								["Hit"] = {
									["max"] = 2861,
									["min"] = 2352,
									["count"] = 14,
									["amount"] = 36391,
								},
							},
							["count"] = 15,
							["amount"] = 41976,
						},
					},
					["ElementDone"] = {
						["Frost"] = 148839,
						["Fire"] = 41976,
					},
					["HealingTaken"] = 24230,
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 19409,
								},
								["Frostbolt"] = {
									["count"] = 35984,
								},
							},
							["amount"] = 55393,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Frostbolt"] = {
									["count"] = 112855,
								},
								["Fire Blast"] = {
									["count"] = 22567,
								},
							},
							["amount"] = 135422,
						},
					},
					["TimeDamage"] = 33.05,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 0.78,
								},
								["Frostbolt"] = {
									["count"] = 7.850000000000001,
								},
							},
							["amount"] = 8.630000000000001,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Frostbolt"] = {
									["count"] = 20.81,
								},
								["Fire Blast"] = {
									["count"] = 3.61,
								},
							},
							["amount"] = 24.42,
						},
					},
					["WhoDamaged"] = {
						["Apothecary Baxter"] = {
							["Details"] = {
								["Chain Reaction"] = {
									["count"] = 17596,
								},
							},
							["amount"] = 17596,
						},
					},
					["DamageTaken"] = 17596,
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 11,
								},
								["Hit"] = {
									["count"] = 34,
								},
							},
							["amount"] = 45,
						},
						["Fire"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 14,
								},
							},
							["amount"] = 15,
						},
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 0.78,
								},
								["Frostbolt"] = {
									["count"] = 7.850000000000001,
								},
							},
							["amount"] = 8.630000000000001,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Frostbolt"] = {
									["count"] = 20.81,
								},
								["Fire Blast"] = {
									["count"] = 3.61,
								},
							},
							["amount"] = 24.42,
						},
					},
					["WhoHealed"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Halo"] = {
									["count"] = 242,
								},
								["Atonement"] = {
									["count"] = 23988,
								},
							},
							["amount"] = 24230,
						},
					},
					["PartialResist"] = {
						["Chain Reaction"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["DeathCount"] = 3,
					["PartialAbsorb"] = {
						["Chain Reaction"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 33.05,
					["ElementTaken"] = {
						["Fire"] = 17596,
					},
					["Damage"] = 190815,
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["Attacks"] = {
						["Frostbolt"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5773,
									["min"] = 4692,
									["count"] = 11,
									["amount"] = 58751,
								},
								["Hit"] = {
									["max"] = 2923,
									["min"] = 2335,
									["count"] = 34,
									["amount"] = 90088,
								},
							},
							["count"] = 45,
							["amount"] = 148839,
						},
						["Fire Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5585,
									["min"] = 5585,
									["count"] = 1,
									["amount"] = 5585,
								},
								["Hit"] = {
									["max"] = 2861,
									["min"] = 2352,
									["count"] = 14,
									["amount"] = 36391,
								},
							},
							["count"] = 15,
							["amount"] = 41976,
						},
					},
					["ElementDone"] = {
						["Frost"] = 148839,
						["Fire"] = 41976,
					},
					["HealingTaken"] = 24230,
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 19409,
								},
								["Frostbolt"] = {
									["count"] = 35984,
								},
							},
							["amount"] = 55393,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Frostbolt"] = {
									["count"] = 112855,
								},
								["Fire Blast"] = {
									["count"] = 22567,
								},
							},
							["amount"] = 135422,
						},
					},
					["TimeDamage"] = 33.05,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fire Blast"] = {
									["count"] = 0.78,
								},
								["Frostbolt"] = {
									["count"] = 7.850000000000001,
								},
							},
							["amount"] = 8.630000000000001,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Frostbolt"] = {
									["count"] = 20.81,
								},
								["Fire Blast"] = {
									["count"] = 3.61,
								},
							},
							["amount"] = 24.42,
						},
					},
					["WhoDamaged"] = {
						["Apothecary Baxter"] = {
							["Details"] = {
								["Chain Reaction"] = {
									["count"] = 17596,
								},
							},
							["amount"] = 17596,
						},
					},
					["DamageTaken"] = 17596,
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 11,
								},
								["Hit"] = {
									["count"] = 34,
								},
							},
							["amount"] = 45,
						},
						["Fire"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 14,
								},
							},
							["amount"] = 15,
						},
					},
				},
			},
			["UnitLockout"] = 1360559599,
			["LastActive"] = 1360559599,
		},
		["Baron Ashbury"] = {
			["GUID"] = "0xF150B7720000C4D7",
			["type"] = "Trivial",
			["FightsSaved"] = 1,
			["LastAttackedBy"] = "Müu-Jubei'Thos",
			["Owner"] = false,
			["enClass"] = "MOB",
			["LastDamageTaken"] = 27425,
			["LastDamageAbility"] = "Howling Blast",
			["Name"] = "Baron Ashbury",
			["LastActive"] = 1360559382,
			["Fights"] = {
				["Fight1"] = {
					["WhoDamaged"] = {
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
				},
				["LastFightData"] = {
					["WhoDamaged"] = {
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["WhoDamaged"] = {
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Howling Blast"] = {
									["count"] = 27425,
								},
							},
							["amount"] = 27425,
						},
					},
				},
			},
			["level"] = 21,
			["UnitLockout"] = 1360559382,
			["LastFightIn"] = 1,
		},
		["Ghost Iron Dragonling"] = {
			["GUID"] = "0xF130E1B70000CDA3",
			["FightsSaved"] = 1,
			["Owner"] = false,
			["Name"] = "Ghost Iron Dragonling",
			["LastAbility"] = 19802.328,
			["LastActive"] = 1360559619,
			["Fights"] = {
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
			},
			["UnitLockout"] = 1360559562,
			["LastFightIn"] = 1,
		},
		["Metalica-Jubei'Thos"] = {
			["GUID"] = "0x0380000005641B0A",
			["LastEventHealth"] = {
				"475109 (100%)", -- [1]
				"475109 (100%)", -- [2]
				"475109 (100%)", -- [3]
				"475109 (100%)", -- [4]
				"475109 (100%)", -- [5]
				"475109 (100%)", -- [6]
				"475109 (100%)", -- [7]
				"475109 (100%)", -- [8]
				"475109 (100%)", -- [9]
				"475109 (100%)", -- [10]
				"475109 (100%)", -- [11]
				"440056 (92%)", -- [12]
				"468703 (98%)", -- [13]
				"469673 (98%)", -- [14]
				"468442 (98%)", -- [15]
				"468442 (98%)", -- [16]
				"451509 (95%)", -- [17]
				"450293 (94%)", -- [18]
				"450820 (94%)", -- [19]
				"450820 (94%)", -- [20]
				"450820 (94%)", -- [21]
				"449439 (94%)", -- [22]
				"432253 (90%)", -- [23]
				"415591 (87%)", -- [24]
				"398405 (83%)", -- [25]
				"457217 (96%)", -- [26]
				"457217 (96%)", -- [27]
				"457217 (96%)", -- [28]
				"457217 (96%)", -- [29]
				"457745 (96%)", -- [30]
				"457745 (96%)", -- [31]
				"475109 (100%)", -- [32]
				"475109 (100%)", -- [33]
				"473064 (99%)", -- [34]
				"473064 (99%)", -- [35]
				"471066 (99%)", -- [36]
				"471066 (99%)", -- [37]
				"471592 (99%)", -- [38]
				"469551 (98%)", -- [39]
				"475109 (100%)", -- [40]
				"475109 (100%)", -- [41]
				"475109 (100%)", -- [42]
				"475109 (100%)", -- [43]
				"475109 (100%)", -- [44]
				"475109 (100%)", -- [45]
				"475109 (100%)", -- [46]
				"475109 (100%)", -- [47]
				"475109 (100%)", -- [48]
				"475109 (100%)", -- [49]
				"475109 (100%)", -- [50]
			},
			["LastAttackedBy"] = "Apothecary Baxter",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"HEAL", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"HEAL", -- [11]
				"DAMAGE", -- [12]
				"HEAL", -- [13]
				"HEAL", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"HEAL", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"HEAL", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"HEAL", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"HEAL", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					3.74, -- [1]
				},
				["Healing"] = {
					148090, -- [1]
				},
				["DamageTaken"] = {
					1107213, -- [1]
				},
				["TimeDamage"] = {
					108.96, -- [1]
				},
				["Overhealing"] = {
					60957, -- [1]
				},
				["RageGain"] = {
					430, -- [1]
				},
				["HOT_Time"] = {
					33, -- [1]
				},
				["ActiveTime"] = {
					112.7, -- [1]
				},
				["HealingTaken"] = {
					1109078, -- [1]
				},
				["ManaGain"] = {
					64800, -- [1]
				},
				["DOT_Time"] = {
					222, -- [1]
				},
				["Damage"] = {
					2785038, -- [1]
				},
			},
			["enClass"] = "DRUID",
			["unit"] = "Metalica",
			["level"] = 90,
			["LastDamageAbility"] = "Irresistible Cologne Spray (DoT)",
			["LastFightIn"] = 1,
			["LastEventNum"] = {
				nil, -- [1]
				nil, -- [2]
				nil, -- [3]
				nil, -- [4]
				nil, -- [5]
				3.999924227914016, -- [6]
				nil, -- [7]
				nil, -- [8]
				nil, -- [9]
				nil, -- [10]
				6.479565741756102, -- [11]
				3.563813777470012, -- [12]
				6.029563742214944, -- [13]
				0.2041636761248472, -- [14]
				0.2590984384635947, -- [15]
				nil, -- [16]
				3.564024255486636, -- [17]
				0.2559412682142414, -- [18]
				nil, -- [19]
				nil, -- [20]
				nil, -- [21]
				0.2906701409571277, -- [22]
				3.617275193692395, -- [23]
				3.617485671709019, -- [24]
				3.617275193692395, -- [25]
				12.26771119890383, -- [26]
				nil, -- [27]
				nil, -- [28]
				nil, -- [29]
				nil, -- [30]
				nil, -- [31]
				3.999924227914016, -- [32]
				[36] = 0.4205350772138604,
				[46] = 3.999924227914016,
				[39] = 0.4295856319286732,
				[40] = 6.744978520718403,
				[34] = 0.4304275439951674,
			},
			["type"] = "Ungrouped",
			["FightsSaved"] = 2,
			["LastDamageTaken"] = 17186,
			["TimeLast"] = {
				["TimeHeal"] = 1360559604,
				["HealingTaken"] = 1360559607,
				["OVERALL"] = 1360559619,
				["DamageTaken"] = 1360559599,
				["Overhealing"] = 1360559617,
				["Healing"] = 1360559604,
				["RageGain"] = 1360559617,
				["HOT_Time"] = 1360559617,
				["ActiveTime"] = 1360559619,
				["TimeDamage"] = 1360559619,
				["ManaGain"] = 1360559617,
				["DOT_Time"] = 1360559619,
				["Damage"] = 1360559619,
			},
			["Owner"] = false,
			["LastAbility"] = 19802.267,
			["NextEventNum"] = 12,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				100, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				100, -- [11]
				92.62211408329458, -- [12]
				98.65167782550951, -- [13]
				98.85584150163436, -- [14]
				98.59674306317076, -- [15]
				98.59674306317076, -- [16]
				95.03271880768413, -- [17]
				94.77677753946989, -- [18]
				94.8876994542305, -- [19]
				94.8876994542305, -- [20]
				94.8876994542305, -- [21]
				94.59702931327338, -- [22]
				90.97975411958097, -- [23]
				87.47276940659933, -- [24]
				83.85549421290693, -- [25]
				96.23412732657138, -- [26]
				96.23412732657138, -- [27]
				96.23412732657138, -- [28]
				96.23412732657138, -- [29]
				96.34525971934862, -- [30]
				96.34525971934862, -- [31]
				100, -- [32]
				100, -- [33]
				99.56957245600484, -- [34]
				99.56957245600484, -- [35]
				99.14903737879098, -- [36]
				99.14903737879098, -- [37]
				99.25974881553496, -- [38]
				98.83016318360629, -- [39]
				100, -- [40]
				100, -- [41]
				100, -- [42]
				100, -- [43]
				100, -- [44]
				100, -- [45]
				100, -- [46]
				100, -- [47]
				100, -- [48]
				100, -- [49]
				100, -- [50]
			},
			["LastEvents"] = {
				"No One Concentrated Irresistible Cologne Spill Metalica-Jubei'Thos Absorb (2137 Absorbed) (Nature)", -- [1]
				"Metalica-Jubei'Thos Melee Apothecary Frye Parry", -- [2]
				"Metalica-Jubei'Thos Mangle Apothecary Frye Hit -25298 (Physical)", -- [3]
				"Metalica-Jubei'Thos Lacerate (DoT) Apothecary Frye Tick -7152 (Physical)", -- [4]
				"Metalica-Jubei'Thos Lacerate Apothecary Frye Crit -38231 (Physical)", -- [5]
				"Metalica-Jubei'Thos Leader of the Pack Metalica-Jubei'Thos Tick +19004 (19004 overheal)", -- [6]
				"Metalica-Jubei'Thos Melee Apothecary Frye Crit -18576 (Physical)", -- [7]
				"Metalica-Jubei'Thos Maul Apothecary Frye Hit -11768 (Physical)", -- [8]
				"Metalica-Jubei'Thos Lacerate (DoT) Apothecary Frye Tick -7152 (Physical)", -- [9]
				"Metalica-Jubei'Thos Melee Apothecary Frye Hit -9354 (Physical)", -- [10]
				"Tanklord-Tichondrius Prayer of Healing Metalica-Jubei'Thos Hit +30785 (30785 overheal)", -- [11]
				"Apothecary Baxter Irresistible Cologne Spray (DoT) Metalica-Jubei'Thos Tick -16932 (Nature)", -- [12]
				"Tanklord-Tichondrius Atonement Metalica-Jubei'Thos Hit +28647", -- [13]
				"Tanklord-Tichondrius Atonement Metalica-Jubei'Thos Hit +970", -- [14]
				"Apothecary Baxter Irresistible Cologne Metalica-Jubei'Thos Hit -1231 (Nature)", -- [15]
				"Metalica-Jubei'Thos Lacerate Apothecary Baxter Hit -21905 (Physical)", -- [16]
				"Apothecary Baxter Irresistible Cologne Spray (DoT) Metalica-Jubei'Thos Tick -16933 (Nature)", -- [17]
				"Apothecary Baxter Irresistible Cologne Metalica-Jubei'Thos Hit -1216 (Nature)", -- [18]
				"Apothecary Baxter Melee Metalica-Jubei'Thos Absorb (7722 Absorbed)", -- [19]
				"Metalica-Jubei'Thos Lacerate (DoT) Apothecary Baxter Tick -8195 (Physical)", -- [20]
				"Metalica-Jubei'Thos Melee Apothecary Frye Hit -9356 (Physical)", -- [21]
				"Apothecary Baxter Irresistible Cologne Metalica-Jubei'Thos Hit -1381 (Nature)", -- [22]
				"Apothecary Baxter Irresistible Cologne Spray (DoT) Metalica-Jubei'Thos Tick -17186 (Nature)", -- [23]
				"Apothecary Baxter Irresistible Cologne Spray (DoT) Metalica-Jubei'Thos Tick -17187 (Nature)", -- [24]
				"Apothecary Baxter Irresistible Cologne Spray (DoT) Metalica-Jubei'Thos Tick -17186 (Nature)", -- [25]
				"Tanklord-Tichondrius Flash Heal Metalica-Jubei'Thos Hit +58285", -- [26]
				"Metalica-Jubei'Thos Immobilized Apothecary Frye Immune (Physical)", -- [27]
				"Metalica-Jubei'Thos Melee Apothecary Frye Hit -9323 (Physical)", -- [28]
				"Metalica-Jubei'Thos Mangle Apothecary Frye Parry (Physical)", -- [29]
				"Metalica-Jubei'Thos Melee Apothecary Frye Hit -8635 (Physical)", -- [30]
				"Metalica-Jubei'Thos Lacerate Apothecary Frye Crit -38230 (Physical)", -- [31]
				"Metalica-Jubei'Thos Leader of the Pack Metalica-Jubei'Thos Tick +19004 (2165 overheal)", -- [32]
				"Metalica-Jubei'Thos Maul Apothecary Frye Hit -12655 (Physical)", -- [33]
				"No One Concentrated Irresistible Cologne Spill Metalica-Jubei'Thos Hit -2045 (Nature)", -- [34]
				"Metalica-Jubei'Thos Thrash Apothecary Frye Parry (Physical)", -- [35]
				"No One Concentrated Irresistible Cologne Spill Metalica-Jubei'Thos Hit -1998 (Nature)", -- [36]
				"Metalica-Jubei'Thos Melee Apothecary Frye Hit -9113 (Physical)", -- [37]
				"Metalica-Jubei'Thos Lacerate (DoT) Apothecary Frye Tick -2384 (Physical)", -- [38]
				"No One Concentrated Irresistible Cologne Spill Metalica-Jubei'Thos Hit -2041 (Nature)", -- [39]
				"Tanklord-Tichondrius Prayer of Healing Metalica-Jubei'Thos Hit +32046 (26488 overheal)", -- [40]
				"Metalica-Jubei'Thos Lacerate Apothecary Frye Hit -19115 (Physical)", -- [41]
				"Metalica-Jubei'Thos Melee Apothecary Frye Glancing -7703 (Physical)", -- [42]
				"Metalica-Jubei'Thos Mangle Apothecary Frye Hit -26045 (Physical)", -- [43]
				"Metalica-Jubei'Thos Lacerate (DoT) Apothecary Frye Tick -4768 (Physical)", -- [44]
				"Metalica-Jubei'Thos Melee Apothecary Frye Crit -17299 (Physical)", -- [45]
				"Metalica-Jubei'Thos Leader of the Pack Metalica-Jubei'Thos Tick +19004 (19004 overheal)", -- [46]
				"Metalica-Jubei'Thos Maul Apothecary Frye Crit -24301 (Physical)", -- [47]
				"Metalica-Jubei'Thos Melee Apothecary Frye Hit -8469 (Physical)", -- [48]
				"Metalica-Jubei'Thos Lacerate (DoT) Apothecary Frye Tick -4768 (Physical)", -- [49]
				"Metalica-Jubei'Thos Lacerate Apothecary Frye Hit -19115 (Physical)", -- [50]
			},
			["Name"] = "Metalica-Jubei'Thos",
			["LastEventIncoming"] = {
				true, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				true, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				true, -- [11]
				true, -- [12]
				true, -- [13]
				true, -- [14]
				true, -- [15]
				false, -- [16]
				true, -- [17]
				true, -- [18]
				true, -- [19]
				false, -- [20]
				false, -- [21]
				true, -- [22]
				true, -- [23]
				true, -- [24]
				true, -- [25]
				true, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				true, -- [32]
				false, -- [33]
				true, -- [34]
				false, -- [35]
				true, -- [36]
				false, -- [37]
				false, -- [38]
				true, -- [39]
				true, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				true, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				19796.711, -- [1]
				19797.853, -- [2]
				19797.909, -- [3]
				19799.034, -- [4]
				19799.52, -- [5]
				19799.914, -- [6]
				19800.043, -- [7]
				19800.335, -- [8]
				19802.019, -- [9]
				19802.267, -- [10]
				19803.136, -- [11]
				19777.736, -- [12]
				19778.158, -- [13]
				19778.158, -- [14]
				19778.158, -- [15]
				19778.559, -- [16]
				19778.746, -- [17]
				19778.958, -- [18]
				19779.74, -- [19]
				19779.779, -- [20]
				19780.131, -- [21]
				19780.177, -- [22]
				19780.79, -- [23]
				19781.775, -- [24]
				19782.767, -- [25]
				19784.21, -- [26]
				19784.714, -- [27]
				19785.327, -- [28]
				19785.369, -- [29]
				19787.017, -- [30]
				19787.017, -- [31]
				19787.425, -- [32]
				19787.827, -- [33]
				19788.229, -- [34]
				19788.844, -- [35]
				19789.033, -- [36]
				19789.36, -- [37]
				19790.025, -- [38]
				19790.249, -- [39]
				19790.249, -- [40]
				19791.064, -- [41]
				19791.254, -- [42]
				19792.255, -- [43]
				19793.024, -- [44]
				19793.437, -- [45]
				19793.886, -- [46]
				19793.886, -- [47]
				19795.671, -- [48]
				19796.02, -- [49]
				19796.286, -- [50]
			},
			["Fights"] = {
				["Fight2"] = {
					["DamagedWho"] = {
						["Frantic Geist"] = {
							["Details"] = {
								["Moonfire"] = {
									["count"] = 19093,
								},
							},
							["amount"] = 19093,
						},
						["Corpse Eater"] = {
							["Details"] = {
								["Moonfire"] = {
									["count"] = 4671,
								},
							},
							["amount"] = 4671,
						},
					},
					["Attacks"] = {
						["Moonfire"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 4797,
									["min"] = 4671,
									["count"] = 5,
									["amount"] = 23764,
								},
							},
							["count"] = 5,
							["amount"] = 23764,
						},
					},
					["ElementHitsDone"] = {
						["Arcane"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 5,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 24,
								},
							},
							["amount"] = 24,
						},
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 7,
								},
							},
							["amount"] = 7,
						},
					},
					["WhoHealed"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 18277,
								},
							},
							["amount"] = 18277,
						},
					},
					["ElementDone"] = {
						["Arcane"] = 23764,
					},
					["PartialResist"] = {
						["Consume Flesh"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 24,
									["amount"] = 0,
								},
							},
							["count"] = 24,
							["amount"] = 0,
						},
						["Slashing Claws"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 18277,
					["PartialAbsorb"] = {
						["Consume Flesh"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 24,
									["amount"] = 0,
								},
							},
							["count"] = 24,
							["amount"] = 0,
						},
						["Slashing Claws"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 15.62,
					["TimeDamaging"] = {
						["Frantic Geist"] = {
							["Details"] = {
								["Moonfire"] = {
									["count"] = 12.12,
								},
							},
							["amount"] = 12.12,
						},
						["Corpse Eater"] = {
							["Details"] = {
								["Moonfire"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["TimeSpent"] = {
						["Frantic Geist"] = {
							["Details"] = {
								["Moonfire"] = {
									["count"] = 12.12,
								},
							},
							["amount"] = 12.12,
						},
						["Corpse Eater"] = {
							["Details"] = {
								["Moonfire"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["ActiveTime"] = 15.62,
					["Damage"] = 23764,
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
						["Thrash (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 24,
								},
								["Apothecary Hummel"] = {
									["count"] = 48,
								},
								["Apothecary Baxter"] = {
									["count"] = 60,
								},
							},
							["amount"] = 132,
						},
						["Lacerate (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 15,
								},
								["Apothecary Hummel"] = {
									["count"] = 42,
								},
								["Apothecary Baxter"] = {
									["count"] = 33,
								},
							},
							["amount"] = 90,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 1107213,
					["RageGainedFrom"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Mangle"] = {
									["count"] = 95,
								},
								["Bear Form"] = {
									["count"] = 20,
								},
								["Primal Fury"] = {
									["count"] = 315,
								},
							},
							["amount"] = 430,
						},
					},
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 6,
								},
								["Dodge"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 11,
								},
							},
							["amount"] = 19,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 31,
								},
								["Tick"] = {
									["count"] = 45,
								},
								["Hit"] = {
									["count"] = 70,
								},
							},
							["amount"] = 146,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 33,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 7,
								},
								["Hit"] = {
									["count"] = 19,
								},
								["Miss"] = {
									["count"] = 4,
								},
								["Crit"] = {
									["count"] = 11,
								},
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 42,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 54,
								},
								["Tick"] = {
									["count"] = 57,
								},
								["Crit"] = {
									["count"] = 36,
								},
								["Parry"] = {
									["count"] = 4,
								},
							},
							["amount"] = 152,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 42739,
						["Nature"] = 200830,
					},
					["ElementTaken"] = {
						["Fire"] = 135502,
						["Melee"] = 65525,
						["Nature"] = 906186,
					},
					["DOT_Time"] = 222,
					["Damage"] = 2761274,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 3.74,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 429875,
						["Physical"] = 2331399,
					},
					["PartialAbsorb"] = {
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 2137,
									["min"] = 2137,
									["count"] = 1,
									["amount"] = 2137,
								},
							},
							["count"] = 1,
							["amount"] = 2137,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 12,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 7722,
									["min"] = 2600,
									["count"] = 7,
									["amount"] = 42739,
								},
							},
							["count"] = 19,
							["amount"] = 42739,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 44,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1482,
									["min"] = 1259,
									["count"] = 13,
									["amount"] = 17923,
								},
							},
							["count"] = 57,
							["amount"] = 17923,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 17,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 4772,
									["min"] = 4772,
									["count"] = 1,
									["amount"] = 4772,
								},
							},
							["count"] = 18,
							["amount"] = 4772,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 24,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1966,
									["min"] = 3,
									["count"] = 3,
									["amount"] = 2398,
								},
							},
							["count"] = 27,
							["amount"] = 2398,
						},
						["Alluring Perfume Spray"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 18010,
									["min"] = 18009,
									["count"] = 3,
									["amount"] = 54028,
								},
							},
							["count"] = 3,
							["amount"] = 54028,
						},
						["Alluring Perfume"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 26,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1461,
									["min"] = 1232,
									["count"] = 8,
									["amount"] = 10793,
								},
							},
							["count"] = 34,
							["amount"] = 10793,
						},
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 19271,
									["min"] = 17334,
									["count"] = 6,
									["amount"] = 108779,
								},
							},
							["count"] = 6,
							["amount"] = 108779,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Maul"] = {
									["count"] = 65630,
								},
								["Thrash (DoT)"] = {
									["count"] = 73224,
								},
								["Melee"] = {
									["count"] = 97828,
								},
								["Lacerate"] = {
									["count"] = 114691,
								},
								["Thrash"] = {
									["count"] = 22703,
								},
								["Lacerate (DoT)"] = {
									["count"] = 26224,
								},
								["Mangle"] = {
									["count"] = 202543,
								},
								["Swipe"] = {
									["count"] = 14164,
								},
							},
							["amount"] = 617007,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Mangle"] = {
									["count"] = 364843,
								},
								["Thrash (DoT)"] = {
									["count"] = 150432,
								},
								["Melee"] = {
									["count"] = 68080,
								},
								["Thrash"] = {
									["count"] = 20854,
								},
								["Lacerate"] = {
									["count"] = 75355,
								},
								["Lacerate (DoT)"] = {
									["count"] = 79785,
								},
								["Maul"] = {
									["count"] = 25975,
								},
								["Swipe"] = {
									["count"] = 23566,
								},
							},
							["amount"] = 808890,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Maul"] = {
									["count"] = 86498,
								},
								["Thrash (DoT)"] = {
									["count"] = 198030,
								},
								["Melee"] = {
									["count"] = 263967,
								},
								["Lacerate"] = {
									["count"] = 211648,
								},
								["Mangle"] = {
									["count"] = 436720,
								},
								["Lacerate (DoT)"] = {
									["count"] = 91065,
								},
								["Thrash"] = {
									["count"] = 32018,
								},
								["Swipe"] = {
									["count"] = 15431,
								},
							},
							["amount"] = 1335377,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Apothecary Baxter"] = {
							["Details"] = {
								["Irresistible Cologne"] = {
									["count"] = 59031,
								},
								["Irresistible Cologne Spray (DoT)"] = {
									["count"] = 484465,
								},
								["Melee"] = {
									["count"] = 21590,
								},
								["Chain Reaction"] = {
									["count"] = 135502,
								},
							},
							["amount"] = 700588,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Alluring Perfume"] = {
									["count"] = 34850,
								},
								["Alluring Perfume Spray (DoT)"] = {
									["count"] = 327840,
								},
								["Melee"] = {
									["count"] = 43935,
								},
							},
							["amount"] = 406625,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 19,
									["amount"] = 0,
								},
							},
							["count"] = 19,
							["amount"] = 0,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 57,
									["amount"] = 0,
								},
							},
							["count"] = 57,
							["amount"] = 0,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 18,
									["amount"] = 0,
								},
							},
							["count"] = 18,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 27,
									["amount"] = 0,
								},
							},
							["count"] = 27,
							["amount"] = 0,
						},
						["Alluring Perfume Spray"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Alluring Perfume"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 34,
									["amount"] = 0,
								},
							},
							["count"] = 34,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
						["Melee"] = 2544,
						["Physical"] = 6769,
					},
					["TimeHealing"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Leader of the Pack"] = {
									["count"] = 3.74,
								},
							},
							["amount"] = 3.74,
						},
					},
					["OverHeals"] = {
						["Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 19004,
									["min"] = 1780,
									["count"] = 5,
									["amount"] = 60957,
								},
							},
							["count"] = 5,
							["amount"] = 60957,
						},
					},
					["ManaGainedFrom"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Leader of the Pack"] = {
									["count"] = 52800,
								},
								["Innervate"] = {
									["count"] = 12000,
								},
							},
							["amount"] = 64800,
						},
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
						["Mangle"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["count"] = 95,
								},
							},
							["amount"] = 95,
						},
						["Bear Form"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
						["Primal Fury"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["count"] = 315,
								},
							},
							["amount"] = 315,
						},
					},
					["HealedWho"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Leader of the Pack"] = {
									["count"] = 148090,
								},
							},
							["amount"] = 148090,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
						["Leader of the Pack"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["count"] = 52800,
								},
							},
							["amount"] = 52800,
						},
						["Innervate"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["count"] = 12000,
								},
							},
							["amount"] = 12000,
						},
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 60957,
					["TimeSpent"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Leader of the Pack"] = {
									["count"] = 3.74,
								},
							},
							["amount"] = 3.74,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Mangle"] = {
									["count"] = 5.81,
								},
								["Thrash (DoT)"] = {
									["count"] = 2.69,
								},
								["Melee"] = {
									["count"] = 8.380000000000001,
								},
								["Thrash"] = {
									["count"] = 0,
								},
								["Lacerate"] = {
									["count"] = 2.24,
								},
								["Lacerate (DoT)"] = {
									["count"] = 4.819999999999999,
								},
								["Maul"] = {
									["count"] = 1.61,
								},
								["Swipe"] = {
									["count"] = 0,
								},
							},
							["amount"] = 25.55,
						},
						["Apothecary Frye"] = {
							["Details"] = {
								["Thrash (DoT)"] = {
									["count"] = 0.66,
								},
								["Melee"] = {
									["count"] = 7.859999999999999,
								},
								["Lacerate"] = {
									["count"] = 1.8,
								},
								["Mangle"] = {
									["count"] = 1.29,
								},
								["Immobilized"] = {
									["count"] = 3.5,
								},
								["Thrash"] = {
									["count"] = 2.81,
								},
								["Lacerate (DoT)"] = {
									["count"] = 4.6,
								},
								["Maul"] = {
									["count"] = 2.24,
								},
								["Swipe"] = {
									["count"] = 1.32,
								},
							},
							["amount"] = 26.07999999999999,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Maul"] = {
									["count"] = 3.27,
								},
								["Thrash (DoT)"] = {
									["count"] = 6.55,
								},
								["Melee"] = {
									["count"] = 15.83,
								},
								["Lacerate"] = {
									["count"] = 4.86,
								},
								["Mangle"] = {
									["count"] = 3.55,
								},
								["Lacerate (DoT)"] = {
									["count"] = 6.44,
								},
								["Thrash"] = {
									["count"] = 1.21,
								},
								["Swipe"] = {
									["count"] = 0,
								},
							},
							["amount"] = 41.70999999999999,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 19005,
									["min"] = 16839,
									["count"] = 8,
									["amount"] = 148090,
								},
							},
							["count"] = 8,
							["amount"] = 148090,
						},
					},
					["WhoHealed"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Leader of the Pack"] = {
									["count"] = 148090,
								},
							},
							["amount"] = 148090,
						},
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 67084,
								},
								["Flash Heal"] = {
									["count"] = 386532,
								},
								["Halo"] = {
									["count"] = 20662,
								},
								["Atonement"] = {
									["count"] = 223489,
								},
								["Penance"] = {
									["count"] = 244944,
								},
							},
							["amount"] = 942711,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 97.08000000000001,
					["Healing"] = 148090,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Thrash (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 16535,
									["min"] = 13021,
									["count"] = 11,
									["amount"] = 171330,
								},
								["Tick"] = {
									["max"] = 8268,
									["min"] = 6510,
									["count"] = 33,
									["amount"] = 250356,
								},
							},
							["count"] = 44,
							["amount"] = 421686,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 8956,
									["min"] = 6893,
									["count"] = 6,
									["amount"] = 45439,
								},
								["Hit"] = {
									["max"] = 10182,
									["min"] = 5891,
									["count"] = 19,
									["amount"] = 170684,
								},
								["Miss"] = {
									["count"] = 4,
									["amount"] = 0,
								},
								["Glancing (Blocked)"] = {
									["max"] = 5936,
									["min"] = 5936,
									["count"] = 1,
									["amount"] = 5936,
								},
								["Crit"] = {
									["max"] = 21470,
									["min"] = 14984,
									["count"] = 11,
									["amount"] = 207816,
								},
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 42,
							["amount"] = 429875,
						},
						["Lacerate"] = {
							["Details"] = {
								["Hit (Blocked)"] = {
									["max"] = 15794,
									["min"] = 15794,
									["count"] = 1,
									["amount"] = 15794,
								},
								["Crit"] = {
									["max"] = 43766,
									["min"] = 21004,
									["count"] = 5,
									["amount"] = 183382,
								},
								["Hit"] = {
									["max"] = 23492,
									["min"] = 14841,
									["count"] = 10,
									["amount"] = 202518,
								},
							},
							["count"] = 16,
							["amount"] = 401694,
						},
						["Immobilized"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Mangle"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 54829,
									["min"] = 45016,
									["count"] = 10,
									["amount"] = 515733,
								},
								["Hit"] = {
									["max"] = 29600,
									["min"] = 17191,
									["count"] = 20,
									["amount"] = 488373,
								},
							},
							["count"] = 31,
							["amount"] = 1004106,
						},
						["Maul"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 24301,
									["min"] = 20513,
									["count"] = 2,
									["amount"] = 44814,
								},
								["Hit"] = {
									["max"] = 13434,
									["min"] = 5128,
									["count"] = 13,
									["amount"] = 133289,
								},
							},
							["count"] = 16,
							["amount"] = 178103,
						},
						["Lacerate (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 15769,
									["min"] = 5628,
									["count"] = 6,
									["amount"] = 59629,
								},
								["Tick"] = {
									["max"] = 8789,
									["min"] = 1363,
									["count"] = 24,
									["amount"] = 137445,
								},
							},
							["count"] = 30,
							["amount"] = 197074,
						},
						["Thrash"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 11529,
									["min"] = 9137,
									["count"] = 5,
									["amount"] = 52872,
								},
								["Crit"] = {
									["max"] = 22703,
									["min"] = 22703,
									["count"] = 1,
									["amount"] = 22703,
								},
								["Parry"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 75575,
						},
						["Swipe"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 15663,
									["min"] = 15663,
									["count"] = 1,
									["amount"] = 15663,
								},
								["Hit"] = {
									["max"] = 7903,
									["min"] = 6333,
									["count"] = 5,
									["amount"] = 37498,
								},
							},
							["count"] = 6,
							["amount"] = 53161,
						},
					},
					["HealingTaken"] = 1090801,
					["RageGain"] = 430,
					["TimeDamage"] = 93.34000000000002,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Thrash (DoT)"] = {
									["count"] = 0.66,
								},
								["Melee"] = {
									["count"] = 7.859999999999999,
								},
								["Lacerate"] = {
									["count"] = 1.8,
								},
								["Mangle"] = {
									["count"] = 1.29,
								},
								["Immobilized"] = {
									["count"] = 3.5,
								},
								["Thrash"] = {
									["count"] = 2.81,
								},
								["Lacerate (DoT)"] = {
									["count"] = 4.6,
								},
								["Maul"] = {
									["count"] = 2.24,
								},
								["Swipe"] = {
									["count"] = 1.32,
								},
							},
							["amount"] = 26.07999999999999,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Mangle"] = {
									["count"] = 5.81,
								},
								["Thrash (DoT)"] = {
									["count"] = 2.69,
								},
								["Melee"] = {
									["count"] = 8.380000000000001,
								},
								["Thrash"] = {
									["count"] = 0,
								},
								["Lacerate"] = {
									["count"] = 2.24,
								},
								["Lacerate (DoT)"] = {
									["count"] = 4.819999999999999,
								},
								["Maul"] = {
									["count"] = 1.61,
								},
								["Swipe"] = {
									["count"] = 0,
								},
							},
							["amount"] = 25.55,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Maul"] = {
									["count"] = 3.27,
								},
								["Thrash (DoT)"] = {
									["count"] = 6.55,
								},
								["Melee"] = {
									["count"] = 15.83,
								},
								["Lacerate"] = {
									["count"] = 4.86,
								},
								["Mangle"] = {
									["count"] = 3.55,
								},
								["Lacerate (DoT)"] = {
									["count"] = 6.44,
								},
								["Thrash"] = {
									["count"] = 1.21,
								},
								["Swipe"] = {
									["count"] = 0,
								},
							},
							["amount"] = 41.70999999999999,
						},
					},
					["ManaGain"] = 64800,
					["HOTs"] = {
						["Leader of the Pack"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["count"] = 33,
								},
							},
							["amount"] = 33,
						},
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["DOTs"] = {
						["Thrash (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 24,
								},
								["Apothecary Hummel"] = {
									["count"] = 48,
								},
								["Apothecary Baxter"] = {
									["count"] = 60,
								},
							},
							["amount"] = 132,
						},
						["Lacerate (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 15,
								},
								["Apothecary Hummel"] = {
									["count"] = 42,
								},
								["Apothecary Baxter"] = {
									["count"] = 33,
								},
							},
							["amount"] = 90,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 1107213,
					["RageGainedFrom"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Mangle"] = {
									["count"] = 95,
								},
								["Bear Form"] = {
									["count"] = 20,
								},
								["Primal Fury"] = {
									["count"] = 315,
								},
							},
							["amount"] = 430,
						},
					},
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 6,
								},
								["Dodge"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 11,
								},
							},
							["amount"] = 19,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 31,
								},
								["Tick"] = {
									["count"] = 45,
								},
								["Hit"] = {
									["count"] = 70,
								},
							},
							["amount"] = 146,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 33,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 7,
								},
								["Hit"] = {
									["count"] = 19,
								},
								["Miss"] = {
									["count"] = 4,
								},
								["Crit"] = {
									["count"] = 11,
								},
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 42,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 54,
								},
								["Tick"] = {
									["count"] = 57,
								},
								["Crit"] = {
									["count"] = 36,
								},
								["Parry"] = {
									["count"] = 4,
								},
							},
							["amount"] = 152,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 42739,
						["Nature"] = 200830,
					},
					["ElementTaken"] = {
						["Fire"] = 135502,
						["Melee"] = 65525,
						["Nature"] = 906186,
					},
					["DOT_Time"] = 222,
					["Damage"] = 2761274,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 3.74,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 429875,
						["Physical"] = 2331399,
					},
					["PartialAbsorb"] = {
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 2137,
									["min"] = 2137,
									["count"] = 1,
									["amount"] = 2137,
								},
							},
							["count"] = 1,
							["amount"] = 2137,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 12,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 7722,
									["min"] = 2600,
									["count"] = 7,
									["amount"] = 42739,
								},
							},
							["count"] = 19,
							["amount"] = 42739,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 44,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1482,
									["min"] = 1259,
									["count"] = 13,
									["amount"] = 17923,
								},
							},
							["count"] = 57,
							["amount"] = 17923,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 17,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 4772,
									["min"] = 4772,
									["count"] = 1,
									["amount"] = 4772,
								},
							},
							["count"] = 18,
							["amount"] = 4772,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 24,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1966,
									["min"] = 3,
									["count"] = 3,
									["amount"] = 2398,
								},
							},
							["count"] = 27,
							["amount"] = 2398,
						},
						["Alluring Perfume Spray"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 18010,
									["min"] = 18009,
									["count"] = 3,
									["amount"] = 54028,
								},
							},
							["count"] = 3,
							["amount"] = 54028,
						},
						["Alluring Perfume"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 26,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1461,
									["min"] = 1232,
									["count"] = 8,
									["amount"] = 10793,
								},
							},
							["count"] = 34,
							["amount"] = 10793,
						},
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 19271,
									["min"] = 17334,
									["count"] = 6,
									["amount"] = 108779,
								},
							},
							["count"] = 6,
							["amount"] = 108779,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Maul"] = {
									["count"] = 65630,
								},
								["Thrash (DoT)"] = {
									["count"] = 73224,
								},
								["Melee"] = {
									["count"] = 97828,
								},
								["Lacerate"] = {
									["count"] = 114691,
								},
								["Thrash"] = {
									["count"] = 22703,
								},
								["Lacerate (DoT)"] = {
									["count"] = 26224,
								},
								["Mangle"] = {
									["count"] = 202543,
								},
								["Swipe"] = {
									["count"] = 14164,
								},
							},
							["amount"] = 617007,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Mangle"] = {
									["count"] = 364843,
								},
								["Thrash (DoT)"] = {
									["count"] = 150432,
								},
								["Melee"] = {
									["count"] = 68080,
								},
								["Thrash"] = {
									["count"] = 20854,
								},
								["Lacerate"] = {
									["count"] = 75355,
								},
								["Lacerate (DoT)"] = {
									["count"] = 79785,
								},
								["Maul"] = {
									["count"] = 25975,
								},
								["Swipe"] = {
									["count"] = 23566,
								},
							},
							["amount"] = 808890,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Maul"] = {
									["count"] = 86498,
								},
								["Thrash (DoT)"] = {
									["count"] = 198030,
								},
								["Melee"] = {
									["count"] = 263967,
								},
								["Lacerate"] = {
									["count"] = 211648,
								},
								["Mangle"] = {
									["count"] = 436720,
								},
								["Lacerate (DoT)"] = {
									["count"] = 91065,
								},
								["Thrash"] = {
									["count"] = 32018,
								},
								["Swipe"] = {
									["count"] = 15431,
								},
							},
							["amount"] = 1335377,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Apothecary Baxter"] = {
							["Details"] = {
								["Irresistible Cologne"] = {
									["count"] = 59031,
								},
								["Irresistible Cologne Spray (DoT)"] = {
									["count"] = 484465,
								},
								["Melee"] = {
									["count"] = 21590,
								},
								["Chain Reaction"] = {
									["count"] = 135502,
								},
							},
							["amount"] = 700588,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Alluring Perfume"] = {
									["count"] = 34850,
								},
								["Alluring Perfume Spray (DoT)"] = {
									["count"] = 327840,
								},
								["Melee"] = {
									["count"] = 43935,
								},
							},
							["amount"] = 406625,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 19,
									["amount"] = 0,
								},
							},
							["count"] = 19,
							["amount"] = 0,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 57,
									["amount"] = 0,
								},
							},
							["count"] = 57,
							["amount"] = 0,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 18,
									["amount"] = 0,
								},
							},
							["count"] = 18,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 27,
									["amount"] = 0,
								},
							},
							["count"] = 27,
							["amount"] = 0,
						},
						["Alluring Perfume Spray"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Alluring Perfume"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 34,
									["amount"] = 0,
								},
							},
							["count"] = 34,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
						["Melee"] = 2544,
						["Physical"] = 6769,
					},
					["TimeHealing"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Leader of the Pack"] = {
									["count"] = 3.74,
								},
							},
							["amount"] = 3.74,
						},
					},
					["OverHeals"] = {
						["Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 19004,
									["min"] = 1780,
									["count"] = 5,
									["amount"] = 60957,
								},
							},
							["count"] = 5,
							["amount"] = 60957,
						},
					},
					["ManaGainedFrom"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Leader of the Pack"] = {
									["count"] = 52800,
								},
								["Innervate"] = {
									["count"] = 12000,
								},
							},
							["amount"] = 64800,
						},
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
						["Mangle"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["count"] = 95,
								},
							},
							["amount"] = 95,
						},
						["Bear Form"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
						["Primal Fury"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["count"] = 315,
								},
							},
							["amount"] = 315,
						},
					},
					["HealedWho"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Leader of the Pack"] = {
									["count"] = 148090,
								},
							},
							["amount"] = 148090,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
						["Leader of the Pack"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["count"] = 52800,
								},
							},
							["amount"] = 52800,
						},
						["Innervate"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["count"] = 12000,
								},
							},
							["amount"] = 12000,
						},
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 60957,
					["TimeSpent"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Leader of the Pack"] = {
									["count"] = 3.74,
								},
							},
							["amount"] = 3.74,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Mangle"] = {
									["count"] = 5.81,
								},
								["Thrash (DoT)"] = {
									["count"] = 2.69,
								},
								["Melee"] = {
									["count"] = 8.380000000000001,
								},
								["Thrash"] = {
									["count"] = 0,
								},
								["Lacerate"] = {
									["count"] = 2.24,
								},
								["Lacerate (DoT)"] = {
									["count"] = 4.819999999999999,
								},
								["Maul"] = {
									["count"] = 1.61,
								},
								["Swipe"] = {
									["count"] = 0,
								},
							},
							["amount"] = 25.55,
						},
						["Apothecary Frye"] = {
							["Details"] = {
								["Thrash (DoT)"] = {
									["count"] = 0.66,
								},
								["Melee"] = {
									["count"] = 7.859999999999999,
								},
								["Lacerate"] = {
									["count"] = 1.8,
								},
								["Mangle"] = {
									["count"] = 1.29,
								},
								["Immobilized"] = {
									["count"] = 3.5,
								},
								["Thrash"] = {
									["count"] = 2.81,
								},
								["Lacerate (DoT)"] = {
									["count"] = 4.6,
								},
								["Maul"] = {
									["count"] = 2.24,
								},
								["Swipe"] = {
									["count"] = 1.32,
								},
							},
							["amount"] = 26.07999999999999,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Maul"] = {
									["count"] = 3.27,
								},
								["Thrash (DoT)"] = {
									["count"] = 6.55,
								},
								["Melee"] = {
									["count"] = 15.83,
								},
								["Lacerate"] = {
									["count"] = 4.86,
								},
								["Mangle"] = {
									["count"] = 3.55,
								},
								["Lacerate (DoT)"] = {
									["count"] = 6.44,
								},
								["Thrash"] = {
									["count"] = 1.21,
								},
								["Swipe"] = {
									["count"] = 0,
								},
							},
							["amount"] = 41.70999999999999,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 19005,
									["min"] = 16839,
									["count"] = 8,
									["amount"] = 148090,
								},
							},
							["count"] = 8,
							["amount"] = 148090,
						},
					},
					["WhoHealed"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Leader of the Pack"] = {
									["count"] = 148090,
								},
							},
							["amount"] = 148090,
						},
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Prayer of Healing"] = {
									["count"] = 67084,
								},
								["Flash Heal"] = {
									["count"] = 386532,
								},
								["Halo"] = {
									["count"] = 20662,
								},
								["Atonement"] = {
									["count"] = 223489,
								},
								["Penance"] = {
									["count"] = 244944,
								},
							},
							["amount"] = 942711,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 97.08000000000001,
					["Healing"] = 148090,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Thrash (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 16535,
									["min"] = 13021,
									["count"] = 11,
									["amount"] = 171330,
								},
								["Tick"] = {
									["max"] = 8268,
									["min"] = 6510,
									["count"] = 33,
									["amount"] = 250356,
								},
							},
							["count"] = 44,
							["amount"] = 421686,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 8956,
									["min"] = 6893,
									["count"] = 6,
									["amount"] = 45439,
								},
								["Hit"] = {
									["max"] = 10182,
									["min"] = 5891,
									["count"] = 19,
									["amount"] = 170684,
								},
								["Miss"] = {
									["count"] = 4,
									["amount"] = 0,
								},
								["Glancing (Blocked)"] = {
									["max"] = 5936,
									["min"] = 5936,
									["count"] = 1,
									["amount"] = 5936,
								},
								["Crit"] = {
									["max"] = 21470,
									["min"] = 14984,
									["count"] = 11,
									["amount"] = 207816,
								},
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 42,
							["amount"] = 429875,
						},
						["Lacerate"] = {
							["Details"] = {
								["Hit (Blocked)"] = {
									["max"] = 15794,
									["min"] = 15794,
									["count"] = 1,
									["amount"] = 15794,
								},
								["Crit"] = {
									["max"] = 43766,
									["min"] = 21004,
									["count"] = 5,
									["amount"] = 183382,
								},
								["Hit"] = {
									["max"] = 23492,
									["min"] = 14841,
									["count"] = 10,
									["amount"] = 202518,
								},
							},
							["count"] = 16,
							["amount"] = 401694,
						},
						["Immobilized"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Mangle"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 54829,
									["min"] = 45016,
									["count"] = 10,
									["amount"] = 515733,
								},
								["Hit"] = {
									["max"] = 29600,
									["min"] = 17191,
									["count"] = 20,
									["amount"] = 488373,
								},
							},
							["count"] = 31,
							["amount"] = 1004106,
						},
						["Maul"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 24301,
									["min"] = 20513,
									["count"] = 2,
									["amount"] = 44814,
								},
								["Hit"] = {
									["max"] = 13434,
									["min"] = 5128,
									["count"] = 13,
									["amount"] = 133289,
								},
							},
							["count"] = 16,
							["amount"] = 178103,
						},
						["Lacerate (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 15769,
									["min"] = 5628,
									["count"] = 6,
									["amount"] = 59629,
								},
								["Tick"] = {
									["max"] = 8789,
									["min"] = 1363,
									["count"] = 24,
									["amount"] = 137445,
								},
							},
							["count"] = 30,
							["amount"] = 197074,
						},
						["Thrash"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 11529,
									["min"] = 9137,
									["count"] = 5,
									["amount"] = 52872,
								},
								["Crit"] = {
									["max"] = 22703,
									["min"] = 22703,
									["count"] = 1,
									["amount"] = 22703,
								},
								["Parry"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 75575,
						},
						["Swipe"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 15663,
									["min"] = 15663,
									["count"] = 1,
									["amount"] = 15663,
								},
								["Hit"] = {
									["max"] = 7903,
									["min"] = 6333,
									["count"] = 5,
									["amount"] = 37498,
								},
							},
							["count"] = 6,
							["amount"] = 53161,
						},
					},
					["HealingTaken"] = 1090801,
					["RageGain"] = 430,
					["TimeDamage"] = 93.34000000000002,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Thrash (DoT)"] = {
									["count"] = 0.66,
								},
								["Melee"] = {
									["count"] = 7.859999999999999,
								},
								["Lacerate"] = {
									["count"] = 1.8,
								},
								["Mangle"] = {
									["count"] = 1.29,
								},
								["Immobilized"] = {
									["count"] = 3.5,
								},
								["Thrash"] = {
									["count"] = 2.81,
								},
								["Lacerate (DoT)"] = {
									["count"] = 4.6,
								},
								["Maul"] = {
									["count"] = 2.24,
								},
								["Swipe"] = {
									["count"] = 1.32,
								},
							},
							["amount"] = 26.07999999999999,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Mangle"] = {
									["count"] = 5.81,
								},
								["Thrash (DoT)"] = {
									["count"] = 2.69,
								},
								["Melee"] = {
									["count"] = 8.380000000000001,
								},
								["Thrash"] = {
									["count"] = 0,
								},
								["Lacerate"] = {
									["count"] = 2.24,
								},
								["Lacerate (DoT)"] = {
									["count"] = 4.819999999999999,
								},
								["Maul"] = {
									["count"] = 1.61,
								},
								["Swipe"] = {
									["count"] = 0,
								},
							},
							["amount"] = 25.55,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Maul"] = {
									["count"] = 3.27,
								},
								["Thrash (DoT)"] = {
									["count"] = 6.55,
								},
								["Melee"] = {
									["count"] = 15.83,
								},
								["Lacerate"] = {
									["count"] = 4.86,
								},
								["Mangle"] = {
									["count"] = 3.55,
								},
								["Lacerate (DoT)"] = {
									["count"] = 6.44,
								},
								["Thrash"] = {
									["count"] = 1.21,
								},
								["Swipe"] = {
									["count"] = 0,
								},
							},
							["amount"] = 41.70999999999999,
						},
					},
					["ManaGain"] = 64800,
					["HOTs"] = {
						["Leader of the Pack"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["count"] = 33,
								},
							},
							["amount"] = 33,
						},
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["DOTs"] = {
						["Thrash (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 24,
								},
								["Apothecary Hummel"] = {
									["count"] = 48,
								},
								["Apothecary Baxter"] = {
									["count"] = 60,
								},
							},
							["amount"] = 132,
						},
						["Lacerate (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 15,
								},
								["Apothecary Hummel"] = {
									["count"] = 42,
								},
								["Apothecary Baxter"] = {
									["count"] = 33,
								},
							},
							["amount"] = 90,
						},
					},
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 7,
								},
							},
							["amount"] = 7,
						},
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
								},
								["Absorb"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 11,
								},
								["Miss"] = {
									["count"] = 24,
								},
							},
							["amount"] = 43,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 31,
								},
								["Tick"] = {
									["count"] = 45,
								},
								["Hit"] = {
									["count"] = 70,
								},
							},
							["amount"] = 146,
						},
					},
					["DamageTaken"] = 1107213,
					["RageGainedFrom"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Mangle"] = {
									["count"] = 95,
								},
								["Bear Form"] = {
									["count"] = 20,
								},
								["Primal Fury"] = {
									["count"] = 315,
								},
							},
							["amount"] = 430,
						},
					},
					["HOT_Time"] = 33,
					["ElementTaken"] = {
						["Fire"] = 135502,
						["Melee"] = 65525,
						["Nature"] = 906186,
					},
					["HOTs"] = {
						["Leader of the Pack"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["count"] = 33,
								},
							},
							["amount"] = 33,
						},
					},
					["Damage"] = 2785038,
					["TimeHeal"] = 3.74,
					["ElementDone"] = {
						["Physical"] = 2331399,
						["Melee"] = 429875,
						["Arcane"] = 23764,
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 54,
								},
								["Tick"] = {
									["count"] = 57,
								},
								["Crit"] = {
									["count"] = 36,
								},
								["Parry"] = {
									["count"] = 4,
								},
							},
							["amount"] = 152,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["count"] = 7,
								},
								["Hit"] = {
									["count"] = 19,
								},
								["Miss"] = {
									["count"] = 4,
								},
								["Crit"] = {
									["count"] = 11,
								},
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 42,
						},
						["Arcane"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 5,
						},
					},
					["WhoDamaged"] = {
						["Apothecary Baxter"] = {
							["Details"] = {
								["Irresistible Cologne"] = {
									["count"] = 59031,
								},
								["Irresistible Cologne Spray (DoT)"] = {
									["count"] = 484465,
								},
								["Melee"] = {
									["count"] = 21590,
								},
								["Chain Reaction"] = {
									["count"] = 135502,
								},
							},
							["amount"] = 700588,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Alluring Perfume"] = {
									["count"] = 34850,
								},
								["Alluring Perfume Spray (DoT)"] = {
									["count"] = 327840,
								},
								["Melee"] = {
									["count"] = 43935,
								},
							},
							["amount"] = 406625,
						},
					},
					["ElementDoneBlock"] = {
						["Melee"] = 2544,
						["Physical"] = 6769,
					},
					["TimeHealing"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Leader of the Pack"] = {
									["count"] = 3.74,
								},
							},
							["amount"] = 3.74,
						},
					},
					["OverHeals"] = {
						["Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 19004,
									["min"] = 1780,
									["count"] = 5,
									["amount"] = 60957,
								},
							},
							["count"] = 5,
							["amount"] = 60957,
						},
					},
					["PartialResist"] = {
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 43,
									["amount"] = 0,
								},
							},
							["count"] = 43,
							["amount"] = 0,
						},
						["Slashing Claws"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 57,
									["amount"] = 0,
								},
							},
							["count"] = 57,
							["amount"] = 0,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 18,
									["amount"] = 0,
								},
							},
							["count"] = 18,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 27,
									["amount"] = 0,
								},
							},
							["count"] = 27,
							["amount"] = 0,
						},
						["Alluring Perfume Spray"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 0,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Consume Flesh"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Alluring Perfume"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 34,
									["amount"] = 0,
								},
							},
							["count"] = 34,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
						["Leader of the Pack"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["count"] = 52800,
								},
							},
							["amount"] = 52800,
						},
						["Innervate"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["count"] = 12000,
								},
							},
							["amount"] = 12000,
						},
					},
					["PartialAbsorb"] = {
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 2137,
									["min"] = 2137,
									["count"] = 1,
									["amount"] = 2137,
								},
							},
							["count"] = 1,
							["amount"] = 2137,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 36,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 7722,
									["min"] = 2600,
									["count"] = 7,
									["amount"] = 42739,
								},
							},
							["count"] = 43,
							["amount"] = 42739,
						},
						["Slashing Claws"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 44,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1482,
									["min"] = 1259,
									["count"] = 13,
									["amount"] = 17923,
								},
							},
							["count"] = 57,
							["amount"] = 17923,
						},
						["Alluring Perfume Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 17,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 4772,
									["min"] = 4772,
									["count"] = 1,
									["amount"] = 4772,
								},
							},
							["count"] = 18,
							["amount"] = 4772,
						},
						["Irresistible Cologne Spray (DoT)"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 24,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1966,
									["min"] = 3,
									["count"] = 3,
									["amount"] = 2398,
								},
							},
							["count"] = 27,
							["amount"] = 2398,
						},
						["Alluring Perfume Spray"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 18010,
									["min"] = 18009,
									["count"] = 3,
									["amount"] = 54028,
								},
							},
							["count"] = 3,
							["amount"] = 54028,
						},
						["Irresistible Cologne Spray"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 19271,
									["min"] = 17334,
									["count"] = 6,
									["amount"] = 108779,
								},
							},
							["count"] = 6,
							["amount"] = 108779,
						},
						["Chain Reaction"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Consume Flesh"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Alluring Perfume"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 26,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 1461,
									["min"] = 1232,
									["count"] = 8,
									["amount"] = 10793,
								},
							},
							["count"] = 34,
							["amount"] = 10793,
						},
					},
					["ActiveTime"] = 112.7,
					["ElementTakenAbsorb"] = {
						["Melee"] = 42739,
						["Nature"] = 200830,
					},
					["DOT_Time"] = 222,
					["Heals"] = {
						["Leader of the Pack"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 19005,
									["min"] = 16839,
									["count"] = 8,
									["amount"] = 148090,
								},
							},
							["count"] = 8,
							["amount"] = 148090,
						},
					},
					["Overhealing"] = 60957,
					["HealedWho"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Leader of the Pack"] = {
									["count"] = 148090,
								},
							},
							["amount"] = 148090,
						},
					},
					["TimeSpent"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Leader of the Pack"] = {
									["count"] = 3.74,
								},
							},
							["amount"] = 3.74,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Mangle"] = {
									["count"] = 5.81,
								},
								["Thrash (DoT)"] = {
									["count"] = 2.69,
								},
								["Melee"] = {
									["count"] = 8.380000000000001,
								},
								["Thrash"] = {
									["count"] = 0,
								},
								["Lacerate"] = {
									["count"] = 2.24,
								},
								["Lacerate (DoT)"] = {
									["count"] = 4.819999999999999,
								},
								["Maul"] = {
									["count"] = 1.61,
								},
								["Swipe"] = {
									["count"] = 0,
								},
							},
							["amount"] = 25.55,
						},
						["Corpse Eater"] = {
							["Details"] = {
								["Moonfire"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Apothecary Frye"] = {
							["Details"] = {
								["Thrash (DoT)"] = {
									["count"] = 0.66,
								},
								["Melee"] = {
									["count"] = 7.859999999999999,
								},
								["Lacerate"] = {
									["count"] = 1.8,
								},
								["Mangle"] = {
									["count"] = 1.29,
								},
								["Immobilized"] = {
									["count"] = 3.5,
								},
								["Thrash"] = {
									["count"] = 2.81,
								},
								["Lacerate (DoT)"] = {
									["count"] = 4.6,
								},
								["Maul"] = {
									["count"] = 2.24,
								},
								["Swipe"] = {
									["count"] = 1.32,
								},
							},
							["amount"] = 26.07999999999999,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Moonfire"] = {
									["count"] = 12.12,
								},
							},
							["amount"] = 12.12,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Maul"] = {
									["count"] = 3.27,
								},
								["Thrash (DoT)"] = {
									["count"] = 6.55,
								},
								["Melee"] = {
									["count"] = 15.83,
								},
								["Lacerate"] = {
									["count"] = 4.86,
								},
								["Mangle"] = {
									["count"] = 3.55,
								},
								["Lacerate (DoT)"] = {
									["count"] = 6.44,
								},
								["Thrash"] = {
									["count"] = 1.21,
								},
								["Swipe"] = {
									["count"] = 0,
								},
							},
							["amount"] = 41.70999999999999,
						},
					},
					["Healing"] = 148090,
					["WhoHealed"] = {
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Penance"] = {
									["count"] = 244944,
								},
								["Flash Heal"] = {
									["count"] = 386532,
								},
								["Halo"] = {
									["count"] = 20662,
								},
								["Atonement"] = {
									["count"] = 223489,
								},
								["Prayer of Healing"] = {
									["count"] = 85361,
								},
							},
							["amount"] = 960988,
						},
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Leader of the Pack"] = {
									["count"] = 148090,
								},
							},
							["amount"] = 148090,
						},
					},
					["ManaGainedFrom"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Leader of the Pack"] = {
									["count"] = 52800,
								},
								["Innervate"] = {
									["count"] = 12000,
								},
							},
							["amount"] = 64800,
						},
					},
					["Attacks"] = {
						["Thrash (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 16535,
									["min"] = 13021,
									["count"] = 11,
									["amount"] = 171330,
								},
								["Tick"] = {
									["max"] = 8268,
									["min"] = 6510,
									["count"] = 33,
									["amount"] = 250356,
								},
							},
							["count"] = 44,
							["amount"] = 421686,
						},
						["Melee"] = {
							["Details"] = {
								["Glancing"] = {
									["max"] = 8956,
									["min"] = 6893,
									["count"] = 6,
									["amount"] = 45439,
								},
								["Hit"] = {
									["max"] = 10182,
									["min"] = 5891,
									["count"] = 19,
									["amount"] = 170684,
								},
								["Miss"] = {
									["count"] = 4,
									["amount"] = 0,
								},
								["Glancing (Blocked)"] = {
									["max"] = 5936,
									["min"] = 5936,
									["count"] = 1,
									["amount"] = 5936,
								},
								["Crit"] = {
									["max"] = 21470,
									["min"] = 14984,
									["count"] = 11,
									["amount"] = 207816,
								},
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 42,
							["amount"] = 429875,
						},
						["Lacerate"] = {
							["Details"] = {
								["Hit (Blocked)"] = {
									["max"] = 15794,
									["min"] = 15794,
									["count"] = 1,
									["amount"] = 15794,
								},
								["Crit"] = {
									["max"] = 43766,
									["min"] = 21004,
									["count"] = 5,
									["amount"] = 183382,
								},
								["Hit"] = {
									["max"] = 23492,
									["min"] = 14841,
									["count"] = 10,
									["amount"] = 202518,
								},
							},
							["count"] = 16,
							["amount"] = 401694,
						},
						["Moonfire"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 4797,
									["min"] = 4671,
									["count"] = 5,
									["amount"] = 23764,
								},
							},
							["count"] = 5,
							["amount"] = 23764,
						},
						["Immobilized"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Mangle"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 54829,
									["min"] = 45016,
									["count"] = 10,
									["amount"] = 515733,
								},
								["Hit"] = {
									["max"] = 29600,
									["min"] = 17191,
									["count"] = 20,
									["amount"] = 488373,
								},
							},
							["count"] = 31,
							["amount"] = 1004106,
						},
						["Maul"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 1,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 24301,
									["min"] = 20513,
									["count"] = 2,
									["amount"] = 44814,
								},
								["Hit"] = {
									["max"] = 13434,
									["min"] = 5128,
									["count"] = 13,
									["amount"] = 133289,
								},
							},
							["count"] = 16,
							["amount"] = 178103,
						},
						["Lacerate (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 15769,
									["min"] = 5628,
									["count"] = 6,
									["amount"] = 59629,
								},
								["Tick"] = {
									["max"] = 8789,
									["min"] = 1363,
									["count"] = 24,
									["amount"] = 137445,
								},
							},
							["count"] = 30,
							["amount"] = 197074,
						},
						["Thrash"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 11529,
									["min"] = 9137,
									["count"] = 5,
									["amount"] = 52872,
								},
								["Crit"] = {
									["max"] = 22703,
									["min"] = 22703,
									["count"] = 1,
									["amount"] = 22703,
								},
								["Parry"] = {
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 75575,
						},
						["Swipe"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 15663,
									["min"] = 15663,
									["count"] = 1,
									["amount"] = 15663,
								},
								["Hit"] = {
									["max"] = 7903,
									["min"] = 6333,
									["count"] = 5,
									["amount"] = 37498,
								},
							},
							["count"] = 6,
							["amount"] = 53161,
						},
					},
					["HealingTaken"] = 1109078,
					["RageGained"] = {
						["Mangle"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["count"] = 95,
								},
							},
							["amount"] = 95,
						},
						["Bear Form"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
						["Primal Fury"] = {
							["Details"] = {
								["Metalica-Jubei'Thos"] = {
									["count"] = 315,
								},
							},
							["amount"] = 315,
						},
					},
					["TimeDamage"] = 108.96,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Thrash (DoT)"] = {
									["count"] = 0.66,
								},
								["Melee"] = {
									["count"] = 7.859999999999999,
								},
								["Lacerate"] = {
									["count"] = 1.8,
								},
								["Mangle"] = {
									["count"] = 1.29,
								},
								["Immobilized"] = {
									["count"] = 3.5,
								},
								["Thrash"] = {
									["count"] = 2.81,
								},
								["Lacerate (DoT)"] = {
									["count"] = 4.6,
								},
								["Maul"] = {
									["count"] = 2.24,
								},
								["Swipe"] = {
									["count"] = 1.32,
								},
							},
							["amount"] = 26.07999999999999,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Mangle"] = {
									["count"] = 5.81,
								},
								["Thrash (DoT)"] = {
									["count"] = 2.69,
								},
								["Melee"] = {
									["count"] = 8.380000000000001,
								},
								["Thrash"] = {
									["count"] = 0,
								},
								["Lacerate"] = {
									["count"] = 2.24,
								},
								["Lacerate (DoT)"] = {
									["count"] = 4.819999999999999,
								},
								["Maul"] = {
									["count"] = 1.61,
								},
								["Swipe"] = {
									["count"] = 0,
								},
							},
							["amount"] = 25.55,
						},
						["Corpse Eater"] = {
							["Details"] = {
								["Moonfire"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Moonfire"] = {
									["count"] = 12.12,
								},
							},
							["amount"] = 12.12,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Maul"] = {
									["count"] = 3.27,
								},
								["Thrash (DoT)"] = {
									["count"] = 6.55,
								},
								["Melee"] = {
									["count"] = 15.83,
								},
								["Lacerate"] = {
									["count"] = 4.86,
								},
								["Mangle"] = {
									["count"] = 3.55,
								},
								["Lacerate (DoT)"] = {
									["count"] = 6.44,
								},
								["Thrash"] = {
									["count"] = 1.21,
								},
								["Swipe"] = {
									["count"] = 0,
								},
							},
							["amount"] = 41.70999999999999,
						},
					},
					["ManaGain"] = 64800,
					["DamagedWho"] = {
						["Corpse Eater"] = {
							["Details"] = {
								["Moonfire"] = {
									["count"] = 4671,
								},
							},
							["amount"] = 4671,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Mangle"] = {
									["count"] = 364843,
								},
								["Thrash (DoT)"] = {
									["count"] = 150432,
								},
								["Melee"] = {
									["count"] = 68080,
								},
								["Thrash"] = {
									["count"] = 20854,
								},
								["Lacerate"] = {
									["count"] = 75355,
								},
								["Lacerate (DoT)"] = {
									["count"] = 79785,
								},
								["Maul"] = {
									["count"] = 25975,
								},
								["Swipe"] = {
									["count"] = 23566,
								},
							},
							["amount"] = 808890,
						},
						["Apothecary Frye"] = {
							["Details"] = {
								["Maul"] = {
									["count"] = 65630,
								},
								["Thrash (DoT)"] = {
									["count"] = 73224,
								},
								["Melee"] = {
									["count"] = 97828,
								},
								["Lacerate"] = {
									["count"] = 114691,
								},
								["Thrash"] = {
									["count"] = 22703,
								},
								["Lacerate (DoT)"] = {
									["count"] = 26224,
								},
								["Mangle"] = {
									["count"] = 202543,
								},
								["Swipe"] = {
									["count"] = 14164,
								},
							},
							["amount"] = 617007,
						},
						["Frantic Geist"] = {
							["Details"] = {
								["Moonfire"] = {
									["count"] = 19093,
								},
							},
							["amount"] = 19093,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Maul"] = {
									["count"] = 86498,
								},
								["Thrash (DoT)"] = {
									["count"] = 198030,
								},
								["Melee"] = {
									["count"] = 263967,
								},
								["Lacerate"] = {
									["count"] = 211648,
								},
								["Mangle"] = {
									["count"] = 436720,
								},
								["Lacerate (DoT)"] = {
									["count"] = 91065,
								},
								["Thrash"] = {
									["count"] = 32018,
								},
								["Swipe"] = {
									["count"] = 15431,
								},
							},
							["amount"] = 1335377,
						},
					},
					["RageGain"] = 430,
				},
			},
			["UnitLockout"] = 1360559619,
			["LastActive"] = 1360559620,
		},
		["No One"] = {
			["GUID"] = "0x0000000000000000",
			["LastEventHealth"] = {
				"???", -- [1]
				"???", -- [2]
				"???", -- [3]
				"???", -- [4]
				"???", -- [5]
				"???", -- [6]
				"???", -- [7]
				"???", -- [8]
				"???", -- [9]
				"???", -- [10]
				"???", -- [11]
				"???", -- [12]
				"???", -- [13]
				"???", -- [14]
				"???", -- [15]
				"???", -- [16]
				"???", -- [17]
				"???", -- [18]
				"???", -- [19]
				"???", -- [20]
				"???", -- [21]
				"???", -- [22]
				"???", -- [23]
				"???", -- [24]
				"???", -- [25]
				"???", -- [26]
				"???", -- [27]
				"???", -- [28]
				"???", -- [29]
				"???", -- [30]
				"???", -- [31]
				"???", -- [32]
				"???", -- [33]
				"???", -- [34]
				"???", -- [35]
				"???", -- [36]
				"???", -- [37]
				"???", -- [38]
				"???", -- [39]
				"???", -- [40]
				"???", -- [41]
				"???", -- [42]
				"???", -- [43]
				"???", -- [44]
				"???", -- [45]
				"???", -- [46]
				"???", -- [47]
				"???", -- [48]
				"???", -- [49]
				"???", -- [50]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeDamage"] = {
					67.08999999999995, -- [1]
				},
				["FDamage"] = {
					98129, -- [1]
				},
				["ActiveTime"] = {
					67.08999999999995, -- [1]
				},
			},
			["level"] = 0,
			["LastFightIn"] = 1,
			["type"] = "Ungrouped",
			["FightsSaved"] = 1,
			["TimeLast"] = {
				["TimeDamage"] = 1360559619,
				["OVERALL"] = 1360559619,
				["FDamage"] = 1360559619,
				["ActiveTime"] = 1360559619,
			},
			["Owner"] = false,
			["LastAbility"] = 19802.328,
			["NextEventNum"] = 50,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
				0, -- [5]
				0, -- [6]
				0, -- [7]
				0, -- [8]
				0, -- [9]
				0, -- [10]
				0, -- [11]
				0, -- [12]
				0, -- [13]
				0, -- [14]
				0, -- [15]
				0, -- [16]
				0, -- [17]
				0, -- [18]
				0, -- [19]
				0, -- [20]
				0, -- [21]
				0, -- [22]
				0, -- [23]
				0, -- [24]
				0, -- [25]
				0, -- [26]
				0, -- [27]
				0, -- [28]
				0, -- [29]
				0, -- [30]
				0, -- [31]
				0, -- [32]
				0, -- [33]
				0, -- [34]
				0, -- [35]
				0, -- [36]
				0, -- [37]
				0, -- [38]
				0, -- [39]
				0, -- [40]
				0, -- [41]
				0, -- [42]
				0, -- [43]
				0, -- [44]
				0, -- [45]
				0, -- [46]
				0, -- [47]
				0, -- [48]
				0, -- [49]
				0, -- [50]
			},
			["LastEvents"] = {
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -465 (Nature)", -- [1]
				"No One Concentrated Alluring Perfume Spill Risen Ally <Müu-Jubei'Thos> Hit -234 (Nature)", -- [2]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -253 (Nature)", -- [3]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -269 (Nature)", -- [4]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -230 (Nature)", -- [5]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -234 (Nature)", -- [6]
				"No One Concentrated Alluring Perfume Spill Risen Ally <Müu-Jubei'Thos> Crit -476 (Nature)", -- [7]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -245 (Nature)", -- [8]
				"No One Concentrated Alluring Perfume Spill Risen Ally <Müu-Jubei'Thos> Hit -256 (Nature)", -- [9]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -468 (Nature)", -- [10]
				"No One Concentrated Alluring Perfume Spill Risen Ally <Müu-Jubei'Thos> Hit -272 (Nature)", -- [11]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -473 (Nature)", -- [12]
				"No One Concentrated Alluring Perfume Spill Risen Ally <Müu-Jubei'Thos> Crit -491 (Nature)", -- [13]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Hit -255 (Nature)", -- [14]
				"No One Concentrated Alluring Perfume Spill Risen Ally <Müu-Jubei'Thos> Hit -233 (Nature)", -- [15]
				"No One Concentrated Alluring Perfume Spill Mirror Image <Acindor-Jubei'Thos> Crit -470 (Nature)", -- [16]
				"No One Concentrated Alluring Perfume Spill Stabsya Hit -3280 (Nature)", -- [17]
				"No One Concentrated Irresistible Cologne Spill Risen Ally <Müu-Jubei'Thos> Crit -522 (Nature)", -- [18]
				"No One Concentrated Irresistible Cologne Spill Müu-Jubei'Thos Hit -2423 (Nature)", -- [19]
				"No One Concentrated Irresistible Cologne Spill Risen Ally <Müu-Jubei'Thos> Hit -247 (Nature)", -- [20]
				"No One Concentrated Alluring Perfume Spill Risen Ally <Müu-Jubei'Thos> Crit -489 (Nature)", -- [21]
				"No One Concentrated Irresistible Cologne Spill Müu-Jubei'Thos Hit -2586 (Nature)", -- [22]
				"No One Concentrated Irresistible Cologne Spill Metalica-Jubei'Thos Hit -2045 (Nature)", -- [23]
				"No One Concentrated Irresistible Cologne Spill Müu-Jubei'Thos Hit -2360 (Nature)", -- [24]
				"No One Concentrated Irresistible Cologne Spill Metalica-Jubei'Thos Hit -1998 (Nature)", -- [25]
				"No One Concentrated Alluring Perfume Spill Risen Ally <Müu-Jubei'Thos> Hit -256 (Nature)", -- [26]
				"No One Concentrated Irresistible Cologne Spill Metalica-Jubei'Thos Hit -2041 (Nature)", -- [27]
				"No One Concentrated Alluring Perfume Spill Risen Ally <Müu-Jubei'Thos> Hit -248 (Nature)", -- [28]
				"No One Concentrated Alluring Perfume Spill Müu-Jubei'Thos Absorb (2380 Absorbed) (Nature)", -- [29]
				"No One Concentrated Irresistible Cologne Spill Acindor-Jubei'Thos Absorb (2673 Absorbed) (Nature)", -- [30]
				"No One Concentrated Alluring Perfume Spill Müu-Jubei'Thos Absorb (2509 Absorbed) (Nature)", -- [31]
				"No One Concentrated Irresistible Cologne Spill Acindor-Jubei'Thos Absorb (2682 Absorbed) (Nature)", -- [32]
				"No One Concentrated Irresistible Cologne Spill Risen Ally <Müu-Jubei'Thos> Hit -239 (Nature)", -- [33]
				"No One Concentrated Alluring Perfume Spill Müu-Jubei'Thos Absorb (2396 Absorbed) (Nature)", -- [34]
				"No One Concentrated Irresistible Cologne Spill Acindor-Jubei'Thos Absorb (2679 Absorbed) (Nature)", -- [35]
				"No One Concentrated Irresistible Cologne Spill Stabsya Absorb (3228 Absorbed) (Nature)", -- [36]
				"No One Concentrated Irresistible Cologne Spill Risen Ally <Müu-Jubei'Thos> Hit -262 (Nature)", -- [37]
				"No One Concentrated Alluring Perfume Spill Tanklord-Tichondrius Absorb (2873 Absorbed) (Nature)", -- [38]
				"No One Concentrated Alluring Perfume Spill Ghost Iron Dragonling Hit -2304 (Nature)", -- [39]
				"No One Concentrated Irresistible Cologne Spill Risen Ally <Müu-Jubei'Thos> Crit -525 (Nature)", -- [40]
				"No One Concentrated Irresistible Cologne Spill Metalica-Jubei'Thos Absorb (2137 Absorbed) (Nature)", -- [41]
				"No One Concentrated Alluring Perfume Spill Ghost Iron Dragonling Hit -2336 (Nature)", -- [42]
				"No One Concentrated Irresistible Cologne Spill Müu-Jubei'Thos Absorb (2456 Absorbed) (Nature)", -- [43]
				"No One Concentrated Irresistible Cologne Spill Müu-Jubei'Thos Absorb (2576 Absorbed) (Nature)", -- [44]
				"No One Concentrated Irresistible Cologne Spill Müu-Jubei'Thos Absorb (2438 Absorbed) (Nature)", -- [45]
				"No One Concentrated Irresistible Cologne Spill Müu-Jubei'Thos Absorb (2369 Absorbed) (Nature)", -- [46]
				"No One Concentrated Alluring Perfume Spill Ghost Iron Dragonling Hit -2729 (Nature)", -- [47]
				"No One Concentrated Irresistible Cologne Spill Müu-Jubei'Thos Hit -207 (2272 Absorbed) (Nature)", -- [48]
				"No One Concentrated Alluring Perfume Spill Ghost Iron Dragonling Hit -2488 (Nature)", -- [49]
				"No One Concentrated Alluring Perfume Spill Risen Ally <Müu-Jubei'Thos> Hit -231 (Nature)", -- [50]
			},
			["Name"] = "No One",
			["LastEventTimes"] = {
				19772.128, -- [1]
				19772.531, -- [2]
				19772.928, -- [3]
				19774.149, -- [4]
				19774.93, -- [5]
				19776.137, -- [6]
				19776.539, -- [7]
				19776.946, -- [8]
				19777.755, -- [9]
				19778.158, -- [10]
				19778.559, -- [11]
				19778.958, -- [12]
				19779.76, -- [13]
				19780.177, -- [14]
				19780.579, -- [15]
				19780.976, -- [16]
				19785.012, -- [17]
				19786.623, -- [18]
				19787.017, -- [19]
				19787.425, -- [20]
				19787.827, -- [21]
				19788.229, -- [22]
				19788.229, -- [23]
				19789.033, -- [24]
				19789.033, -- [25]
				19789.841, -- [26]
				19790.249, -- [27]
				19791.064, -- [28]
				19791.447, -- [29]
				19791.859, -- [30]
				19792.255, -- [31]
				19792.687, -- [32]
				19793.076, -- [33]
				19793.482, -- [34]
				19793.886, -- [35]
				19793.886, -- [36]
				19795.496, -- [37]
				19795.895, -- [38]
				19795.895, -- [39]
				19796.286, -- [40]
				19796.711, -- [41]
				19796.711, -- [42]
				19797.51, -- [43]
				19798.718, -- [44]
				19799.52, -- [45]
				19800.729, -- [46]
				19801.532, -- [47]
				19801.532, -- [48]
				19802.328, -- [49]
				19771.729, -- [50]
			},
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["Fights"] = {
				["Fight1"] = {
					["TimeSpent"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 4.35,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2.05,
								},
							},
							["amount"] = 6.4,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 10.87000000000001,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 4.82,
								},
							},
							["amount"] = 15.69,
						},
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0.4,
								},
							},
							["amount"] = 0.4,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 2.42,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 15.42000000000001,
								},
							},
							["amount"] = 17.84000000000001,
						},
						["Acindor-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 1.24,
								},
							},
							["amount"] = 1.24,
						},
						["Mirror Image <Acindor-Jubei'Thos>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 14.41,
								},
							},
							["amount"] = 14.41,
						},
						["Stabsya"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 3.5,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 3.19,
								},
							},
							["amount"] = 6.69,
						},
						["Ghost Iron Dragonling"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 1.6,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2.82,
								},
							},
							["amount"] = 4.42,
						},
					},
					["FAttacks"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 516,
									["min"] = 451,
									["count"] = 11,
									["amount"] = 5293,
								},
								["Hit"] = {
									["max"] = 3280,
									["min"] = 118,
									["count"] = 40,
									["amount"] = 40780,
								},
							},
							["count"] = 51,
							["amount"] = 46073,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 525,
									["min"] = 497,
									["count"] = 3,
									["amount"] = 1544,
								},
								["Hit"] = {
									["max"] = 3293,
									["min"] = 207,
									["count"] = 23,
									["amount"] = 50512,
								},
							},
							["count"] = 26,
							["amount"] = 52056,
						},
					},
					["ElementDoneAbsorb"] = {
						["Nature"] = 40585,
					},
					["Attacks"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
					},
					["FDamage"] = 98129,
					["TimeDamage"] = 67.08999999999995,
					["TimeDamaging"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 4.35,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2.05,
								},
							},
							["amount"] = 6.4,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 10.87000000000001,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 4.82,
								},
							},
							["amount"] = 15.69,
						},
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0.4,
								},
							},
							["amount"] = 0.4,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 2.42,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 15.42000000000001,
								},
							},
							["amount"] = 17.84000000000001,
						},
						["Acindor-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 1.24,
								},
							},
							["amount"] = 1.24,
						},
						["Mirror Image <Acindor-Jubei'Thos>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 14.41,
								},
							},
							["amount"] = 14.41,
						},
						["Stabsya"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 3.5,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 3.19,
								},
							},
							["amount"] = 6.69,
						},
						["Ghost Iron Dragonling"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 1.6,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2.82,
								},
							},
							["amount"] = 4.42,
						},
					},
					["ElementHitsDone"] = {
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 22,
								},
							},
							["amount"] = 22,
						},
					},
					["FDamagedWho"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 4282,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 10351,
								},
							},
							["amount"] = 14633,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 3820,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2292,
								},
							},
							["amount"] = 6112,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 17002,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 17639,
								},
							},
							["amount"] = 34641,
						},
						["Mirror Image <Acindor-Jubei'Thos>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 7832,
								},
							},
							["amount"] = 7832,
						},
						["Stabsya"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 3280,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 19346,
								},
							},
							["amount"] = 22626,
						},
						["Ghost Iron Dragonling"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 9857,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2428,
								},
							},
							["amount"] = 12285,
						},
					},
					["ActiveTime"] = 67.08999999999995,
				},
				["LastFightData"] = {
					["TimeSpent"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 4.35,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2.05,
								},
							},
							["amount"] = 6.4,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 10.87000000000001,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 4.82,
								},
							},
							["amount"] = 15.69,
						},
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0.4,
								},
							},
							["amount"] = 0.4,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 2.42,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 15.42000000000001,
								},
							},
							["amount"] = 17.84000000000001,
						},
						["Acindor-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 1.24,
								},
							},
							["amount"] = 1.24,
						},
						["Mirror Image <Acindor-Jubei'Thos>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 14.41,
								},
							},
							["amount"] = 14.41,
						},
						["Stabsya"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 3.5,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 3.19,
								},
							},
							["amount"] = 6.69,
						},
						["Ghost Iron Dragonling"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 1.6,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2.82,
								},
							},
							["amount"] = 4.42,
						},
					},
					["FAttacks"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 516,
									["min"] = 451,
									["count"] = 11,
									["amount"] = 5293,
								},
								["Hit"] = {
									["max"] = 3280,
									["min"] = 118,
									["count"] = 40,
									["amount"] = 40780,
								},
							},
							["count"] = 51,
							["amount"] = 46073,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 525,
									["min"] = 497,
									["count"] = 3,
									["amount"] = 1544,
								},
								["Hit"] = {
									["max"] = 3293,
									["min"] = 207,
									["count"] = 23,
									["amount"] = 50512,
								},
							},
							["count"] = 26,
							["amount"] = 52056,
						},
					},
					["ElementDoneAbsorb"] = {
						["Nature"] = 40585,
					},
					["Attacks"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
					},
					["FDamage"] = 98129,
					["TimeDamage"] = 67.08999999999995,
					["TimeDamaging"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 4.35,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2.05,
								},
							},
							["amount"] = 6.4,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 10.87000000000001,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 4.82,
								},
							},
							["amount"] = 15.69,
						},
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0.4,
								},
							},
							["amount"] = 0.4,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 2.42,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 15.42000000000001,
								},
							},
							["amount"] = 17.84000000000001,
						},
						["Acindor-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 1.24,
								},
							},
							["amount"] = 1.24,
						},
						["Mirror Image <Acindor-Jubei'Thos>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 14.41,
								},
							},
							["amount"] = 14.41,
						},
						["Stabsya"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 3.5,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 3.19,
								},
							},
							["amount"] = 6.69,
						},
						["Ghost Iron Dragonling"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 1.6,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2.82,
								},
							},
							["amount"] = 4.42,
						},
					},
					["ElementHitsDone"] = {
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 22,
								},
							},
							["amount"] = 22,
						},
					},
					["FDamagedWho"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 4282,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 10351,
								},
							},
							["amount"] = 14633,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 3820,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2292,
								},
							},
							["amount"] = 6112,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 17002,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 17639,
								},
							},
							["amount"] = 34641,
						},
						["Mirror Image <Acindor-Jubei'Thos>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 7832,
								},
							},
							["amount"] = 7832,
						},
						["Stabsya"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 3280,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 19346,
								},
							},
							["amount"] = 22626,
						},
						["Ghost Iron Dragonling"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 9857,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2428,
								},
							},
							["amount"] = 12285,
						},
					},
					["ActiveTime"] = 67.08999999999995,
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeSpent"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 4.35,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2.05,
								},
							},
							["amount"] = 6.4,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 10.87000000000001,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 4.82,
								},
							},
							["amount"] = 15.69,
						},
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0.4,
								},
							},
							["amount"] = 0.4,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 2.42,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 15.42000000000001,
								},
							},
							["amount"] = 17.84000000000001,
						},
						["Acindor-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 1.24,
								},
							},
							["amount"] = 1.24,
						},
						["Mirror Image <Acindor-Jubei'Thos>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 14.41,
								},
							},
							["amount"] = 14.41,
						},
						["Stabsya"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 3.5,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 3.19,
								},
							},
							["amount"] = 6.69,
						},
						["Ghost Iron Dragonling"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 1.6,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2.82,
								},
							},
							["amount"] = 4.42,
						},
					},
					["FAttacks"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 516,
									["min"] = 451,
									["count"] = 11,
									["amount"] = 5293,
								},
								["Hit"] = {
									["max"] = 3280,
									["min"] = 118,
									["count"] = 40,
									["amount"] = 40780,
								},
							},
							["count"] = 51,
							["amount"] = 46073,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 525,
									["min"] = 497,
									["count"] = 3,
									["amount"] = 1544,
								},
								["Hit"] = {
									["max"] = 3293,
									["min"] = 207,
									["count"] = 23,
									["amount"] = 50512,
								},
							},
							["count"] = 26,
							["amount"] = 52056,
						},
					},
					["ElementDoneAbsorb"] = {
						["Nature"] = 40585,
					},
					["Attacks"] = {
						["Concentrated Alluring Perfume Spill"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
					},
					["FDamage"] = 98129,
					["TimeDamage"] = 67.08999999999995,
					["TimeDamaging"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 4.35,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2.05,
								},
							},
							["amount"] = 6.4,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 10.87000000000001,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 4.82,
								},
							},
							["amount"] = 15.69,
						},
						["Tanklord-Tichondrius"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 0.4,
								},
							},
							["amount"] = 0.4,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 2.42,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 15.42000000000001,
								},
							},
							["amount"] = 17.84000000000001,
						},
						["Acindor-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 1.24,
								},
							},
							["amount"] = 1.24,
						},
						["Mirror Image <Acindor-Jubei'Thos>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 14.41,
								},
							},
							["amount"] = 14.41,
						},
						["Stabsya"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 3.5,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 3.19,
								},
							},
							["amount"] = 6.69,
						},
						["Ghost Iron Dragonling"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 1.6,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2.82,
								},
							},
							["amount"] = 4.42,
						},
					},
					["ElementHitsDone"] = {
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 22,
								},
							},
							["amount"] = 22,
						},
					},
					["FDamagedWho"] = {
						["Metalica-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 4282,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 10351,
								},
							},
							["amount"] = 14633,
						},
						["Risen Ally <Müu-Jubei'Thos>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 3820,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2292,
								},
							},
							["amount"] = 6112,
						},
						["Müu-Jubei'Thos"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 17002,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 17639,
								},
							},
							["amount"] = 34641,
						},
						["Mirror Image <Acindor-Jubei'Thos>"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 7832,
								},
							},
							["amount"] = 7832,
						},
						["Stabsya"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 3280,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 19346,
								},
							},
							["amount"] = 22626,
						},
						["Ghost Iron Dragonling"] = {
							["Details"] = {
								["Concentrated Alluring Perfume Spill"] = {
									["count"] = 9857,
								},
								["Concentrated Irresistible Cologne Spill"] = {
									["count"] = 2428,
								},
							},
							["amount"] = 12285,
						},
					},
					["ActiveTime"] = 67.08999999999995,
				},
			},
			["UnitLockout"] = 1360559619,
			["LastActive"] = 1360559619,
		},
		["Acindor-Jubei'Thos"] = {
			["GUID"] = "0x038000000523CBAD",
			["LastEventHealth"] = {
				"403785 (100%)", -- [1]
				"403785 (100%)", -- [2]
				"403785 (100%)", -- [3]
				"403785 (100%)", -- [4]
				"403785 (100%)", -- [5]
				"403785 (100%)", -- [6]
				"403785 (100%)", -- [7]
				"403785 (100%)", -- [8]
				"403785 (100%)", -- [9]
				"403785 (100%)", -- [10]
				"403785 (100%)", -- [11]
				"403785 (100%)", -- [12]
				"403785 (100%)", -- [13]
				"403785 (100%)", -- [14]
				"403785 (100%)", -- [15]
				"403785 (100%)", -- [16]
				"403785 (100%)", -- [17]
				"403785 (100%)", -- [18]
				"403785 (100%)", -- [19]
				"403785 (100%)", -- [20]
				"403785 (100%)", -- [21]
				"403785 (100%)", -- [22]
				"403785 (100%)", -- [23]
				"403785 (100%)", -- [24]
				"403785 (100%)", -- [25]
				"403785 (100%)", -- [26]
				"403785 (100%)", -- [27]
				"403785 (100%)", -- [28]
				"403785 (100%)", -- [29]
				"403785 (100%)", -- [30]
				"403785 (100%)", -- [31]
				"403785 (100%)", -- [32]
				"403785 (100%)", -- [33]
				"403785 (100%)", -- [34]
				"403785 (100%)", -- [35]
				"403785 (100%)", -- [36]
				"403785 (100%)", -- [37]
				"403785 (100%)", -- [38]
				"403785 (100%)", -- [39]
				"403785 (100%)", -- [40]
				"403785 (100%)", -- [41]
				"403785 (100%)", -- [42]
				"403785 (100%)", -- [43]
				"403785 (100%)", -- [44]
				"403785 (100%)", -- [45]
				"403785 (100%)", -- [46]
				"403785 (100%)", -- [47]
				"403785 (100%)", -- [48]
				"403785 (100%)", -- [49]
				"403785 (100%)", -- [50]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"HEAL", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"HEAL", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["Absorbs"] = {
					24970, -- [1]
				},
				["ActiveTime"] = {
					98.33999999999998, -- [1]
				},
				["TimeDamage"] = {
					98.33999999999998, -- [1]
				},
				["DOT_Time"] = {
					591, -- [1]
				},
				["Damage"] = {
					7944620, -- [1]
				},
			},
			["enClass"] = "MAGE",
			["unit"] = "Acindor",
			["level"] = 90,
			["LastAbility"] = 19802.975,
			["LastFightIn"] = 1,
			["LastEventNum"] = {
				[6] = 7.214482955037953,
				[34] = 7.69592728803695,
			},
			["type"] = "Ungrouped",
			["FightsSaved"] = 2,
			["GuardianReverseGUIDs"] = {
				["Mirror Image"] = {
					["LatestGuardian"] = 2,
					["GUIDs"] = {
						"0xF13079F00000CEAA", -- [1]
						"0xF13079F00000CEAB", -- [2]
						[0] = "0xF13079F00000CEA9",
					},
				},
				["Past Self"] = {
					["LatestGuardian"] = 0,
					["GUIDs"] = {
						[0] = "0xF130E4AE0000CEBF",
					},
				},
			},
			["TimeLast"] = {
				["Absorbs"] = 1360559567,
				["ActiveTime"] = 1360559620,
				["TimeDamage"] = 1360559620,
				["OVERALL"] = 1360559620,
				["DOT_Time"] = 1360559620,
				["Damage"] = 1360559620,
			},
			["Owner"] = false,
			["Pet"] = {
				"Mirror Image <Acindor-Jubei'Thos>", -- [1]
				"Past Self <Acindor-Jubei'Thos>", -- [2]
			},
			["NextEventNum"] = 35,
			["LastEventHealthNum"] = {
				100, -- [1]
				100, -- [2]
				100, -- [3]
				100, -- [4]
				100, -- [5]
				100, -- [6]
				100, -- [7]
				100, -- [8]
				100, -- [9]
				100, -- [10]
				100, -- [11]
				100, -- [12]
				100, -- [13]
				100, -- [14]
				100, -- [15]
				100, -- [16]
				100, -- [17]
				100, -- [18]
				100, -- [19]
				100, -- [20]
				100, -- [21]
				100, -- [22]
				100, -- [23]
				100, -- [24]
				100, -- [25]
				100, -- [26]
				100, -- [27]
				100, -- [28]
				100, -- [29]
				100, -- [30]
				100, -- [31]
				100, -- [32]
				100, -- [33]
				100, -- [34]
				100, -- [35]
				100, -- [36]
				100, -- [37]
				100, -- [38]
				100, -- [39]
				100, -- [40]
				100, -- [41]
				100, -- [42]
				100, -- [43]
				100, -- [44]
				100, -- [45]
				100, -- [46]
				100, -- [47]
				100, -- [48]
				100, -- [49]
				100, -- [50]
			},
			["LastEvents"] = {
				"Acindor-Jubei'Thos Ignite (DoT) Apothecary Frye Tick -15704 (Fire)", -- [1]
				"Acindor-Jubei'Thos Pyroblast (DoT) Apothecary Frye Crit -31150 (Fire)", -- [2]
				"Acindor-Jubei'Thos Living Bomb (DoT) Apothecary Frye Tick -10444 (Fire)", -- [3]
				"Acindor-Jubei'Thos Fireball Apothecary Frye Hit -47832 (Fire)", -- [4]
				"Acindor-Jubei'Thos Ignite (DoT) Apothecary Frye Tick -13949 (Fire)", -- [5]
				"Tanklord-Tichondrius Prayer of Healing Acindor-Jubei'Thos Hit +29131 (29131 overheal)", -- [6]
				"Acindor-Jubei'Thos Fireball Apothecary Frye Hit -48079 (Fire)", -- [7]
				"Acindor-Jubei'Thos Pyroblast (DoT) Apothecary Frye Tick -15575 (Fire)", -- [8]
				"Acindor-Jubei'Thos Living Bomb (DoT) Apothecary Frye Tick -10444 (Fire)", -- [9]
				"No One Concentrated Irresistible Cologne Spill Acindor-Jubei'Thos Absorb (2673 Absorbed) (Nature)", -- [10]
				"Acindor-Jubei'Thos Fireball Apothecary Frye Crit -95926 (Fire)", -- [11]
				"Acindor-Jubei'Thos Ignite (DoT) Apothecary Frye Tick -12799 (Fire)", -- [12]
				"Acindor-Jubei'Thos Pyroblast (DoT) Apothecary Frye Tick -15575 (Fire)", -- [13]
				"No One Concentrated Irresistible Cologne Spill Acindor-Jubei'Thos Absorb (2682 Absorbed) (Nature)", -- [14]
				"Acindor-Jubei'Thos Living Bomb (DoT) Apothecary Frye Crit -20888 (Fire)", -- [15]
				"Acindor-Jubei'Thos Living Bomb Apothecary Frye Hit -30803 (Fire)", -- [16]
				"Acindor-Jubei'Thos Inferno Blast Apothecary Frye Crit -38410 (Fire)", -- [17]
				"Acindor-Jubei'Thos Fireball Apothecary Frye Hit -48003 (Fire)", -- [18]
				"No One Concentrated Irresistible Cologne Spill Acindor-Jubei'Thos Absorb (2679 Absorbed) (Nature)", -- [19]
				"Acindor-Jubei'Thos Ignite (DoT) Apothecary Frye Tick -15513 (Fire)", -- [20]
				"Acindor-Jubei'Thos Pyroblast (DoT) Apothecary Frye Tick -15575 (Fire)", -- [21]
				"Acindor-Jubei'Thos Pyroblast Apothecary Frye Hit -95202 (Fire)", -- [22]
				"Acindor-Jubei'Thos Ignite (DoT) Apothecary Frye Tick -23557 (Fire)", -- [23]
				"Acindor-Jubei'Thos Pyroblast (DoT) Apothecary Frye Tick -14159 (Fire)", -- [24]
				"Acindor-Jubei'Thos Fireball Apothecary Frye Hit -47245 (Fire)", -- [25]
				"Acindor-Jubei'Thos Ignite (DoT) Apothecary Frye Tick -19142 (Fire)", -- [26]
				"Acindor-Jubei'Thos Pyroblast (DoT) Apothecary Frye Tick -14159 (Fire)", -- [27]
				"Acindor-Jubei'Thos Fireball Apothecary Frye Hit -47228 (Fire)", -- [28]
				"Acindor-Jubei'Thos Ignite (DoT) Apothecary Frye Tick -16199 (Fire)", -- [29]
				"Acindor-Jubei'Thos Pyroblast (DoT) Apothecary Frye Tick -14159 (Fire)", -- [30]
				"Acindor-Jubei'Thos Fireball Apothecary Frye Hit -47050 (Fire)", -- [31]
				"Acindor-Jubei'Thos Ignite (DoT) Apothecary Frye Tick -14222 (Fire)", -- [32]
				"Acindor-Jubei'Thos Pyroblast (DoT) Apothecary Frye Tick -14159 (Fire)", -- [33]
				"Tanklord-Tichondrius Prayer of Healing Acindor-Jubei'Thos Hit +31075 (31075 overheal)", -- [34]
				"Acindor-Jubei'Thos Pyroblast (DoT) Apothecary Baxter Crit -38711 (Fire)", -- [35]
				"Acindor-Jubei'Thos Pyroblast (DoT) Apothecary Frye Crit -34702 (Fire)", -- [36]
				"Acindor-Jubei'Thos Ignite (DoT) Apothecary Baxter Tick -23291 (Fire)", -- [37]
				"Acindor-Jubei'Thos Pyroblast (DoT) Apothecary Baxter Tick -19355 (Fire)", -- [38]
				"Acindor-Jubei'Thos Pyroblast (DoT) Apothecary Frye Tick -17351 (Fire)", -- [39]
				"Acindor-Jubei'Thos Pyroblast (DoT) Apothecary Frye Tick -19087 (Fire)", -- [40]
				"Acindor-Jubei'Thos Living Bomb (DoT) Apothecary Frye Tick -9946 (Fire)", -- [41]
				"Acindor-Jubei'Thos Inferno Blast Apothecary Frye Crit -39444 (Fire)", -- [42]
				"Acindor-Jubei'Thos Fireball Apothecary Frye Hit -49586 (Fire)", -- [43]
				"Acindor-Jubei'Thos Pyroblast (DoT) Apothecary Frye Tick -19086 (Fire)", -- [44]
				"Acindor-Jubei'Thos Pyroblast Apothecary Frye Hit -90304 (Fire)", -- [45]
				"Acindor-Jubei'Thos Living Bomb (DoT) Apothecary Frye Tick -9947 (Fire)", -- [46]
				"Acindor-Jubei'Thos Ignite (DoT) Apothecary Frye Tick -13050 (Fire)", -- [47]
				"Acindor-Jubei'Thos Pyroblast (DoT) Apothecary Frye Tick -15575 (Fire)", -- [48]
				"Acindor-Jubei'Thos Living Bomb (DoT) Apothecary Frye Tick -10444 (Fire)", -- [49]
				"Acindor-Jubei'Thos Fireball Apothecary Frye Crit -96256 (Fire)", -- [50]
			},
			["Name"] = "Acindor-Jubei'Thos",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				true, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				true, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				true, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				true, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				true, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				19788.195, -- [1]
				19788.448, -- [2]
				19788.88, -- [3]
				19788.88, -- [4]
				19790.196, -- [5]
				19790.249, -- [6]
				19790.478, -- [7]
				19790.513, -- [8]
				19790.958, -- [9]
				19791.859, -- [10]
				19792.003, -- [11]
				19792.197, -- [12]
				19792.599, -- [13]
				19792.687, -- [14]
				19793.024, -- [15]
				19793.076, -- [16]
				19793.482, -- [17]
				19793.691, -- [18]
				19793.886, -- [19]
				19794.196, -- [20]
				19794.664, -- [21]
				19794.724, -- [22]
				19796.204, -- [23]
				19796.754, -- [24]
				19797.492, -- [25]
				19798.202, -- [26]
				19798.83, -- [27]
				19799.464, -- [28]
				19800.192, -- [29]
				19800.896, -- [30]
				19801.494, -- [31]
				19802.195, -- [32]
				19802.975, -- [33]
				19803.136, -- [34]
				19777.977, -- [35]
				19778.058, -- [36]
				19779.179, -- [37]
				19780.047, -- [38]
				19780.147, -- [39]
				19782.215, -- [40]
				19782.655, -- [41]
				19783.4, -- [42]
				19783.437, -- [43]
				19784.312, -- [44]
				19784.693, -- [45]
				19784.734, -- [46]
				19786.197, -- [47]
				19786.366, -- [48]
				19786.806, -- [49]
				19787.323, -- [50]
			},
			["Fights"] = {
				["Fight2"] = {
					["PartialResist"] = {
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Slashing Claws"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["PartialAbsorb"] = {
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Slashing Claws"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["Absorbed"] = {
						["Ice Barrier"] = {
							["Details"] = {
								["Acindor-Jubei'Thos"] = {
									["max"] = 24970,
									["min"] = 24970,
									["count"] = 1,
									["amount"] = 24970,
								},
							},
							["count"] = 1,
							["amount"] = 24970,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["DOTs"] = {
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 27,
								},
								["Apothecary Hummel"] = {
									["count"] = 24,
								},
								["Apothecary Baxter"] = {
									["count"] = 27,
								},
							},
							["amount"] = 78,
						},
						["Combustion (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 18,
								},
								["Apothecary Hummel"] = {
									["count"] = 66,
								},
								["Apothecary Baxter"] = {
									["count"] = 66,
								},
							},
							["amount"] = 150,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 84,
								},
								["Apothecary Hummel"] = {
									["count"] = 48,
								},
								["Apothecary Baxter"] = {
									["count"] = 60,
								},
							},
							["amount"] = 192,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 51,
								},
								["Apothecary Hummel"] = {
									["count"] = 60,
								},
								["Apothecary Baxter"] = {
									["count"] = 60,
								},
							},
							["amount"] = 171,
						},
					},
					["ShieldedWho"] = {
						["Acindor-Jubei'Thos"] = {
							["Details"] = {
								["Ice Barrier"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 24970,
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 32,
								},
								["Crit"] = {
									["count"] = 72,
								},
								["Tick"] = {
									["count"] = 154,
								},
							},
							["amount"] = 258,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 14364,
						["Nature"] = 29314,
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 591,
					["Damage"] = 7944620,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Fire"] = 7944620,
					},
					["PartialAbsorb"] = {
						["Irresistible Cologne"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 1970,
									["min"] = 1624,
									["count"] = 12,
									["amount"] = 21280,
								},
							},
							["count"] = 12,
							["amount"] = 21280,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 2682,
									["min"] = 2673,
									["count"] = 3,
									["amount"] = 8034,
								},
							},
							["count"] = 3,
							["amount"] = 8034,
						},
						["Melee"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 14364,
									["min"] = 14364,
									["count"] = 1,
									["amount"] = 14364,
								},
							},
							["count"] = 1,
							["amount"] = 14364,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 527205,
								},
								["Inferno Blast"] = {
									["count"] = 77854,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 633048,
								},
								["Ignite (DoT)"] = {
									["count"] = 301578,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 97028,
								},
								["Pyroblast"] = {
									["count"] = 185506,
								},
								["Combustion (DoT)"] = {
									["count"] = 60296,
								},
								["Living Bomb"] = {
									["count"] = 227209,
								},
							},
							["amount"] = 2109724,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 971352,
								},
								["Inferno Blast"] = {
									["count"] = 176706,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 449764,
								},
								["Combustion (DoT)"] = {
									["count"] = 211037,
								},
								["Combustion"] = {
									["count"] = 66411,
								},
								["Living Bomb"] = {
									["count"] = 198953,
								},
								["Pyroblast"] = {
									["count"] = 708272,
								},
								["Ignite (DoT)"] = {
									["count"] = 405236,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 81920,
								},
							},
							["amount"] = 3269651,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 558834,
								},
								["Pyroblast"] = {
									["count"] = 538774,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 489223,
								},
								["Ignite (DoT)"] = {
									["count"] = 363809,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 88727,
								},
								["Inferno Blast"] = {
									["count"] = 136765,
								},
								["Combustion (DoT)"] = {
									["count"] = 192705,
								},
								["Living Bomb"] = {
									["count"] = 196408,
								},
							},
							["amount"] = 2565245,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 12,
									["amount"] = 0,
								},
							},
							["count"] = 12,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Acindor-Jubei'Thos"] = {
							["Details"] = {
								["Ice Barrier"] = {
									["count"] = 24970,
								},
							},
							["amount"] = 24970,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 4.069999999999999,
								},
								["Inferno Blast"] = {
									["count"] = 1.16,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 9.879999999999999,
								},
								["Ignite (DoT)"] = {
									["count"] = 9.550000000000001,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 2.59,
								},
								["Pyroblast"] = {
									["count"] = 0.44,
								},
								["Combustion (DoT)"] = {
									["count"] = 0.52,
								},
								["Living Bomb"] = {
									["count"] = 0.26,
								},
							},
							["amount"] = 28.47,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 8.310000000000001,
								},
								["Inferno Blast"] = {
									["count"] = 4.680000000000001,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 5.91,
								},
								["Combustion (DoT)"] = {
									["count"] = 7.209999999999999,
								},
								["Combustion"] = {
									["count"] = 0.91,
								},
								["Living Bomb"] = {
									["count"] = 0.07000000000000001,
								},
								["Pyroblast"] = {
									["count"] = 0.8500000000000001,
								},
								["Ignite (DoT)"] = {
									["count"] = 8.969999999999999,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 3.82,
								},
							},
							["amount"] = 40.72999999999997,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 2.74,
								},
								["Pyroblast"] = {
									["count"] = 1.97,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 4.34,
								},
								["Ignite (DoT)"] = {
									["count"] = 11.06,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 3.089999999999999,
								},
								["Inferno Blast"] = {
									["count"] = 0.6399999999999999,
								},
								["Combustion (DoT)"] = {
									["count"] = 5.299999999999999,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 29.13999999999999,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["Ice Barrier"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 24970,
									["min"] = 24970,
									["count"] = 1,
									["amount"] = 24970,
								},
							},
							["count"] = 1,
							["amount"] = 24970,
						},
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 98.33999999999998,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Fireball"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 141060,
									["min"] = 94248,
									["count"] = 10,
									["amount"] = 1085420,
								},
								["Hit"] = {
									["max"] = 70446,
									["min"] = 45105,
									["count"] = 18,
									["amount"] = 971971,
								},
							},
							["count"] = 28,
							["amount"] = 2057391,
						},
						["Inferno Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 56249,
									["min"] = 38335,
									["count"] = 9,
									["amount"] = 391325,
								},
							},
							["count"] = 9,
							["amount"] = 391325,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 45614,
									["min"] = 29135,
									["count"] = 25,
									["amount"] = 896383,
								},
								["Tick"] = {
									["max"] = 22807,
									["min"] = 14159,
									["count"] = 39,
									["amount"] = 675652,
								},
							},
							["count"] = 64,
							["amount"] = 1572035,
						},
						["Combustion (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 15074,
									["min"] = 13804,
									["count"] = 13,
									["amount"] = 193422,
								},
								["Tick"] = {
									["max"] = 7538,
									["min"] = 6902,
									["count"] = 37,
									["amount"] = 270616,
								},
							},
							["count"] = 50,
							["amount"] = 464038,
						},
						["Combustion"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 66411,
									["min"] = 66411,
									["count"] = 1,
									["amount"] = 66411,
								},
							},
							["count"] = 1,
							["amount"] = 66411,
						},
						["Living Bomb"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 79064,
									["min"] = 58671,
									["count"] = 6,
									["amount"] = 398682,
								},
								["Hit"] = {
									["max"] = 44939,
									["min"] = 29335,
									["count"] = 7,
									["amount"] = 223888,
								},
							},
							["count"] = 13,
							["amount"] = 622570,
						},
						["Pyroblast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 235930,
									["min"] = 187409,
									["count"] = 4,
									["amount"] = 805225,
								},
								["Hit"] = {
									["max"] = 138977,
									["min"] = 88733,
									["count"] = 6,
									["amount"] = 627327,
								},
							},
							["count"] = 10,
							["amount"] = 1432552,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 43734,
									["min"] = 4192,
									["count"] = 57,
									["amount"] = 1070623,
								},
							},
							["count"] = 57,
							["amount"] = 1070623,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 20888,
									["min"] = 15327,
									["count"] = 5,
									["amount"] = 85955,
								},
								["Tick"] = {
									["max"] = 10444,
									["min"] = 7664,
									["count"] = 21,
									["amount"] = 181720,
								},
							},
							["count"] = 26,
							["amount"] = 267675,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 98.33999999999998,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 4.069999999999999,
								},
								["Inferno Blast"] = {
									["count"] = 1.16,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 9.879999999999999,
								},
								["Ignite (DoT)"] = {
									["count"] = 9.550000000000001,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 2.59,
								},
								["Pyroblast"] = {
									["count"] = 0.44,
								},
								["Combustion (DoT)"] = {
									["count"] = 0.52,
								},
								["Living Bomb"] = {
									["count"] = 0.26,
								},
							},
							["amount"] = 28.47,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 8.310000000000001,
								},
								["Inferno Blast"] = {
									["count"] = 4.680000000000001,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 5.91,
								},
								["Combustion (DoT)"] = {
									["count"] = 7.209999999999999,
								},
								["Combustion"] = {
									["count"] = 0.91,
								},
								["Living Bomb"] = {
									["count"] = 0.07000000000000001,
								},
								["Pyroblast"] = {
									["count"] = 0.8500000000000001,
								},
								["Ignite (DoT)"] = {
									["count"] = 8.969999999999999,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 3.82,
								},
							},
							["amount"] = 40.72999999999997,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 2.74,
								},
								["Pyroblast"] = {
									["count"] = 1.97,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 4.34,
								},
								["Ignite (DoT)"] = {
									["count"] = 11.06,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 3.089999999999999,
								},
								["Inferno Blast"] = {
									["count"] = 0.6399999999999999,
								},
								["Combustion (DoT)"] = {
									["count"] = 5.299999999999999,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 29.13999999999999,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["Absorbed"] = {
						["Ice Barrier"] = {
							["Details"] = {
								["Acindor-Jubei'Thos"] = {
									["max"] = 24970,
									["min"] = 24970,
									["count"] = 1,
									["amount"] = 24970,
								},
							},
							["count"] = 1,
							["amount"] = 24970,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["DOTs"] = {
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 27,
								},
								["Apothecary Hummel"] = {
									["count"] = 24,
								},
								["Apothecary Baxter"] = {
									["count"] = 27,
								},
							},
							["amount"] = 78,
						},
						["Combustion (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 18,
								},
								["Apothecary Hummel"] = {
									["count"] = 66,
								},
								["Apothecary Baxter"] = {
									["count"] = 66,
								},
							},
							["amount"] = 150,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 84,
								},
								["Apothecary Hummel"] = {
									["count"] = 48,
								},
								["Apothecary Baxter"] = {
									["count"] = 60,
								},
							},
							["amount"] = 192,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 51,
								},
								["Apothecary Hummel"] = {
									["count"] = 60,
								},
								["Apothecary Baxter"] = {
									["count"] = 60,
								},
							},
							["amount"] = 171,
						},
					},
					["ShieldedWho"] = {
						["Acindor-Jubei'Thos"] = {
							["Details"] = {
								["Ice Barrier"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 24970,
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 32,
								},
								["Crit"] = {
									["count"] = 72,
								},
								["Tick"] = {
									["count"] = 154,
								},
							},
							["amount"] = 258,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 14364,
						["Nature"] = 29314,
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 591,
					["Damage"] = 7944620,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Fire"] = 7944620,
					},
					["PartialAbsorb"] = {
						["Irresistible Cologne"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 1970,
									["min"] = 1624,
									["count"] = 12,
									["amount"] = 21280,
								},
							},
							["count"] = 12,
							["amount"] = 21280,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 2682,
									["min"] = 2673,
									["count"] = 3,
									["amount"] = 8034,
								},
							},
							["count"] = 3,
							["amount"] = 8034,
						},
						["Melee"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 14364,
									["min"] = 14364,
									["count"] = 1,
									["amount"] = 14364,
								},
							},
							["count"] = 1,
							["amount"] = 14364,
						},
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 527205,
								},
								["Inferno Blast"] = {
									["count"] = 77854,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 633048,
								},
								["Ignite (DoT)"] = {
									["count"] = 301578,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 97028,
								},
								["Pyroblast"] = {
									["count"] = 185506,
								},
								["Combustion (DoT)"] = {
									["count"] = 60296,
								},
								["Living Bomb"] = {
									["count"] = 227209,
								},
							},
							["amount"] = 2109724,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 971352,
								},
								["Inferno Blast"] = {
									["count"] = 176706,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 449764,
								},
								["Combustion (DoT)"] = {
									["count"] = 211037,
								},
								["Combustion"] = {
									["count"] = 66411,
								},
								["Living Bomb"] = {
									["count"] = 198953,
								},
								["Pyroblast"] = {
									["count"] = 708272,
								},
								["Ignite (DoT)"] = {
									["count"] = 405236,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 81920,
								},
							},
							["amount"] = 3269651,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 558834,
								},
								["Pyroblast"] = {
									["count"] = 538774,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 489223,
								},
								["Ignite (DoT)"] = {
									["count"] = 363809,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 88727,
								},
								["Inferno Blast"] = {
									["count"] = 136765,
								},
								["Combustion (DoT)"] = {
									["count"] = 192705,
								},
								["Living Bomb"] = {
									["count"] = 196408,
								},
							},
							["amount"] = 2565245,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 12,
									["amount"] = 0,
								},
							},
							["count"] = 12,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Acindor-Jubei'Thos"] = {
							["Details"] = {
								["Ice Barrier"] = {
									["count"] = 24970,
								},
							},
							["amount"] = 24970,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 4.069999999999999,
								},
								["Inferno Blast"] = {
									["count"] = 1.16,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 9.879999999999999,
								},
								["Ignite (DoT)"] = {
									["count"] = 9.550000000000001,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 2.59,
								},
								["Pyroblast"] = {
									["count"] = 0.44,
								},
								["Combustion (DoT)"] = {
									["count"] = 0.52,
								},
								["Living Bomb"] = {
									["count"] = 0.26,
								},
							},
							["amount"] = 28.47,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 8.310000000000001,
								},
								["Inferno Blast"] = {
									["count"] = 4.680000000000001,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 5.91,
								},
								["Combustion (DoT)"] = {
									["count"] = 7.209999999999999,
								},
								["Combustion"] = {
									["count"] = 0.91,
								},
								["Living Bomb"] = {
									["count"] = 0.07000000000000001,
								},
								["Pyroblast"] = {
									["count"] = 0.8500000000000001,
								},
								["Ignite (DoT)"] = {
									["count"] = 8.969999999999999,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 3.82,
								},
							},
							["amount"] = 40.72999999999997,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 2.74,
								},
								["Pyroblast"] = {
									["count"] = 1.97,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 4.34,
								},
								["Ignite (DoT)"] = {
									["count"] = 11.06,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 3.089999999999999,
								},
								["Inferno Blast"] = {
									["count"] = 0.6399999999999999,
								},
								["Combustion (DoT)"] = {
									["count"] = 5.299999999999999,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 29.13999999999999,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["Ice Barrier"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 24970,
									["min"] = 24970,
									["count"] = 1,
									["amount"] = 24970,
								},
							},
							["count"] = 1,
							["amount"] = 24970,
						},
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 98.33999999999998,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["Fireball"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 141060,
									["min"] = 94248,
									["count"] = 10,
									["amount"] = 1085420,
								},
								["Hit"] = {
									["max"] = 70446,
									["min"] = 45105,
									["count"] = 18,
									["amount"] = 971971,
								},
							},
							["count"] = 28,
							["amount"] = 2057391,
						},
						["Inferno Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 56249,
									["min"] = 38335,
									["count"] = 9,
									["amount"] = 391325,
								},
							},
							["count"] = 9,
							["amount"] = 391325,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 45614,
									["min"] = 29135,
									["count"] = 25,
									["amount"] = 896383,
								},
								["Tick"] = {
									["max"] = 22807,
									["min"] = 14159,
									["count"] = 39,
									["amount"] = 675652,
								},
							},
							["count"] = 64,
							["amount"] = 1572035,
						},
						["Combustion (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 15074,
									["min"] = 13804,
									["count"] = 13,
									["amount"] = 193422,
								},
								["Tick"] = {
									["max"] = 7538,
									["min"] = 6902,
									["count"] = 37,
									["amount"] = 270616,
								},
							},
							["count"] = 50,
							["amount"] = 464038,
						},
						["Combustion"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 66411,
									["min"] = 66411,
									["count"] = 1,
									["amount"] = 66411,
								},
							},
							["count"] = 1,
							["amount"] = 66411,
						},
						["Living Bomb"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 79064,
									["min"] = 58671,
									["count"] = 6,
									["amount"] = 398682,
								},
								["Hit"] = {
									["max"] = 44939,
									["min"] = 29335,
									["count"] = 7,
									["amount"] = 223888,
								},
							},
							["count"] = 13,
							["amount"] = 622570,
						},
						["Pyroblast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 235930,
									["min"] = 187409,
									["count"] = 4,
									["amount"] = 805225,
								},
								["Hit"] = {
									["max"] = 138977,
									["min"] = 88733,
									["count"] = 6,
									["amount"] = 627327,
								},
							},
							["count"] = 10,
							["amount"] = 1432552,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 43734,
									["min"] = 4192,
									["count"] = 57,
									["amount"] = 1070623,
								},
							},
							["count"] = 57,
							["amount"] = 1070623,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 20888,
									["min"] = 15327,
									["count"] = 5,
									["amount"] = 85955,
								},
								["Tick"] = {
									["max"] = 10444,
									["min"] = 7664,
									["count"] = 21,
									["amount"] = 181720,
								},
							},
							["count"] = 26,
							["amount"] = 267675,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 98.33999999999998,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 4.069999999999999,
								},
								["Inferno Blast"] = {
									["count"] = 1.16,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 9.879999999999999,
								},
								["Ignite (DoT)"] = {
									["count"] = 9.550000000000001,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 2.59,
								},
								["Pyroblast"] = {
									["count"] = 0.44,
								},
								["Combustion (DoT)"] = {
									["count"] = 0.52,
								},
								["Living Bomb"] = {
									["count"] = 0.26,
								},
							},
							["amount"] = 28.47,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 8.310000000000001,
								},
								["Inferno Blast"] = {
									["count"] = 4.680000000000001,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 5.91,
								},
								["Combustion (DoT)"] = {
									["count"] = 7.209999999999999,
								},
								["Combustion"] = {
									["count"] = 0.91,
								},
								["Living Bomb"] = {
									["count"] = 0.07000000000000001,
								},
								["Pyroblast"] = {
									["count"] = 0.8500000000000001,
								},
								["Ignite (DoT)"] = {
									["count"] = 8.969999999999999,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 3.82,
								},
							},
							["amount"] = 40.72999999999997,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 2.74,
								},
								["Pyroblast"] = {
									["count"] = 1.97,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 4.34,
								},
								["Ignite (DoT)"] = {
									["count"] = 11.06,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 3.089999999999999,
								},
								["Inferno Blast"] = {
									["count"] = 0.6399999999999999,
								},
								["Combustion (DoT)"] = {
									["count"] = 5.299999999999999,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 29.13999999999999,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["DOTs"] = {
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 27,
								},
								["Apothecary Hummel"] = {
									["count"] = 24,
								},
								["Apothecary Baxter"] = {
									["count"] = 27,
								},
							},
							["amount"] = 78,
						},
						["Combustion (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 18,
								},
								["Apothecary Hummel"] = {
									["count"] = 66,
								},
								["Apothecary Baxter"] = {
									["count"] = 66,
								},
							},
							["amount"] = 150,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 84,
								},
								["Apothecary Hummel"] = {
									["count"] = 48,
								},
								["Apothecary Baxter"] = {
									["count"] = 60,
								},
							},
							["amount"] = 192,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Apothecary Frye"] = {
									["count"] = 51,
								},
								["Apothecary Hummel"] = {
									["count"] = 60,
								},
								["Apothecary Baxter"] = {
									["count"] = 60,
								},
							},
							["amount"] = 171,
						},
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
								["Miss"] = {
									["count"] = 3,
								},
							},
							["amount"] = 4,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["HealedWho"] = {
						["Acindor-Jubei'Thos"] = {
							["Details"] = {
								["Ice Barrier"] = {
									["count"] = 24970,
								},
							},
							["amount"] = 24970,
						},
					},
					["PartialResist"] = {
						["Irresistible Cologne"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 12,
									["amount"] = 0,
								},
							},
							["count"] = 12,
							["amount"] = 0,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["Slashing Claws"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Irresistible Cologne"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 1970,
									["min"] = 1624,
									["count"] = 12,
									["amount"] = 21280,
								},
							},
							["count"] = 12,
							["amount"] = 21280,
						},
						["Concentrated Irresistible Cologne Spill"] = {
							["Details"] = {
								["Absorbed"] = {
									["max"] = 2682,
									["min"] = 2673,
									["count"] = 3,
									["amount"] = 8034,
								},
							},
							["count"] = 3,
							["amount"] = 8034,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
								["Absorbed"] = {
									["max"] = 14364,
									["min"] = 14364,
									["count"] = 1,
									["amount"] = 14364,
								},
							},
							["count"] = 4,
							["amount"] = 14364,
						},
						["Slashing Claws"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 98.33999999999998,
					["DOT_Time"] = 591,
					["Damage"] = 7944620,
					["Heals"] = {
						["Ice Barrier"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 24970,
									["min"] = 24970,
									["count"] = 1,
									["amount"] = 24970,
								},
							},
							["count"] = 1,
							["amount"] = 24970,
						},
					},
					["ShieldedWho"] = {
						["Acindor-Jubei'Thos"] = {
							["Details"] = {
								["Ice Barrier"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["ElementDone"] = {
						["Fire"] = 7944620,
					},
					["Absorbs"] = 24970,
					["Attacks"] = {
						["Fireball"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 141060,
									["min"] = 94248,
									["count"] = 10,
									["amount"] = 1085420,
								},
								["Hit"] = {
									["max"] = 70446,
									["min"] = 45105,
									["count"] = 18,
									["amount"] = 971971,
								},
							},
							["count"] = 28,
							["amount"] = 2057391,
						},
						["Inferno Blast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 56249,
									["min"] = 38335,
									["count"] = 9,
									["amount"] = 391325,
								},
							},
							["count"] = 9,
							["amount"] = 391325,
						},
						["Pyroblast (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 45614,
									["min"] = 29135,
									["count"] = 25,
									["amount"] = 896383,
								},
								["Tick"] = {
									["max"] = 22807,
									["min"] = 14159,
									["count"] = 39,
									["amount"] = 675652,
								},
							},
							["count"] = 64,
							["amount"] = 1572035,
						},
						["Combustion (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 15074,
									["min"] = 13804,
									["count"] = 13,
									["amount"] = 193422,
								},
								["Tick"] = {
									["max"] = 7538,
									["min"] = 6902,
									["count"] = 37,
									["amount"] = 270616,
								},
							},
							["count"] = 50,
							["amount"] = 464038,
						},
						["Combustion"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 66411,
									["min"] = 66411,
									["count"] = 1,
									["amount"] = 66411,
								},
							},
							["count"] = 1,
							["amount"] = 66411,
						},
						["Living Bomb"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 79064,
									["min"] = 58671,
									["count"] = 6,
									["amount"] = 398682,
								},
								["Hit"] = {
									["max"] = 44939,
									["min"] = 29335,
									["count"] = 7,
									["amount"] = 223888,
								},
							},
							["count"] = 13,
							["amount"] = 622570,
						},
						["Pyroblast"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 235930,
									["min"] = 187409,
									["count"] = 4,
									["amount"] = 805225,
								},
								["Hit"] = {
									["max"] = 138977,
									["min"] = 88733,
									["count"] = 6,
									["amount"] = 627327,
								},
							},
							["count"] = 10,
							["amount"] = 1432552,
						},
						["Ignite (DoT)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 43734,
									["min"] = 4192,
									["count"] = 57,
									["amount"] = 1070623,
								},
							},
							["count"] = 57,
							["amount"] = 1070623,
						},
						["Living Bomb (DoT)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 20888,
									["min"] = 15327,
									["count"] = 5,
									["amount"] = 85955,
								},
								["Tick"] = {
									["max"] = 10444,
									["min"] = 7664,
									["count"] = 21,
									["amount"] = 181720,
								},
							},
							["count"] = 26,
							["amount"] = 267675,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 14364,
						["Nature"] = 29314,
					},
					["DamagedWho"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 527205,
								},
								["Inferno Blast"] = {
									["count"] = 77854,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 633048,
								},
								["Ignite (DoT)"] = {
									["count"] = 301578,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 97028,
								},
								["Pyroblast"] = {
									["count"] = 185506,
								},
								["Combustion (DoT)"] = {
									["count"] = 60296,
								},
								["Living Bomb"] = {
									["count"] = 227209,
								},
							},
							["amount"] = 2109724,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 971352,
								},
								["Inferno Blast"] = {
									["count"] = 176706,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 449764,
								},
								["Combustion (DoT)"] = {
									["count"] = 211037,
								},
								["Combustion"] = {
									["count"] = 66411,
								},
								["Living Bomb"] = {
									["count"] = 198953,
								},
								["Pyroblast"] = {
									["count"] = 708272,
								},
								["Ignite (DoT)"] = {
									["count"] = 405236,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 81920,
								},
							},
							["amount"] = 3269651,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 558834,
								},
								["Pyroblast"] = {
									["count"] = 538774,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 489223,
								},
								["Ignite (DoT)"] = {
									["count"] = 363809,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 88727,
								},
								["Inferno Blast"] = {
									["count"] = 136765,
								},
								["Combustion (DoT)"] = {
									["count"] = 192705,
								},
								["Living Bomb"] = {
									["count"] = 196408,
								},
							},
							["amount"] = 2565245,
						},
					},
					["TimeDamage"] = 98.33999999999998,
					["TimeDamaging"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 4.069999999999999,
								},
								["Inferno Blast"] = {
									["count"] = 1.16,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 9.879999999999999,
								},
								["Ignite (DoT)"] = {
									["count"] = 9.550000000000001,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 2.59,
								},
								["Pyroblast"] = {
									["count"] = 0.44,
								},
								["Combustion (DoT)"] = {
									["count"] = 0.52,
								},
								["Living Bomb"] = {
									["count"] = 0.26,
								},
							},
							["amount"] = 28.47,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 8.310000000000001,
								},
								["Inferno Blast"] = {
									["count"] = 4.680000000000001,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 5.91,
								},
								["Combustion (DoT)"] = {
									["count"] = 7.209999999999999,
								},
								["Combustion"] = {
									["count"] = 0.91,
								},
								["Living Bomb"] = {
									["count"] = 0.07000000000000001,
								},
								["Pyroblast"] = {
									["count"] = 0.8500000000000001,
								},
								["Ignite (DoT)"] = {
									["count"] = 8.969999999999999,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 3.82,
								},
							},
							["amount"] = 40.72999999999997,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 2.74,
								},
								["Pyroblast"] = {
									["count"] = 1.97,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 4.34,
								},
								["Ignite (DoT)"] = {
									["count"] = 11.06,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 3.089999999999999,
								},
								["Inferno Blast"] = {
									["count"] = 0.6399999999999999,
								},
								["Combustion (DoT)"] = {
									["count"] = 5.299999999999999,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 29.13999999999999,
						},
					},
					["ElementHitsDone"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 32,
								},
								["Crit"] = {
									["count"] = 72,
								},
								["Tick"] = {
									["count"] = 154,
								},
							},
							["amount"] = 258,
						},
					},
					["TimeSpent"] = {
						["Apothecary Frye"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 4.069999999999999,
								},
								["Inferno Blast"] = {
									["count"] = 1.16,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 9.879999999999999,
								},
								["Ignite (DoT)"] = {
									["count"] = 9.550000000000001,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 2.59,
								},
								["Pyroblast"] = {
									["count"] = 0.44,
								},
								["Combustion (DoT)"] = {
									["count"] = 0.52,
								},
								["Living Bomb"] = {
									["count"] = 0.26,
								},
							},
							["amount"] = 28.47,
						},
						["Apothecary Hummel"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 8.310000000000001,
								},
								["Inferno Blast"] = {
									["count"] = 4.680000000000001,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 5.91,
								},
								["Combustion (DoT)"] = {
									["count"] = 7.209999999999999,
								},
								["Combustion"] = {
									["count"] = 0.91,
								},
								["Living Bomb"] = {
									["count"] = 0.07000000000000001,
								},
								["Pyroblast"] = {
									["count"] = 0.8500000000000001,
								},
								["Ignite (DoT)"] = {
									["count"] = 8.969999999999999,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 3.82,
								},
							},
							["amount"] = 40.72999999999997,
						},
						["Apothecary Baxter"] = {
							["Details"] = {
								["Fireball"] = {
									["count"] = 2.74,
								},
								["Pyroblast"] = {
									["count"] = 1.97,
								},
								["Pyroblast (DoT)"] = {
									["count"] = 4.34,
								},
								["Ignite (DoT)"] = {
									["count"] = 11.06,
								},
								["Living Bomb (DoT)"] = {
									["count"] = 3.089999999999999,
								},
								["Inferno Blast"] = {
									["count"] = 0.6399999999999999,
								},
								["Combustion (DoT)"] = {
									["count"] = 5.299999999999999,
								},
								["Living Bomb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 29.13999999999999,
						},
					},
					["Absorbed"] = {
						["Ice Barrier"] = {
							["Details"] = {
								["Acindor-Jubei'Thos"] = {
									["max"] = 24970,
									["min"] = 24970,
									["count"] = 1,
									["amount"] = 24970,
								},
							},
							["count"] = 1,
							["amount"] = 24970,
						},
					},
				},
			},
			["UnitLockout"] = 1360559617,
			["LastActive"] = 1360559620,
		},
	},
	["FightNum"] = 2,
	["CombatTimes"] = {
		{
			1360559347, -- [1]
			1360559375, -- [2]
			"21:09:07", -- [3]
			"21:09:35", -- [4]
			"Frantic Geist", -- [5]
		}, -- [1]
		{
			1360559523, -- [1]
			1360559622, -- [2]
			"21:12:03", -- [3]
			"21:13:42", -- [4]
			"Apothecary Hummel", -- [5]
		}, -- [2]
	},
	["FoughtWho"] = {
		"Apothecary Hummel 21:12:03-21:13:42", -- [1]
		"Frantic Geist 21:09:07-21:09:35", -- [2]
	},
}
