
EavesDropStatsDB = {
	["profileKeys"] = {
		["Starrsight - Nathrezim"] = "Starrsight - Nathrezim",
	},
	["profiles"] = {
		["Starrsight - Nathrezim"] = {
			{
				["heal"] = {
					["Renewal"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 08:32:10|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:108238:SPELL_HEAL|h|cffffffffRenewal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000036A9980:Starrsight|hYou|h |cffffffff8631|r |cffffffffNature|r. (32782 Overhealed) ",
							["amount"] = 41413,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_NatureBlessing",
					},
					["Leader of the Pack"] = {
						[-2] = {
							["time"] = "|cffffffff12/08/12 07:46:35|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:34299:SPELL_PERIODIC_HEAL|h|cffffffffLeader of the Pack|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000036A9980:Starrsight|hYou|h |cffffffff6510|r |cffffffffPhysical|r. ",
							["amount"] = 6510,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_UnyeildingStamina",
					},
					["Healing Potion"] = {
						[-2] = {
						},
						[2] = {
							["time"] = "|cffffffff12/15/12 08:45:51|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:78989:SPELL_HEAL|h|cffffffffHealing Potion|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000036A9980:Starrsight|hYou|h |cffffffff49539|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 49539,
						},
						["icon"] = "INTERFACE\\ICONS\\inv_misc_potionsetf",
					},
					["Rejuvenation"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 08:32:20|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cffffffffRejuvenation|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000036A9980:Starrsight|hYou|h |cffffffff3093|r |cffffffffNature|r. (2863 Overhealed) ",
							["amount"] = 5956,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Rejuvenation",
					},
					["Lifeblood"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 08:49:30|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:74497:SPELL_HEAL|h|cffffffffLifeblood|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000036A9980:Starrsight|hYou|h |cffffffff2432|r |cffffffffNature|r. ",
							["amount"] = 2432,
						},
						[2] = {
							["time"] = "|cffffffff12/15/12 08:41:59|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:74497:SPELL_HEAL|h|cffffffffLifeblood|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000036A9980:Starrsight|hYou|h |cffffffff0|r |cffffffffNature|r. (5271 Overhealed) (Critical) ",
							["amount"] = 5271,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_WispSplodeGreen",
					},
					["Frenzied Regeneration"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 08:45:51|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:22842:SPELL_HEAL|h|cffffffffFrenzied Regeneration|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000036A9980:Starrsight|hYou|h |cffffffff10262|r |cffffffffPhysical|r. ",
							["amount"] = 10262,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_BullRush",
					},
				},
				["hit"] = {
					["Ravage"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 08:14:19|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:6785:SPELL_DAMAGE|h|cffffffffRavage|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13102EA003CBD44:Garrosh'ar Grunt|hGarrosh'ar Grunt|h |cffffffff14153|r |cffffffffPhysical|r. ",
							["amount"] = 14153,
						},
						[2] = {
							["time"] = "|cffffffff12/08/12 07:45:52|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:6785:SPELL_DAMAGE|h|cffffffffRavage|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF53102E8002122E3:Garrosh'ar Peon|hGarrosh'ar Peon|h |cffffffff31875|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 31875,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Ravage",
					},
					["Faerie Fire"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 08:49:37|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:770:SPELL_DAMAGE|h|cffffffffFaerie Fire|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13102EA003D18BF:Garrosh'ar Grunt|hGarrosh'ar Grunt|h |cffffffff5837|r |cffffffffNature|r. ",
							["amount"] = 5837,
						},
						[2] = {
							["time"] = "|cffffffff12/15/12 08:42:15|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:770:SPELL_DAMAGE|h|cffffffffFaerie Fire|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13102F2003CFAAF:Garrosh'ar Gear-Greaser|hGarrosh'ar Gear-Greaser|h |cffffffff12482|r |cffffffffNature|r. (Critical) ",
							["amount"] = 12482,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_FaerieFire",
					},
					["Rake"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 08:12:26|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:1822:SPELL_DAMAGE|h|cffffffffRake|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13102F2003C78AC:Garrosh'ar Gear-Greaser|hGarrosh'ar Gear-Greaser|h |cffffffff3529|r |cffffffffPhysical|r. ",
							["amount"] = 3529,
						},
						[2] = {
							["time"] = "|cffffffff12/15/12 08:12:32|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:1822:SPELL_PERIODIC_DAMAGE|h|cffffffffRake|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF13102F2003C78AC:Garrosh'ar Gear-Greaser|hGarrosh'ar Gear-Greaser|h |cffffffff7269|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 7269,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Disembowel",
					},
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 08:44:06|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF13102F20039833A:Garrosh'ar Gear-Greaser|hGarrosh'ar Gear-Greaser|h |cffffffff5167|r |cffffffffPhysical|r. ",
							["amount"] = 5167,
						},
						[2] = {
							["time"] = "|cffffffff12/15/12 08:49:32|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF13102EA003D18BF:Garrosh'ar Grunt|hGarrosh'ar Grunt|h |cffffffff11086|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 11086,
						},
					},
					["Ferocious Bite"] = {
						[-2] = {
							["time"] = "|cffffffff12/08/12 07:46:31|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:22568:SPELL_DAMAGE|h|cffffffffFerocious Bite|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF53102F20022864B:Garrosh'ar Gear-Greaser|hGarrosh'ar Gear-Greaser|h |cffffffff19226|r |cffffffffPhysical|r. ",
							["amount"] = 19226,
						},
						[2] = {
							["time"] = "|cffffffff12/08/12 07:46:13|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:22568:SPELL_DAMAGE|h|cffffffffFerocious Bite|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF53102EA002282CD:Garrosh'ar Grunt|hGarrosh'ar Grunt|h |cffffffff36258|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 36258,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_FerociousBite",
					},
					["Swipe"] = {
						[-2] = {
							["time"] = "|cffffffff12/08/12 07:42:40|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:62078:SPELL_DAMAGE|h|cffffffffSwipe|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF53102EA002217C0:Garrosh'ar Grunt|hGarrosh'ar Grunt|h |cffffffff8202|r |cffffffffPhysical|r. ",
							["amount"] = 8202,
						},
						[2] = {
							["time"] = "|cffffffff12/15/12 08:42:12|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:779:SPELL_DAMAGE|h|cffffffffSwipe|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13102F2003CFAAF:Garrosh'ar Gear-Greaser|hGarrosh'ar Gear-Greaser|h |cffffffff8119|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 8119,
						},
						["icon"] = "Interface\\Icons\\INV_Misc_MonsterClaw_03",
					},
					["Lacerate"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 08:44:02|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:33745:SPELL_DAMAGE|h|cffffffffLacerate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13102EA003D0422:Garrosh'ar Grunt|hGarrosh'ar Grunt|h |cffffffff8388|r |cffffffffPhysical|r. ",
							["amount"] = 8388,
						},
						[2] = {
							["time"] = "|cffffffff12/15/12 08:42:14|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:33745:SPELL_DAMAGE|h|cffffffffLacerate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13102F2003CFAAF:Garrosh'ar Gear-Greaser|hGarrosh'ar Gear-Greaser|h |cffffffff17779|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 17779,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Lacerate",
					},
					["Maul"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 08:42:13|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:6807:SPELL_DAMAGE|h|cffffffffMaul|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13102F2003CFAAF:Garrosh'ar Gear-Greaser|hGarrosh'ar Gear-Greaser|h |cffffffff7197|r |cffffffffPhysical|r. ",
							["amount"] = 7197,
						},
						[2] = {
							["time"] = "|cffffffff12/15/12 08:44:17|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:6807:SPELL_DAMAGE|h|cffffffffMaul|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13102EA003989A7:Garrosh'ar Grunt|hGarrosh'ar Grunt|h |cffffffff14378|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 14378,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Maul",
					},
					["Mangle"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 08:44:16|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:33878:SPELL_DAMAGE|h|cffffffffMangle|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13102EA003989A7:Garrosh'ar Grunt|hGarrosh'ar Grunt|h |cffffffff14747|r |cffffffffPhysical|r. ",
							["amount"] = 14747,
						},
						[2] = {
							["time"] = "|cffffffff12/15/12 08:49:33|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:33878:SPELL_DAMAGE|h|cffffffffMangle|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13102EA003D18BF:Garrosh'ar Grunt|hGarrosh'ar Grunt|h |cffffffff31172|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 31172,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Mangle2",
					},
					["Thrash"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 08:49:35|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:77758:SPELL_DAMAGE|h|cffffffffThrash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13102EA003D18BF:Garrosh'ar Grunt|hGarrosh'ar Grunt|h |cffffffff4806|r |cffffffffPhysical|r. ",
							["amount"] = 4806,
						},
						[2] = {
							["time"] = "|cffffffff12/15/12 08:42:06|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:77758:SPELL_DAMAGE|h|cffffffffThrash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13102EA003D0532:Garrosh'ar Grunt|hGarrosh'ar Grunt|h |cffffffff9632|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 9632,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_druid_thrash",
					},
					["Rip"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 08:12:34|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:1079:SPELL_PERIODIC_DAMAGE|h|cffffffffRip|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF13102F2003C78AC:Garrosh'ar Gear-Greaser|hGarrosh'ar Gear-Greaser|h |cffffffff4317|r |cffffffffPhysical|r. ",
							["amount"] = 4317,
						},
						[2] = {
							["time"] = "|cffffffff12/15/12 08:16:40|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:1079:SPELL_PERIODIC_DAMAGE|h|cffffffffRip|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF13102F200391C21:Garrosh'ar Gear-Greaser|hGarrosh'ar Gear-Greaser|h |cffffffff8892|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 8892,
						},
						["icon"] = "Interface\\Icons\\Ability_GhoulFrenzy",
					},
					["Pounce Bleed"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 08:16:42|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:9007:SPELL_PERIODIC_DAMAGE|h|cffffffffPounce Bleed|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF13102F200391C21:Garrosh'ar Gear-Greaser|hGarrosh'ar Gear-Greaser|h |cffffffff1296|r |cffffffffPhysical|r. ",
							["amount"] = 1296,
						},
						[2] = {
							["time"] = "|cffffffff12/15/12 08:16:30|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:9007:SPELL_PERIODIC_DAMAGE|h|cffffffffPounce Bleed|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF13102F200391C21:Garrosh'ar Gear-Greaser|hGarrosh'ar Gear-Greaser|h |cffffffff2669|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 2669,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_VampiricAura",
					},
					["Thorns"] = {
						[-2] = {
							["time"] = "|cffffffff12/22/12 06:12:13|r\n|Hunit:0x01000000036A9980:Starrsight|hYour|h |Hspell:33907:DAMAGE_SHIELD|h|cffffffffThorns|r|h |Haction:DAMAGE_SHIELD|hdamages|h |Hunit:0xF5310AED002FA4FD:Horde Priest|hHorde Priest|h |cffffffff57|r |cffffffffNature|r. ",
							["amount"] = 57,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Thorns",
					},
				},
			}, -- [1]
			[-1] = {
				["hit"] = {
					["Physical"] = {
						[-2] = {
							["time"] = "|cffffffff12/22/12 06:19:38|r\n|Haction:ENVIRONMENTAL_DAMAGE|h|cffffffffFalling|r|h |Haction:ENVIRONMENTAL_DAMAGE|hdamaged|h |Hunit:0x01000000036A9980:Starrsight|hYou|h |cffffffff19151|r |cffffffffPhysical|r. ",
							["amount"] = 19151,
						},
						[2] = {
						},
					},
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff12/22/12 06:34:19|r\n|Hunit:0x0100000004385137:Vålence|hVålence|h |Hspell:78674:SPELL_DAMAGE|h|cffff1313Starsurge|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000036A9980:Starrsight|hYou|h |cffff13139846|r |cffff1313Spellstorm|r. ",
							["amount"] = 9846,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Arcane_Arcane03",
					},
					["Arcane"] = {
						[-2] = {
							["time"] = "|cffffffff12/22/12 06:34:37|r\n|Hunit:0x0100000004385137:Vålence|hVålence|h |Hspell:2912:SPELL_DAMAGE|h|cffff1313Starfire|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000036A9980:Starrsight|hYou|h |cffff13139597|r |cffff1313Arcane|r. ",
							["amount"] = 9597,
						},
						[2] = {
							["time"] = "|cffffffff12/22/12 06:34:24|r\n|Hunit:0x0100000004385137:Vålence|hVålence|h |Hspell:50288:SPELL_DAMAGE|h|cffff1313Starfall|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000036A9980:Starrsight|hYou|h |cffff13132021|r |cffff1313Arcane|r. (Critical) ",
							["amount"] = 2021,
						},
						["icon"] = "Interface\\Icons\\Spell_Arcane_StarFire",
					},
					["Fire"] = {
						[-2] = {
							["time"] = "|cffffffff12/15/12 08:49:04|r\n|Hunit:0xF1310317003CFBAB:Garrosh'ar Shredder|hGarrosh'ar Shredder|h |Hspell:131000:SPELL_DAMAGE|h|cffff1313Ground Rockets|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000036A9980:Starrsight|hYou|h |cffff13137693|r |cffff1313Fire|r. ",
							["amount"] = 7693,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Misc_MissileLarge_Red",
					},
					["Shadow"] = {
						[-2] = {
							["time"] = "|cffffffff12/22/12 06:12:14|r\n|Hunit:0xF5310AED002FA4FD:Horde Priest|hHorde Priest|h |Hspell:16568:SPELL_PERIODIC_DAMAGE|h|cffff1313Mind Flay|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x01000000036A9980:Starrsight|hYou|h |cffff13133117|r |cffff1313Shadow|r. ",
							["amount"] = 3117,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_SiphonMana",
					},
					["Nature"] = {
						[-2] = {
							["time"] = "|cffffffff12/22/12 06:14:37|r\n|Hunit:0xF530E3680031A075:Wildscale Herbalist|hWildscale Herbalist|h |Hspell:119577:SPELL_DAMAGE|h|cffff1313Wrath|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000036A9980:Starrsight|hYou|h |cffff13134040|r |cffff1313Nature|r. ",
							["amount"] = 4040,
						},
						[2] = {
							["time"] = "|cffffffff12/22/12 06:34:33|r\n|Hunit:0x0100000004385137:Vålence|hVålence|h |Hspell:5176:SPELL_DAMAGE|h|cffff1313Wrath|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000036A9980:Starrsight|hYou|h |cffff13137245|r |cffff1313Nature|r. (Critical) ",
							["amount"] = 7245,
						},
						["icon"] = "Interface\\Icons\\spell_nature_wrathv2",
					},
				},
			},
		},
	},
}
