
FishingBuddy_Player = {
	["MinimapData"] = {
		["minimapPos"] = 154.7070293162338,
		["hide"] = false,
	},
	["Settings"] = {
		["ResetWatcher"] = 1,
	},
	["WasWearing"] = {
	},
	["Outfit"] = {
	},
}
