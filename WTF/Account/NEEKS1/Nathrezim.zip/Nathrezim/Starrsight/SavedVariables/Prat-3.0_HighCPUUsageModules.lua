
Prat3HighCPUPerCharDB = {
	["time"] = 1360783664,
	["scrollback"] = {
		["ChatFrame1"] = {
			{
				"|cff979797[11:27:35]|r|c00000000|r |Hchannel:channel:1|h[1] |h Joined Channel: |Hchannel:1|h[1. General - Mount Hyjal]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				69, -- [5]
			}, -- [1]
			{
				"|cff979797[11:27:44]|r|c00000000|r |cffaad372Central|r added to friends.", -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
				1, -- [5]
			}, -- [2]
		},
	},
}
