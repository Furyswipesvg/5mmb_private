
REFDatabase = {
}
REFSettings = {
	["ArenaSupport"] = true,
	["MiniBarScale"] = 1,
	["MiniBarAnchor"] = "CENTER",
	["MiniBarOrder"] = {
		{
			"KillingBlows", -- [1]
			"HonorKills", -- [2]
			"Damage", -- [3]
			"Healing", -- [4]
			"Deaths", -- [5]
			"KDRatio", -- [6]
			"Honor", -- [7]
		}, -- [1]
		{
			"KillingBlows", -- [1]
			"HonorKills", -- [2]
			"Damage", -- [3]
			"Healing", -- [4]
			"Deaths", -- [5]
			"KDRatio", -- [6]
			"Honor", -- [7]
		}, -- [2]
	},
	["LDBShowPlace"] = false,
	["LastDayStats"] = {
		["2v2"] = 0,
		["3v3"] = 0,
		["RBG"] = 0,
		["Honor"] = 322,
		["CP"] = 0,
		["5v5"] = 0,
		["MMRBG"] = 0,
		["MMR"] = 0,
	},
	["RBGListFirstTime"] = true,
	["ShowMiniBar"] = false,
	["LDBBGMorph"] = true,
	["ShowMinimapButton"] = true,
	["MiniBarY"] = 0,
	["UNBGSupport"] = true,
	["LDBShowQueues"] = true,
	["MinimapPos"] = 45,
	["MiniBarVisible"] = {
		{
			["KillingBlows"] = 1,
			["HonorKills"] = 1,
			["Healing"] = 2,
			["Damage"] = 2,
		}, -- [1]
		{
			["KillingBlows"] = 1,
			["HonorKills"] = 1,
			["Healing"] = 2,
			["Damage"] = 2,
		}, -- [2]
	},
	["AllowQuery"] = true,
	["Version"] = 19,
	["LDBShowTotalBG"] = false,
	["LDBCPCap"] = true,
	["CurrentMMRBG"] = 0,
	["ArenasListFirstTime"] = true,
	["MiniBarX"] = 0,
	["LDBShowTotalArena"] = false,
	["ShowDetectedBuilds"] = true,
	["LDBHK"] = false,
	["CurrentMMR"] = 0,
	["RBGSupport"] = true,
	["LastDay"] = "13",
	["OnlyNew"] = false,
}
REFDatabaseA = {
	{
		["PlayerTeam"] = 1,
		["GreenTeamRatingChange"] = -6,
		["GoldTeamRating"] = 1338,
		["Season"] = 11,
		["GoldTeamRatingChange"] = 19,
		["MMRChange"] = 0,
		["KB"] = 1,
		["Damage"] = 169966,
		["TimeRaw"] = 1342243404,
		["DataVersion"] = 17,
		["GoldTeam"] = {
			{
				["classToken"] = "MAGE",
				["Healing"] = 4152,
				["Race"] = "Worgen",
				["Name"] = "Chinowolf",
				["KB"] = 2,
				["Build"] = 64,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 204077,
			}, -- [1]
			{
				["classToken"] = "DRUID",
				["Healing"] = 129703,
				["Build"] = 0,
				["Race"] = "NightElf",
				["Name"] = "Starrsight",
				["KB"] = 1,
				["oldBuild"] = "Feral Combat",
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 169966,
			}, -- [2]
			{
				["classToken"] = "DEATHKNIGHT",
				["Healing"] = 9674,
				["Race"] = "Human",
				["Name"] = "Errose",
				["KB"] = 0,
				["Build"] = 251,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 225826,
			}, -- [3]
		},
		["Healing"] = 129703,
		["TalentSet"] = 2,
		["GreenTeamMMR"] = 1335,
		["GreenTeamRating"] = 1176,
		["GreenTeamName"] = "Familia Buscape",
		["DurationRaw"] = 157,
		["Bracket"] = 3,
		["PreMMR"] = 0,
		["MapName"] = "The Ring of Valor",
		["GreenTeam"] = {
			{
				["classToken"] = "PALADIN",
				["Healing"] = 132063,
				["Race"] = "Draenei",
				["Name"] = "Auratus-Gurubashi",
				["KB"] = 0,
				["Build"] = 70,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 81159,
			}, -- [1]
			{
				["classToken"] = "PALADIN",
				["Healing"] = 7983,
				["Race"] = "Draenei",
				["Name"] = "Ryuuzak-Gurubashi",
				["KB"] = 0,
				["Build"] = 65,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 985,
			}, -- [2]
			{
				["classToken"] = "ROGUE",
				["Healing"] = 0,
				["Race"] = "NightElf",
				["Name"] = "Vintecomer-Gurubashi",
				["KB"] = 0,
				["Build"] = 261,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 122656,
			}, -- [3]
		},
		["Winner"] = 1,
		["GoldTeamMMR"] = 1377,
		["GoldTeamName"] = "thresome",
	}, -- [1]
	{
		["PlayerTeam"] = 0,
		["GreenTeamRatingChange"] = 14,
		["GoldTeamRating"] = 759,
		["Season"] = 11,
		["GoldTeamRatingChange"] = -1,
		["MMRChange"] = 0,
		["KB"] = 3,
		["Damage"] = 520236,
		["TimeRaw"] = 1342244099,
		["DataVersion"] = 17,
		["GoldTeam"] = {
			{
				["classToken"] = "MAGE",
				["Healing"] = 53431,
				["Race"] = "BloodElf",
				["Name"] = "Freezeyoazz-Shadowsong",
				["KB"] = 1,
				["Build"] = 64,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 465216,
			}, -- [1]
			{
				["classToken"] = "ROGUE",
				["Healing"] = 89509,
				["Race"] = "BloodElf",
				["Name"] = "Sòmbra-Shadowsong",
				["KB"] = 1,
				["Build"] = 261,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 227767,
			}, -- [2]
			{
				["classToken"] = "PALADIN",
				["Healing"] = 80242,
				["Race"] = "BloodElf",
				["Name"] = "Zanro-Shadowsong",
				["KB"] = 0,
				["Build"] = 70,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 40914,
			}, -- [3]
		},
		["Healing"] = 234973,
		["TalentSet"] = 2,
		["GreenTeamMMR"] = 1365,
		["GreenTeamRating"] = 1343,
		["GreenTeamName"] = "thresome",
		["DurationRaw"] = 335,
		["Bracket"] = 3,
		["PreMMR"] = 0,
		["MapName"] = "Dalaran Arena",
		["GreenTeam"] = {
			{
				["classToken"] = "DRUID",
				["Healing"] = 234973,
				["Build"] = 0,
				["Race"] = "NightElf",
				["Name"] = "Starrsight",
				["KB"] = 3,
				["oldBuild"] = "Feral Combat",
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 520236,
			}, -- [1]
			{
				["classToken"] = "MAGE",
				["Healing"] = 3001,
				["Race"] = "Worgen",
				["Name"] = "Chinowolf",
				["KB"] = 0,
				["Build"] = 64,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 168488,
			}, -- [2]
			{
				["classToken"] = "DEATHKNIGHT",
				["Healing"] = 25451,
				["Race"] = "Human",
				["Name"] = "Errose",
				["KB"] = 0,
				["Build"] = 251,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 53917,
			}, -- [3]
		},
		["Winner"] = 0,
		["GoldTeamMMR"] = 1284,
		["GoldTeamName"] = "Two guys and a mage",
	}, -- [2]
	{
		["PlayerTeam"] = 0,
		["GreenTeamRatingChange"] = -9,
		["GoldTeamRating"] = 1394,
		["Season"] = 11,
		["GoldTeamRatingChange"] = 21,
		["MMRChange"] = 0,
		["KB"] = 0,
		["Damage"] = 273218,
		["TimeRaw"] = 1342244379,
		["DataVersion"] = 17,
		["GoldTeam"] = {
			{
				["classToken"] = "DEATHKNIGHT",
				["Healing"] = 21510,
				["Race"] = "Orc",
				["Name"] = "Ivello-Shadow Council",
				["KB"] = 3,
				["Build"] = 251,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 485890,
			}, -- [1]
			{
				["classToken"] = "WARLOCK",
				["Healing"] = 88792,
				["Race"] = "BloodElf",
				["Name"] = "Demagus-Shadow Council",
				["KB"] = 0,
				["Build"] = 265,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 211585,
			}, -- [2]
			{
				["classToken"] = "SHAMAN",
				["Healing"] = 684749,
				["Race"] = "Orc",
				["Name"] = "Riptyde-Shadow Council",
				["KB"] = 0,
				["Build"] = 264,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 91594,
			}, -- [3]
		},
		["Healing"] = 149385,
		["TalentSet"] = 2,
		["GreenTeamMMR"] = 1419,
		["GreenTeamRating"] = 1334,
		["GreenTeamName"] = "thresome",
		["DurationRaw"] = 179,
		["Bracket"] = 3,
		["PreMMR"] = 0,
		["MapName"] = "Ruins of Lordaeron",
		["GreenTeam"] = {
			{
				["classToken"] = "MAGE",
				["Healing"] = 24000,
				["Race"] = "Worgen",
				["Name"] = "Chinowolf",
				["KB"] = 0,
				["Build"] = 64,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 156080,
			}, -- [1]
			{
				["classToken"] = "DEATHKNIGHT",
				["Healing"] = 4837,
				["Race"] = "Human",
				["Name"] = "Errose",
				["KB"] = 0,
				["Build"] = 251,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 389174,
			}, -- [2]
			{
				["classToken"] = "DRUID",
				["Healing"] = 149385,
				["Build"] = 0,
				["Race"] = "NightElf",
				["Name"] = "Starrsight",
				["KB"] = 0,
				["oldBuild"] = "Feral Combat",
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 273218,
			}, -- [3]
		},
		["Winner"] = 1,
		["GoldTeamMMR"] = 1434,
		["GoldTeamName"] = "Ugly but effective",
	}, -- [3]
	{
		["PlayerTeam"] = 1,
		["GreenTeamRatingChange"] = -15,
		["GoldTeamRating"] = 1342,
		["Season"] = 11,
		["GoldTeamRatingChange"] = 16,
		["MMRChange"] = 0,
		["KB"] = 1,
		["Damage"] = 247757,
		["TimeRaw"] = 1342244986,
		["DataVersion"] = 17,
		["GoldTeam"] = {
			{
				["classToken"] = "MAGE",
				["Healing"] = 57694,
				["Race"] = "Worgen",
				["Name"] = "Chinowolf",
				["KB"] = 1,
				["Build"] = 64,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 101976,
			}, -- [1]
			{
				["classToken"] = "DEATHKNIGHT",
				["Healing"] = 134953,
				["Race"] = "Human",
				["Name"] = "Errose",
				["KB"] = 1,
				["Build"] = 251,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 412110,
			}, -- [2]
			{
				["classToken"] = "DRUID",
				["Healing"] = 44736,
				["Build"] = 0,
				["Race"] = "NightElf",
				["Name"] = "Starrsight",
				["KB"] = 1,
				["oldBuild"] = "Feral Combat",
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 247757,
			}, -- [3]
		},
		["Healing"] = 44736,
		["TalentSet"] = 2,
		["GreenTeamMMR"] = 1435,
		["GreenTeamRating"] = 1396,
		["GreenTeamName"] = "Bum Beads and Cinnamon",
		["DurationRaw"] = 151,
		["Bracket"] = 3,
		["PreMMR"] = 0,
		["MapName"] = "Dalaran Arena",
		["GreenTeam"] = {
			{
				["classToken"] = "DEATHKNIGHT",
				["Healing"] = 130232,
				["Race"] = "NightElf",
				["Name"] = "Fearection-Windrunner",
				["KB"] = 0,
				["Build"] = 251,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 407853,
			}, -- [1]
			{
				["classToken"] = "PRIEST",
				["Healing"] = 5302,
				["Race"] = "Gnome",
				["Name"] = "Poontangle-Windrunner",
				["KB"] = 0,
				["Build"] = 256,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 0,
			}, -- [2]
			{
				["classToken"] = "SHAMAN",
				["Healing"] = 45361,
				["Race"] = "Dwarf",
				["Name"] = "Redeeming-Windrunner",
				["KB"] = 0,
				["Build"] = 263,
				["MMRChange"] = 0,
				["PreMMR"] = 0,
				["Damage"] = 132673,
			}, -- [3]
		},
		["Winner"] = 1,
		["GoldTeamMMR"] = 1311,
		["GoldTeamName"] = "thresome",
	}, -- [4]
}
