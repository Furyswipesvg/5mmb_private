
RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
		["Starrsight"] = {
			["GUID"] = "0x01000000036A9980",
			["LastEventHealth"] = {
				"137144 (91%)", -- [1]
				"135117 (90%)", -- [2]
				"145671 (97%)", -- [3]
				"137156 (91%)", -- [4]
				"127167 (84%)", -- [5]
				"127167 (84%)", -- [6]
				"105978 (70%)", -- [7]
				"105978 (70%)", -- [8]
				"105978 (70%)", -- [9]
				"89287 (59%)", -- [10]
				"89287 (59%)", -- [11]
				"150741 (97%)", -- [12]
			},
			["LastAttackedBy"] = "Seething Pyrelord",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
			},
			["TimeWindows"] = {
				["DamageTaken"] = {
					103806, -- [1]
				},
			},
			["enClass"] = "DRUID",
			["unit"] = "Starrsight",
			["LastActive"] = 1360612906,
			["level"] = 86,
			["LastDamageAbility"] = "Chain Fireball",
			["LastFightIn"] = 1,
			["LastEventNum"] = {
				8.584074335764088, -- [1]
				9.935209502606284, -- [2]
				5.675834210982389, -- [3]
				6.658356774339763, -- [4]
				1.925717561424325, -- [5]
				7.784191651891056, -- [6]
				4.414019277172681, -- [7]
				4.609990534721574, -- [8]
				6.515711029049073, -- [9]
				6.659023343242991, -- [10]
				5.873138606337737, -- [11]
				0.5414555980564458, -- [12]
			},
			["type"] = "Self",
			["FightsSaved"] = 2,
			["LastEventTimes"] = {
				12791.993, -- [1]
				12890.218, -- [2]
				12937.358, -- [3]
				12939.771, -- [4]
				12945.015, -- [5]
				12945.015, -- [6]
				12971.519, -- [7]
				12972.41, -- [8]
				12972.791, -- [9]
				12988.721, -- [10]
				12989.042, -- [11]
				5588.41, -- [12]
			},
			["LastEventIncoming"] = {
				true, -- [1]
				true, -- [2]
				true, -- [3]
				true, -- [4]
				true, -- [5]
				true, -- [6]
				true, -- [7]
				true, -- [8]
				true, -- [9]
				true, -- [10]
				true, -- [11]
				true, -- [12]
			},
			["Owner"] = false,
			["Pet"] = {
				"Hyjal Protector <Starrsight>", -- [1]
				"Image of Archmage Vargoth <Starrsight>", -- [2]
			},
			["NextEventNum"] = 13,
			["LastEventHealthNum"] = {
				91.41592566423591, -- [1]
				90.06479049739372, -- [2]
				97.09975870205703, -- [3]
				91.42392449107464, -- [4]
				84.76556771673488, -- [5]
				84.76556771673488, -- [6]
				70.64163922624682, -- [7]
				70.64163922624682, -- [8]
				70.64163922624682, -- [9]
				59.51593766247617, -- [10]
				59.51593766247617, -- [11]
				97.39804093869533, -- [12]
			},
			["LastEvents"] = {
				"Environment Falling Starrsight Hit -12878 (Physical)", -- [1]
				"Environment Falling Starrsight Hit -14905 (Physical)", -- [2]
				"Vor'thik Dreadsworn Melee Starrsight Hit -8515 (Physical)", -- [3]
				"Vor'thik Dreadsworn Melee Starrsight Hit -9989 (Physical)", -- [4]
				"Nagging Dreadling Melee Starrsight Hit -2889 (Physical)", -- [5]
				"Vor'thik Fear-Shaper Melee Starrsight Crushing -11678 (Physical)", -- [6]
				"Greatback Mushan Mushan Charge Starrsight Hit -6622 (Physical)", -- [7]
				"Greatback Mushan Melee Starrsight Hit -6916 (Physical)", -- [8]
				"Greatback Mushan Melee Starrsight Hit -9775 (Physical)", -- [9]
				"Greatback Mushan Melee Starrsight Hit -9990 (Physical)", -- [10]
				"Greatback Mushan Melee Starrsight Hit -8811 (Physical)", -- [11]
				"Seething Pyrelord Chain Fireball Starrsight Hit -838 (Fire)", -- [12]
			},
			["Name"] = "Starrsight",
			["TimeLast"] = {
				["DamageTaken"] = 1360612906,
				["OVERALL"] = 1360612906,
			},
			["Fights"] = {
				["Fight2"] = {
					["PartialResist"] = {
						["Falling"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Mushan Charge"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Falling"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Mushan Charge"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["Vor'thik Dreadsworn"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 18504,
								},
							},
							["amount"] = 18504,
						},
						["Vor'thik Fear-Shaper"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 11678,
								},
							},
							["amount"] = 11678,
						},
						["Environment"] = {
							["Details"] = {
								["Falling"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Greatback Mushan"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 35492,
								},
								["Mushan Charge"] = {
									["count"] = 6622,
								},
							},
							["amount"] = 42114,
						},
						["Nagging Dreadling"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2889,
								},
							},
							["amount"] = 2889,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 68563,
						["Physical"] = 6622,
					},
					["DamageTaken"] = 75185,
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Crushing"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 8,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 838,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
						["Fire"] = 838,
					},
					["HOTs"] = {
					},
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["DamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
					},
					["ElementHitsDone"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["WhoDamaged"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Chain Fireball"] = {
									["count"] = 838,
								},
							},
							["amount"] = 838,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["CCBroken"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["Dispelled"] = 0,
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["FDamage"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["PartialAbsorb"] = {
						["Chain Fireball"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["Interrupts"] = 0,
					["EnergyGained"] = {
					},
					["PartialResist"] = {
						["Chain Fireball"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["Attacks"] = {
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["DOT_Time"] = 0,
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 838,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTaken"] = {
						["Fire"] = 838,
					},
					["HOTs"] = {
					},
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["DamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["HealingTaken"] = 0,
					["ElementDone"] = {
					},
					["ElementHitsDone"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["WhoDamaged"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Chain Fireball"] = {
									["count"] = 838,
								},
							},
							["amount"] = 838,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["CCBroken"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["Dispelled"] = 0,
					["WhoHealed"] = {
					},
					["HealedWho"] = {
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
					},
					["FDamage"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["PartialAbsorb"] = {
						["Chain Fireball"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["ElementTakenResist"] = {
					},
					["Heals"] = {
					},
					["Interrupts"] = 0,
					["EnergyGained"] = {
					},
					["PartialResist"] = {
						["Chain Fireball"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["Attacks"] = {
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["DOT_Time"] = 0,
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["PartialResist"] = {
						["Falling"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Chain Fireball"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Mushan Charge"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["Falling"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["Chain Fireball"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["Mushan Charge"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["Vor'thik Dreadsworn"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 18504,
								},
							},
							["amount"] = 18504,
						},
						["Vor'thik Fear-Shaper"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 11678,
								},
							},
							["amount"] = 11678,
						},
						["Environment"] = {
							["Details"] = {
								["Falling"] = {
									["count"] = 27783,
								},
							},
							["amount"] = 27783,
						},
						["Greatback Mushan"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 35492,
								},
								["Mushan Charge"] = {
									["count"] = 6622,
								},
							},
							["amount"] = 42114,
						},
						["Seething Pyrelord"] = {
							["Details"] = {
								["Chain Fireball"] = {
									["count"] = 838,
								},
							},
							["amount"] = 838,
						},
						["Nagging Dreadling"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 2889,
								},
							},
							["amount"] = 2889,
						},
					},
					["ElementTaken"] = {
						["Physical"] = 34405,
						["Melee"] = 68563,
						["Fire"] = 838,
					},
					["DamageTaken"] = 103806,
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Melee"] = {
							["Details"] = {
								["Crushing"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 8,
						},
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
				},
			},
			["LastDamageTaken"] = 838,
			["UnitLockout"] = 1358751641,
			["LastAbility"] = 76994.936,
		},
		["Gart Mistrunner"] = {
			["GUID"] = "0xF130D250000041CE",
			["type"] = "Nontrivial",
			["FightsSaved"] = 1,
			["GuardianReverseGUIDs"] = {
				["Treant Ally"] = {
					["LatestGuardian"] = 0,
					["GUIDs"] = {
						[0] = "0xF53016AE0017A124",
					},
				},
			},
			["Owner"] = false,
			["enClass"] = "MOB",
			["LastAbility"] = 76994.936,
			["Name"] = "Gart Mistrunner",
			["Pet"] = {
				"Treant Ally <Gart Mistrunner>", -- [1]
			},
			["UnitLockout"] = 1360612631,
			["level"] = 1,
			["Fights"] = {
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
			},
			["LastFightIn"] = 1,
		},
		["Hyjal Protector <Starrsight>"] = {
			["GUID"] = "0xF530CBF50017A8CF",
			["LastEventHealth"] = {
				"???", -- [1]
				"???", -- [2]
				"???", -- [3]
				"???", -- [4]
				"???", -- [5]
				"???", -- [6]
				"???", -- [7]
				"???", -- [8]
				"???", -- [9]
				"???", -- [10]
				"???", -- [11]
				"???", -- [12]
				"???", -- [13]
				"???", -- [14]
				"???", -- [15]
				"???", -- [16]
			},
			["LastAttackedBy"] = "Seething Pyrelord",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
			},
			["TimeWindows"] = {
				["ActiveTime"] = {
					6.07, -- [1]
				},
				["Damage"] = {
					17038, -- [1]
				},
				["DamageTaken"] = {
					17833, -- [1]
				},
				["TimeDamage"] = {
					6.07, -- [1]
				},
			},
			["enClass"] = "PET",
			["LastDamageTaken"] = 1172,
			["level"] = 1,
			["LastDamageAbility"] = "Chain Fireball",
			["LastFightIn"] = 1,
			["type"] = "Pet",
			["FightsSaved"] = 1,
			["LastActive"] = 1360612908,
			["Owner"] = "Starrsight",
			["UnitLockout"] = 1360612908,
			["NextEventNum"] = 17,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
				0, -- [5]
				0, -- [6]
				0, -- [7]
				0, -- [8]
				0, -- [9]
				0, -- [10]
				0, -- [11]
				0, -- [12]
				0, -- [13]
				0, -- [14]
				0, -- [15]
				0, -- [16]
			},
			["LastEvents"] = {
				"Hyjal Protector <Starrsight> Melee Seething Pyrelord Hit -4637 (Physical)", -- [1]
				"Seething Pyrelord Chain Fireball Hyjal Protector <Starrsight> Hit -1263 (Fire)", -- [2]
				"Seething Pyrelord Chain Fireball Hyjal Protector <Starrsight> Hit -1185 (Fire)", -- [3]
				"Hyjal Protector <Starrsight> Melee Seething Pyrelord Hit -3488 (Physical)", -- [4]
				"Seething Pyrelord Chain Fireball Hyjal Protector <Starrsight> Hit -1181 (Fire)", -- [5]
				"Seething Pyrelord Chain Fireball Hyjal Protector <Starrsight> Hit -1213 (Fire)", -- [6]
				"Seething Pyrelord Chain Fireball Hyjal Protector <Starrsight> Hit -1224 (Fire)", -- [7]
				"Seething Pyrelord Chain Fireball Hyjal Protector <Starrsight> Hit -1158 (Fire)", -- [8]
				"Seething Pyrelord Melee Hyjal Protector <Starrsight> Hit -5776 (Physical)", -- [9]
				"Hyjal Protector <Starrsight> Melee Seething Pyrelord Hit -4344 (Physical)", -- [10]
				"Seething Pyrelord Chain Fireball Hyjal Protector <Starrsight> Hit -1274 (Fire)", -- [11]
				"Seething Pyrelord Chain Fireball Hyjal Protector <Starrsight> Hit -1130 (Fire)", -- [12]
				"Seething Pyrelord Chain Fireball Hyjal Protector <Starrsight> Hit -1257 (Fire)", -- [13]
				"Hyjal Protector <Starrsight> Melee Seething Pyrelord Hit -4569 (Physical)", -- [14]
				"Seething Pyrelord Chain Fireball Hyjal Protector <Starrsight> Hit -1172 (Fire)", -- [15]
				"Hyjal Protector <Starrsight> Entangling Roots Seething Pyrelord Miss (Nature)", -- [16]
			},
			["Name"] = "Hyjal Protector",
			["Fights"] = {
				["OverallData"] = {
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 4637,
									["min"] = 3488,
									["count"] = 4,
									["amount"] = 17038,
								},
							},
							["count"] = 4,
							["amount"] = 17038,
						},
						["Entangling Roots"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 6.07,
					["ElementDone"] = {
						["Melee"] = 17038,
					},
					["TimeDamaging"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.5,
								},
								["Entangling Roots"] = {
									["count"] = 0.57,
								},
							},
							["amount"] = 6.07,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["DamageTaken"] = 17833,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["Nature"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["PartialResist"] = {
						["Chain Fireball"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 17038,
								},
							},
							["amount"] = 17038,
						},
					},
					["PartialAbsorb"] = {
						["Chain Fireball"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 6.07,
					["WhoDamaged"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Chain Fireball"] = {
									["count"] = 12057,
								},
								["Melee"] = {
									["count"] = 5776,
								},
							},
							["amount"] = 17833,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 5776,
						["Fire"] = 12057,
					},
					["TimeSpent"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.5,
								},
								["Entangling Roots"] = {
									["count"] = 0.57,
								},
							},
							["amount"] = 6.07,
						},
					},
					["Damage"] = 17038,
				},
				["LastFightData"] = {
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 4637,
									["min"] = 3488,
									["count"] = 4,
									["amount"] = 17038,
								},
							},
							["count"] = 4,
							["amount"] = 17038,
						},
						["Entangling Roots"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 6.07,
					["ElementDone"] = {
						["Melee"] = 17038,
					},
					["TimeDamaging"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.5,
								},
								["Entangling Roots"] = {
									["count"] = 0.57,
								},
							},
							["amount"] = 6.07,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["DamageTaken"] = 17833,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["Nature"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["PartialResist"] = {
						["Chain Fireball"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 17038,
								},
							},
							["amount"] = 17038,
						},
					},
					["PartialAbsorb"] = {
						["Chain Fireball"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 6.07,
					["WhoDamaged"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Chain Fireball"] = {
									["count"] = 12057,
								},
								["Melee"] = {
									["count"] = 5776,
								},
							},
							["amount"] = 17833,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 5776,
						["Fire"] = 12057,
					},
					["TimeSpent"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.5,
								},
								["Entangling Roots"] = {
									["count"] = 0.57,
								},
							},
							["amount"] = 6.07,
						},
					},
					["Damage"] = 17038,
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 4637,
									["min"] = 3488,
									["count"] = 4,
									["amount"] = 17038,
								},
							},
							["count"] = 4,
							["amount"] = 17038,
						},
						["Entangling Roots"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 6.07,
					["ElementDone"] = {
						["Melee"] = 17038,
					},
					["TimeDamaging"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.5,
								},
								["Entangling Roots"] = {
									["count"] = 0.57,
								},
							},
							["amount"] = 6.07,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["DamageTaken"] = 17833,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["Nature"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["PartialResist"] = {
						["Chain Fireball"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 17038,
								},
							},
							["amount"] = 17038,
						},
					},
					["PartialAbsorb"] = {
						["Chain Fireball"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 6.07,
					["WhoDamaged"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Chain Fireball"] = {
									["count"] = 12057,
								},
								["Melee"] = {
									["count"] = 5776,
								},
							},
							["amount"] = 17833,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 5776,
						["Fire"] = 12057,
					},
					["TimeSpent"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5.5,
								},
								["Entangling Roots"] = {
									["count"] = 0.57,
								},
							},
							["amount"] = 6.07,
						},
					},
					["Damage"] = 17038,
				},
			},
			["TimeLast"] = {
				["ActiveTime"] = 1360612908,
				["TimeDamage"] = 1360612908,
				["OVERALL"] = 1360612908,
				["DamageTaken"] = 1360612908,
				["Damage"] = 1360612908,
			},
			["LastEventIncoming"] = {
				false, -- [1]
				true, -- [2]
				true, -- [3]
				false, -- [4]
				true, -- [5]
				true, -- [6]
				true, -- [7]
				true, -- [8]
				true, -- [9]
				false, -- [10]
				true, -- [11]
				true, -- [12]
				true, -- [13]
				false, -- [14]
				true, -- [15]
				false, -- [16]
			},
			["LastEventTimes"] = {
				5588.41, -- [1]
				5588.41, -- [2]
				5588.566, -- [3]
				5588.566, -- [4]
				5588.566, -- [5]
				5588.971000000001, -- [6]
				5589.091, -- [7]
				5589.091, -- [8]
				5589.091, -- [9]
				5589.091, -- [10]
				5589.552, -- [11]
				5589.965, -- [12]
				5590.164, -- [13]
				5590.400000000001, -- [14]
				5590.78, -- [15]
				5590.967000000001, -- [16]
			},
			["LastAbility"] = 76994.936,
		},
		["Image of Archmage Vargoth <Starrsight>"] = {
			["GUID"] = "0xF530CC270017A8D1",
			["LastEventHealth"] = {
				"???", -- [1]
				"???", -- [2]
				"???", -- [3]
				"???", -- [4]
			},
			["LastAttackedBy"] = "Seething Pyrelord",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
			},
			["TimeWindows"] = {
				["ActiveTime"] = {
					3.5, -- [1]
				},
				["TimeDamage"] = {
					3.5, -- [1]
				},
				["DamageTaken"] = {
					3492, -- [1]
				},
				["Damage"] = {
					5699, -- [1]
				},
			},
			["enClass"] = "PET",
			["LastDamageTaken"] = 1149,
			["level"] = 1,
			["LastDamageAbility"] = "Chain Fireball",
			["LastFightIn"] = 1,
			["type"] = "Pet",
			["FightsSaved"] = 1,
			["LastActive"] = 1360612907,
			["Owner"] = "Starrsight",
			["UnitLockout"] = 1360612907,
			["NextEventNum"] = 5,
			["LastEventHealthNum"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0, -- [4]
			},
			["LastEvents"] = {
				"Seething Pyrelord Chain Fireball Image of Archmage Vargoth <Starrsight> Hit -1118 (Fire)", -- [1]
				"Seething Pyrelord Chain Fireball Image of Archmage Vargoth <Starrsight> Hit -1225 (Fire)", -- [2]
				"Image of Archmage Vargoth <Starrsight> Melee Seething Pyrelord Hit -5699 (Physical)", -- [3]
				"Seething Pyrelord Chain Fireball Image of Archmage Vargoth <Starrsight> Hit -1149 (Fire)", -- [4]
			},
			["Name"] = "Image of Archmage Vargoth",
			["Fights"] = {
				["OverallData"] = {
					["DamagedWho"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5699,
								},
							},
							["amount"] = 5699,
						},
					},
					["TimeDamage"] = 3.5,
					["TimeSpent"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["WhoDamaged"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Chain Fireball"] = {
									["count"] = 3492,
								},
							},
							["amount"] = 3492,
						},
					},
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["DamageTaken"] = 3492,
					["PartialResist"] = {
						["Chain Fireball"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Melee"] = 5699,
					},
					["PartialAbsorb"] = {
						["Chain Fireball"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ActiveTime"] = 3.5,
					["TimeDamaging"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["ElementTaken"] = {
						["Fire"] = 3492,
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5699,
									["min"] = 5699,
									["count"] = 1,
									["amount"] = 5699,
								},
							},
							["count"] = 1,
							["amount"] = 5699,
						},
					},
					["Damage"] = 5699,
				},
				["LastFightData"] = {
					["DamagedWho"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5699,
								},
							},
							["amount"] = 5699,
						},
					},
					["TimeDamage"] = 3.5,
					["TimeSpent"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["WhoDamaged"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Chain Fireball"] = {
									["count"] = 3492,
								},
							},
							["amount"] = 3492,
						},
					},
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["DamageTaken"] = 3492,
					["PartialResist"] = {
						["Chain Fireball"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Melee"] = 5699,
					},
					["PartialAbsorb"] = {
						["Chain Fireball"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ActiveTime"] = 3.5,
					["TimeDamaging"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["ElementTaken"] = {
						["Fire"] = 3492,
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5699,
									["min"] = 5699,
									["count"] = 1,
									["amount"] = 5699,
								},
							},
							["count"] = 1,
							["amount"] = 5699,
						},
					},
					["Damage"] = 5699,
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["DamagedWho"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 5699,
								},
							},
							["amount"] = 5699,
						},
					},
					["TimeDamage"] = 3.5,
					["TimeSpent"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["WhoDamaged"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Chain Fireball"] = {
									["count"] = 3492,
								},
							},
							["amount"] = 3492,
						},
					},
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["DamageTaken"] = 3492,
					["PartialResist"] = {
						["Chain Fireball"] = {
							["Details"] = {
								["No Resist"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Melee"] = 5699,
					},
					["PartialAbsorb"] = {
						["Chain Fireball"] = {
							["Details"] = {
								["No Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ActiveTime"] = 3.5,
					["TimeDamaging"] = {
						["Seething Pyrelord"] = {
							["Details"] = {
								["Melee"] = {
									["count"] = 3.5,
								},
							},
							["amount"] = 3.5,
						},
					},
					["ElementTaken"] = {
						["Fire"] = 3492,
					},
					["Attacks"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5699,
									["min"] = 5699,
									["count"] = 1,
									["amount"] = 5699,
								},
							},
							["count"] = 1,
							["amount"] = 5699,
						},
					},
					["Damage"] = 5699,
				},
			},
			["TimeLast"] = {
				["ActiveTime"] = 1360612907,
				["TimeDamage"] = 1360612907,
				["OVERALL"] = 1360612907,
				["DamageTaken"] = 1360612907,
				["Damage"] = 1360612907,
			},
			["LastEventIncoming"] = {
				true, -- [1]
				true, -- [2]
				false, -- [3]
				true, -- [4]
			},
			["LastEventTimes"] = {
				5588.681000000001, -- [1]
				5589.091, -- [2]
				5589.418, -- [3]
				5589.828, -- [4]
			},
			["LastAbility"] = 76994.936,
		},
	},
	["FightNum"] = 2,
	["CombatTimes"] = {
		{
			1358751787, -- [1]
			1358751868, -- [2]
			"23:03:07", -- [3]
			"23:04:28", -- [4]
			"Vor'thik Dreadsworn", -- [5]
		}, -- [1]
		{
			1360612906, -- [1]
			1360612916, -- [2]
			"12:01:46", -- [3]
			"12:01:56", -- [4]
			"Seething Pyrelord", -- [5]
		}, -- [2]
	},
	["FoughtWho"] = {
		"Seething Pyrelord 12:01:46-12:01:56", -- [1]
		"Vor'thik Dreadsworn 23:03:07-23:04:28", -- [2]
	},
}
