
SpellReminderDBPerChar = {
	["char"] = {
		["Starrsight - Nathrezim"] = {
			["spellSetup"] = {
				["Honorless Target"] = {
					["moduleManaged"] = true,
					["active"] = true,
					["displayName"] = "Honorless Target",
					["installed"] = true,
					["category"] = "Buffs",
					["detected"] = true,
					["last_seen"] = 1352860074,
					["r"] = 5,
					["d"] = 30,
					["icon"] = "Interface\\Icons\\Spell_Magic_LesserInvisibilty",
				},
				["Enhanced Agility"] = {
					["moduleManaged"] = true,
					["active"] = true,
					["displayName"] = "Enhanced Agility",
					["installed"] = true,
					["category"] = "Buffs",
					["detected"] = true,
					["last_seen"] = 1352860074,
					["r"] = 15,
					["d"] = 1786,
					["icon"] = "INTERFACE\\ICONS\\inv_potione_2",
				},
			},
		},
	},
	["profileKeys"] = {
		["Starrsight - Nathrezim"] = "Default",
	},
}
