
EavesDropStatsDB = {
	["profileKeys"] = {
		["Statue - Nathrezim"] = "Statue - Nathrezim",
	},
	["profiles"] = {
		["Statue - Nathrezim"] = {
			{
				["heal"] = {
					["Mortal Coil"] = {
						[-2] = {
							["time"] = "|cffffffff11/10/12 10:30:53|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:108396:SPELL_HEAL|h|cffffffffMortal Coil|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff0|r |cffffffffShadow|r. (63387 Overhealed) ",
							["amount"] = 63387,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_warlock_mortalcoil",
					},
					["Holy Nova"] = {
						[-2] = {
							["time"] = "|cffffffff11/09/12 11:22:50|r\n|Hunit:0xF530FA0D0037F410:Kaz'tik the Manipulator|hKaz'tik the Manipulator|h |Hspell:79822:SPELL_HEAL|h|cffffffffHoly Nova|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff128|r |cffffffffHoly|r. (5968 Overhealed) ",
							["amount"] = 6096,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolyNova",
					},
					["Bo's Rejuvinating Mist"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 11:07:24|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:122194:SPELL_PERIODIC_HEAL|h|cffffffffBo's Rejuvinating Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff12323|r |cffffffffPhysical|r. ",
							["amount"] = 12323,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_healthsphere",
					},
					["Harvest Life"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 11:23:55|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:125314:SPELL_PERIODIC_HEAL|h|cffffffffHarvest Life|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff0|r |cffffffffShadow|r. (17365 Overhealed) ",
							["amount"] = 17365,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_LifeDrain02",
					},
					["Hozenbane"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 11:09:07|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:122373:SPELL_HEAL|h|cffffffffHozenbane|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff20539|r |cffffffffPhysical|r. ",
							["amount"] = 20539,
						},
						[2] = {
							["time"] = "|cffffffff11/24/12 11:11:58|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:122373:SPELL_HEAL|h|cffffffffHozenbane|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff41077|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 41077,
						},
						["icon"] = "Interface\\Icons\\Achievement_BG_kill_flag_carrierEOS",
					},
					["Health Funnel"] = {
						[-2] = {
							["time"] = "|cffffffff12/20/12 10:05:17|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:114189:SPELL_HEAL|h|cffffffffHealth Funnel|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0xF140EF8BBA000304:Arcamotos|hArcamotos|h |cffffffff0|r |cffffffffShadow|r. (43923 Overhealed) ",
							["amount"] = 43923,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_LifeDrain",
					},
					["Cintron-Infused Bandage"] = {
						[-2] = {
							["time"] = "|cffffffff11/04/12 02:52:55|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:120573:SPELL_PERIODIC_HEAL|h|cffffffffCintron-Infused Bandage|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0xF530F0FC00232AE6:Injured Gao-Ran Blackguard|hInjured Gao-Ran Blackguard|h |cffffffff39394|r |cffffffffPhysical|r. ",
							["amount"] = 39394,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\inv_misc_bandage_frostweave",
					},
					["Magnetic Shroud Overload"] = {
						[-2] = {
							["time"] = "|cffffffff11/01/12 09:02:56|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:107174:SPELL_HEAL|h|cffffffffMagnetic Shroud Overload|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01800000041B9242:Battousia-Daggerspine|hBattousia-Daggerspine|h |cffffffff26250|r |cffffffffPhysical|r. ",
							["amount"] = 26250,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Trade_Engineering",
					},
					["Grimoire of Sacrifice"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 10:46:35|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:108503:SPELL_PERIODIC_HEAL|h|cffffffffGrimoire of Sacrifice|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff12865|r |cffffffffShadow|r. ",
							["amount"] = 12865,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\warlock_grimoireofsacrifice",
					},
					["Glyph of Soul Consumption"] = {
						[-2] = {
							["time"] = "|cffffffff11/16/12 12:31:05|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:58068:SPELL_HEAL|h|cffffffffGlyph of Soul Consumption|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff0|r |cffffffffShadow|r. (116167 Overhealed) ",
							["amount"] = 116167,
						},
						[2] = {
							["time"] = "|cffffffff11/16/12 12:56:25|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:58068:SPELL_HEAL|h|cffffffffGlyph of Soul Consumption|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff0|r |cffffffffShadow|r. (217180 Overhealed) (Critical) ",
							["amount"] = 217180,
						},
						["icon"] = "INTERFACE\\ICONS\\ability_warlock_soulsiphon",
					},
					["Healthstone"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 10:57:16|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:6262:SPELL_HEAL|h|cffffffffHealthstone|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff13575|r |cffffffffPhysical|r. (101201 Overhealed) ",
							["amount"] = 114776,
						},
						[2] = {
							["time"] = "|cffffffff11/05/12 11:02:06|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:6262:SPELL_HEAL|h|cffffffffHealthstone|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff205449|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 205449,
						},
						["icon"] = "Interface\\Icons\\warlock_ healthstone",
					},
					["Health Funnel (Glyphed)"] = {
						[-2] = {
							["time"] = "|cffffffff11/16/12 11:30:24|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:114189:SPELL_HEAL|h|cffffffffHealth Funnel (Glyphed)|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0xF140F1575900422A:Az-ithak|hAz-ithak|h |cffffffff33591|r |cffffffffShadow|r. ",
							["amount"] = 33591,
						},
						[2] = {
							["time"] = "|cffffffff11/16/12 11:33:04|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:114189:SPELL_HEAL|h|cffffffffHealth Funnel (Glyphed)|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0xF140F1575900422A:Az-ithak|hAz-ithak|h |cffffffff3243|r |cffffffffShadow|r. (63938 Overhealed) (Critical) ",
							["amount"] = 67181,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_LifeDrain",
					},
					["Blanche's Elixir of Replenishment"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 11:44:00|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:121951:SPELL_PERIODIC_HEAL|h|cffffffffBlanche's Elixir of Replenishment|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff0|r |cffffffffPhysical|r. (43413 Overhealed) ",
							["amount"] = 43413,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_healthsphere",
					},
					["Drain Life"] = {
						[-2] = {
							["time"] = "|cffffffff12/20/12 10:30:36|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:89653:SPELL_PERIODIC_HEAL|h|cffffffffDrain Life|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff0|r |cffffffffShadow|r. (12389 Overhealed) ",
							["amount"] = 12389,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_LifeDrain02",
					},
					["First Aid"] = {
						[-2] = {
							["time"] = "|cffffffff11/05/12 10:57:04|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:102695:SPELL_PERIODIC_HEAL|h|cffffffffFirst Aid|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff24336|r |cffffffffPhysical|r. ",
							["amount"] = 24336,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Heal",
					},
					["Soul Link"] = {
						[-2] = {
							["time"] = "|cffffffff11/17/12 09:42:32|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:108447:SPELL_HEAL|h|cffffffffSoul Link|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff394|r |cffffffffShadow|r. (2804 Overhealed) ",
							["amount"] = 3198,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_warlock_soullink",
					},
					["Dark Regeneration"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 02:47:49|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:108359:SPELL_PERIODIC_HEAL|h|cffffffffDark Regeneration|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff11170|r |cffffffffShadow|r. ",
							["amount"] = 11170,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\spell_warlock_darkregeneration",
					},
					["Leeching Swarm"] = {
						[-2] = {
							["time"] = "|cffffffff11/10/12 08:58:14|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:66125:SPELL_HEAL|h|cffffffffLeeching Swarm|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0xF13087040000155C:Anub'arak|hAnub'arak|h |cffffffff66953|r |cffffffffShadow|r. ",
							["amount"] = 66953,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_InsectSwarm",
					},
					["Shado-Pan Bandage"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 02:33:06|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:122829:SPELL_PERIODIC_HEAL|h|cffffffffShado-Pan Bandage|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0xF530E72F0027F97E:Wounded Defender|hWounded Defender|h |cffffffff137880|r |cffffffffPhysical|r. ",
							["amount"] = 137880,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\inv_misc_bandage_frostweave",
					},
					["Siphon Life"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 10:50:06|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:63106:SPELL_HEAL|h|cffffffffSiphon Life|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff11131|r |cffffffffShadow|r. ",
							["amount"] = 11131,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_Requiem",
					},
					["Ember Tap"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 11:33:13|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:114635:SPELL_HEAL|h|cffffffffEmber Tap|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff0|r |cffffffffShadow|r. (116226 Overhealed) ",
							["amount"] = 116226,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\inv_ember",
					},
					["Soul Leech"] = {
						[-2] = {
							["time"] = "|cffffffff11/10/12 11:14:38|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:108366:SPELL_HEAL|h|cffffffffSoul Leech|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff0|r |cffffffffShadow|r. (14245 Overhealed) ",
							["amount"] = 14245,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\warlock_siphonlife",
					},
					["Curse of Mending"] = {
						[-2] = {
							["time"] = "|cffffffff11/07/12 08:44:01|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:39703:SPELL_HEAL|h|cffffffffCurse of Mending|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0xF13076F500004688:Onyx Sanctum Guardian|hOnyx Sanctum Guardian|h |cffffffff39099|r |cffffffffShadow|r. ",
							["amount"] = 39099,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_AntiShadow",
					},
					["Cauterize Master"] = {
						[-2] = {
							["time"] = "|cffffffff11/09/12 12:39:56|r\n|Hunit:0xF140F0A3FA0002F6:Pippik|hPippik|h |Hspell:119899:SPELL_PERIODIC_HEAL|h|cffffffffCauterize Master|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff16559|r |cffffffffFire|r. ",
							["amount"] = 16559,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\inv_misc_volatilefire",
					},
				},
				["hit"] = {
					["Corruption"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 06:11:52|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:172:SPELL_PERIODIC_DAMAGE|h|cffffffffCorruption|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130EBFA000006DF:Elegon|hElegon|h |cffffffff15842|r |cffffffffShadow|r. ",
							["amount"] = 15842,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 06:11:56|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:172:SPELL_PERIODIC_DAMAGE|h|cffffffffCorruption|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130EBFA000006DF:Elegon|hElegon|h |cffffffff31684|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 31684,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_AbominationExplosion",
					},
					["Fel Flame"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 03:17:08|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:77799:SPELL_DAMAGE|h|cffffffffFel Flame|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0580000000150E35:Jolthammer-Anvilmar|hJolthammer-Anvilmar|h |cffffffff43920|r |cffffffffShadowflame|r. (11298 Overkill) ",
							["amount"] = 55218,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 08:37:52|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:77799:SPELL_DAMAGE|h|cffffffffFel Flame|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff204463|r |cffffffffShadowflame|r. (Critical) ",
							["amount"] = 204463,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_FelFireNova",
					},
					["Negative Charge"] = {
						[-2] = {
							["time"] = "|cffffffff11/07/12 08:10:58|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:28085:SPELL_DAMAGE|h|cffffffffNegative Charge|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004BA92B5:Pypir|hPypir|h |cffffffff4500|r |cffffffffNature|r. ",
							["amount"] = 4500,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_ChargeNegative",
					},
					["Shadowflame"] = {
						[-2] = {
							["time"] = "|cffffffff11/17/12 01:12:29|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:47960:SPELL_PERIODIC_DAMAGE|h|cffffffffShadowflame|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130EFAB00330180:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff6745|r |cffffffffShadowflame|r. ",
							["amount"] = 6745,
						},
						[2] = {
							["time"] = "|cffffffff11/17/12 12:58:13|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:47960:SPELL_PERIODIC_DAMAGE|h|cffffffffShadowflame|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130EFAB0032DB7F:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff10722|r |cffffffffShadowflame|r. (Critical) ",
							["amount"] = 10722,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_fire_twilightflamebreath",
					},
					["Volatile Greenstone Brew"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 10:15:06|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:119090:SPELL_DAMAGE|h|cffffffffVolatile Greenstone Brew|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EEF6000071FB:Cursed Jade|hCursed Jade|h |cffffffff106743|r |cffffffffNature|r. ",
							["amount"] = 106743,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\inv_drink_32_disgustingrotgut",
					},
					["Immolate"] = {
						[-2] = {
							["time"] = "|cffffffff11/13/12 10:15:51|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:348:SPELL_PERIODIC_DAMAGE|h|cffffffffImmolate|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff31049|r |cffffffffFire|r. ",
							["amount"] = 31049,
						},
						[2] = {
							["time"] = "|cffffffff11/13/12 10:15:57|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:348:SPELL_PERIODIC_DAMAGE|h|cffffffffImmolate|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff63962|r |cffffffffFire|r. (Critical) ",
							["amount"] = 63962,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_Immolation",
					},
					["Harvest Life"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 10:47:35|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:108371:SPELL_PERIODIC_DAMAGE|h|cffffffffHarvest Life|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130F68200003606:Sik'thik Swarmer|hSik'thik Swarmer|h |cffffffff10019|r |cffffffffShadow|r. ",
							["amount"] = 10019,
						},
						[2] = {
							["time"] = "|cffffffff11/08/12 10:48:04|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:108371:SPELL_PERIODIC_DAMAGE|h|cffffffffHarvest Life|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130F1050000361A:Sik'thik Warrior|hSik'thik Warrior|h |cffffffff20038|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 20038,
						},
						["icon"] = "Interface\\Icons\\spell_warlock_harvestoflife",
					},
					["Agony"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 06:11:58|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:980:SPELL_PERIODIC_DAMAGE|h|cffffffffAgony|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130EBFA000006DF:Elegon|hElegon|h |cffffffff20602|r |cffffffffShadow|r. ",
							["amount"] = 20602,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 06:11:59|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:131737:SPELL_DAMAGE|h|cffffffffAgony|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EBFA000006DF:Elegon|hElegon|h |cffffffff41205|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 41205,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_CurseOfSargeras",
					},
					["Archimonde's Vengeance"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 09:42:48|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:112938:SPELL_DAMAGE|h|cffffffffArchimonde's Vengeance|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x028000000558EDA8:Tynz-Ragnaros|hTynz-Ragnaros|h |cffffffff24089|r |cffffffffMagic|r. ",
							["amount"] = 24089,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Achievement_Boss_Archimonde ",
					},
					["Doom"] = {
						[-2] = {
							["time"] = "|cffffffff11/17/12 01:17:37|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:603:SPELL_PERIODIC_DAMAGE|h|cffffffffDoom|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130EFAB00330DD6:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff481|r |cffffffffShadow|r. (40496 Overkill) ",
							["amount"] = 40977,
						},
						[2] = {
							["time"] = "|cffffffff11/17/12 01:13:33|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:603:SPELL_PERIODIC_DAMAGE|h|cffffffffDoom|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130EFAB003303F3:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff49984|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 49984,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_AuraOfDarkness",
					},
					["Haunt"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 10:29:25|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:48181:SPELL_DAMAGE|h|cffffffffHaunt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F146000034BE:Crypt Guardian|hCrypt Guardian|h |cffffffff79197|r |cffffffffShadow|r. ",
							["amount"] = 79197,
						},
						[2] = {
							["time"] = "|cffffffff11/24/12 12:07:24|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:48181:SPELL_DAMAGE|h|cffffffffHaunt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130FF1800000CBA:Hateful Monstrosity|hHateful Monstrosity|h |cffffffff158394|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 158394,
						},
						["icon"] = "Interface\\Icons\\Ability_Warlock_Haunt",
					},
					["Rain of Fire"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 10:45:47|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:104233:SPELL_DAMAGE|h|cffffffffRain of Fire|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F68200003614:Sik'thik Swarmer|hSik'thik Swarmer|h |cffffffff20608|r |cffffffffFire|r. ",
							["amount"] = 20608,
						},
						[2] = {
							["time"] = "|cffffffff11/08/12 10:45:46|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:104233:SPELL_DAMAGE|h|cffffffffRain of Fire|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F68200003614:Sik'thik Swarmer|hSik'thik Swarmer|h |cffffffff41215|r |cffffffffFire|r. (Critical) ",
							["amount"] = 41215,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_RainOfFire",
					},
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 10:33:33|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF130F239000033B5:Shadows of Anger|hShadows of Anger|h |cffffffff8225|r |cffffffffPhysical|r. (Glancing) ",
							["amount"] = 8225,
						},
						[2] = {
							["time"] = "|cffffffff11/07/12 08:12:46|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF1303F4100015805:Skeletal Smith|hSkeletal Smith|h |cffffffff9987|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 9987,
						},
					},
					["Mantid Poison"] = {
						[-2] = {
							["time"] = "|cffffffff11/07/12 01:19:31|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:128386:SPELL_PERIODIC_DAMAGE|h|cffffffffMantid Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF530E6EF00122580:Kunzen Ravager|hKunzen Ravager|h |cffffffff7052|r |cffffffffNature|r. ",
							["amount"] = 7052,
						},
						[2] = {
							["time"] = "|cffffffff11/08/12 03:54:12|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:128386:SPELL_PERIODIC_DAMAGE|h|cffffffffMantid Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF1300F8900046213:High Inquisitor Whitemane|hHigh Inquisitor Whitemane|h |cffffffff8516|r |cffffffffNature|r. (Critical) ",
							["amount"] = 8516,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_NullifyPoison",
					},
					["Drain Soul"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 10:33:39|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:1120:SPELL_PERIODIC_DAMAGE|h|cffffffffDrain Soul|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130F239000033B5:Shadows of Anger|hShadows of Anger|h |cffffffff42024|r |cffffffffShadow|r. ",
							["amount"] = 42024,
						},
						[2] = {
							["time"] = "|cffffffff11/16/12 08:14:37|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:1120:SPELL_PERIODIC_DAMAGE|h|cffffffffDrain Soul|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF13085940000750A:Rune Etched Sentry|hRune Etched Sentry|h |cffffffff13040|r |cffffffffShadow|r. (52661 Overkill) (Critical) ",
							["amount"] = 65701,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_Haunting",
					},
					["Soul Link"] = {
						[-2] = {
							["time"] = "|cffffffff11/17/12 09:42:16|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:108451:SPELL_DAMAGE|h|cffffffffSoul Link|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff10832|r |cffffffffShadow|r. ",
							["amount"] = 10832,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_warlock_soullink",
					},
					["Stormlash"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 06:28:20|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:120687:SPELL_DAMAGE|h|cffffffffStormlash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150EBED000009B1:Emperor's Strength|hEmperor's Strength|h |cffffffff12408|r |cffffffffNature|r. ",
							["amount"] = 12408,
						},
						[2] = {
							["time"] = "|cffffffff11/07/12 07:56:04|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:120687:SPELL_DAMAGE|h|cffffffffStormlash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1303E7500017EC0:Sapphiron|hSapphiron|h |cffffffff22844|r |cffffffffNature|r. (Critical) ",
							["amount"] = 22844,
						},
						["icon"] = "Interface\\Icons\\Spell_Lightning_LightningBolt01",
					},
					["Hand of Gul'dan"] = {
						[-2] = {
							["time"] = "|cffffffff11/17/12 01:05:36|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:86040:SPELL_DAMAGE|h|cffffffffHand of Gul'dan|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB0032EC57:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff13393|r |cffffffffShadowflame|r. ",
							["amount"] = 13393,
						},
						[2] = {
							["time"] = "|cffffffff11/17/12 09:40:18|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:123197:SPELL_DAMAGE|h|cffffffffHand of Gul'dan|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EEFD003FEDA5:Krik'thik Limbpincer|hKrik'thik Limbpincer|h |cffffffff23331|r |cffffffffShadowflame|r. (Critical) ",
							["amount"] = 23331,
						},
						["icon"] = "Interface\\Icons\\ability_warlock_handofguldan",
					},
					["Drain Life"] = {
						[-2] = {
							["time"] = "|cffffffff12/20/12 10:21:41|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:689:SPELL_PERIODIC_DAMAGE|h|cffffffffDrain Life|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF13106C500003FA6:Kirrawk|hKirrawk|h |cffffffff9593|r |cffffffffShadow|r. ",
							["amount"] = 9593,
						},
						[2] = {
							["time"] = "|cffffffff12/20/12 10:09:45|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:689:SPELL_PERIODIC_DAMAGE|h|cffffffffDrain Life|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF1310A9F00003F8A:Dippy|hDippy|h |cffffffff16330|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 16330,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_LifeDrain02",
					},
					["Unstable Affliction"] = {
						[-2] = {
							["time"] = "|cffffffff11/10/12 10:35:47|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:31117:SPELL_DAMAGE|h|cffffffffUnstable Affliction|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x05800000081DB699:Chiteatree-Kel'Thuzad|hChiteatree-Kel'Thuzad|h |cffffffff27533|r |cffffffffShadow|r. ",
							["amount"] = 27533,
						},
						[2] = {
							["time"] = "|cffffffff11/16/12 08:35:00|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:31117:SPELL_DAMAGE|h|cffffffffUnstable Affliction|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0280000005734233:Swoompty-BurningLegion|hSwoompty-BurningLegion|h |cffffffff48300|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 48300,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Silence",
					},
					["Detonate"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 10:56:38|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:119395:SPELL_DAMAGE|h|cffffffffDetonate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F00800004658:Sik'thik Soldier|hSik'thik Soldier|h |cffffffff184344|r |cffffffffFire|r. (315656 Overkill) ",
							["amount"] = 500000,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Misc_Bomb_02",
					},
					["Chaos Wave"] = {
						[-2] = {
							["time"] = "|cffffffff11/17/12 09:11:32|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:129347:SPELL_DAMAGE|h|cffffffffChaos Wave|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB003F5D06:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff71104|r |cffffffffChaos|r. ",
							["amount"] = 71104,
						},
						[2] = {
							["time"] = "|cffffffff11/17/12 09:11:32|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:129347:SPELL_DAMAGE|h|cffffffffChaos Wave|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB003F675E:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff142208|r |cffffffffChaos|r. (Critical) ",
							["amount"] = 142208,
						},
						["icon"] = "Interface\\Icons\\ability_warlock_coil2",
					},
					["Touch of Chaos"] = {
						[-2] = {
							["time"] = "|cffffffff11/17/12 01:13:02|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:103964:SPELL_DAMAGE|h|cffffffffTouch of Chaos|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB0033034D:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff27344|r |cffffffffChaos|r. ",
							["amount"] = 27344,
						},
						[2] = {
							["time"] = "|cffffffff11/17/12 01:13:18|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:103964:SPELL_DAMAGE|h|cffffffffTouch of Chaos|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB003303DA:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff54670|r |cffffffffChaos|r. (Critical) ",
							["amount"] = 54670,
						},
						["icon"] = "INTERFACE\\ICONS\\inv_jewelcrafting_shadowspirit_02",
					},
					["Firewall"] = {
						[-2] = {
							["time"] = "|cffffffff11/10/12 03:04:47|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:128517:SPELL_PERIODIC_DAMAGE|h|cffffffffFirewall|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff25000|r |cffffffffFire|r. ",
							["amount"] = 25000,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_Immolation",
					},
					["Brew Explosion"] = {
						[-2] = {
							["time"] = "|cffffffff11/09/12 12:15:38|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:106784:SPELL_DAMAGE|h|cffffffffBrew Explosion|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130DD3D0002BF69:Ook-Ook|hOok-Ook|h |cffffffff138000|r |cffffffffPhysical|r. ",
							["amount"] = 138000,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Cask_02",
					},
					["Shado-Pan Dragon Gun"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 10:36:16|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:120751:SPELL_DAMAGE|h|cffffffffShado-Pan Dragon Gun|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530F27D002DFB01:Dreadspinner Egg|hDreadspinner Egg|h |cffffffff98090|r |cffffffffFire|r. ",
							["amount"] = 98090,
						},
						[2] = {
							["time"] = "|cffffffff11/08/12 10:36:24|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:120751:SPELL_DAMAGE|h|cffffffffShado-Pan Dragon Gun|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530F27D002E027F:Dreadspinner Egg|hDreadspinner Egg|h |cffffffff32697|r |cffffffffFire|r. (163483 Overkill) (Critical) ",
							["amount"] = 196180,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_Burnout",
					},
					["Hand of Sacrifice"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 12:23:36|r\n|Hunit:0x010000000246AC55:Statue|hYou|h |Hspell:6940:DAMAGE_SPLIT|h|cffffffffHand of Sacrifice|r|h |Haction:DAMAGE_SPLIT|hshared damage|h |Hunit:0x0100000001C0632E:Tankbot|hTankbot|h |cffffffff19709|r |cffffffffFire|r. ",
							["amount"] = 19709,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SealOfSacrifice",
					},
					["Chaos Bolt"] = {
						[-2] = {
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 10:46:29|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:116858:SPELL_DAMAGE|h|cffffffffChaos Bolt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EBFA000051F1:Elegon|hElegon|h |cffffffff535207|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 535207,
						},
						["icon"] = "Interface\\Icons\\Ability_Warlock_ChaosBolt",
					},
					["Dark Bargain"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 10:48:55|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:110914:SPELL_PERIODIC_DAMAGE|h|cffffffffDark Bargain|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff55088|r |cffffffffShadow|r. (66626 Overkill) ",
							["amount"] = 121714,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_deathwing_bloodcorruption_death",
					},
					["Shadow Bolt"] = {
						[-2] = {
							["time"] = "|cffffffff11/17/12 01:05:40|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:686:SPELL_DAMAGE|h|cffffffffShadow Bolt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB0032EC57:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff32134|r |cffffffffShadow|r. ",
							["amount"] = 32134,
						},
						[2] = {
							["time"] = "|cffffffff11/17/12 09:12:20|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:686:SPELL_DAMAGE|h|cffffffffShadow Bolt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB003FA6A5:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff44282|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 44282,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_ShadowBolt",
					},
					["Beach Bomb Kaboom"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 11:06:13|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:122087:SPELL_DAMAGE|h|cffffffffBeach Bomb Kaboom|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F47E00000CA5:Unga Scallywag|hUnga Scallywag|h |cffffffff117909|r |cffffffffFire|r. ",
							["amount"] = 117909,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Misc_Bomb_02",
					},
					["Reave"] = {
						[-2] = {
							["time"] = "|cffffffff11/09/12 12:00:31|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:122161:SPELL_DAMAGE|h|cffffffffReave|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530F3B20036CE0E:Sapfly|hSapfly|h |cffffffff12529|r |cffffffffPhysical|r. (103402 Overkill) ",
							["amount"] = 115931,
						},
						[2] = {
							["time"] = "|cffffffff11/09/12 12:00:31|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:122161:SPELL_DAMAGE|h|cffffffffReave|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530F3B20036CCC9:Sapfly|hSapfly|h |cffffffff12529|r |cffffffffPhysical|r. (219334 Overkill) (Critical) ",
							["amount"] = 231863,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_FlameBlades",
					},
					["Hellfire"] = {
						[-2] = {
							["time"] = "|cffffffff11/17/12 08:08:22|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:5857:SPELL_DAMAGE|h|cffffffffHellfire|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB003F0000:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff5355|r |cffffffffFire|r. ",
							["amount"] = 5355,
						},
						[2] = {
							["time"] = "|cffffffff11/17/12 08:08:22|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:5857:SPELL_DAMAGE|h|cffffffffHellfire|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB003EFF26:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff4176|r |cffffffffFire|r. (6534 Overkill) (Critical) ",
							["amount"] = 10710,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_Incinerate",
					},
					["Incinerate"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 10:50:10|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:29722:SPELL_DAMAGE|h|cffffffffIncinerate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F10500003602:Sik'thik Warrior|hSik'thik Warrior|h |cffffffff122730|r |cffffffffFire|r. ",
							["amount"] = 122730,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 10:47:30|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:29722:SPELL_DAMAGE|h|cffffffffIncinerate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EBFA000051F1:Elegon|hElegon|h |cffffffff158237|r |cffffffffFire|r. (Critical) ",
							["amount"] = 158237,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_Burnout",
					},
					["Set Fire"] = {
						[-2] = {
							["time"] = "|cffffffff11/04/12 02:11:46|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:118103:SPELL_PERIODIC_DAMAGE|h|cffffffffSet Fire|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF530EE040022DFF2:Ashfang Hyena|hAshfang Hyena|h |cffffffff10199|r |cffffffffFire|r. ",
							["amount"] = 10199,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Torch_Lit",
					},
					["Malefic Grasp"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 10:34:20|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:103103:SPELL_PERIODIC_DAMAGE|h|cffffffffMalefic Grasp|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130F10B0000356E:Abomination of Anger|hAbomination of Anger|h |cffffffff11316|r |cffffffffShadow|r. ",
							["amount"] = 11316,
						},
						[2] = {
							["time"] = "|cffffffff11/24/12 10:33:59|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:103103:SPELL_PERIODIC_DAMAGE|h|cffffffffMalefic Grasp|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130FF18000033A1:Hateful Monstrosity|hHateful Monstrosity|h |cffffffff22631|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 22631,
						},
						["icon"] = "Interface\\Icons\\Ability_Warlock_EverlastingAffliction",
					},
					["Sonic Divebomb"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 11:22:33|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:123065:SPELL_DAMAGE|h|cffffffffSonic Divebomb|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530F463002E6EFD:Shek'zeer Bladesworn|hShek'zeer Bladesworn|h |cffffffff393941|r |cffffffffPhysical|r. (158786 Overkill) ",
							["amount"] = 552727,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_HeroicLeap",
					},
					["Reclaimed Magic"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 02:37:51|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:126940:SPELL_DAMAGE|h|cffffffffReclaimed Magic|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff4950|r |cffffffffArcane|r. ",
							["amount"] = 4950,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_ConsumeMagic",
					},
					["Conflagrate"] = {
						[-2] = {
							["time"] = "|cffffffff11/13/12 10:15:46|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:17962:SPELL_DAMAGE|h|cffffffffConflagrate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff115468|r |cffffffffFire|r. ",
							["amount"] = 115468,
						},
						[2] = {
							["time"] = "|cffffffff11/13/12 10:21:33|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:17962:SPELL_DAMAGE|h|cffffffffConflagrate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000512F0C8:Capsi-Silvermoon|hCapsi-Silvermoon|h |cffffffff99377|r |cffffffffFire|r. (1777 Absorbed) (127074 Overkill) (Critical) ",
							["amount"] = 226451,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_Fireball",
					},
					["Sabotage"] = {
						[-2] = {
							["time"] = "|cffffffff11/05/12 10:56:54|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:113645:SPELL_DAMAGE|h|cffffffffSabotage|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff50551|r |cffffffffFire|r. ",
							["amount"] = 50551,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Misc_Bomb_05",
					},
					["Squash"] = {
						[-2] = {
							["time"] = "|cffffffff11/01/12 12:33:10|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:107913:SPELL_DAMAGE|h|cffffffffSquash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130DF950018E66C:Bookworm|hBookworm|h |cffffffff108125|r |cffffffffPhysical|r. ",
							["amount"] = 108125,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\inv_boots_08",
					},
					["Ban's Bomb"] = {
						[-2] = {
							["time"] = "|cffffffff11/07/12 01:19:39|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:128365:SPELL_DAMAGE|h|cffffffffBan's Bomb|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530E6EF00122580:Kunzen Ravager|hKunzen Ravager|h |cffffffff36596|r |cffffffffFire|r. ",
							["amount"] = 36596,
						},
						[2] = {
							["time"] = "|cffffffff11/08/12 02:05:32|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:128365:SPELL_DAMAGE|h|cffffffffBan's Bomb|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530EFAB0022BE58:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff57950|r |cffffffffFire|r. (Critical) ",
							["amount"] = 57950,
						},
						["icon"] = "Interface\\Icons\\inv_misc_blackironbomb",
					},
					["Immolation Aura"] = {
						[-2] = {
							["time"] = "|cffffffff11/17/12 01:17:17|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:129476:SPELL_DAMAGE|h|cffffffffImmolation Aura|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB00330C78:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff7172|r |cffffffffFire|r. ",
							["amount"] = 7172,
						},
						[2] = {
							["time"] = "|cffffffff11/17/12 09:49:23|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:129476:SPELL_DAMAGE|h|cffffffffImmolation Aura|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EEFD004007AB:Krik'thik Limbpincer|hKrik'thik Limbpincer|h |cffffffff8794|r |cffffffffFire|r. (Critical) ",
							["amount"] = 8794,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_Incinerate",
					},
					["Soul Fire"] = {
						[-2] = {
						},
						[2] = {
							["time"] = "|cffffffff11/01/12 11:26:24|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:104027:SPELL_DAMAGE|h|cffffffffSoul Fire|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130DD9C00006B7D:Liu Flameheart|hLiu Flameheart|h |cffffffff43556|r |cffffffffFire|r. (Critical) ",
							["amount"] = 43556,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_Fireball02",
					},
					["Arcane Resonance"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 05:25:23|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:116434:SPELL_DAMAGE|h|cffffffffArcane Resonance|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x038000000290C9D8:Inception-Malorne|hInception-Malorne|h |cffffffff42500|r |cffffffffArcane|r. ",
							["amount"] = 42500,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Frost_ChainsOfIce",
					},
					["Soul Swap Exhale"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 06:21:18|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:86213:SPELL_DAMAGE|h|cffffffffSoul Swap Exhale|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EBEC000008C3:Emperor's Rage|hEmperor's Rage|h |cffffffff9158|r |cffffffffShadow|r. ",
							["amount"] = 9158,
						},
						[2] = {
							["time"] = "|cffffffff02/05/13 08:23:37|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:86213:SPELL_DAMAGE|h|cffffffffSoul Swap Exhale|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1302BFE00001681:Onyxian Whelp|hOnyxian Whelp|h |cffffffff21540|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 21540,
						},
						["icon"] = "Interface\\Icons\\Ability_Rogue_EnvelopingShadows",
					},
					["Polyformic Acid Blast"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 11:55:13|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:114821:SPELL_DAMAGE|h|cffffffffPolyformic Acid Blast|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E6C800009FEA:Darkmaster Gandling|hDarkmaster Gandling|h |cffffffff108173|r |cffffffffNature|r. ",
							["amount"] = 108173,
						},
						[2] = {
							["time"] = "|cffffffff11/08/12 11:54:25|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:114821:SPELL_DAMAGE|h|cffffffffPolyformic Acid Blast|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E6C800009FEA:Darkmaster Gandling|hDarkmaster Gandling|h |cffffffff71550|r |cffffffffNature|r. (Critical) ",
							["amount"] = 71550,
						},
						["icon"] = "Interface\\Icons\\INV_Potion_97",
					},
					["Melee"] = {
						[-2] = {
							["time"] = "|cffffffff11/17/12 01:13:07|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:103988:SPELL_DAMAGE|h|cffffffffMelee|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB0033034D:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff3412|r |cffffffffShadow|r. ",
							["amount"] = 3412,
						},
						[2] = {
							["time"] = "|cffffffff11/17/12 01:13:15|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:103988:SPELL_DAMAGE|h|cffffffffMelee|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB003303DA:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff6808|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 6808,
						},
						["icon"] = "INTERFACE\\ICONS\\ability_warlock_jinx",
					},
					["Carrion Swarm"] = {
						[-2] = {
							["time"] = "|cffffffff11/17/12 01:13:04|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:103967:SPELL_DAMAGE|h|cffffffffCarrion Swarm|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB0033034D:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff20535|r |cffffffffShadow|r. ",
							["amount"] = 20535,
						},
						[2] = {
							["time"] = "|cffffffff11/17/12 12:13:33|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:103967:SPELL_DAMAGE|h|cffffffffCarrion Swarm|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB00327519:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff18088|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 18088,
						},
						["icon"] = "Interface\\Icons\\Ability_Warlock_DemonicPower",
					},
					["Infernal Awakening"] = {
						[-2] = {
							["time"] = "|cffffffff11/17/12 01:08:58|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:22703:SPELL_DAMAGE|h|cffffffffInfernal Awakening|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB0032F6A4:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff25082|r |cffffffffFire|r. ",
							["amount"] = 25082,
						},
						[2] = {
							["time"] = "|cffffffff11/17/12 12:09:15|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:22703:SPELL_DAMAGE|h|cffffffffInfernal Awakening|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB00325EE4:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff36230|r |cffffffffFire|r. (Critical) ",
							["amount"] = 36230,
						},
						["icon"] = "Interface\\Icons\\Spell_Frost_Stun",
					},
					["Void Ray"] = {
						[-2] = {
							["time"] = "|cffffffff11/17/12 01:05:31|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:115422:SPELL_DAMAGE|h|cffffffffVoid Ray|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB0032EBF7:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff9820|r |cffffffffShadowflame|r. ",
							["amount"] = 9820,
						},
						[2] = {
							["time"] = "|cffffffff11/17/12 01:15:20|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:115422:SPELL_DAMAGE|h|cffffffffVoid Ray|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB003308B6:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff18723|r |cffffffffShadowflame|r. (Critical) ",
							["amount"] = 18723,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_fire_twilightnova",
					},
					["Demonic Slash"] = {
						[-2] = {
							["time"] = "|cffffffff11/17/12 12:13:06|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:114175:SPELL_DAMAGE|h|cffffffffDemonic Slash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB003273FA:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff7324|r |cffffffffShadow|r. (4727 Overkill) ",
							["amount"] = 12051,
						},
						[2] = {
							["time"] = "|cffffffff11/17/12 12:14:15|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:114175:SPELL_DAMAGE|h|cffffffffDemonic Slash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EFAB003276AD:Kor'thik Timberhusk|hKor'thik Timberhusk|h |cffffffff24108|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 24108,
						},
						["icon"] = "INTERFACE\\ICONS\\inv_jewelcrafting_shadowspirit_02",
					},
					["Seed of Corruption"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 10:29:05|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:87385:SPELL_DAMAGE|h|cffffffffSeed of Corruption|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF131002D000034B1:Essence of Hate|hEssence of Hate|h |cffffffff6685|r |cffffffffShadow|r. (19555 Overkill) ",
							["amount"] = 26240,
						},
						[2] = {
							["time"] = "|cffffffff11/24/12 11:13:17|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:27285:SPELL_DAMAGE|h|cffffffffSeed of Corruption|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150F40100000BC4:Captain Ook|hCaptain Ook|h |cffffffff51677|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 51677,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_SeedOfDestruction",
					},
					["Elemental Force"] = {
						[-2] = {
							["time"] = "|cffffffff11/06/12 04:38:58|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:116616:SPELL_DAMAGE|h|cffffffffElemental Force|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130B63700000C91:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffElemental|r. (3110 Overkill) ",
							["amount"] = 3111,
						},
						[2] = {
							["time"] = "|cffffffff11/06/12 05:29:32|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:116616:SPELL_DAMAGE|h|cffffffffElemental Force|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530E6EF00055A53:Kunzen Ravager|hKunzen Ravager|h |cffffffff3007|r |cffffffffElemental|r. (3589 Overkill) (Critical) ",
							["amount"] = 6596,
						},
						["icon"] = "Interface\\Icons\\Ability_Mage_FireStarter",
					},
					["Black Hole"] = {
						[-2] = {
							["time"] = "|cffffffff11/16/12 08:20:12|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:62169:SPELL_PERIODIC_DAMAGE|h|cffffffffBlack Hole|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff1910|r |cffffffffArcane|r. ",
							["amount"] = 1910,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_Twilight",
					},
					["Soul Swap"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 06:11:49|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:119678:SPELL_DAMAGE|h|cffffffffSoul Swap|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EBFA000006DF:Elegon|hElegon|h |cffffffff19793|r |cffffffffShadow|r. ",
							["amount"] = 19793,
						},
						[2] = {
							["time"] = "|cffffffff02/05/13 08:26:30|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:86121:SPELL_DAMAGE|h|cffffffffSoul Swap|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13027C800001691:Onyxia|hOnyxia|h |cffffffff28272|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 28272,
						},
						["icon"] = "Interface\\Icons\\Ability_Rogue_EnvelopingShadows",
					},
					["Shadowburn"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 10:46:32|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:17877:SPELL_DAMAGE|h|cffffffffShadowburn|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130ED79000052ED:Celestial Protector|hCelestial Protector|h |cffffffff233060|r |cffffffffShadow|r. ",
							["amount"] = 233060,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 02:48:53|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:17877:SPELL_DAMAGE|h|cffffffffShadowburn|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150EA69000012A9:Feng the Accursed|hFeng the Accursed|h |cffffffff263570|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 263570,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_ScourgeBuild",
					},
					["Magma"] = {
						[-2] = {
							["time"] = "|cffffffff11/07/12 08:45:44|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:57634:SPELL_PERIODIC_DAMAGE|h|cffffffffMagma|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff2400|r |cffffffffFire|r. ",
							["amount"] = 2400,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_LavaFlow",
					},
					["Jasper Chains"] = {
						[-2] = {
							["time"] = "|cffffffff11/09/12 03:46:43|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:130404:SPELL_DAMAGE|h|cffffffffJasper Chains|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x03000000073E0F80:Youradhere-Proudmoore|hYouradhere-Proudmoore|h |cffffffff41558|r |cffffffffFire|r. (5482 Absorbed) ",
							["amount"] = 41558,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\inv_belt_44b",
					},
					["Sniper Shot"] = {
						[-2] = {
							["time"] = "|cffffffff10/28/12 12:40:09|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:103621:SPELL_DAMAGE|h|cffffffffSniper Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530D9EF0051A35F:Pearlfin Poolwatcher|hPearlfin Poolwatcher|h |cffffffff158079|r |cffffffffPhysical|r. (117324 Overkill) ",
							["amount"] = 275403,
						},
						[2] = {
							["time"] = "|cffffffff10/28/12 12:38:32|r\n|Hunit:0x010000000246AC55:Statue|hYour|h |Hspell:103621:SPELL_DAMAGE|h|cffffffffSniper Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530D9EF00519DED:Pearlfin Poolwatcher|hPearlfin Poolwatcher|h |cffffffff158079|r |cffffffffPhysical|r. (305993 Overkill) (Critical) ",
							["amount"] = 464072,
						},
						["icon"] = "Interface\\Icons\\INV_Weapon_Rifle_06",
					},
					["Cauterize Master"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 04:33:11|r\n|Hunit:0xF140F0A3FA00003B:Pippik|hPippik|h |Hspell:119899:SPELL_DAMAGE|h|cffffffffCauterize Master|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff8914|r |cffffffffFire|r. ",
							["amount"] = 8914,
						},
						[2] = {
							["time"] = "|cffffffff11/08/12 04:34:14|r\n|Hunit:0xF140F0A3FA00003B:Pippik|hPippik|h |Hspell:119899:SPELL_DAMAGE|h|cffffffffCauterize Master|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffffffff17826|r |cffffffffFire|r. (Critical) ",
							["amount"] = 17826,
						},
						["icon"] = "INTERFACE\\ICONS\\inv_misc_volatilefire",
					},
				},
			}, -- [1]
			[-1] = {
				["heal"] = {
					["Renew"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 01:05:40|r\n|Hunit:0x0300000006FB19D4:Fapaccino-Kil'jaeden|hFapaccino-Kil'jaeden|h |Hspell:139:SPELL_PERIODIC_HEAL|h|cff82f4ffRenew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff4173|r |cff82f4ffHoly|r. (12880 Overhealed) ",
							["amount"] = 17053,
						},
						[2] = {
							["time"] = "|cffffffff11/01/12 12:39:00|r\n|Hunit:0x0180000003F4CDC2:Shandari-Suramar|hShandari-Suramar|h |Hspell:139:SPELL_PERIODIC_HEAL|h|cff82f4ffRenew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff19268|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 19268,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Renew",
					},
					["Swiftmend"] = {
						[-2] = {
							["time"] = "|cffffffff11/09/12 12:20:05|r\n|Hunit:0x0180000004C18C2D:Dallamain-Uldum|hDallamain-Uldum|h |Hspell:18562:SPELL_HEAL|h|cff82f4ffSwiftmend|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff65368|r |cff82f4ffNature|r. ",
							["amount"] = 65368,
						},
						[2] = {
							["time"] = "|cffffffff11/13/12 11:19:14|r\n|Hunit:0x0580000008226C1A:Woodydr-AeriePeak|hWoodydr-AeriePeak|h |Hspell:18562:SPELL_HEAL|h|cff82f4ffSwiftmend|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff92535|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 92535,
						},
						["icon"] = "Interface\\Icons\\INV_Relics_IdolofRejuvenation",
					},
					["Healing Wave"] = {
						[-2] = {
							["time"] = "|cffffffff11/13/12 11:19:22|r\n|Hunit:0x01000000050BE616:Senzlol-Dragonmaw|hSenzlol-Dragonmaw|h |Hspell:331:SPELL_HEAL|h|cff82f4ffHealing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff70294|r |cff82f4ffNature|r. ",
							["amount"] = 70294,
						},
						[2] = {
							["time"] = "|cffffffff11/13/12 11:19:35|r\n|Hunit:0x01000000050BE616:Senzlol-Dragonmaw|hSenzlol-Dragonmaw|h |Hspell:331:SPELL_HEAL|h|cff82f4ffHealing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff81859|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 81859,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_MagicImmunity",
					},
					["Glyph of Power Word: Shield"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 03:41:11|r\n|Hunit:0x0100000002481119:Sett|hSett|h |Hspell:56160:SPELL_HEAL|h|cff82f4ffGlyph of Power Word: Shield|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff8583|r |cff82f4ffHoly|r. (15251 Overhealed) ",
							["amount"] = 23834,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Arcing Light"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 11:39:05|r\n|Hunit:0x03000000071299C2:Abrup-Barthilas|hAbrup-Barthilas|h |Hspell:119952:SPELL_PERIODIC_HEAL|h|cff82f4ffArcing Light|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (17716 Overhealed) ",
							["amount"] = 17716,
						},
						[2] = {
							["time"] = "|cffffffff11/08/12 11:39:07|r\n|Hunit:0x03000000071299C2:Abrup-Barthilas|hAbrup-Barthilas|h |Hspell:119952:SPELL_PERIODIC_HEAL|h|cff82f4ffArcing Light|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (34388 Overhealed) (Critical) ",
							["amount"] = 34388,
						},
						["icon"] = "Interface\\Icons\\spell_paladin_lightshammer",
					},
					["Holy Word: Serenity"] = {
						[-2] = {
							["time"] = "|cffffffff11/01/12 02:33:00|r\n|Hunit:0x0180000002EC3702:Pepzer-Uldum|hPepzer-Uldum|h |Hspell:88684:SPELL_HEAL|h|cff82f4ffHoly Word: Serenity|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff58788|r |cff82f4ffHoly|r. ",
							["amount"] = 58788,
						},
						[2] = {
							["time"] = "|cffffffff11/01/12 02:34:28|r\n|Hunit:0x0180000002EC3702:Pepzer-Uldum|hPepzer-Uldum|h |Hspell:88684:SPELL_HEAL|h|cff82f4ffHoly Word: Serenity|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff22310|r |cff82f4ffHoly|r. (52983 Overhealed) (Critical) ",
							["amount"] = 75293,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_holy_persuitofjustice",
					},
					["Soothing Mist"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 03:42:51|r\n|Hunit:0x0180000004C6B7DE:Panistar-Bronzebeard|hPanistar-Bronzebeard|h |Hspell:115175:SPELL_PERIODIC_HEAL|h|cff82f4ffSoothing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff10982|r |cff82f4ffNature|r. ",
							["amount"] = 10982,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 08:57:59|r\n|Hunit:0x0680000005762455:Trayvon-Tortheldrin|hTrayvon-Tortheldrin|h |Hspell:115175:SPELL_PERIODIC_HEAL|h|cff82f4ffSoothing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff8404|r |cff82f4ffNature|r. (11914 Overhealed) (Critical) ",
							["amount"] = 20318,
						},
						["icon"] = "Interface\\Icons\\ability_monk_soothingmists",
					},
					["Echo of Light"] = {
						[-2] = {
							["time"] = "|cffffffff11/01/12 02:34:34|r\n|Hunit:0x0180000002EC3702:Pepzer-Uldum|hPepzer-Uldum|h |Hspell:77489:SPELL_PERIODIC_HEAL|h|cff82f4ffEcho of Light|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (5268 Overhealed) ",
							["amount"] = 5268,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Aspiration",
					},
					["Nature's Vigil"] = {
						[-2] = {
							["time"] = "|cffffffff11/16/12 08:20:52|r\n|Hunit:0x0100000004B301BD:Specialkid|hSpecialkid|h |Hspell:124988:SPELL_HEAL|h|cff82f4ffNature's Vigil|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff56605|r |cff82f4ffNature|r. ",
							["amount"] = 56605,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Achievement_Zone_Feralas",
					},
					["Conductivity"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 10:16:43|r\n|Hunit:0x01000000047A2692:Apexpredator-ScarletCrusade|hApexpredator-ScarletCrusade|h |Hspell:118800:SPELL_HEAL|h|cff82f4ffConductivity|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff11024|r |cff82f4ffNature|r. ",
							["amount"] = 11024,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_shaman_fortifyingwaters",
					},
					["Healing Rain"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 02:48:03|r\n|Hunit:0x0300000006F479BF:Bellamus-Proudmoore|hBellamus-Proudmoore|h |Hspell:73921:SPELL_HEAL|h|cff82f4ffHealing Rain|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff13146|r |cff82f4ffNature|r. ",
							["amount"] = 13146,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 01:15:27|r\n|Hunit:0x018000000393F4B6:Lunashock-AzjolNerub|hLunashock-AzjolNerub|h |Hspell:73921:SPELL_HEAL|h|cff82f4ffHealing Rain|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (24014 Overhealed) (Critical) ",
							["amount"] = 24014,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_GiftoftheWaterSpirit",
					},
					["Unleash Life"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 10:57:12|r\n|Hunit:0x0100000002AE0D65:Klunder-Spirestone|hKlunder-Spirestone|h |Hspell:73685:SPELL_HEAL|h|cff82f4ffUnleash Life|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff21097|r |cff82f4ffNature|r. ",
							["amount"] = 21097,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\spell_shaman_unleashweapon_life",
					},
					["Light of Dawn"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 02:47:42|r\n|Hunit:0x0300000003DBEDBD:Loroline-Blackrock|hLoroline-Blackrock|h |Hspell:85222:SPELL_HEAL|h|cff82f4ffLight of Dawn|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff30271|r |cff82f4ffHoly|r. ",
							["amount"] = 30271,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 10:55:45|r\n|Hunit:0x018000000432ECF8:Valyne-Daggerspine|hValyne-Daggerspine|h |Hspell:85222:SPELL_HEAL|h|cff82f4ffLight of Dawn|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff49897|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 49897,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_paladin_lightofdawn",
					},
					["Ancestral Awakening"] = {
						[-2] = {
							["time"] = "|cffffffff11/16/12 12:34:29|r\n|Hunit:0x01800000010703FC:Hyperionz-Crushridge|hHyperionz-Crushridge|h |Hspell:52752:SPELL_HEAL|h|cff82f4ffAncestral Awakening|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff77361|r |cff82f4ffNature|r. (60934 Overhealed) ",
							["amount"] = 138295,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_AncestralAwakening",
					},
					["Rapid Renewal"] = {
						[-2] = {
							["time"] = "|cffffffff11/01/12 02:32:57|r\n|Hunit:0x0180000002EC3702:Pepzer-Uldum|hPepzer-Uldum|h |Hspell:63544:SPELL_HEAL|h|cff82f4ffRapid Renewal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff9871|r |cff82f4ffHoly|r. ",
							["amount"] = 9871,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Renew",
					},
					["Divine Light"] = {
						[-2] = {
							["time"] = "|cffffffff11/16/12 01:04:34|r\n|Hunit:0x0300000007537466:Bloodholic-Frostwolf|hBloodholic-Frostwolf|h |Hspell:82326:SPELL_HEAL|h|cff82f4ffDivine Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff70109|r |cff82f4ffHoly|r. ",
							["amount"] = 70109,
						},
						[2] = {
							["time"] = "|cffffffff11/09/12 03:58:52|r\n|Hunit:0x03800000044282B6:Bluecloud-Draka|hBluecloud-Draka|h |Hspell:82326:SPELL_HEAL|h|cff82f4ffDivine Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff15174|r |cff82f4ffHoly|r. (106292 Overhealed) (Critical) ",
							["amount"] = 121466,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SurgeOfLight",
					},
					["Eminence"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 10:25:05|r\n|Hunit:0x010000000516813F:Tzoo-Arathor|hTzoo-Arathor|h |Hspell:126890:SPELL_HEAL|h|cff82f4ffEminence|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff27601|r |cff82f4ffNature|r. ",
							["amount"] = 27601,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\inv_jewelcrafting_jadeserpent",
					},
					["Regrowth"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 09:27:17|r\n|Hunit:0x0380000005149A56:Mysstique-Runetotem|hMysstique-Runetotem|h |Hspell:8936:SPELL_HEAL|h|cff82f4ffRegrowth|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff61548|r |cff82f4ffNature|r. ",
							["amount"] = 61548,
						},
						[2] = {
							["time"] = "|cffffffff11/13/12 06:49:57|r\n|Hunit:0x0100000004CE6B12:Batzerfbirt-Smolderthorn|hBatzerfbirt-Smolderthorn|h |Hspell:8936:SPELL_HEAL|h|cff82f4ffRegrowth|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff100390|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 100390,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_ResistNature",
					},
					["Holy Word: Sanctuary"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 09:21:33|r\n|Hunit:0x0600000006276EAA:Sanctusletum-Vashj|hSanctusletum-Vashj|h |Hspell:88686:SPELL_PERIODIC_HEAL|h|cff82f4ffHoly Word: Sanctuary|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (2636 Overhealed) ",
							["amount"] = 2636,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 09:23:30|r\n|Hunit:0x0600000006276EAA:Sanctusletum-Vashj|hSanctusletum-Vashj|h |Hspell:88686:SPELL_PERIODIC_HEAL|h|cff82f4ffHoly Word: Sanctuary|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (5231 Overhealed) (Critical) ",
							["amount"] = 5231,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_DivineProvidence",
					},
					["Binding Heal"] = {
						[-2] = {
							["time"] = "|cffffffff11/01/12 02:53:30|r\n|Hunit:0x0180000002EC3702:Pepzer-Uldum|hPepzer-Uldum|h |Hspell:32546:SPELL_HEAL|h|cff82f4ffBinding Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff22870|r |cff82f4ffHoly|r. (10957 Overhealed) ",
							["amount"] = 33827,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_BlindingHeal",
					},
					["Holy Shock"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 01:03:37|r\n|Hunit:0x0100000004329F68:Ifaceroll-Frostmane|hIfaceroll-Frostmane|h |Hspell:25914:SPELL_HEAL|h|cff82f4ffHoly Shock|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff41747|r |cff82f4ffHoly|r. (4380 Overhealed) ",
							["amount"] = 46127,
						},
						[2] = {
							["time"] = "|cffffffff11/10/12 10:55:02|r\n|Hunit:0x07000000050C3428:Tríførçë-Area52|hTríførçë-Area52|h |Hspell:25914:SPELL_HEAL|h|cff82f4ffHoly Shock|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff93609|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 93609,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SearingLight",
					},
					["Divine Star"] = {
						[-2] = {
							["time"] = "|cffffffff11/09/12 03:40:43|r\n|Hunit:0x0100000000F2E4E3:Papal-Spirestone|hPapal-Spirestone|h |Hspell:122128:SPELL_HEAL|h|cff82f4ffDivine Star|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffSpellshadow|r. (13710 Overhealed) ",
							["amount"] = 13710,
						},
						[2] = {
							["time"] = "|cffffffff11/09/12 03:51:29|r\n|Hunit:0x0100000000F2E4E3:Papal-Spirestone|hPapal-Spirestone|h |Hspell:122128:SPELL_HEAL|h|cff82f4ffDivine Star|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff22768|r |cff82f4ffSpellshadow|r. (Critical) ",
							["amount"] = 22768,
						},
						["icon"] = "Interface\\Icons\\spell_priest_divinestar_shadow2",
					},
					["Magnetic Shroud Overload"] = {
						[-2] = {
							["time"] = "|cffffffff11/01/12 10:44:39|r\n|Hunit:0x01800000017A43CE:Gusgus-Crushridge|hGusgus-Crushridge|h |Hspell:107174:SPELL_HEAL|h|cff82f4ffMagnetic Shroud Overload|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff22854|r |cff82f4ffPhysical|r. (6021 Overhealed) ",
							["amount"] = 28875,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Trade_Engineering",
					},
					["Word of Glory"] = {
						[-2] = {
							["time"] = "|cffffffff11/16/12 01:00:53|r\n|Hunit:0x0300000007537466:Bloodholic-Frostwolf|hBloodholic-Frostwolf|h |Hspell:130551:SPELL_HEAL|h|cff82f4ffWord of Glory|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff40990|r |cff82f4ffHoly|r. (29179 Overhealed) ",
							["amount"] = 70169,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 01:04:00|r\n|Hunit:0x0100000004329F68:Ifaceroll-Frostmane|hIfaceroll-Frostmane|h |Hspell:130551:SPELL_HEAL|h|cff82f4ffWord of Glory|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff94711|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 94711,
						},
						["icon"] = "INTERFACE\\ICONS\\inv_helmet_96",
					},
					["Cascade"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 02:37:32|r\n|Hunit:0x01800000037350AB:Nyxe-Darkspear|hNyxe-Darkspear|h |Hspell:121148:SPELL_HEAL|h|cff82f4ffCascade|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff19415|r |cff82f4ffHoly|r. (36927 Overhealed) ",
							["amount"] = 56342,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 02:42:59|r\n|Hunit:0x01800000037350AB:Nyxe-Darkspear|hNyxe-Darkspear|h |Hspell:121148:SPELL_HEAL|h|cff82f4ffCascade|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff40913|r |cff82f4ffHoly|r. (89417 Overhealed) (Critical) ",
							["amount"] = 130330,
						},
						["icon"] = "Interface\\Icons\\ability_priest_cascade",
					},
					["Earth Shield"] = {
						[-2] = {
							["time"] = "|cffffffff11/16/12 07:51:29|r\n|Hunit:0x020000000574FC51:Phook-Trollbane|hPhook-Trollbane|h |Hspell:379:SPELL_HEAL|h|cff82f4ffEarth Shield|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff10072|r |cff82f4ffNature|r. ",
							["amount"] = 10072,
						},
						[2] = {
							["time"] = "|cffffffff11/16/12 09:01:31|r\n|Hunit:0x0300000001D08743:Deverin-Kil'jaeden|hDeverin-Kil'jaeden|h |Hspell:379:SPELL_HEAL|h|cff82f4ffEarth Shield|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff21001|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 21001,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_SkinofEarth",
					},
					["Riptide"] = {
						[-2] = {
							["time"] = "|cffffffff11/16/12 07:51:47|r\n|Hunit:0x020000000574FC51:Phook-Trollbane|hPhook-Trollbane|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff40289|r |cff82f4ffNature|r. ",
							["amount"] = 40289,
						},
						[2] = {
							["time"] = "|cffffffff11/16/12 07:51:31|r\n|Hunit:0x020000000574FC51:Phook-Trollbane|hPhook-Trollbane|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff45865|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 45865,
						},
						["icon"] = "Interface\\Icons\\spell_nature_riptide",
					},
					["Enveloping Mist"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 03:42:52|r\n|Hunit:0x0180000004C6B7DE:Panistar-Bronzebeard|hPanistar-Bronzebeard|h |Hspell:132120:SPELL_PERIODIC_HEAL|h|cff82f4ffEnveloping Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff33119|r |cff82f4ffNature|r. ",
							["amount"] = 33119,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 08:59:16|r\n|Hunit:0x0680000005762455:Trayvon-Tortheldrin|hTrayvon-Tortheldrin|h |Hspell:132120:SPELL_PERIODIC_HEAL|h|cff82f4ffEnveloping Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff59033|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 59033,
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_SpiritLink",
					},
					["Surging Mist"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 03:49:43|r\n|Hunit:0x0180000004C6B7DE:Panistar-Bronzebeard|hPanistar-Bronzebeard|h |Hspell:116995:SPELL_HEAL|h|cff82f4ffSurging Mist|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff142644|r |cff82f4ffNature|r. ",
							["amount"] = 142644,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 08:59:55|r\n|Hunit:0x0680000005762455:Trayvon-Tortheldrin|hTrayvon-Tortheldrin|h |Hspell:116995:SPELL_HEAL|h|cff82f4ffSurging Mist|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff92820|r |cff82f4ffNature|r. (42731 Overhealed) (Critical) ",
							["amount"] = 135551,
						},
						["icon"] = "Interface\\Icons\\ability_monk_surgingmist",
					},
					["Cleansing Waters"] = {
						[-2] = {
							["time"] = "|cffffffff11/01/12 05:30:26|r\n|Hunit:0x03800000046C9A7C:Charities-Aegwynn|hCharities-Aegwynn|h |Hspell:86961:SPELL_HEAL|h|cff82f4ffCleansing Waters|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff12190|r |cff82f4ffNature|r. ",
							["amount"] = 12190,
						},
						[2] = {
							["time"] = "|cffffffff11/01/12 05:34:44|r\n|Hunit:0x03800000046C9A7C:Charities-Aegwynn|hCharities-Aegwynn|h |Hspell:86961:SPELL_HEAL|h|cff82f4ffCleansing Waters|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (20530 Overhealed) (Critical) ",
							["amount"] = 20530,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Regeneration_02",
					},
					["Atonement"] = {
						[-2] = {
							["time"] = "|cffffffff11/05/12 11:03:59|r\n|Hunit:0x0180000003DCCD83:Superclever-Dunemaul|hSuperclever-Dunemaul|h |Hspell:81751:SPELL_HEAL|h|cff82f4ffAtonement|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff3845|r |cff82f4ffHoly|r. (37698 Overhealed) ",
							["amount"] = 41543,
						},
						[2] = {
							["time"] = "|cffffffff11/09/12 04:06:05|r\n|Hunit:0x03000000073F64A4:Triddle-Kil'jaeden|hTriddle-Kil'jaeden|h |Hspell:94472:SPELL_HEAL|h|cff82f4ffAtonement|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff65539|r |cff82f4ffHoly|r. (8185 Overhealed) (Critical) ",
							["amount"] = 73724,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_CircleOfRenewal",
					},
					["Cauterize Master"] = {
						[-2] = {
							["time"] = "|cffffffff11/09/12 02:14:29|r\n|Hunit:0xF140F0A3FA0029B3:Pippik|hPippik|h |Hspell:119899:SPELL_PERIODIC_HEAL|h|cffff1313Cauterize Master|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffff13135173|r |cffff1313Fire|r. (6678 Overhealed) ",
							["amount"] = 11851,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\inv_misc_volatilefire",
					},
					["Healing Surge"] = {
						[-2] = {
							["time"] = "|cffffffff11/16/12 07:49:39|r\n|Hunit:0x020000000574FC51:Phook-Trollbane|hPhook-Trollbane|h |Hspell:8004:SPELL_HEAL|h|cff82f4ffHealing Surge|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff59931|r |cff82f4ffNature|r. (51008 Overhealed) ",
							["amount"] = 110939,
						},
						[2] = {
							["time"] = "|cffffffff11/08/12 10:49:30|r\n|Hunit:0x0100000002AE0D65:Klunder-Spirestone|hKlunder-Spirestone|h |Hspell:8004:SPELL_HEAL|h|cff82f4ffHealing Surge|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff166755|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 166755,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWay",
					},
					["Prayer of Mending"] = {
						[-2] = {
							["time"] = "|cffffffff11/10/12 10:54:29|r\n|Hunit:0x0200000006652D16:Xéo-Zul'jin|hXéo-Zul'jin|h |Hspell:33110:SPELL_HEAL|h|cff82f4ffPrayer of Mending|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff43337|r |cff82f4ffHoly|r. ",
							["amount"] = 43337,
						},
						[2] = {
							["time"] = "|cffffffff11/24/12 03:41:42|r\n|Hunit:0x0100000002481119:Sett|hSett|h |Hspell:33110:SPELL_HEAL|h|cff82f4ffPrayer of Mending|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff64803|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 64803,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfMendingtga",
					},
					["Circle of Healing"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 09:20:58|r\n|Hunit:0x0600000006276EAA:Sanctusletum-Vashj|hSanctusletum-Vashj|h |Hspell:34861:SPELL_HEAL|h|cff82f4ffCircle of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (19770 Overhealed) ",
							["amount"] = 19770,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 06:40:21|r\n|Hunit:0x038000000014470E:Shirah-Muradin|hShirah-Muradin|h |Hspell:34861:SPELL_HEAL|h|cff82f4ffCircle of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff37462|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 37462,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_CircleOfRenewal",
					},
					["Chi Wave"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 01:02:35|r\n|Hunit:0x0100000005125B17:Xunmi-Shadowsong|hXunmi-Shadowsong|h |Hspell:132463:SPELL_HEAL|h|cff82f4ffChi Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff11626|r |cff82f4ffNature|r. (30130 Overhealed) ",
							["amount"] = 41756,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 09:03:00|r\n|Hunit:0x0680000005762455:Trayvon-Tortheldrin|hTrayvon-Tortheldrin|h |Hspell:132463:SPELL_HEAL|h|cff82f4ffChi Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff69452|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 69452,
						},
						["icon"] = "Interface\\Icons\\ability_monk_chiwave",
					},
					["Spinning Crane Kick"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 03:37:30|r\n|Hunit:0x0180000004C6B7DE:Panistar-Bronzebeard|hPanistar-Bronzebeard|h |Hspell:117640:SPELL_HEAL|h|cff82f4ffSpinning Crane Kick|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff6908|r |cff82f4ffNature|r. ",
							["amount"] = 6908,
						},
						[2] = {
							["time"] = "|cffffffff11/08/12 03:37:29|r\n|Hunit:0x0180000004C6B7DE:Panistar-Bronzebeard|hPanistar-Bronzebeard|h |Hspell:117640:SPELL_HEAL|h|cff82f4ffSpinning Crane Kick|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (13817 Overhealed) (Critical) ",
							["amount"] = 13817,
						},
						["icon"] = "Interface\\Icons\\ability_monk_cranekick_new",
					},
					["Spirit Mend"] = {
						[-2] = {
							["time"] = "|cffffffff11/16/12 08:49:02|r\n|Hunit:0xF140EB594400019E:Spirit Beast|hSpirit Beast|h |Hspell:90361:SPELL_HEAL|h|cff82f4ffSpirit Mend|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff10578|r |cff82f4ffNature|r. ",
							["amount"] = 10578,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_SpiritLink",
					},
					["Uplift"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 10:47:39|r\n|Hunit:0x03800000058E37FC:Tyquando-Akama|hTyquando-Akama|h |Hspell:116670:SPELL_HEAL|h|cff82f4ffUplift|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (45421 Overhealed) ",
							["amount"] = 45421,
						},
						[2] = {
							["time"] = "|cffffffff11/24/12 03:41:31|r\n|Hunit:0x0100000005131C13:Málingshu|hMálingshu|h |Hspell:116670:SPELL_HEAL|h|cff82f4ffUplift|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (72671 Overhealed) (Critical) ",
							["amount"] = 72671,
						},
						["icon"] = "Interface\\Icons\\ability_monk_uplift",
					},
					["Greater Healing Wave"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 10:57:14|r\n|Hunit:0x0100000002AE0D65:Klunder-Spirestone|hKlunder-Spirestone|h |Hspell:77472:SPELL_HEAL|h|cff82f4ffGreater Healing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff129096|r |cff82f4ffNature|r. ",
							["amount"] = 129096,
						},
						[2] = {
							["time"] = "|cffffffff11/08/12 10:49:32|r\n|Hunit:0x0100000002AE0D65:Klunder-Spirestone|hKlunder-Spirestone|h |Hspell:77472:SPELL_HEAL|h|cff82f4ffGreater Healing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff78910|r |cff82f4ffNature|r. (78874 Overhealed) (Critical) ",
							["amount"] = 157784,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWaveLesser",
					},
					["Beacon of Light"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 01:01:41|r\n|Hunit:0x03000000067DC11A:Buziaki-Blackrock|hBuziaki-Blackrock|h |Hspell:53652:SPELL_HEAL|h|cff82f4ffBeacon of Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (31588 Overhealed) ",
							["amount"] = 31588,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Paladin_BeaconofLight",
					},
					["Lightwell Renew"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 09:22:43|r\n|Hunit:0x0600000006276EAA:Sanctusletum-Vashj|hSanctusletum-Vashj|h |Hspell:7001:SPELL_PERIODIC_HEAL|h|cff82f4ffLightwell Renew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (19493 Overhealed) ",
							["amount"] = 19493,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SummonLightwell",
					},
					["Greater Heal"] = {
						[-2] = {
							["time"] = "|cffffffff11/05/12 10:54:47|r\n|Hunit:0x0180000003DCCD83:Superclever-Dunemaul|hSuperclever-Dunemaul|h |Hspell:2060:SPELL_HEAL|h|cff82f4ffGreater Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff77293|r |cff82f4ffHoly|r. ",
							["amount"] = 77293,
						},
						[2] = {
							["time"] = "|cffffffff11/05/12 10:54:25|r\n|Hunit:0x0180000003DCCD83:Superclever-Dunemaul|hSuperclever-Dunemaul|h |Hspell:2060:SPELL_HEAL|h|cff82f4ffGreater Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff101370|r |cff82f4ffHoly|r. (48745 Overhealed) (Critical) ",
							["amount"] = 150115,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_GreaterHeal",
					},
					["Blood Burst"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 09:58:39|r\n|Hunit:0xF1306D71000019AF:Bloodworm|hBloodworm|h |Hspell:81280:SPELL_HEAL|h|cff82f4ffBlood Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff33199|r |cff82f4ffShadow|r. ",
							["amount"] = 33199,
						},
						[2] = {
							["time"] = "|cffffffff11/24/12 10:15:03|r\n|Hunit:0xF1306D7100006C68:Bloodworm|hBloodworm|h |Hspell:81280:SPELL_HEAL|h|cff82f4ffBlood Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff54326|r |cff82f4ffShadow|r. (Critical) ",
							["amount"] = 54326,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_BloodNova",
					},
					["Flash Heal"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 10:04:23|r\n|Hunit:0xF130FC1C000026D1:Anduin Wrynn|hAnduin Wrynn|h |Hspell:126400:SPELL_HEAL|h|cffff1313Flash Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffff13130|r |cffff1313Holy|r. (347227 Overhealed) ",
							["amount"] = 347227,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 12:29:02|r\n|Hunit:0x028000000461E028:Fikle-Lightning'sBlade|hFikle-Lightning'sBlade|h |Hspell:2061:SPELL_HEAL|h|cff82f4ffFlash Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff64214|r |cff82f4ffHoly|r. (67158 Overhealed) (Critical) ",
							["amount"] = 131372,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Halo"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 10:44:34|r\n|Hunit:0x0380000004809876:Faeryna-Akama|hFaeryna-Akama|h |Hspell:120696:SPELL_HEAL|h|cff82f4ffHalo|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffShadow|r. (98442 Overhealed) ",
							["amount"] = 98442,
						},
						[2] = {
							["time"] = "|cffffffff11/13/12 05:50:05|r\n|Hunit:0x0200000006444CA9:Pcl-ShatteredHand|hPcl-ShatteredHand|h |Hspell:120696:SPELL_HEAL|h|cff82f4ffHalo|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff241511|r |cff82f4ffShadow|r. (Critical) ",
							["amount"] = 241511,
						},
						["icon"] = "Interface\\Icons\\ability_priest_halo_shadow",
					},
					["Eminence (Statue)"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 06:09:26|r\n|Hunit:0x0100000005136F9F:Fightclub-Terenas|hFightclub-Terenas|h |Hspell:117895:SPELL_HEAL|h|cff82f4ffEminence (Statue)|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff29119|r |cff82f4ffNature|r. (109915 Overhealed) ",
							["amount"] = 139034,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\inv_jewelcrafting_jadeserpent",
					},
					["Aggressive Behavior"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 03:42:44|r\n|Hunit:0xF150EC4B0043C32F:Sha of Anger|hSha of Anger|h |Hspell:119626:SPELL_HEAL|h|cffff1313Aggressive Behavior|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffff131345870|r |cffff1313Shadow|r. (388254 Overhealed) ",
							["amount"] = 434124,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Misc_EmotionAngry",
					},
					["Lay on Hands"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 09:39:27|r\n|Hunit:0x07000000050A9354:Fláshlight-Area52|hFláshlight-Area52|h |Hspell:633:SPELL_HEAL|h|cff82f4ffLay on Hands|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff276352|r |cff82f4ffHoly|r. ",
							["amount"] = 276352,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_LayOnHands",
					},
					["Chi Torpedo"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 08:32:27|r\n|Hunit:0x0700000004FDFE17:Schmearson-Coilfang|hSchmearson-Coilfang|h |Hspell:124040:SPELL_HEAL|h|cff82f4ffChi Torpedo|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (30366 Overhealed) ",
							["amount"] = 30366,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_quitornado",
					},
					["Divine Hymn"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 06:40:11|r\n|Hunit:0x038000000014470E:Shirah-Muradin|hShirah-Muradin|h |Hspell:64844:SPELL_HEAL|h|cff82f4ffDivine Hymn|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff59886|r |cff82f4ffHoly|r. ",
							["amount"] = 59886,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 03:10:27|r\n|Hunit:0x070000000508506D:Mapplethorpe-Area52|hMapplethorpe-Area52|h |Hspell:64844:SPELL_HEAL|h|cff82f4ffDivine Hymn|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (83822 Overhealed) (Critical) ",
							["amount"] = 83822,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_DivineProvidence",
					},
					["Healing Sphere"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 03:47:50|r\n|Hunit:0x0180000004C6B7DE:Panistar-Bronzebeard|hPanistar-Bronzebeard|h |Hspell:115464:SPELL_HEAL|h|cff82f4ffHealing Sphere|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff21993|r |cff82f4ffNature|r. (17544 Overhealed) ",
							["amount"] = 39537,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_healthsphere",
					},
					["Chain Heal"] = {
						[-2] = {
							["time"] = "|cffffffff11/16/12 07:51:20|r\n|Hunit:0x020000000574FC51:Phook-Trollbane|hPhook-Trollbane|h |Hspell:1064:SPELL_HEAL|h|cff82f4ffChain Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff41260|r |cff82f4ffNature|r. ",
							["amount"] = 41260,
						},
						[2] = {
							["time"] = "|cffffffff11/16/12 07:46:46|r\n|Hunit:0x020000000574FC51:Phook-Trollbane|hPhook-Trollbane|h |Hspell:1064:SPELL_HEAL|h|cff82f4ffChain Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff39040|r |cff82f4ffNature|r. (15339 Overhealed) (Critical) ",
							["amount"] = 54379,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWaveGreater",
					},
					["Flash of Light"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 08:26:54|r\n|Hunit:0x0300000006966634:Wópe-Barthilas|hWópe-Barthilas|h |Hspell:19750:SPELL_HEAL|h|cff82f4ffFlash of Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff69249|r |cff82f4ffHoly|r. ",
							["amount"] = 69249,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 09:42:47|r\n|Hunit:0x07000000050A9354:Fláshlight-Area52|hFláshlight-Area52|h |Hspell:19750:SPELL_HEAL|h|cff82f4ffFlash of Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff115115|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 115115,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Holy Prism"] = {
						[-2] = {
							["time"] = "|cffffffff12/20/12 10:21:59|r\n|Hunit:0x01800000015ECCE9:Sheesh-Stormscale|hSheesh-Stormscale|h |Hspell:114871:SPELL_HEAL|h|cff82f4ffHoly Prism|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff61983|r |cff82f4ffHoly|r. ",
							["amount"] = 61983,
						},
						[2] = {
							["time"] = "|cffffffff12/20/12 10:02:07|r\n|Hunit:0x01800000015ECCE9:Sheesh-Stormscale|hSheesh-Stormscale|h |Hspell:114871:SPELL_HEAL|h|cff82f4ffHoly Prism|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff18363|r |cff82f4ffHoly|r. (113404 Overhealed) (Critical) ",
							["amount"] = 131767,
						},
						["icon"] = "Interface\\Icons\\spell_paladin_holyprism",
					},
					["Zen Sphere: Detonate"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 03:55:31|r\n|Hunit:0x0180000004C6B7DE:Panistar-Bronzebeard|hPanistar-Bronzebeard|h |Hspell:124101:SPELL_HEAL|h|cff82f4ffZen Sphere: Detonate|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (44602 Overhealed) ",
							["amount"] = 44602,
						},
						[2] = {
							["time"] = "|cffffffff11/09/12 04:01:22|r\n|Hunit:0x038000000582E547:Madmojoman-Runetotem|hMadmojoman-Runetotem|h |Hspell:124101:SPELL_HEAL|h|cff82f4ffZen Sphere: Detonate|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (38181 Overhealed) (Critical) ",
							["amount"] = 38181,
						},
						["icon"] = "Interface\\Icons\\ability_monk_forcesphere",
					},
					["Light of the Ancient Kings"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 08:36:02|r\n|Hunit:0xF130B5A300000094:Guardian of Ancient Kings|hGuardian of Ancient Kings|h |Hspell:86678:SPELL_HEAL|h|cff82f4ffLight of the Ancient Kings|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff68442|r |cff82f4ffHoly|r. ",
							["amount"] = 68442,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolyBolt",
					},
					["Healing Touch"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 09:32:35|r\n|Hunit:0x010000000184A0D9:Canden|hCanden|h |Hspell:5185:SPELL_HEAL|h|cff82f4ffHealing Touch|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff65456|r |cff82f4ffNature|r. ",
							["amount"] = 65456,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingTouch",
					},
					["Tranquility"] = {
						[-2] = {
							["time"] = "|cffffffff11/09/12 03:55:54|r\n|Hunit:0x03000000061556A0:Clucker-Ner'zhul|hClucker-Ner'zhul|h |Hspell:44203:SPELL_HEAL|h|cff82f4ffTranquility|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff36200|r |cff82f4ffNature|r. ",
							["amount"] = 36200,
						},
						[2] = {
							["time"] = "|cffffffff11/09/12 12:20:51|r\n|Hunit:0x0180000004C18C2D:Dallamain-Uldum|hDallamain-Uldum|h |Hspell:44203:SPELL_HEAL|h|cff82f4ffTranquility|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff70405|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 70405,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Tranquility",
					},
					["Wild Growth"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 09:21:06|r\n|Hunit:0x0380000005149A56:Mysstique-Runetotem|hMysstique-Runetotem|h |Hspell:48438:SPELL_PERIODIC_HEAL|h|cff82f4ffWild Growth|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (6202 Overhealed) ",
							["amount"] = 6202,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 09:21:06|r\n|Hunit:0x0380000005149A56:Mysstique-Runetotem|hMysstique-Runetotem|h |Hspell:48438:SPELL_PERIODIC_HEAL|h|cff82f4ffWild Growth|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (12487 Overhealed) (Critical) ",
							["amount"] = 12487,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Flourish",
					},
					["Spirit Link"] = {
						[-2] = {
							["time"] = "|cffffffff11/13/12 11:08:29|r\n|Hunit:0xF130CF0E0000044A:Spirit Link Totem|hSpirit Link Totem|h |Hspell:98021:SPELL_HEAL|h|cff82f4ffSpirit Link|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff61766|r |cff82f4ffNature|r. ",
							["amount"] = 61766,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_SpiritLink",
					},
					["Gift of the Serpent"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 11:01:13|r\n|Hunit:0x03000000073EC284:Gwyn-SilverHand|hGwyn-SilverHand|h |Hspell:124041:SPELL_HEAL|h|cff82f4ffGift of the Serpent|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (37576 Overhealed) ",
							["amount"] = 37576,
						},
						[2] = {
							["time"] = "|cffffffff11/08/12 03:49:13|r\n|Hunit:0x0180000004C6B7DE:Panistar-Bronzebeard|hPanistar-Bronzebeard|h |Hspell:124041:SPELL_HEAL|h|cff82f4ffGift of the Serpent|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff20705|r |cff82f4ffNature|r. (43737 Overhealed) (Critical) ",
							["amount"] = 64442,
						},
						["icon"] = "Interface\\Icons\\ability_monk_healthsphere",
					},
					["Nourish"] = {
						[-2] = {
							["time"] = "|cffffffff11/04/12 12:10:16|r\n|Hunit:0x0100000004B1E5BB:Eielyse-Frostmane|hEielyse-Frostmane|h |Hspell:50464:SPELL_HEAL|h|cff82f4ffNourish|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff29665|r |cff82f4ffNature|r. ",
							["amount"] = 29665,
						},
						[2] = {
							["time"] = "|cffffffff11/04/12 12:10:18|r\n|Hunit:0x0100000004B1E5BB:Eielyse-Frostmane|hEielyse-Frostmane|h |Hspell:50464:SPELL_HEAL|h|cff82f4ffNourish|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff46224|r |cff82f4ffNature|r. (12261 Overhealed) (Critical) ",
							["amount"] = 58485,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Nourish",
					},
					["Healing Tide"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 02:48:32|r\n|Hunit:0x0100000003DC6A67:Capplanet-Dragonmaw|hCapplanet-Dragonmaw|h |Hspell:114942:SPELL_HEAL|h|cff82f4ffHealing Tide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff48129|r |cff82f4ffPhysical|r. ",
							["amount"] = 48129,
						},
						[2] = {
							["time"] = "|cffffffff11/08/12 11:00:17|r\n|Hunit:0x0100000002AE0D65:Klunder-Spirestone|hKlunder-Spirestone|h |Hspell:114942:SPELL_HEAL|h|cff82f4ffHealing Tide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff98084|r |cff82f4ffPhysical|r. (Critical) ",
							["amount"] = 98084,
						},
						["icon"] = "Interface\\Icons\\ability_shaman_healingtide",
					},
					["Living Seed"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 12:04:09|r\n|Hunit:0x068000000558E4CD:Losus-MoonGuard|hLosus-MoonGuard|h |Hspell:48503:SPELL_HEAL|h|cff82f4ffLiving Seed|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff30062|r |cff82f4ffNature|r. ",
							["amount"] = 30062,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_GiftoftheEarthmother",
					},
					["Wild Mushroom: Bloom"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 05:35:52|r\n|Hunit:0x038000000290C9D8:Inception-Malorne|hInception-Malorne|h |Hspell:102792:SPELL_HEAL|h|cff82f4ffWild Mushroom: Bloom|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff8285|r |cff82f4ffNature|r. ",
							["amount"] = 8285,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 05:37:46|r\n|Hunit:0x038000000290C9D8:Inception-Malorne|hInception-Malorne|h |Hspell:102792:SPELL_HEAL|h|cff82f4ffWild Mushroom: Bloom|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (15456 Overhealed) (Critical) ",
							["amount"] = 15456,
						},
						["icon"] = "Interface\\Icons\\INV_Mushroom_07",
					},
					["Lifebloom"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 09:27:40|r\n|Hunit:0x0380000005149A56:Mysstique-Runetotem|hMysstique-Runetotem|h |Hspell:33778:SPELL_HEAL|h|cff82f4ffLifebloom|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (88503 Overhealed) ",
							["amount"] = 88503,
						},
						[2] = {
							["time"] = "|cffffffff11/16/12 07:51:00|r\n|Hunit:0x040000000071E98E:Punkybrewstr-Destromath|hPunkybrewstr-Destromath|h |Hspell:33778:SPELL_HEAL|h|cff82f4ffLifebloom|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff38362|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 38362,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingTouch",
					},
					["Revival"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 03:44:55|r\n|Hunit:0x0180000004C6B7DE:Panistar-Bronzebeard|hPanistar-Bronzebeard|h |Hspell:115310:SPELL_HEAL|h|cff82f4ffRevival|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (142058 Overhealed) ",
							["amount"] = 142058,
						},
						[2] = {
							["time"] = "|cffffffff11/08/12 03:36:55|r\n|Hunit:0x0180000004C6B7DE:Panistar-Bronzebeard|hPanistar-Bronzebeard|h |Hspell:115310:SPELL_HEAL|h|cff82f4ffRevival|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (291948 Overhealed) (Critical) ",
							["amount"] = 291948,
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_BlessingOfEternals",
					},
					["Mistweaving"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 10:17:39|r\n|Hunit:0xF130FF0F000067A8:Mistweaver Nian|hMistweaver Nian|h |Hspell:125125:SPELL_PERIODIC_HEAL|h|cff82f4ffMistweaving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff65119|r |cff82f4ffNature|r. ",
							["amount"] = 65119,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_soothingmists",
					},
					["Prayer of Healing"] = {
						[-2] = {
							["time"] = "|cffffffff11/05/12 10:51:26|r\n|Hunit:0x0180000003DCCD83:Superclever-Dunemaul|hSuperclever-Dunemaul|h |Hspell:596:SPELL_HEAL|h|cff82f4ffPrayer of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff49622|r |cff82f4ffHoly|r. ",
							["amount"] = 49622,
						},
						[2] = {
							["time"] = "|cffffffff11/05/12 11:00:56|r\n|Hicon:128:source|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8.blp:0|t|h|Hunit:0x0180000003DCCD83:Superclever-Dunemaul|hSuperclever-Dunemaul|h |Hspell:596:SPELL_HEAL|h|cff82f4ffPrayer of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (88491 Overhealed) (Critical) ",
							["amount"] = 88491,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfHealing02",
					},
					["Holy Radiance"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 10:46:41|r\n|Hunit:0x018000000432ECF8:Valyne-Daggerspine|hValyne-Daggerspine|h |Hspell:82327:SPELL_HEAL|h|cff82f4ffHoly Radiance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff19069|r |cff82f4ffHoly|r. (22510 Overhealed) ",
							["amount"] = 41579,
						},
						[2] = {
							["time"] = "|cffffffff11/01/12 12:46:38|r\n|Hunit:0x03800000045451C3:Ateth-Korgath|hAteth-Korgath|h |Hspell:82327:SPELL_HEAL|h|cff82f4ffHoly Radiance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff16288|r |cff82f4ffHoly|r. (26151 Overhealed) (Critical) ",
							["amount"] = 42439,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_paladin_divinecircle",
					},
					["Ancestral Guidance"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 11:48:15|r\n|Hunit:0x038000000581AEE8:Savarese-Mug'thol|hSavarese-Mug'thol|h |Hspell:114911:SPELL_HEAL|h|cff82f4ffAncestral Guidance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffPhysical|r. (99850 Overhealed) ",
							["amount"] = 99850,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_shaman_ancestralguidance",
					},
					["Restorative Mists"] = {
						[-2] = {
							["time"] = "|cffffffff11/16/12 12:36:31|r\n|Hunit:0x01800000010703FC:Hyperionz-Crushridge|hHyperionz-Crushridge|h |Hspell:114083:SPELL_HEAL|h|cff82f4ffRestorative Mists|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (73569 Overhealed) ",
							["amount"] = 73569,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_TidalWaves",
					},
					["Renewing Mist"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 10:47:11|r\n|Hunit:0x03800000058E37FC:Tyquando-Akama|hTyquando-Akama|h |Hspell:119611:SPELL_PERIODIC_HEAL|h|cff82f4ffRenewing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (13458 Overhealed) ",
							["amount"] = 13458,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 10:47:13|r\n|Hunit:0x03800000058E37FC:Tyquando-Akama|hTyquando-Akama|h |Hspell:119611:SPELL_PERIODIC_HEAL|h|cff82f4ffRenewing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (27723 Overhealed) (Critical) ",
							["amount"] = 27723,
						},
						["icon"] = "Interface\\Icons\\ability_monk_renewingmists",
					},
					["Rejuvenation"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 05:31:47|r\n|Hunit:0x0300000006CEF121:Faronn-Tichondrius|hFaronn-Tichondrius|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cff82f4ffRejuvenation|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (22249 Overhealed) ",
							["amount"] = 22249,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 05:31:42|r\n|Hunit:0x0300000006CEF121:Faronn-Tichondrius|hFaronn-Tichondrius|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cff82f4ffRejuvenation|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff45832|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 45832,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Rejuvenation",
					},
					["Vampiric Embrace"] = {
						[-2] = {
							["time"] = "|cffffffff11/13/12 05:50:50|r\n|Hunit:0x0200000006444CA9:Pcl-ShatteredHand|hPcl-ShatteredHand|h |Hspell:15290:SPELL_PERIODIC_HEAL|h|cff82f4ffVampiric Embrace|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff9906|r |cff82f4ffShadow|r. ",
							["amount"] = 9906,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_UnsummonBuilding",
					},
					["Lightspring Renew"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 01:01:32|r\n|Hunit:0x0300000006FB19D4:Fapaccino-Kil'jaeden|hFapaccino-Kil'jaeden|h |Hspell:126154:SPELL_PERIODIC_HEAL|h|cff82f4ffLightspring Renew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff17238|r |cff82f4ffHoly|r. ",
							["amount"] = 17238,
						},
						[2] = {
							["time"] = "|cffffffff11/01/12 02:49:27|r\n|Hunit:0x0180000002EC3702:Pepzer-Uldum|hPepzer-Uldum|h |Hspell:126154:SPELL_PERIODIC_HEAL|h|cff82f4ffLightspring Renew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (27332 Overhealed) (Critical) ",
							["amount"] = 27332,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SummonLightwell",
					},
					["Zen Sphere"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 03:45:45|r\n|Hunit:0x0180000004C6B7DE:Panistar-Bronzebeard|hPanistar-Bronzebeard|h |Hspell:124081:SPELL_PERIODIC_HEAL|h|cff82f4ffZen Sphere|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (11541 Overhealed) ",
							["amount"] = 11541,
						},
						[2] = {
							["time"] = "|cffffffff11/13/12 10:24:57|r\n|Hunit:0x010000000516D810:Lokitahruark-Spirestone|hLokitahruark-Spirestone|h |Hspell:124081:SPELL_PERIODIC_HEAL|h|cff82f4ffZen Sphere|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff12301|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 12301,
						},
						["icon"] = "Interface\\Icons\\ability_monk_forcesphere",
					},
					["Earthliving"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 10:49:22|r\n|Hunit:0x0100000002AE0D65:Klunder-Spirestone|hKlunder-Spirestone|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff6702|r |cff82f4ffNature|r. ",
							["amount"] = 6702,
						},
						[2] = {
							["time"] = "|cffffffff11/08/12 10:47:08|r\n|Hunit:0x0100000002AE0D65:Klunder-Spirestone|hKlunder-Spirestone|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff11235|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 11235,
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_GiftEarthmother",
					},
					["Holy Light"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 10:46:30|r\n|Hunit:0x0300000007450C0E:Kolzzi-Blackrock|hKolzzi-Blackrock|h |Hspell:635:SPELL_HEAL|h|cff82f4ffHoly Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (40417 Overhealed) ",
							["amount"] = 40417,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 10:46:30|r\n|Hunit:0x018000000432ECF8:Valyne-Daggerspine|hValyne-Daggerspine|h |Hspell:635:SPELL_HEAL|h|cff82f4ffHoly Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff3357|r |cff82f4ffHoly|r. (79811 Overhealed) (Critical) ",
							["amount"] = 83168,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolyBolt",
					},
					["Cleansing Flames"] = {
						[-2] = {
							["time"] = "|cffffffff11/01/12 02:33:05|r\n|Hunit:0x0180000002EC3702:Pepzer-Uldum|hPepzer-Uldum|h |Hspell:107835:SPELL_HEAL|h|cff82f4ffCleansing Flames|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (12627 Overhealed) ",
							["amount"] = 12627,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_MoltenBlood",
					},
					["Battle Insight"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 12:53:22|r\n|Hunit:0x05000000015ED635:Cayse-Dalaran|hCayse-Dalaran|h |Hspell:123530:SPELL_HEAL|h|cff82f4ffBattle Insight|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff18073|r |cff82f4ffHoly|r. ",
							["amount"] = 18073,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_CircleOfRenewal",
					},
					["Heal"] = {
						[-2] = {
							["time"] = "|cffffffff11/05/12 10:55:20|r\n|Hunit:0x0180000003DCCD83:Superclever-Dunemaul|hSuperclever-Dunemaul|h |Hspell:2050:SPELL_HEAL|h|cff82f4ffHeal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff40066|r |cff82f4ffHoly|r. (11801 Overhealed) ",
							["amount"] = 51867,
						},
						[2] = {
							["time"] = "|cffffffff11/02/12 09:46:22|r\n|Hunit:0x03800000056EC5FB:Cowbublz-Muradin|hCowbublz-Muradin|h |Hspell:2050:SPELL_HEAL|h|cff82f4ffHeal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff47323|r |cff82f4ffHoly|r. (4492 Overhealed) (Critical) ",
							["amount"] = 51815,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_LesserHeal",
					},
					["Penance"] = {
						[-2] = {
							["time"] = "|cffffffff11/05/12 10:51:21|r\n|Hunit:0x0180000003DCCD83:Superclever-Dunemaul|hSuperclever-Dunemaul|h |Hspell:47750:SPELL_HEAL|h|cff82f4ffPenance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff29844|r |cff82f4ffHoly|r. ",
							["amount"] = 29844,
						},
						[2] = {
							["time"] = "|cffffffff11/05/12 11:02:23|r\n|Hunit:0x0180000003DCCD83:Superclever-Dunemaul|hSuperclever-Dunemaul|h |Hspell:47750:SPELL_HEAL|h|cff82f4ffPenance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff53914|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 53914,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Penance",
					},
					["Daybreak"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 02:42:27|r\n|Hunit:0x0300000003DBEDBD:Loroline-Blackrock|hLoroline-Blackrock|h |Hspell:121129:SPELL_HEAL|h|cff82f4ffDaybreak|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff41321|r |cff82f4ffPhysical|r. ",
							["amount"] = 41321,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_QirajIdol_Sun",
					},
					["Eternal Flame"] = {
						[-2] = {
							["time"] = "|cffffffff11/13/12 07:16:16|r\n|Hunit:0x0100000004D8C7EA:Notthehair-Dragonmaw|hNotthehair-Dragonmaw|h |Hspell:114163:SPELL_HEAL|h|cff82f4ffEternal Flame|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff71256|r |cff82f4ffHoly|r. ",
							["amount"] = 71256,
						},
						[2] = {
							["time"] = "|cffffffff11/01/12 12:55:39|r\n|Hunit:0x03800000045451C3:Ateth-Korgath|hAteth-Korgath|h |Hspell:114163:SPELL_HEAL|h|cff82f4ffEternal Flame|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff49030|r |cff82f4ffHoly|r. (47576 Overhealed) (Critical) ",
							["amount"] = 96606,
						},
						["icon"] = "Interface\\Icons\\INV_Torch_Thrown",
					},
					["Healing Stream Totem"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 06:11:37|r\n|Hunit:0x038000000581B785:Redsealmint-Mug'thol|hRedsealmint-Mug'thol|h |Hspell:52042:SPELL_PERIODIC_HEAL|h|cff82f4ffHealing Stream Totem|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff45445|r |cff82f4ffNature|r. ",
							["amount"] = 45445,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 06:16:04|r\n|Hunit:0x038000000581B785:Redsealmint-Mug'thol|hRedsealmint-Mug'thol|h |Hspell:52042:SPELL_PERIODIC_HEAL|h|cff82f4ffHealing Stream Totem|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff54799|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 54799,
						},
						["icon"] = "Interface\\Icons\\INV_Spear_04",
					},
					["Cenarion Ward"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 12:04:09|r\n|Hunit:0x068000000558E4CD:Losus-MoonGuard|hLosus-MoonGuard|h |Hspell:102352:SPELL_PERIODIC_HEAL|h|cff82f4ffCenarion Ward|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff19132|r |cff82f4ffNature|r. ",
							["amount"] = 19132,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_NaturalPerfection",
					},
					["Ferment"] = {
						[-2] = {
							["time"] = "|cffffffff11/01/12 09:46:37|r\n|Hunit:0xF131036D0003AFC6:Yeasty Brew Alemental|hYeasty Brew Alemental|h |Hspell:114451:SPELL_HEAL|h|cffff1313Ferment|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffff13130|r |cffff1313Physical|r. (2335 Overhealed) ",
							["amount"] = 2335,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\inv_misc_lifeblood",
					},
				},
				["hit"] = {
					["Holy"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 11:32:58|r\n|Hunit:0x0180000004CBB6AB:Slaytón-Darkspear|hSlaytón-Darkspear|h |Hspell:24275:SPELL_DAMAGE|h|cffff1313Hammer of Wrath|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffff1313106702|r |cffff1313Holy|r. ",
							["amount"] = 106702,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 12:44:00|r\n|Hunit:0x04800000058CE89C:Ravenvale-EmeraldDream|hRavenvale-EmeraldDream|h |Hspell:120517:SPELL_DAMAGE|h|cffff1313Halo|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffff131355241|r |cffff1313Holy|r. (24627 Overkill) (Critical) ",
							["amount"] = 79868,
						},
						["icon"] = "Interface\\Icons\\spell_paladin_hammerofwrath",
					},
					["Frost"] = {
						[-2] = {
							["time"] = "|cffffffff11/01/12 02:36:15|r\n|Hunit:0xF130DC800000D0CE:Wise Mari|hWise Mari|h |Hspell:106334:SPELL_DAMAGE|h|cffff1313Wash Away|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffff131394005|r |cffff1313Frost|r. ",
							["amount"] = 94005,
						},
						[2] = {
							["time"] = "|cffffffff11/13/12 08:10:08|r\n|Hunit:0x060000000306488F:Irônmage-Shu'halo|hIrônmage-Shu'halo|h |Hspell:113092:SPELL_DAMAGE|h|cffff1313Frost Bomb|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffff1313280109|r |cffff1313Frost|r. (51326 Overkill) (Critical) ",
							["amount"] = 331435,
						},
						["icon"] = "Interface\\Icons\\spell_mage_frostbomb",
					},
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff11/14/12 05:36:33|r\n|Hunit:0x0300000005BDE5A8:Aircondishnr-Tichondrius|hAircondishnr-Tichondrius|h |Hspell:124915:SPELL_DAMAGE|h|cffff1313Chaos Wave|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffff131310846|r |cffff1313Chaos|r. (132916 Overkill) ",
							["amount"] = 143762,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 07:51:06|r\n|Hunit:0x028000000566C7D7:Firemagic-Drakkari|hFiremagic-Drakkari|h |Hspell:124915:SPELL_DAMAGE|h|cffff1313Chaos Wave|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffff1313156545|r |cffff1313Chaos|r. (Critical) ",
							["amount"] = 156545,
						},
						["icon"] = "Interface\\Icons\\ability_warlock_coil2",
					},
					["Arcane"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 06:06:05|r\n|Hunit:0xF130ED79000006FB:Celestial Protector|hCelestial Protector|h |Hspell:117914:SPELL_DAMAGE|h|cffff1313Total Annihilation|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffff1313129301|r |cffff1313Arcane|r. ",
							["amount"] = 129301,
						},
						[2] = {
							["time"] = "|cffffffff11/13/12 07:46:19|r\n|Hunit:0x0100000001A422EF:Yaross-Terenas|hYaross-Terenas|h |Hspell:3044:SPELL_DAMAGE|h|cffff1313Arcane Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffff131358597|r |cffff1313Arcane|r. (Critical) ",
							["amount"] = 58597,
						},
						["icon"] = "Interface\\Icons\\Ability_Mage_WorldInFlames",
					},
					["Shadow"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 10:34:29|r\n|Hunit:0xF130F10B0000356E:Abomination of Anger|hAbomination of Anger|h |Hspell:120783:SPELL_DAMAGE|h|cffff1313Deathforce|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffff1313373421|r |cffff1313Shadow|r. (115299275 Overkill) ",
							["amount"] = 115672696,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 09:39:22|r\n|Hunit:0x01000000050A5EFB:Clavain-Spirestone|hClavain-Spirestone|h |Hspell:116858:SPELL_DAMAGE|h|cffff1313Chaos Bolt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffff1313281738|r |cffff1313Shadow|r. (Critical) ",
							["amount"] = 281738,
						},
						["icon"] = "Interface\\Icons\\sha_ability_rogue_envelopingshadows",
					},
					["Fire"] = {
						[-2] = {
							["time"] = "|cffffffff11/08/12 10:57:10|r\n|Hunit:0xF130F00C000046CB:Siege Explosives|hSiege Explosives|h |Hspell:119703:SPELL_DAMAGE|h|cff82f4ffDetonate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cff82f4ff197669|r |cff82f4ffFire|r. ",
							["amount"] = 197669,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 09:40:37|r\n|Hunit:0x0580000006E89BEB:Brickyoface-AlteracMountains|hBrickyoface-AlteracMountains|h |Hspell:51505:SPELL_DAMAGE|h|cffff1313Lava Burst|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffff1313179966|r |cffff1313Fire|r. (Critical) ",
							["amount"] = 179966,
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_LavaBurst",
					},
					["Physical"] = {
						[-2] = {
							["time"] = "|cffffffff12/20/12 10:09:54|r\n|Hunit:0xF1310A9F00003F8A:Dippy|hDippy|h |Hspell:134537:SPELL_DAMAGE|h|cffff1313Peck|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffff1313375409|r |cffff1313Physical|r. (709012 Overkill) ",
							["amount"] = 1084421,
						},
						[2] = {
							["time"] = "|cffffffff11/13/12 10:09:42|r\n|Hunit:0x07000000046E1033:Bajis-Terokkar|hBajis-Terokkar|h |Hspell:86346:SPELL_DAMAGE|h|cffff1313Colossus Smash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffff1313206553|r |cffff1313Physical|r. (Critical) ",
							["amount"] = 206553,
						},
						["icon"] = "Interface\\Icons\\INV_Misc_Birdbeck_01",
					},
					["Nature"] = {
						[-2] = {
							["time"] = "|cffffffff11/24/12 10:29:24|r\n|Hspell:119748:SPELL_DAMAGE|h|cffff1313Lightning Trap|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffff1313215090|r |cffff1313Nature|r. ",
							["amount"] = 215090,
						},
						[2] = {
							["time"] = "|cffffffff11/14/12 08:36:47|r\n|Hunit:0x03800000058808EC:Netherheart-Eitrigg|hNetherheart-Eitrigg|h |Hspell:421:SPELL_DAMAGE|h|cffff1313Chain Lightning|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000246AC55:Statue|hYou|h |cffff1313103662|r |cffff1313Nature|r. (Critical) ",
							["amount"] = 103662,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_LightningOverload",
					},
				},
			},
		},
	},
}
