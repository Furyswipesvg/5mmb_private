
FishingBuddy_Player = {
	["MinimapData"] = {
		["minimapPos"] = 190.8705332182547,
		["hide"] = false,
	},
	["Settings"] = {
		["ResetWatcher"] = 1,
	},
	["WasWearing"] = {
	},
	["Outfit"] = {
	},
}
