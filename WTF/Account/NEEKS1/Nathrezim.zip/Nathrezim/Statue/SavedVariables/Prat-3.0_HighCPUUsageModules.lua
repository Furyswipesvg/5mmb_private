
Prat3HighCPUPerCharDB = {
	["time"] = 1361085713,
	["scrollback"] = {
		["ChatFrame1"] = {
			{
				"|cff979797[23:21:41]|r|c00000000|r |Hchannel:channel:1|h[1] |h Joined Channel: |Hchannel:1|h[1. General - Shrine of Two Moons]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				69, -- [5]
			}, -- [1]
			{
				"|cff979797[23:21:41]|r|c00000000|r |Hchannel:channel:2|h[2] |h Joined Channel: |Hchannel:2|h[2. Trade - City]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				70, -- [5]
			}, -- [2]
			{
				"|cff979797[23:21:46]|r|c00000000|r |cffd8d8d8[|r|Hplayer:Eûlogy:294:GUILD|h|cffd8d83f90|r:|cffffffffEûlogy|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:8013:0100000004F575F9:1:2:16:13:4294967295:4294967295:4294967295:4294967295|h[Domination Point]|h|r!", -- [1]
				0.250980406999588, -- [2]
				1, -- [3]
				0.250980406999588, -- [4]
				48, -- [5]
			}, -- [3]
			{
				"|cff979797[23:21:46]|r|c00000000|r |cffd8d8d8[|r|Hplayer:Eûlogy:295:GUILD|h|cffd8d83f90|r:|cffffffffEûlogy|r|h|cffd8d8d8]|r has earned the achievement |cffffff00|Hachievement:8014:0100000004F575F9:1:2:16:13:4294967295:4294967295:4294967295:4294967295|h[Number Five Is Alive]|h|r!", -- [1]
				0.250980406999588, -- [2]
				1, -- [3]
				0.250980406999588, -- [4]
				48, -- [5]
			}, -- [4]
			{
				"|cff979797[23:21:53]|r|c00000000|r |Hchannel:GUILD|h[G] |h|cffd8d8d8[|r|Hplayer:Statue:296:GUILD|h|cffd8d83f90|r:|cff9382c9Statue|r|h|cffd8d8d8]|r: (|cFF32ff00437.3|r) Gratz", -- [1]
				0.250980406999588, -- [2]
				1, -- [3]
				0.250980406999588, -- [4]
				5, -- [5]
			}, -- [5]
		},
	},
}
