
BlizzardStopwatchOptions = {
	["position"] = {
		["y"] = 609.9673461914063,
		["x"] = 976.2492065429688,
	},
}
