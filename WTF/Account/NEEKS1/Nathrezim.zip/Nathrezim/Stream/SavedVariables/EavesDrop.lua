
EavesDropStatsDB = {
	["profileKeys"] = {
		["Stream - Nathrezim"] = "Stream - Nathrezim",
	},
	["profiles"] = {
		["Stream - Nathrezim"] = {
			{
				["hit"] = {
					["Mantid Poison"] = {
						[-2] = {
							["time"] = "|cffffffff12/21/12 04:48:28|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:128386:SPELL_PERIODIC_DAMAGE|h|cffffffffMantid Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130E67600014CD4:Scarlet Defender|hScarlet Defender|h |cffffffff8815|r |cffffffffNature|r. ",
							["amount"] = 8815,
						},
						[2] = {
							["time"] = "|cffffffff12/21/12 04:48:32|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:128386:SPELL_PERIODIC_DAMAGE|h|cffffffffMantid Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130E67600014CD4:Scarlet Defender|hScarlet Defender|h |cffffffff17630|r |cffffffffNature|r. (Critical) ",
							["amount"] = 17630,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_NullifyPoison",
					},
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff01/29/13 05:28:49|r\n|Hicon:32:source|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_6.blp:0|t|h|Hunit:0x0100000004DD3052:Stream|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF150EC4B0003D021:Sha of Anger|hSha of Anger|h |cffffffff14051|r |cffffffffPhysical|r. ",
							["amount"] = 14051,
						},
						[2] = {
							["time"] = "|cffffffff01/19/13 08:27:52|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF530E4790042B955:Wilderland Stag|hWilderland Stag|h |cffffffff11298|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 11298,
						},
					},
					["Shadow Word: Pain"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 07:40:45|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:124464:SPELL_DAMAGE|h|cffffffffShadow Word: Pain|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150DE2D0004A181:Raigonn|hRaigonn|h |cffffffff50477|r |cffffffffShadow|r. ",
							["amount"] = 50477,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 07:40:30|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:589:SPELL_PERIODIC_DAMAGE|h|cffffffffShadow Word: Pain|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF150DE2D0004A181:Raigonn|hRaigonn|h |cffffffff87890|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 87890,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_ShadowWordPain",
					},
					["Magma"] = {
						[-2] = {
							["time"] = "|cffffffff01/17/13 10:49:06|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:81114:SPELL_PERIODIC_DAMAGE|h|cffffffffMagma|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff7250|r |cffffffffFire|r. ",
							["amount"] = 7250,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_LavaFlow",
					},
					["Power Word: Solace"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 04:36:08|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:129250:SPELL_DAMAGE|h|cffffffffPower Word: Solace|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E73000001098:Jandice Barov|hJandice Barov|h |cffffffff32482|r |cffffffffHoly|r. ",
							["amount"] = 32482,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 04:39:29|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:129250:SPELL_DAMAGE|h|cffffffffPower Word: Solace|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E7110000253F:Rattlegore|hRattlegore|h |cffffffff66656|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 66656,
						},
						["icon"] = "Interface\\Icons\\ability_priest_flashoflight",
					},
					["Devouring Plague"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 07:41:03|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:2944:SPELL_DAMAGE|h|cffffffffDevouring Plague|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150DE2D0004A181:Raigonn|hRaigonn|h |cffffffff369989|r |cffffffffShadow|r. ",
							["amount"] = 369989,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 07:27:09|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:2944:SPELL_DAMAGE|h|cffffffffDevouring Plague|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150DD0D00044D5F:Striker Ga'dok|hStriker Ga'dok|h |cffffffff193630|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 193630,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_DevouringPlague",
					},
					["Spellweave"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 02:55:33|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:106043:SPELL_DAMAGE|h|cffffffffSpellweave|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150DBC700000A13:Regenerative Blood|hRegenerative Blood|h |cffffffff21524|r |cffffffffArcane|r. ",
							["amount"] = 21524,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Arcane_ArcaneTorrent",
					},
					["Mind Sear"] = {
						[-2] = {
							["time"] = "|cffffffff01/09/13 11:59:37|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:49821:SPELL_DAMAGE|h|cffffffffMind Sear|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E7E800005C74:Krastinovian Carver|hKrastinovian Carver|h |cffffffff39791|r |cffffffffShadow|r. ",
							["amount"] = 39791,
						},
						[2] = {
							["time"] = "|cffffffff01/05/13 10:42:19|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:49821:SPELL_DAMAGE|h|cffffffffMind Sear|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E61200002495:Vigilant Watchman|hVigilant Watchman|h |cffffffff68933|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 68933,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_MindShear",
					},
					["Stormlash"] = {
						[-2] = {
							["time"] = "|cffffffff01/05/13 01:36:28|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:120687:SPELL_DAMAGE|h|cffffffffStormlash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F3BD00000293:Wind Lord Mel'jarak|hWind Lord Mel'jarak|h |cffffffff21470|r |cffffffffNature|r. ",
							["amount"] = 21470,
						},
						[2] = {
							["time"] = "|cffffffff01/04/13 10:11:39|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:120687:SPELL_DAMAGE|h|cffffffffStormlash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EBFA00002249:Elegon|hElegon|h |cffffffff45570|r |cffffffffNature|r. (Critical) ",
							["amount"] = 45570,
						},
						["icon"] = "Interface\\Icons\\Spell_Lightning_LightningBolt01",
					},
					["Halo"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 07:41:08|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:120696:SPELL_DAMAGE|h|cffffffffHalo|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150DE2D0004A181:Raigonn|hRaigonn|h |cffffffff386134|r |cffffffffShadow|r. ",
							["amount"] = 386134,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 07:34:47|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:120696:SPELL_DAMAGE|h|cffffffffHalo|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E9BB0004B0BD:Krik'thik Swarmer|hKrik'thik Swarmer|h |cffffffff106790|r |cffffffffShadow|r. (104362 Overkill) (Critical) ",
							["amount"] = 211152,
						},
						["icon"] = "Interface\\Icons\\ability_priest_halo_shadow",
					},
					["Mind Flay"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 07:54:05|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:15407:SPELL_PERIODIC_DAMAGE|h|cffffffffMind Flay|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130EF3B00007535:Gekkan|hGekkan|h |cffffffff24196|r |cffffffffShadow|r. ",
							["amount"] = 24196,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 07:41:05|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:15407:SPELL_PERIODIC_DAMAGE|h|cffffffffMind Flay|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF150DE2D0004A181:Raigonn|hRaigonn|h |cffffffff162240|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 162240,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_SiphonMana",
					},
					["Explosion"] = {
						[-2] = {
							["time"] = "|cffffffff01/05/13 12:01:12|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:20476:SPELL_DAMAGE|h|cffffffffExplosion|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff59081|r |cffffffffFire|r. ",
							["amount"] = 59081,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_SelfDestruct",
					},
					["Detonate"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 12:39:14|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:119395:SPELL_DAMAGE|h|cffffffffDetonate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F02D0001086A:General Pa'valak|hGeneral Pa'valak|h |cffffffff950000|r |cffffffffFire|r. ",
							["amount"] = 950000,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Misc_Bomb_02",
					},
					["Firewall"] = {
						[-2] = {
							["time"] = "|cffffffff01/06/13 01:23:29|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:132661:SPELL_PERIODIC_DAMAGE|h|cffffffffFirewall|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff80000|r |cffffffffFire|r. ",
							["amount"] = 80000,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_Immolation",
					},
					["Smite"] = {
						[-2] = {
							["time"] = "|cffffffff01/09/13 08:55:34|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:585:SPELL_DAMAGE|h|cffffffffSmite|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150DE2D000105BD:Raigonn|hRaigonn|h |cffffffff166457|r |cffffffffHoly|r. ",
							["amount"] = 166457,
						},
						[2] = {
							["time"] = "|cffffffff01/09/13 08:55:31|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:585:SPELL_DAMAGE|h|cffffffffSmite|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150DE2D000105BD:Raigonn|hRaigonn|h |cffffffff320937|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 320937,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolySmite",
					},
					["Zealous Rush"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 09:09:33|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:123626:SPELL_DAMAGE|h|cffffffffZealous Rush|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff29236|r |cffffffffPhysical|r. ",
							["amount"] = 29236,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_paladin_speedoflight",
					},
					["Mind Spike"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 07:41:10|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:73510:SPELL_DAMAGE|h|cffffffffMind Spike|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150DE2D0004A181:Raigonn|hRaigonn|h |cffffffff181951|r |cffffffffShadowfrost|r. ",
							["amount"] = 181951,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 07:24:11|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:73510:SPELL_DAMAGE|h|cffffffffMind Spike|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E2FC00047DB5:Krik'thik Infiltrator|hKrik'thik Infiltrator|h |cffffffff167428|r |cffffffffShadowfrost|r. (Critical) ",
							["amount"] = 167428,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_priest_mindspike",
					},
					["Pact of the Darkfallen"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 06:34:04|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:71341:SPELL_DAMAGE|h|cffffffffPact of the Darkfallen|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff8250|r |cffffffffShadow|r. ",
							["amount"] = 8250,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_DestructiveSoul",
					},
					["Amber Strike"] = {
						[-2] = {
							["time"] = "|cffffffff01/12/13 07:44:06|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:122389:SPELL_DAMAGE|h|cffffffffAmber Strike|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F42F00000558:Amber-Shaper Un'sok|hAmber-Shaper Un'sok|h |cffffffff1117387|r |cffffffffNature|r. ",
							["amount"] = 1117387,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_CriticalStrike",
					},
					["Bloodbolt Splash"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 06:22:18|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:71447:SPELL_DAMAGE|h|cffffffffBloodbolt Splash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hicon:2:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2.blp:0|t|h|Hunit:0x0300000006D38995:Osgiliath-Kil'jaeden|hOsgiliath-Kil'jaeden|h |cffffffff8820|r |cffffffffSpellshadow|r. ",
							["amount"] = 8820,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_FelMending",
					},
					["Mana Burn"] = {
						[-2] = {
							["time"] = "|cffffffff06/24/12 03:43:24|r\n|Hunit:0x0100000004DD3052:Stream|hStream's|h |Hspell:8129:SPELL_DAMAGE|h|cffffffffMana Burn|r|h hits |Hunit:0x0100000004E8706E:Merdi-Firetree|hMerdi-Firetree|h for |cffffffff3557|r |cffffffffShadow|r.",
							["amount"] = 3557,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_ManaBurn",
					},
					["Conflagration"] = {
						[-2] = {
							["time"] = "|cffffffff12/20/12 06:32:46|r\n|Hicon:1:source|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1.blp:0|t|h|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:37019:SPELL_DAMAGE|h|cffffffffConflagration|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000051942CA:Slaughtered|hSlaughtered|h |cffffffff810|r |cffffffffFire|r. ",
							["amount"] = 810,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_Incinerate",
					},
					["Volatile Greenstone Brew"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 09:09:30|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:119090:SPELL_DAMAGE|h|cffffffffVolatile Greenstone Brew|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130EEE700006EEC:Greenstone Terror|hGreenstone Terror|h |cffffffff105327|r |cffffffffNature|r. ",
							["amount"] = 105327,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\inv_drink_32_disgustingrotgut",
					},
					["Visions of Demise"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:54:48|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:124868:SPELL_DAMAGE|h|cffffffffVisions of Demise|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0300000006132642:Defekt-Khaz'goroth|hDefekt-Khaz'goroth|h |cffffffff5125|r |cffffffffShadow|r. ",
							["amount"] = 5125,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\inv_misc_eye_03",
					},
					["Polyformic Acid Blast"] = {
						[-2] = {
							["time"] = "|cffffffff01/10/13 12:10:21|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:114821:SPELL_DAMAGE|h|cffffffffPolyformic Acid Blast|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E6C800005B35:Darkmaster Gandling|hDarkmaster Gandling|h |cffffffff42559|r |cffffffffNature|r. ",
							["amount"] = 42559,
						},
						[2] = {
							["time"] = "|cffffffff01/10/13 12:10:12|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:114821:SPELL_DAMAGE|h|cffffffffPolyformic Acid Blast|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E6C800005B35:Darkmaster Gandling|hDarkmaster Gandling|h |cffffffff37214|r |cffffffffNature|r. (Critical) ",
							["amount"] = 37214,
						},
						["icon"] = "Interface\\Icons\\INV_Potion_97",
					},
					["Mind Blast"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 07:41:01|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:8092:SPELL_DAMAGE|h|cffffffffMind Blast|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150DE2D0004A181:Raigonn|hRaigonn|h |cffffffff294901|r |cffffffffShadow|r. ",
							["amount"] = 294901,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 04:49:01|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:8092:SPELL_DAMAGE|h|cffffffffMind Blast|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF131039E00C25DE4:Rankbite Ancient|hRankbite Ancient|h |cffffffff5738|r |cffffffffShadow|r. (193863 Overkill) (Critical) ",
							["amount"] = 199601,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_UnholyFrenzy",
					},
					["Lightning Prison"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 11:44:26|r\n|Hicon:1:source|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1.blp:0|t|h|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:117398:SPELL_DAMAGE|h|cffffffffLightning Prison|r|h |Haction:SPELL_DAMAGE|hhit|h |Hicon:1:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_1.blp:0|t|h|Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff28000|r |cffffffffNature|r. ",
							["amount"] = 28000,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_StaticShock",
					},
					["Sabotage"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 09:19:05|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:107093:SPELL_DAMAGE|h|cffffffffSabotage|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff53611|r |cffffffffFire|r. ",
							["amount"] = 53611,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_MindBomb",
					},
					["Imbued Poison"] = {
						[-2] = {
							["time"] = "|cffffffff01/05/13 02:09:32|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:124833:SPELL_DAMAGE|h|cffffffffImbued Poison|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150F57500000004:Grand Empress Shek'zeer|hGrand Empress Shek'zeer|h |cffffffff53706|r |cffffffffNature|r. ",
							["amount"] = 53706,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Creature_Poison_02",
					},
					["Blood of Deathwing"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 02:40:12|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:106201:SPELL_DAMAGE|h|cffffffffBlood of Deathwing|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x03000000077AC8B0:Kolag-Tichondrius|hKolag-Tichondrius|h |cffffffff374412|r |cffffffffFire|r. (573466 Overkill) ",
							["amount"] = 947878,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_deathwing_bloodcorruption_earth",
					},
					["Ignite Fuel"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 06:28:23|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:135868:SPELL_DAMAGE|h|cffffffffIgnite Fuel|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff21679|r |cffffffffFire|r. ",
							["amount"] = 21679,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_SelfDestruct",
					},
					["Empowered Shock Vortex"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 06:14:41|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:72038:SPELL_DAMAGE|h|cffffffffEmpowered Shock Vortex|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000050B339A:Urial|hUrial|h |cffffffff6000|r |cffffffffPhysical|r. ",
							["amount"] = 6000,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_EarthBind",
					},
					["Arcane Resonance"] = {
						[-2] = {
							["time"] = "|cffffffff12/24/12 01:07:10|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:116434:SPELL_DAMAGE|h|cffffffffArcane Resonance|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x03000000067EA28D:Leprakorn-Barthilas|hLeprakorn-Barthilas|h |cffffffff21861|r |cffffffffArcane|r. (12139 Absorbed) ",
							["amount"] = 21861,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Frost_ChainsOfIce",
					},
					["Shadow Word: Death"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 07:41:12|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:32379:SPELL_DAMAGE|h|cffffffffShadow Word: Death|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150DE2D0004A181:Raigonn|hRaigonn|h |cffffffff263210|r |cffffffffShadow|r. ",
							["amount"] = 263210,
						},
						[2] = {
							["time"] = "|cffffffff01/12/13 10:25:51|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:32379:SPELL_DAMAGE|h|cffffffffShadow Word: Death|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1310B310022F5EC:Korune Mutilator|hKorune Mutilator|h |cffffffff54721|r |cffffffffShadow|r. (158420 Overkill) (Critical) ",
							["amount"] = 213141,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_DemonicFortitude",
					},
					["Holy Fire"] = {
						[-2] = {
							["time"] = "|cffffffff01/09/13 08:55:06|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:14914:SPELL_DAMAGE|h|cffffffffHoly Fire|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150DE2D000105BD:Raigonn|hRaigonn|h |cffffffff154898|r |cffffffffHoly|r. ",
							["amount"] = 154898,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 12:12:18|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:14914:SPELL_DAMAGE|h|cffffffffHoly Fire|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E6760000A610:Scarlet Defender|hScarlet Defender|h |cffffffff242034|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 242034,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SearingLight",
					},
					["Rocket Launcher"] = {
						[-2] = {
							["time"] = "|cffffffff12/23/12 08:20:39|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:135200:SPELL_DAMAGE|h|cffffffffRocket Launcher|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF131086A00010611:Thaumaturge Moonspire|hThaumaturge Moonspire|h |cffffffff208902|r |cffffffffFire|r. ",
							["amount"] = 208902,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\ability_racial_rocketbarrage",
					},
					["Void Shift"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 07:29:13|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:118594:SPELL_DAMAGE|h|cffffffffVoid Shift|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff307581|r |cffffffffShadow|r. ",
							["amount"] = 307581,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\spell_priest_voidshift",
					},
					["Parasitic Backlash"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 03:06:34|r\n|Hicon:128:source|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8.blp:0|t|h|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:108787:SPELL_DAMAGE|h|cffffffffParasitic Backlash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x03000000077AC8B0:Kolag-Tichondrius|hKolag-Tichondrius|h |cffffffff255836|r |cffffffffFire|r. ",
							["amount"] = 255836,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_rhyolith_magmaflow_wave",
					},
					["Cascade"] = {
						[-2] = {
							["time"] = "|cffffffff01/05/13 01:53:40|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:120785:SPELL_DAMAGE|h|cffffffffCascade|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0300000004B0653E:Consonant-Thaurissan|hConsonant-Thaurissan|h |cffffffff69582|r |cffffffffHoly|r. ",
							["amount"] = 69582,
						},
						[2] = {
							["time"] = "|cffffffff01/10/13 01:09:38|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:120785:SPELL_DAMAGE|h|cffffffffCascade|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F2FD000020C7:Wing Leader Ner'onok|hWing Leader Ner'onok|h |cffffffff128542|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 128542,
						},
						["icon"] = "Interface\\Icons\\ability_priest_cascade",
					},
					["Ice Wrath"] = {
						[-2] = {
							["time"] = "|cffffffff12/21/12 12:08:58|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:111616:SPELL_DAMAGE|h|cffffffffIce Wrath|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01800000046FBDA1:Mandiessa-Uldum|hMandiessa-Uldum|h |cffffffff15907|r |cffffffffFrost|r. ",
							["amount"] = 15907,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Frost_ArcticWinds",
					},
					["Beach Bomb Kaboom"] = {
						[-2] = {
							["time"] = "|cffffffff12/23/12 07:43:25|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:122087:SPELL_DAMAGE|h|cffffffffBeach Bomb Kaboom|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F47E00003908:Unga Scallywag|hUnga Scallywag|h |cffffffff112724|r |cffffffffFire|r. ",
							["amount"] = 112724,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Misc_Bomb_02",
					},
					["Jasper Chains"] = {
						[-2] = {
							["time"] = "|cffffffff12/24/12 12:53:48|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:130404:SPELL_DAMAGE|h|cffffffffJasper Chains|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x03000000050649D4:Effingbelf-Tichondrius|hEffingbelf-Tichondrius|h |cffffffff48000|r |cffffffffFire|r. ",
							["amount"] = 48000,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\inv_belt_44b",
					},
					["Amber Explosion"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:41:58|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:122398:SPELL_DAMAGE|h|cffffffffAmber Explosion|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0300000007715545:Desecrâtor-Barthilas|hDesecrâtor-Barthilas|h |cffffffff100000|r |cffffffffNature|r. ",
							["amount"] = 100000,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_BloodNova",
					},
					["Penance"] = {
						[-2] = {
							["time"] = "|cffffffff01/09/13 08:55:39|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:47666:SPELL_DAMAGE|h|cffffffffPenance|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150DE2D000105BD:Raigonn|hRaigonn|h |cffffffff157434|r |cffffffffHoly|r. ",
							["amount"] = 157434,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 12:31:17|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:47666:SPELL_DAMAGE|h|cffffffffPenance|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F10500010178:Sik'thik Warrior|hSik'thik Warrior|h |cffffffff222480|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 222480,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Penance",
					},
					["Reflective Shield"] = {
						[-2] = {
							["time"] = "|cffffffff12/23/12 06:05:13|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:33619:SPELL_DAMAGE|h|cffffffffReflective Shield|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F02D00014D9E:General Pa'valak|hGeneral Pa'valak|h |cffffffff45369|r |cffffffffHoly|r. ",
							["amount"] = 45369,
						},
						[2] = {
							["time"] = "|cffffffff12/23/12 06:22:51|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:33619:SPELL_DAMAGE|h|cffffffffReflective Shield|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F4A800014DA3:Sik'thik Engineer|hSik'thik Engineer|h |cffffffff42642|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 42642,
						},
						["icon"] = "INTERFACE\\ICONS\\ability_priest_reflectiveshield",
					},
					["Enraging Flames"] = {
						[-2] = {
							["time"] = "|cffffffff01/06/13 04:47:59|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:134545:SPELL_PERIODIC_DAMAGE|h|cffffffffEnraging Flames|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff56175|r |cffffffffFire|r. (11825 Overkill) ",
							["amount"] = 68000,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_Immolation",
					},
					["Vampiric Touch"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 07:41:03|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:124465:SPELL_DAMAGE|h|cffffffffVampiric Touch|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150DE2D0004A181:Raigonn|hRaigonn|h |cffffffff50836|r |cffffffffShadow|r. ",
							["amount"] = 50836,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 04:49:01|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:34914:SPELL_PERIODIC_DAMAGE|h|cffffffffVampiric Touch|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF131039E00C25DE4:Rankbite Ancient|hRankbite Ancient|h |cffffffff34074|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 34074,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Stoicism",
					},
					["Reaver Bombs"] = {
						[-2] = {
							["time"] = "|cffffffff12/23/12 08:17:34|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:135219:SPELL_DAMAGE|h|cffffffffReaver Bombs|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13108D20001062A:Gilnean Mauler|hGilnean Mauler|h |cffffffff80535|r |cffffffffFire|r. ",
							["amount"] = 80535,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Misc_Bomb_02",
					},
					["Holy Nova"] = {
						[-2] = {
							["time"] = "|cffffffff01/29/13 05:28:49|r\n|Hicon:32:source|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_6.blp:0|t|h|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:132157:SPELL_DAMAGE|h|cffffffffHoly Nova|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150EC4B0003D021:Sha of Anger|hSha of Anger|h |cffffffff17837|r |cffffffffHoly|r. ",
							["amount"] = 17837,
						},
						[2] = {
							["time"] = "|cffffffff01/09/13 12:10:19|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:132157:SPELL_DAMAGE|h|cffffffffHoly Nova|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E84500001AC9:Hopling|hHopling|h |cffffffff11785|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 11785,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolyNova",
					},
				},
				["heal"] = {
					["Renew"] = {
						[-2] = {
							["time"] = "|cffffffff12/20/12 06:35:02|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:139:SPELL_PERIODIC_HEAL|h|cffffffffRenew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0xF1304CA6000030CF:Kael'thas Sunstrider|hKael'thas Sunstrider|h |cffffffff59902|r |cffffffffHoly|r. ",
							["amount"] = 59902,
						},
						[2] = {
							["time"] = "|cffffffff01/12/13 07:54:56|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:139:SPELL_PERIODIC_HEAL|h|cffffffffRenew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0300000006EB9459:Stôneheart-Blackrock|hStôneheart-Blackrock|h |cffffffff0|r |cffffffffHoly|r. (39680 Overhealed) (Critical) ",
							["amount"] = 39680,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Renew",
					},
					["Strange Feeling"] = {
						[-2] = {
							["time"] = "|cffffffff01/06/13 05:33:26|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:134851:SPELL_HEAL|h|cffffffffStrange Feeling|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff38890|r |cffffffffPhysical|r. ",
							["amount"] = 38890,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Arcane_MassDispel",
					},
					["Bo's Rejuvinating Mist"] = {
						[-2] = {
							["time"] = "|cffffffff12/23/12 07:42:07|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:122194:SPELL_PERIODIC_HEAL|h|cffffffffBo's Rejuvinating Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff0|r |cffffffffPhysical|r. (10374 Overhealed) ",
							["amount"] = 10374,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_healthsphere",
					},
					["Holy Nova"] = {
						[-2] = {
							["time"] = "|cffffffff01/09/13 12:10:17|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:23455:SPELL_HEAL|h|cffffffffHoly Nova|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0180000001308463:Broodwitch-AzjolNerub|hBroodwitch-AzjolNerub|h |cffffffff0|r |cffffffffHoly|r. (10772 Overhealed) ",
							["amount"] = 10772,
						},
						[2] = {
							["time"] = "|cffffffff01/09/13 12:11:35|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:23455:SPELL_HEAL|h|cffffffffHoly Nova|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff20821|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 20821,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolyNova",
					},
					["Glyph of Power Word: Shield"] = {
						[-2] = {
							["time"] = "|cffffffff12/24/12 01:29:07|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:56160:SPELL_HEAL|h|cffffffffGlyph of Power Word: Shield|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x03000000075E9FDC:Geckomoriah-Kil'jaeden|hGeckomoriah-Kil'jaeden|h |cffffffff42163|r |cffffffffHoly|r. ",
							["amount"] = 42163,
						},
						[2] = {
							["time"] = "|cffffffff06/24/12 03:50:55|r\n|Hunit:0x0100000004DD3052:Stream|hStream's|h |Hspell:56160:SPELL_HEAL|h|cffffffffGlyph of Power Word: Shield|r|h heals |Hunit:0x010000000027511D:Wayborn|hWayborn|h for |cffffffff16026|r.(Critical)",
							["amount"] = 16026,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Binding Heal"] = {
						[-2] = {
							["time"] = "|cffffffff01/10/13 10:36:19|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:32546:SPELL_HEAL|h|cffffffffBinding Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x03800000053810CC:Vularzoll-Eitrigg|hVularzoll-Eitrigg|h |cffffffff0|r |cffffffffHoly|r. (76638 Overhealed) ",
							["amount"] = 76638,
						},
						[2] = {
							["time"] = "|cffffffff01/14/13 11:50:08|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:32546:SPELL_HEAL|h|cffffffffBinding Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff44467|r |cffffffffHoly|r. (68153 Overhealed) (Critical) ",
							["amount"] = 112620,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_BlindingHeal",
					},
					["Prayer of Mending"] = {
						[-2] = {
							["time"] = "|cffffffff01/09/13 01:10:24|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:33110:SPELL_HEAL|h|cffffffffPrayer of Mending|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0180000004DCCC27:Guotie-Dragonblight|hGuotie-Dragonblight|h |cffffffff35811|r |cffffffffHoly|r. (8129 Overhealed) ",
							["amount"] = 43940,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 08:19:18|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:33110:SPELL_HEAL|h|cffffffffPrayer of Mending|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x030000000765C48D:Preon-Kil'jaeden|hPreon-Kil'jaeden|h |cffffffff82669|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 82669,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfMendingtga",
					},
					["Circle of Healing"] = {
						[-2] = {
							["time"] = "|cffffffff12/04/12 10:28:59|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:34861:SPELL_HEAL|h|cffffffffCircle of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E48298:Snobgoblin|hSnobgoblin|h |cffffffff0|r |cffffffffHoly|r. (10939 Overhealed) ",
							["amount"] = 10939,
						},
						[2] = {
							["time"] = "|cffffffff12/04/12 10:28:39|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:34861:SPELL_HEAL|h|cffffffffCircle of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff0|r |cffffffffHoly|r. (18603 Overhealed) (Critical) ",
							["amount"] = 18603,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_CircleOfRenewal",
					},
					["Devouring Plague"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 05:01:59|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:127626:SPELL_HEAL|h|cffffffffDevouring Plague|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff1104|r |cffffffffShadow|r. (15364 Overhealed) ",
							["amount"] = 16468,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_DevouringPlague",
					},
					["Prayer of Healing"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 06:33:40|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:596:SPELL_HEAL|h|cffffffffPrayer of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0xF140EE4A74000036:Cat|hCat|h |cffffffff0|r |cffffffffHoly|r. (212119 Overhealed) ",
							["amount"] = 212119,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 06:36:44|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:596:SPELL_HEAL|h|cffffffffPrayer of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0xF150F3EA00000957:Tsulong|hTsulong|h |cffffffff508975|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 508975,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfHealing02",
					},
					["Hellscream's Warcry"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 04:59:30|r\n|Hunit:0xF13109E800C47D84:Garrosh Hellscream|hGarrosh Hellscream|h |Hspell:134542:SPELL_HEAL|h|cffffffffHellscream's Warcry|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff5091|r |cffffffffPhysical|r. (104693 Overhealed) ",
							["amount"] = 109784,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Trade_Engineering",
					},
					["Magnetic Shroud Overload"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 07:13:01|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:107174:SPELL_HEAL|h|cffffffffMagnetic Shroud Overload|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0300000006FBEBB2:Hanible-Kil'jaeden|hHanible-Kil'jaeden|h |cffffffff0|r |cffffffffPhysical|r. (26954 Overhealed) ",
							["amount"] = 26954,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Trade_Engineering",
					},
					["Healthstone"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 12:24:11|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:6262:SPELL_HEAL|h|cffffffffHealthstone|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff46432|r |cffffffffPhysical|r. (72290 Overhealed) ",
							["amount"] = 118722,
						},
						[2] = {
							["time"] = "|cffffffff01/04/13 10:05:31|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:6262:SPELL_HEAL|h|cffffffffHealthstone|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff38287|r |cffffffffPhysical|r. (248920 Overhealed) (Critical) ",
							["amount"] = 287207,
						},
						["icon"] = "Interface\\Icons\\warlock_ healthstone",
					},
					["Rapid Renewal"] = {
						[-2] = {
							["time"] = "|cffffffff12/04/12 10:28:55|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:63544:SPELL_HEAL|h|cffffffffRapid Renewal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hMootalia|h |cffffffff0|r |cffffffffHoly|r. (3933 Overhealed) ",
							["amount"] = 3933,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Renew",
					},
					["Echo of Light"] = {
						[-2] = {
							["time"] = "|cffffffff11/29/12 07:48:11|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:77489:SPELL_PERIODIC_HEAL|h|cffffffffEcho of Light|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004E48298:Snobgoblin|hSnobgoblin|h |cffffffff0|r |cffffffffHoly|r. (2510 Overhealed) ",
							["amount"] = 2510,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Aspiration",
					},
					["Desperate Prayer"] = {
						[-2] = {
							["time"] = "|cffffffff01/09/13 12:31:43|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:19236:SPELL_HEAL|h|cffffffffDesperate Prayer|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff109427|r |cffffffffHoly|r. (72847 Overhealed) ",
							["amount"] = 182274,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_TestOfFaith",
					},
					["Greater Heal"] = {
						[-2] = {
							["time"] = "|cffffffff01/09/13 08:50:58|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:2060:SPELL_HEAL|h|cffffffffGreater Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x03800000016DF01F:Brogo-Draka|hBrogo-Draka|h |cffffffff121278|r |cffffffffHoly|r. (8819 Overhealed) ",
							["amount"] = 130097,
						},
						[2] = {
							["time"] = "|cffffffff01/05/13 11:45:47|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:2060:SPELL_HEAL|h|cffffffffGreater Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0380000003AB9495:Kaelnarae-Mug'thol|hKaelnarae-Mug'thol|h |cffffffff293880|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 293880,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_GreaterHeal",
					},
					["Vampiric Embrace"] = {
						[-2] = {
							["time"] = "|cffffffff01/06/13 04:47:30|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:15290:SPELL_PERIODIC_HEAL|h|cffffffffVampiric Embrace|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff55391|r |cffffffffShadow|r. ",
							["amount"] = 55391,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_UnsummonBuilding",
					},
					["Flash Heal"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 11:56:44|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:2061:SPELL_HEAL|h|cffffffffFlash Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0xF150F3EA00000227:Tsulong|hTsulong|h |cffffffff664251|r |cffffffffHoly|r. ",
							["amount"] = 664251,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 11:53:10|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:2061:SPELL_HEAL|h|cffffffffFlash Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0xF150F3EA00000227:Tsulong|hTsulong|h |cffffffff851633|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 851633,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Halo"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 05:00:45|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:120696:SPELL_HEAL|h|cffffffffHalo|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0xF531093F00CF8BBE:Horde Grunt|hHorde Grunt|h |cffffffff0|r |cffffffffShadow|r. (148736 Overhealed) ",
							["amount"] = 148736,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 07:33:56|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:120696:SPELL_HEAL|h|cffffffffHalo|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x03800000053089B0:Tatortott-Mug'thol|hTatortott-Mug'thol|h |cffffffff104977|r |cffffffffShadow|r. (157019 Overhealed) (Critical) ",
							["amount"] = 261996,
						},
						["icon"] = "Interface\\Icons\\ability_priest_halo_shadow",
					},
					["Cascade"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 10:37:59|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:121148:SPELL_HEAL|h|cffffffffCascade|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0xF140D7AF97000019:Hedwig|hHedwig|h |cffffffff0|r |cffffffffHoly|r. (122153 Overhealed) ",
							["amount"] = 122153,
						},
						[2] = {
							["time"] = "|cffffffff01/08/13 10:37:59|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:121148:SPELL_HEAL|h|cffffffffCascade|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0380000005993EC7:Bubbleoseven-Mug'thol|hBubbleoseven-Mug'thol|h |cffffffff0|r |cffffffffHoly|r. (179739 Overhealed) (Critical) ",
							["amount"] = 179739,
						},
						["icon"] = "Interface\\Icons\\ability_priest_cascade",
					},
					["Divine Hymn"] = {
						[-2] = {
							["time"] = "|cffffffff11/29/12 07:48:07|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:64844:SPELL_HEAL|h|cffffffffDivine Hymn|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E48298:Snobgoblin|hSnobgoblin|h |cffffffff0|r |cffffffffHoly|r. (31030 Overhealed) ",
							["amount"] = 31030,
						},
						[2] = {
							["time"] = "|cffffffff11/29/12 07:48:05|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:64844:SPELL_HEAL|h|cffffffffDivine Hymn|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004E48298:Snobgoblin|hSnobgoblin|h |cffffffff0|r |cffffffffHoly|r. (62060 Overhealed) (Critical) ",
							["amount"] = 62060,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_DivineProvidence",
					},
					["Blanche's Elixir of Replenishment"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 05:03:39|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:121951:SPELL_PERIODIC_HEAL|h|cffffffffBlanche's Elixir of Replenishment|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff7822|r |cffffffffPhysical|r. (28122 Overhealed) ",
							["amount"] = 35944,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_healthsphere",
					},
					["Hozenbane"] = {
						[-2] = {
							["time"] = "|cffffffff12/23/12 07:43:10|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:122373:SPELL_HEAL|h|cffffffffHozenbane|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff0|r |cffffffffPhysical|r. (17290 Overhealed) ",
							["amount"] = 17290,
						},
						[2] = {
							["time"] = "|cffffffff12/21/12 12:03:30|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:122373:SPELL_HEAL|h|cffffffffHozenbane|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff22202|r |cffffffffPhysical|r. (5686 Overhealed) (Critical) ",
							["amount"] = 27888,
						},
						["icon"] = "Interface\\Icons\\Achievement_BG_kill_flag_carrierEOS",
					},
					["Heal"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 12:53:17|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:2050:SPELL_HEAL|h|cffffffffHeal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0xF150F3EA000001F1:Tsulong|hTsulong|h |cffffffff552750|r |cffffffffHoly|r. ",
							["amount"] = 552750,
						},
						[2] = {
							["time"] = "|cffffffff12/24/12 01:56:54|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:2050:SPELL_HEAL|h|cffffffffHeal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0380000004CB49DD:Bonkieeb-Saurfang|hBonkieeb-Saurfang|h |cffffffff103852|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 103852,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_LesserHeal",
					},
					["Penance"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 06:33:43|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:47750:SPELL_HEAL|h|cffffffffPenance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0xF150F3EA00000957:Tsulong|hTsulong|h |cffffffff136773|r |cffffffffHoly|r. ",
							["amount"] = 136773,
						},
						[2] = {
							["time"] = "|cffffffff12/25/12 08:23:45|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:47750:SPELL_HEAL|h|cffffffffPenance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000051942CA:Slaughtered|hSlaughtered|h |cffffffff83688|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 83688,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Penance",
					},
					["Void Shift"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 10:50:46|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:118594:SPELL_HEAL|h|cffffffffVoid Shift|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0300000006A2FC9E:Mizigoth-Barthilas|hMizigoth-Barthilas|h |cffffffff377574|r |cffffffffShadow|r. (25420 Overhealed) ",
							["amount"] = 402994,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\spell_priest_voidshift",
					},
					["Flash of Light"] = {
						[-2] = {
							["time"] = "|cffffffff01/12/13 10:29:39|r\n|Hunit:0xF1310B270031EC66:Aenea|hAenea|h |Hspell:135053:SPELL_HEAL|h|cffffffffFlash of Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff70631|r |cffffffffHoly|r. ",
							["amount"] = 70631,
						},
						[2] = {
							["time"] = "|cffffffff01/12/13 10:30:36|r\n|Hunit:0xF1310B270031EC66:Aenea|hAenea|h |Hspell:135053:SPELL_HEAL|h|cffffffffFlash of Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff129231|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 129231,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Lightwell Renew"] = {
						[-2] = {
							["time"] = "|cffffffff12/04/12 11:31:01|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:7001:SPELL_PERIODIC_HEAL|h|cffffffffLightwell Renew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x018000000037EADA:Ickiss-Stormscale|hIckiss-Stormscale|h |cffffffff0|r |cffffffffHoly|r. (11964 Overhealed) ",
							["amount"] = 11964,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SummonLightwell",
					},
					["Atonement"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 06:37:13|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:81751:SPELL_HEAL|h|cffffffffAtonement|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000511AD77:Brucetea-Smolderthorn|hBrucetea-Smolderthorn|h |cffffffff194328|r |cffffffffHoly|r. (8868 Overhealed) ",
							["amount"] = 203196,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 06:37:17|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:94472:SPELL_HEAL|h|cffffffffAtonement|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0380000002ADC10B:Uglúk-Runetotem|hUglúk-Runetotem|h |cffffffff276789|r |cffffffffHoly|r. (154163 Overhealed) (Critical) ",
							["amount"] = 430952,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_CircleOfRenewal",
					},
					["Mogu Power"] = {
						[-2] = {
							["time"] = "|cffffffff12/21/12 12:18:50|r\n|Hunit:0x0100000004DD3052:Stream|hYour|h |Hspell:133475:SPELL_PERIODIC_HEAL|h|cffffffffMogu Power|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffffffff5126|r |cffffffffNature|r. (6440 Overhealed) ",
							["amount"] = 11566,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\spell_mage_runeofpower",
					},
				},
			}, -- [1]
			[-1] = {
				["heal"] = {
					["Renew"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:43:46|r\n|Hunit:0x0180000001FB95FD:Jen-Stormscale|hJen-Stormscale|h |Hspell:139:SPELL_PERIODIC_HEAL|h|cff82f4ffRenew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (14791 Overhealed) ",
							["amount"] = 14791,
						},
						[2] = {
							["time"] = "|cffffffff12/24/12 02:38:48|r\n|Hunit:0x030000000749E4E2:Melodramatíc-Ner'zhul|hMelodramatíc-Ner'zhul|h |Hspell:139:SPELL_PERIODIC_HEAL|h|cff82f4ffRenew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (30883 Overhealed) (Critical) ",
							["amount"] = 30883,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Renew",
					},
					["Swiftmend"] = {
						[-2] = {
							["time"] = "|cffffffff01/17/13 10:50:34|r\n|Hunit:0x0100000004ED47D3:Natronn|hNatronn|h |Hspell:18562:SPELL_HEAL|h|cff82f4ffSwiftmend|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff59473|r |cff82f4ffNature|r. ",
							["amount"] = 59473,
						},
						[2] = {
							["time"] = "|cffffffff01/08/13 10:39:03|r\n|Hunit:0x0180000002698952:Painsgone-Dunemaul|hPainsgone-Dunemaul|h |Hspell:18562:SPELL_HEAL|h|cff82f4ffSwiftmend|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff62168|r |cff82f4ffNature|r. (34916 Overhealed) (Critical) ",
							["amount"] = 97084,
						},
						["icon"] = "Interface\\Icons\\INV_Relics_IdolofRejuvenation",
					},
					["Healing Wave"] = {
						[-2] = {
							["time"] = "|cffffffff01/06/13 08:15:07|r\n|Hunit:0xF1310756000074C1:Vol'jin|hVol'jin|h |Hspell:133033:SPELL_HEAL|h|cff82f4ffHealing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff112276|r |cff82f4ffNature|r. ",
							["amount"] = 112276,
						},
						[2] = {
							["time"] = "|cffffffff12/24/12 01:29:00|r\n|Hunit:0x0300000007597B8B:Lucifelle-Kil'jaeden|hLucifelle-Kil'jaeden|h |Hspell:331:SPELL_HEAL|h|cff82f4ffHealing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff92269|r |cff82f4ffNature|r. (43141 Overhealed) (Critical) ",
							["amount"] = 135410,
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_TidalWaves",
					},
					["Glyph of Power Word: Shield"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 11:11:41|r\n|Hunit:0x03000000061D6C2B:Addvil-Tichondrius|hAddvil-Tichondrius|h |Hspell:56160:SPELL_HEAL|h|cff82f4ffGlyph of Power Word: Shield|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff19586|r |cff82f4ffHoly|r. ",
							["amount"] = 19586,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Arcing Light"] = {
						[-2] = {
							["time"] = "|cffffffff01/09/13 01:25:04|r\n|Hunit:0x0300000003A65E7D:Naughtyspec-Blackrock|hNaughtyspec-Blackrock|h |Hspell:119952:SPELL_PERIODIC_HEAL|h|cff82f4ffArcing Light|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (69556 Overhealed) ",
							["amount"] = 69556,
						},
						[2] = {
							["time"] = "|cffffffff01/09/13 01:25:06|r\n|Hunit:0x0300000003A65E7D:Naughtyspec-Blackrock|hNaughtyspec-Blackrock|h |Hspell:119952:SPELL_PERIODIC_HEAL|h|cff82f4ffArcing Light|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (142004 Overhealed) (Critical) ",
							["amount"] = 142004,
						},
						["icon"] = "Interface\\Icons\\spell_paladin_lightshammer",
					},
					["Holy Word: Serenity"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 10:40:51|r\n|Hunit:0x03000000021C8EA0:Vehicle-Frostwolf|hVehicle-Frostwolf|h |Hspell:88684:SPELL_HEAL|h|cff82f4ffHoly Word: Serenity|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff74213|r |cff82f4ffHoly|r. ",
							["amount"] = 74213,
						},
						[2] = {
							["time"] = "|cffffffff01/19/13 01:11:01|r\n|Hunit:0x0180000000575504:Malicia-Dragonblight|hMalicia-Dragonblight|h |Hspell:88684:SPELL_HEAL|h|cff82f4ffHoly Word: Serenity|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff4210|r |cff82f4ffHoly|r. (104454 Overhealed) (Critical) ",
							["amount"] = 108664,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_holy_persuitofjustice",
					},
					["Soothing Mist"] = {
						[-2] = {
							["time"] = "|cffffffff01/04/13 10:11:07|r\n|Hunit:0x0180000004C8B1EC:Fuzzywuzhe-Uldum|hFuzzywuzhe-Uldum|h |Hspell:115175:SPELL_PERIODIC_HEAL|h|cff82f4ffSoothing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff12818|r |cff82f4ffNature|r. ",
							["amount"] = 12818,
						},
						[2] = {
							["time"] = "|cffffffff01/04/13 09:38:16|r\n|Hunit:0x0180000004C8B1EC:Fuzzywuzhe-Uldum|hFuzzywuzhe-Uldum|h |Hspell:115175:SPELL_PERIODIC_HEAL|h|cff82f4ffSoothing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hicon:128:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8.blp:0|t|h|Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (21567 Overhealed) (Critical) ",
							["amount"] = 21567,
						},
						["icon"] = "Interface\\Icons\\ability_monk_soothingmists",
					},
					["Echo of Light"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 02:06:41|r\n|Hunit:0x0300000005AC8374:Bandayde-Kilrogg|hBandayde-Kilrogg|h |Hspell:77489:SPELL_PERIODIC_HEAL|h|cff82f4ffEcho of Light|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff7946|r |cff82f4ffHoly|r. ",
							["amount"] = 7946,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Aspiration",
					},
					["Nature's Vigil"] = {
						[-2] = {
							["time"] = "|cffffffff12/24/12 01:49:55|r\n|Hunit:0x03000000074F9AEC:Phantomdrake-Caelestrasz|hPhantomdrake-Caelestrasz|h |Hspell:124988:SPELL_HEAL|h|cff82f4ffNature's Vigil|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff62425|r |cff82f4ffNature|r. ",
							["amount"] = 62425,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Achievement_Zone_Feralas",
					},
					["Conductivity"] = {
						[-2] = {
							["time"] = "|cffffffff01/05/13 01:40:50|r\n|Hunit:0x0380000003540598:Stourg-Rexxar|hStourg-Rexxar|h |Hspell:118800:SPELL_HEAL|h|cff82f4ffConductivity|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (2562 Overhealed) ",
							["amount"] = 2562,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_shaman_fortifyingwaters",
					},
					["Healing Rain"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 12:53:47|r\n|Hunit:0x03800000058703CB:Saucylp-Mug'thol|hSaucylp-Mug'thol|h |Hspell:73921:SPELL_HEAL|h|cff82f4ffHealing Rain|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (61286 Overhealed) ",
							["amount"] = 61286,
						},
						[2] = {
							["time"] = "|cffffffff01/12/13 07:54:53|r\n|Hunit:0x0300000005B33496:Mangouzzie-Ner'zhul|hMangouzzie-Ner'zhul|h |Hspell:73921:SPELL_HEAL|h|cff82f4ffHealing Rain|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff30309|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 30309,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_GiftoftheWaterSpirit",
					},
					["Unleash Life"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 09:35:00|r\n|Hunit:0x0380000005654097:Spoonicle-Akama|hSpoonicle-Akama|h |Hspell:73685:SPELL_HEAL|h|cff82f4ffUnleash Life|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff17526|r |cff82f4ffNature|r. ",
							["amount"] = 17526,
						},
						[2] = {
							["time"] = "|cffffffff01/14/13 11:54:53|r\n|Hunit:0x0380000002A46085:Scynpho-Runetotem|hScynpho-Runetotem|h |Hspell:73685:SPELL_HEAL|h|cff82f4ffUnleash Life|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff31669|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 31669,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_shaman_unleashweapon_life",
					},
					["Light of Dawn"] = {
						[-2] = {
							["time"] = "|cffffffff12/24/12 01:34:33|r\n|Hunit:0x03000000052907B3:Holycullens-Frostmourne|hHolycullens-Frostmourne|h |Hspell:85222:SPELL_HEAL|h|cff82f4ffLight of Dawn|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (34276 Overhealed) ",
							["amount"] = 34276,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 11:00:10|r\n|Hunit:0x030000000752C667:Elluu-Blackrock|hElluu-Blackrock|h |Hspell:85222:SPELL_HEAL|h|cff82f4ffLight of Dawn|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (74253 Overhealed) (Critical) ",
							["amount"] = 74253,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_paladin_lightofdawn",
					},
					["Ancestral Awakening"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:49:14|r\n|Hunit:0x0100000003B215DF:Swagged-Spirestone|hSwagged-Spirestone|h |Hspell:52752:SPELL_HEAL|h|cff82f4ffAncestral Awakening|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff81583|r |cff82f4ffNature|r. ",
							["amount"] = 81583,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_AncestralAwakening",
					},
					["Restorative Mists"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 11:56:41|r\n|Hunit:0x03000000068718E6:Darkcinder-Ner'zhul|hDarkcinder-Ner'zhul|h |Hspell:114083:SPELL_HEAL|h|cff82f4ffRestorative Mists|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff56932|r |cff82f4ffNature|r. (165579 Overhealed) ",
							["amount"] = 222511,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_TidalWaves",
					},
					["Divine Light"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 01:50:49|r\n|Hunit:0x01000000013DCAB7:Ariosto-Terenas|hAriosto-Terenas|h |Hspell:82326:SPELL_HEAL|h|cff82f4ffDivine Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff70990|r |cff82f4ffHoly|r. ",
							["amount"] = 70990,
						},
						[2] = {
							["time"] = "|cffffffff01/05/13 01:36:57|r\n|Hunit:0x03000000077485E8:Drkpally-Sen'jin|hDrkpally-Sen'jin|h |Hspell:82326:SPELL_HEAL|h|cff82f4ffDivine Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff98824|r |cff82f4ffHoly|r. (25905 Overhealed) (Critical) ",
							["amount"] = 124729,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SurgeOfLight",
					},
					["Eminence"] = {
						[-2] = {
							["time"] = "|cffffffff01/05/13 01:37:13|r\n|Hunit:0x0300000007438535:Bubalicious-Frostmourne|hBubalicious-Frostmourne|h |Hspell:126890:SPELL_HEAL|h|cff82f4ffEminence|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff48808|r |cff82f4ffNature|r. (25122 Overhealed) ",
							["amount"] = 73930,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\inv_jewelcrafting_jadeserpent",
					},
					["Regrowth"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 11:14:54|r\n|Hunit:0x03000000077277EF:Toastbang-Blackrock|hToastbang-Blackrock|h |Hspell:8936:SPELL_HEAL|h|cff82f4ffRegrowth|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff37474|r |cff82f4ffNature|r. ",
							["amount"] = 37474,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 11:03:42|r\n|Hunit:0x03000000077277EF:Toastbang-Blackrock|hToastbang-Blackrock|h |Hspell:8936:SPELL_HEAL|h|cff82f4ffRegrowth|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff77941|r |cff82f4ffNature|r. (53276 Overhealed) (Critical) ",
							["amount"] = 131217,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_ResistNature",
					},
					["Holy Word: Sanctuary"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 09:38:42|r\n|Hunit:0x03000000077920FF:Dethwhyspur-Proudmoore|hDethwhyspur-Proudmoore|h |Hspell:88686:SPELL_PERIODIC_HEAL|h|cff82f4ffHoly Word: Sanctuary|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (3072 Overhealed) ",
							["amount"] = 3072,
						},
						[2] = {
							["time"] = "|cffffffff01/04/13 10:11:18|r\n|Hunit:0x03000000001B3877:Zypochondria-Blackrock|hZypochondria-Blackrock|h |Hspell:88686:SPELL_PERIODIC_HEAL|h|cff82f4ffHoly Word: Sanctuary|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff7100|r |cff82f4ffHoly|r. (32 Overhealed) (Critical) ",
							["amount"] = 7132,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_DivineProvidence",
					},
					["Binding Heal"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 07:41:04|r\n|Hunit:0x03800000053089B0:Tatortott-Mug'thol|hTatortott-Mug'thol|h |Hspell:32546:SPELL_HEAL|h|cff82f4ffBinding Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff51817|r |cff82f4ffHoly|r. ",
							["amount"] = 51817,
						},
						[2] = {
							["time"] = "|cffffffff01/08/13 09:16:32|r\n|Hunit:0x0300000006A892CB:Juupiter-Blackrock|hJuupiter-Blackrock|h |Hspell:32546:SPELL_HEAL|h|cff82f4ffBinding Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff107488|r |cff82f4ffHoly|r. (7847 Overhealed) (Critical) ",
							["amount"] = 115335,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_BlindingHeal",
					},
					["Holy Shock"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 11:01:28|r\n|Hunit:0x030000000752C667:Elluu-Blackrock|hElluu-Blackrock|h |Hspell:25914:SPELL_HEAL|h|cff82f4ffHoly Shock|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (61645 Overhealed) ",
							["amount"] = 61645,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 10:57:56|r\n|Hunit:0x030000000752C667:Elluu-Blackrock|hElluu-Blackrock|h |Hspell:25914:SPELL_HEAL|h|cff82f4ffHoly Shock|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (125300 Overhealed) (Critical) ",
							["amount"] = 125300,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SearingLight",
					},
					["Divine Star"] = {
						[-2] = {
							["time"] = "|cffffffff01/10/13 12:28:29|r\n|Hunit:0x03000000060AB250:Plextor-Kil'jaeden|hPlextor-Kil'jaeden|h |Hspell:122128:SPELL_HEAL|h|cff82f4ffDivine Star|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffSpellshadow|r. (46094 Overhealed) ",
							["amount"] = 46094,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 06:35:03|r\n|Hunit:0x0380000005812782:Pwntera-Korgath|hPwntera-Korgath|h |Hspell:122128:SPELL_HEAL|h|cff82f4ffDivine Star|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff67116|r |cff82f4ffSpellshadow|r. (Critical) ",
							["amount"] = 67116,
						},
						["icon"] = "Interface\\Icons\\spell_priest_divinestar_shadow2",
					},
					["Magnetic Shroud Overload"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 07:12:44|r\n|Hunit:0x0300000006268BC8:Bøwzer-Kil'jaeden|hBøwzer-Kil'jaeden|h |Hspell:107174:SPELL_HEAL|h|cff82f4ffMagnetic Shroud Overload|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff15935|r |cff82f4ffPhysical|r. (70315 Overhealed) ",
							["amount"] = 86250,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Trade_Engineering",
					},
					["Chi Burst"] = {
						[-2] = {
							["time"] = "|cffffffff01/05/13 01:57:43|r\n|Hunit:0x0300000007438535:Bubalicious-Frostmourne|hBubalicious-Frostmourne|h |Hspell:130654:SPELL_HEAL|h|cff82f4ffChi Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (37941 Overhealed) ",
							["amount"] = 37941,
						},
						[2] = {
							["time"] = "|cffffffff01/05/13 01:36:26|r\n|Hunit:0x0300000007438535:Bubalicious-Frostmourne|hBubalicious-Frostmourne|h |Hspell:130654:SPELL_HEAL|h|cff82f4ffChi Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff7725|r |cff82f4ffNature|r. (87374 Overhealed) (Critical) ",
							["amount"] = 95099,
						},
						["icon"] = "Interface\\Icons\\Spell_Arcane_ArcaneTorrent",
					},
					["Word of Glory"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 08:13:49|r\n|Hunit:0x030000000765C48D:Preon-Kil'jaeden|hPreon-Kil'jaeden|h |Hspell:130551:SPELL_HEAL|h|cff82f4ffWord of Glory|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff55087|r |cff82f4ffHoly|r. ",
							["amount"] = 55087,
						},
						[2] = {
							["time"] = "|cffffffff01/08/13 11:42:42|r\n|Hunit:0x038000000237C7BA:Holypornstar-Jubei'Thos|hHolypornstar-Jubei'Thos|h |Hspell:130551:SPELL_HEAL|h|cff82f4ffWord of Glory|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff116347|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 116347,
						},
						["icon"] = "INTERFACE\\ICONS\\inv_helmet_96",
					},
					["Cascade"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 06:32:40|r\n|Hunit:0x03000000071F02D4:Trofelinth-Frostmourne|hTrofelinth-Frostmourne|h |Hspell:121148:SPELL_HEAL|h|cff82f4ffCascade|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff243917|r |cff82f4ffHoly|r. (7780 Overhealed) ",
							["amount"] = 251697,
						},
						[2] = {
							["time"] = "|cffffffff02/10/13 06:08:19|r\n|Hunit:0x01000000002D3462:Sweettarts|hSweettarts|h |Hspell:121148:SPELL_HEAL|h|cff82f4ffCascade|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff58844|r |cff82f4ffHoly|r. (139140 Overhealed) (Critical) ",
							["amount"] = 197984,
						},
						["icon"] = "Interface\\Icons\\ability_priest_cascade",
					},
					["Earth Shield"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 11:47:31|r\n|Hunit:0x0180000004D3707F:Makasü-Darkspear|hMakasü-Darkspear|h |Hspell:379:SPELL_HEAL|h|cff82f4ffEarth Shield|r|h |Haction:SPELL_HEAL|hhealed|h |Hicon:128:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8.blp:0|t|h|Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff9131|r |cff82f4ffNature|r. ",
							["amount"] = 9131,
						},
						[2] = {
							["time"] = "|cffffffff01/06/13 09:38:09|r\n|Hunit:0x0100000004107E05:Wrecku|hWrecku|h |Hspell:379:SPELL_HEAL|h|cff82f4ffEarth Shield|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff11202|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 11202,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_SkinofEarth",
					},
					["Riptide"] = {
						[-2] = {
							["time"] = "|cffffffff01/22/13 06:02:52|r\n|Hunit:0x01000000002D00F6:Shockice|hShockice|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff22864|r |cff82f4ffNature|r. ",
							["amount"] = 22864,
						},
						[2] = {
							["time"] = "|cffffffff01/05/13 12:58:34|r\n|Hunit:0x03800000035B1BD5:Atath-Malorne|hAtath-Malorne|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff42085|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 42085,
						},
						["icon"] = "Interface\\Icons\\spell_nature_riptide",
					},
					["Enveloping Mist"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 01:35:10|r\n|Hunit:0x010000000511338E:Monklox-Silvermoon|hMonklox-Silvermoon|h |Hspell:132120:SPELL_PERIODIC_HEAL|h|cff82f4ffEnveloping Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff22639|r |cff82f4ffNature|r. ",
							["amount"] = 22639,
						},
						[2] = {
							["time"] = "|cffffffff01/19/13 01:50:53|r\n|Hunit:0x010000000511338E:Monklox-Silvermoon|hMonklox-Silvermoon|h |Hspell:132120:SPELL_PERIODIC_HEAL|h|cff82f4ffEnveloping Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (43938 Overhealed) (Critical) ",
							["amount"] = 43938,
						},
						["icon"] = "Interface\\Icons\\spell_monk_envelopingmist",
					},
					["Rejuvenation"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 10:38:22|r\n|Hunit:0x01800000002F0EA5:Devilangel-Uldum|hDevilangel-Uldum|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cff82f4ffRejuvenation|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff24186|r |cff82f4ffNature|r. ",
							["amount"] = 24186,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 11:04:02|r\n|Hunit:0x03000000077277EF:Toastbang-Blackrock|hToastbang-Blackrock|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cff82f4ffRejuvenation|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff47992|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 47992,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Rejuvenation",
					},
					["Atonement"] = {
						[-2] = {
							["time"] = "|cffffffff12/24/12 02:09:05|r\n|Hunit:0x03000000075A5D25:Ghostyface-Kil'jaeden|hGhostyface-Kil'jaeden|h |Hspell:81751:SPELL_HEAL|h|cff82f4ffAtonement|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff48028|r |cff82f4ffHoly|r. (65433 Overhealed) ",
							["amount"] = 113461,
						},
						[2] = {
							["time"] = "|cffffffff12/24/12 01:54:20|r\n|Hunit:0x03000000075A5D25:Ghostyface-Kil'jaeden|hGhostyface-Kil'jaeden|h |Hspell:94472:SPELL_HEAL|h|cff82f4ffAtonement|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff53075|r |cff82f4ffHoly|r. (168983 Overhealed) (Critical) ",
							["amount"] = 222058,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_CircleOfRenewal",
					},
					["Healing Surge"] = {
						[-2] = {
							["time"] = "|cffffffff01/04/13 10:11:08|r\n|Hunit:0x038000000562B99C:Shockapwn-Korgath|hShockapwn-Korgath|h |Hspell:8004:SPELL_HEAL|h|cff82f4ffHealing Surge|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff70772|r |cff82f4ffNature|r. ",
							["amount"] = 70772,
						},
						[2] = {
							["time"] = "|cffffffff01/04/13 09:29:13|r\n|Hunit:0x0100000003AB021F:Amorene-Silvermoon|hAmorene-Silvermoon|h |Hspell:8004:SPELL_HEAL|h|cff82f4ffHealing Surge|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff7272|r |cff82f4ffNature|r. (131424 Overhealed) (Critical) ",
							["amount"] = 138696,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWay",
					},
					["Holy Nova"] = {
						[-2] = {
							["time"] = "|cffffffff01/15/13 12:00:25|r\n|Hunit:0x0380000003A3D166:Celestíne-Mug'thol|hCelestíne-Mug'thol|h |Hspell:23455:SPELL_HEAL|h|cff82f4ffHoly Nova|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff9360|r |cff82f4ffHoly|r. ",
							["amount"] = 9360,
						},
						[2] = {
							["time"] = "|cffffffff01/15/13 12:00:28|r\n|Hunit:0x0380000003A3D166:Celestíne-Mug'thol|hCelestíne-Mug'thol|h |Hspell:23455:SPELL_HEAL|h|cff82f4ffHoly Nova|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff19486|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 19486,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolyNova",
					},
					["Prayer of Mending"] = {
						[-2] = {
							["time"] = "|cffffffff01/29/13 05:31:00|r\n|Hunit:0x0700000004FB88AD:Mellifluous-Velen|hMellifluous-Velen|h |Hspell:33110:SPELL_HEAL|h|cff82f4ffPrayer of Mending|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff45492|r |cff82f4ffHoly|r. ",
							["amount"] = 45492,
						},
						[2] = {
							["time"] = "|cffffffff01/09/13 01:16:41|r\n|Hunit:0x0180000004512230:Amaveli-Dragonblight|hAmaveli-Dragonblight|h |Hspell:33110:SPELL_HEAL|h|cff82f4ffPrayer of Mending|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff68316|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 68316,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfMendingtga",
					},
					["Circle of Healing"] = {
						[-2] = {
							["time"] = "|cffffffff01/04/13 10:06:03|r\n|Hunit:0x03000000001B3877:Zypochondria-Blackrock|hZypochondria-Blackrock|h |Hspell:34861:SPELL_HEAL|h|cff82f4ffCircle of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff28496|r |cff82f4ffHoly|r. ",
							["amount"] = 28496,
						},
						[2] = {
							["time"] = "|cffffffff01/08/13 10:40:07|r\n|Hunit:0x03000000021C8EA0:Vehicle-Frostwolf|hVehicle-Frostwolf|h |Hspell:34861:SPELL_HEAL|h|cff82f4ffCircle of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff34508|r |cff82f4ffHoly|r. (15934 Overhealed) (Critical) ",
							["amount"] = 50442,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_CircleOfRenewal",
					},
					["Chi Wave"] = {
						[-2] = {
							["time"] = "|cffffffff02/15/13 09:19:10|r\n|Hunit:0x03000000073E27E1:Unbearablê-Sen'jin|hUnbearablê-Sen'jin|h |Hspell:132463:SPELL_HEAL|h|cff82f4ffChi Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff45334|r |cff82f4ffNature|r. ",
							["amount"] = 45334,
						},
						[2] = {
							["time"] = "|cffffffff01/09/13 01:19:29|r\n|Hunit:0x0180000004DCCC27:Guotie-Dragonblight|hGuotie-Dragonblight|h |Hspell:132463:SPELL_HEAL|h|cff82f4ffChi Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff82198|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 82198,
						},
						["icon"] = "Interface\\Icons\\ability_monk_chiwave",
					},
					["Spinning Crane Kick"] = {
						[-2] = {
							["time"] = "|cffffffff01/04/13 10:11:32|r\n|Hunit:0x0180000004C8B1EC:Fuzzywuzhe-Uldum|hFuzzywuzhe-Uldum|h |Hspell:117640:SPELL_HEAL|h|cff82f4ffSpinning Crane Kick|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff12720|r |cff82f4ffNature|r. ",
							["amount"] = 12720,
						},
						[2] = {
							["time"] = "|cffffffff01/05/13 01:33:45|r\n|Hunit:0x0300000007438535:Bubalicious-Frostmourne|hBubalicious-Frostmourne|h |Hspell:117640:SPELL_HEAL|h|cff82f4ffSpinning Crane Kick|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff19541|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 19541,
						},
						["icon"] = "Interface\\Icons\\ability_monk_cranekick_new",
					},
					["Uplift"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 11:01:37|r\n|Hunit:0x03800000057C99F1:Owells-Mug'thol|hOwells-Mug'thol|h |Hspell:130316:SPELL_HEAL|h|cff82f4ffUplift|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff34878|r |cff82f4ffNature|r. ",
							["amount"] = 34878,
						},
						[2] = {
							["time"] = "|cffffffff01/19/13 02:04:00|r\n|Hunit:0x010000000511338E:Monklox-Silvermoon|hMonklox-Silvermoon|h |Hspell:116670:SPELL_HEAL|h|cff82f4ffUplift|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff4277|r |cff82f4ffNature|r. (59073 Overhealed) (Critical) ",
							["amount"] = 63350,
						},
						["icon"] = "Interface\\Icons\\ability_monk_uplift",
					},
					["Holy Radiance"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 11:00:59|r\n|Hunit:0x030000000752C667:Elluu-Blackrock|hElluu-Blackrock|h |Hspell:82327:SPELL_HEAL|h|cff82f4ffHoly Radiance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff4472|r |cff82f4ffHoly|r. (40936 Overhealed) ",
							["amount"] = 45408,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 11:04:20|r\n|Hunit:0x030000000752C667:Elluu-Blackrock|hElluu-Blackrock|h |Hspell:82327:SPELL_HEAL|h|cff82f4ffHoly Radiance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff82578|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 82578,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_paladin_divinecircle",
					},
					["Greater Heal"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 01:59:43|r\n|Hunit:0x0300000005AC8374:Bandayde-Kilrogg|hBandayde-Kilrogg|h |Hspell:2060:SPELL_HEAL|h|cff82f4ffGreater Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff48149|r |cff82f4ffHoly|r. (31112 Overhealed) ",
							["amount"] = 79261,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_GreaterHeal",
					},
					["Blood Burst"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 07:12:43|r\n|Hunit:0xF1306D7100000FAA:Bloodworm|hBloodworm|h |Hspell:81280:SPELL_HEAL|h|cff82f4ffBlood Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff24593|r |cff82f4ffShadow|r. (28957 Overhealed) ",
							["amount"] = 53550,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 08:35:34|r\n|Hunit:0xF1306D710002556D:Bloodworm|hBloodworm|h |Hspell:81280:SPELL_HEAL|h|cff82f4ffBlood Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff57376|r |cff82f4ffShadow|r. (14362 Overhealed) (Critical) ",
							["amount"] = 71738,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_BloodNova",
					},
					["Flash Heal"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 05:51:38|r\n|Hunit:0xF130FC1C0000368B:Anduin Wrynn|hAnduin Wrynn|h |Hspell:126400:SPELL_HEAL|h|cffff1313Flash Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffff13130|r |cffff1313Holy|r. (297930 Overhealed) ",
							["amount"] = 297930,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 07:33:57|r\n|Hunit:0x03800000053089B0:Tatortott-Mug'thol|hTatortott-Mug'thol|h |Hspell:2061:SPELL_HEAL|h|cff82f4ffFlash Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff134038|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 134038,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Halo"] = {
						[-2] = {
							["time"] = "|cffffffff01/06/13 09:24:08|r\n|Hunit:0x0100000004D3CF9C:Georgmuller-Dragonmaw|hGeorgmuller-Dragonmaw|h |Hspell:120692:SPELL_HEAL|h|cff82f4ffHalo|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (136368 Overhealed) ",
							["amount"] = 136368,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 11:22:12|r\n|Hunit:0x0300000006640C4A:Captnpowpow-Tichondrius|hCaptnpowpow-Tichondrius|h |Hspell:120696:SPELL_HEAL|h|cff82f4ffHalo|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff33483|r |cff82f4ffShadow|r. (188889 Overhealed) (Critical) ",
							["amount"] = 222372,
						},
						["icon"] = "Interface\\Icons\\ability_priest_halo",
					},
					["Aggressive Behavior"] = {
						[-2] = {
							["time"] = "|cffffffff01/29/13 05:28:49|r\n|Hunit:0xF150EC4B0003D021:Sha of Anger|hSha of Anger|h |Hspell:119626:SPELL_HEAL|h|cffff1313Aggressive Behavior|r|h |Haction:SPELL_HEAL|hhealed|h |Hicon:32:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_6.blp:0|t|h|Hunit:0x0100000004DD3052:Stream|hYou|h |cffff131369495|r |cffff1313Shadow|r. (320928 Overhealed) ",
							["amount"] = 390423,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Misc_EmotionAngry",
					},
					["Eternal Flame"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 10:59:23|r\n|Hunit:0x03000000068C0098:Medîç-Blackrock|hMedîç-Blackrock|h |Hspell:114163:SPELL_HEAL|h|cff82f4ffEternal Flame|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff17773|r |cff82f4ffHoly|r. (51009 Overhealed) ",
							["amount"] = 68782,
						},
						[2] = {
							["time"] = "|cffffffff12/24/12 01:29:10|r\n|Hunit:0x030000000764FB0B:Bubleahearth-Frostmourne|hBubleahearth-Frostmourne|h |Hspell:114163:SPELL_HEAL|h|cff82f4ffEternal Flame|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff148453|r |cff82f4ffHoly|r. (42288 Overhealed) (Critical) ",
							["amount"] = 190741,
						},
						["icon"] = "Interface\\Icons\\INV_Torch_Thrown",
					},
					["Lay on Hands"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:41:14|r\n|Hunit:0x0380000000C72335:Paliwanacrka-Mug'thol|hPaliwanacrka-Mug'thol|h |Hspell:633:SPELL_HEAL|h|cff82f4ffLay on Hands|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff88680|r |cff82f4ffHoly|r. (402399 Overhealed) ",
							["amount"] = 491079,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_LayOnHands",
					},
					["Daybreak"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 11:01:52|r\n|Hunit:0x030000000752C667:Elluu-Blackrock|hElluu-Blackrock|h |Hspell:121129:SPELL_HEAL|h|cff82f4ffDaybreak|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffPhysical|r. (169479 Overhealed) ",
							["amount"] = 169479,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_QirajIdol_Sun",
					},
					["Healing Stream Totem"] = {
						[-2] = {
							["time"] = "|cffffffff12/24/12 01:29:00|r\n|Hunit:0x0300000007597B8B:Lucifelle-Kil'jaeden|hLucifelle-Kil'jaeden|h |Hspell:52042:SPELL_PERIODIC_HEAL|h|cff82f4ffHealing Stream Totem|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff40685|r |cff82f4ffNature|r. ",
							["amount"] = 40685,
						},
						[2] = {
							["time"] = "|cffffffff12/24/12 01:28:58|r\n|Hunit:0x0300000007597B8B:Lucifelle-Kil'jaeden|hLucifelle-Kil'jaeden|h |Hspell:52042:SPELL_PERIODIC_HEAL|h|cff82f4ffHealing Stream Totem|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff93484|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 93484,
						},
						["icon"] = "Interface\\Icons\\INV_Spear_04",
					},
					["Cleansing Waters"] = {
						[-2] = {
							["time"] = "|cffffffff01/04/13 09:17:38|r\n|Hunit:0x0100000003AB021F:Amorene-Silvermoon|hAmorene-Silvermoon|h |Hspell:86961:SPELL_HEAL|h|cff82f4ffCleansing Waters|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (18606 Overhealed) ",
							["amount"] = 18606,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 12:24:40|r\n|Hunit:0x0100000003CB880B:Beatha-ScarletCrusade|hBeatha-ScarletCrusade|h |Hspell:86961:SPELL_HEAL|h|cff82f4ffCleansing Waters|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (29461 Overhealed) (Critical) ",
							["amount"] = 29461,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Regeneration_02",
					},
					["Chain Heal"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 09:36:52|r\n|Hunit:0x0380000005654097:Spoonicle-Akama|hSpoonicle-Akama|h |Hspell:1064:SPELL_HEAL|h|cff82f4ffChain Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff45883|r |cff82f4ffNature|r. ",
							["amount"] = 45883,
						},
						[2] = {
							["time"] = "|cffffffff01/04/13 09:19:28|r\n|Hunit:0x0100000003AB021F:Amorene-Silvermoon|hAmorene-Silvermoon|h |Hspell:1064:SPELL_HEAL|h|cff82f4ffChain Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff76847|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 76847,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWaveGreater",
					},
					["Flash of Light"] = {
						[-2] = {
							["time"] = "|cffffffff01/04/13 09:40:13|r\n|Hunit:0x0100000000F14CA0:Krasni-Silvermoon|hKrasni-Silvermoon|h |Hspell:19750:SPELL_HEAL|h|cff82f4ffFlash of Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff51447|r |cff82f4ffHoly|r. (38447 Overhealed) ",
							["amount"] = 89894,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Greater Healing Wave"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:49:14|r\n|Hunit:0x038000000589AE90:Amyzing-Mug'thol|hAmyzing-Mug'thol|h |Hspell:77472:SPELL_HEAL|h|cff82f4ffGreater Healing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff95863|r |cff82f4ffNature|r. ",
							["amount"] = 95863,
						},
						[2] = {
							["time"] = "|cffffffff01/08/13 11:48:21|r\n|Hunit:0x038000000589AE90:Amyzing-Mug'thol|hAmyzing-Mug'thol|h |Hspell:77472:SPELL_HEAL|h|cff82f4ffGreater Healing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff62101|r |cff82f4ffNature|r. (98936 Overhealed) (Critical) ",
							["amount"] = 161037,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWaveLesser",
					},
					["Zen Sphere: Detonate"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 08:47:04|r\n|Hunit:0x01000000050DC954:Mcpawsome|hMcpawsome|h |Hspell:124101:SPELL_HEAL|h|cff82f4ffZen Sphere: Detonate|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff21946|r |cff82f4ffNature|r. ",
							["amount"] = 21946,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_forcesphere",
					},
					["Penance"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 07:22:49|r\n|Hunit:0x03800000053089B0:Tatortott-Mug'thol|hTatortott-Mug'thol|h |Hspell:47750:SPELL_HEAL|h|cff82f4ffPenance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff32363|r |cff82f4ffHoly|r. ",
							["amount"] = 32363,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 07:22:51|r\n|Hunit:0x03800000053089B0:Tatortott-Mug'thol|hTatortott-Mug'thol|h |Hspell:47750:SPELL_HEAL|h|cff82f4ffPenance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff65396|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 65396,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Penance",
					},
					["Healing Touch"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 12:05:31|r\n|Hunit:0x03800000024B9AFF:Shadowlerker-Chromaggus|hShadowlerker-Chromaggus|h |Hspell:5185:SPELL_HEAL|h|cff82f4ffHealing Touch|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff91522|r |cff82f4ffNature|r. ",
							["amount"] = 91522,
						},
						[2] = {
							["time"] = "|cffffffff01/05/13 12:42:51|r\n|Hunit:0x01000000032BA283:Trotsalot-Dragonmaw|hTrotsalot-Dragonmaw|h |Hspell:5185:SPELL_HEAL|h|cff82f4ffHealing Touch|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff126302|r |cff82f4ffNature|r. (38134 Overhealed) (Critical) ",
							["amount"] = 164436,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingTouch",
					},
					["Tranquility"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 06:33:12|r\n|Hunit:0x0300000007394215:Purra-Kil'jaeden|hPurra-Kil'jaeden|h |Hspell:44203:SPELL_HEAL|h|cff82f4ffTranquility|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff77807|r |cff82f4ffNature|r. (111060 Overhealed) ",
							["amount"] = 188867,
						},
						[2] = {
							["time"] = "|cffffffff01/12/13 08:00:26|r\n|Hunit:0x018000000157664D:Donnyd-Boulderfist|hDonnyd-Boulderfist|h |Hspell:44203:SPELL_HEAL|h|cff82f4ffTranquility|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff85670|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 85670,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Tranquility",
					},
					["Volatile Amber"] = {
						[-2] = {
							["time"] = "|cffffffff01/12/13 07:43:30|r\n|Hspell:123198:SPELL_HEAL|h|cffff1313Volatile Amber|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffff131382809|r |cffff1313Nature|r. (1394174 Overhealed) ",
							["amount"] = 1476983,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\spell_fire_ragnaros_lavabolt",
					},
					["Glyph of Purify"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 06:23:35|r\n|Hunit:0x0300000007393DCF:Junie-Kil'jaeden|hJunie-Kil'jaeden|h |Hspell:56131:SPELL_HEAL|h|cff82f4ffGlyph of Purify|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (11036 Overhealed) ",
							["amount"] = 11036,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Gift of the Serpent"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 10:40:59|r\n|Hunit:0x030000000740DE31:Sunang-Blackrock|hSunang-Blackrock|h |Hspell:124041:SPELL_HEAL|h|cff82f4ffGift of the Serpent|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff1849|r |cff82f4ffNature|r. (44621 Overhealed) ",
							["amount"] = 46470,
						},
						[2] = {
							["time"] = "|cffffffff01/19/13 01:28:53|r\n|Hunit:0x010000000511338E:Monklox-Silvermoon|hMonklox-Silvermoon|h |Hspell:124041:SPELL_HEAL|h|cff82f4ffGift of the Serpent|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff73386|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 73386,
						},
						["icon"] = "Interface\\Icons\\ability_monk_healthsphere",
					},
					["Nourish"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 10:36:51|r\n|Hunit:0x01800000002F0EA5:Devilangel-Uldum|hDevilangel-Uldum|h |Hspell:50464:SPELL_HEAL|h|cff82f4ffNourish|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff18552|r |cff82f4ffNature|r. (15051 Overhealed) ",
							["amount"] = 33603,
						},
						[2] = {
							["time"] = "|cffffffff01/15/13 12:11:29|r\n|Hunit:0x0180000001E2C743:Grotk-Dragonblight|hGrotk-Dragonblight|h |Hspell:50464:SPELL_HEAL|h|cff82f4ffNourish|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff6341|r |cff82f4ffNature|r. (50445 Overhealed) (Critical) ",
							["amount"] = 56786,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Nourish",
					},
					["Healing Tide"] = {
						[-2] = {
							["time"] = "|cffffffff01/04/13 09:30:45|r\n|Hunit:0x0100000003AB021F:Amorene-Silvermoon|hAmorene-Silvermoon|h |Hspell:114942:SPELL_HEAL|h|cff82f4ffHealing Tide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff58294|r |cff82f4ffPhysical|r. ",
							["amount"] = 58294,
						},
						[2] = {
							["time"] = "|cffffffff01/05/13 01:16:00|r\n|Hunit:0x03800000035B1BD5:Atath-Malorne|hAtath-Malorne|h |Hspell:114942:SPELL_HEAL|h|cff82f4ffHealing Tide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff99676|r |cff82f4ffPhysical|r. (Critical) ",
							["amount"] = 99676,
						},
						["icon"] = "Interface\\Icons\\ability_shaman_healingtide",
					},
					["Living Seed"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:14:49|r\n|Hunit:0x01000000002707CA:Gurp|hGurp|h |Hspell:48503:SPELL_HEAL|h|cff82f4ffLiving Seed|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff29822|r |cff82f4ffNature|r. ",
							["amount"] = 29822,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_GiftoftheEarthmother",
					},
					["Stay of Execution"] = {
						[-2] = {
							["time"] = "|cffffffff01/12/13 08:00:41|r\n|Hunit:0x030000000772F1E6:Deputyperkin-Frostmourne|hDeputyperkin-Frostmourne|h |Hspell:114917:SPELL_PERIODIC_HEAL|h|cff82f4ffStay of Execution|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (41935 Overhealed) ",
							["amount"] = 41935,
						},
						[2] = {
							["time"] = "|cffffffff01/12/13 08:00:39|r\n|Hunit:0x030000000772F1E6:Deputyperkin-Frostmourne|hDeputyperkin-Frostmourne|h |Hspell:114917:SPELL_PERIODIC_HEAL|h|cff82f4ffStay of Execution|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (15707 Overhealed) (Critical) ",
							["amount"] = 15707,
						},
						["icon"] = "Interface\\Icons\\spell_paladin_executionsentence",
					},
					["Wild Mushroom: Bloom"] = {
						[-2] = {
							["time"] = "|cffffffff01/15/13 12:53:48|r\n|Hunit:0x0380000003DC030F:Rarww-Jubei'Thos|hRarww-Jubei'Thos|h |Hspell:102792:SPELL_HEAL|h|cff82f4ffWild Mushroom: Bloom|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff1133|r |cff82f4ffNature|r. (13162 Overhealed) ",
							["amount"] = 14295,
						},
						[2] = {
							["time"] = "|cffffffff01/05/13 12:45:43|r\n|Hunit:0x01000000032BA283:Trotsalot-Dragonmaw|hTrotsalot-Dragonmaw|h |Hspell:102792:SPELL_HEAL|h|cff82f4ffWild Mushroom: Bloom|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (18480 Overhealed) (Critical) ",
							["amount"] = 18480,
						},
						["icon"] = "Interface\\Icons\\INV_Mushroom_07",
					},
					["Chi Torpedo"] = {
						[-2] = {
							["time"] = "|cffffffff01/29/13 05:28:27|r\n|Hunit:0x010000000516A192:Kungfukerg|hKungfukerg|h |Hspell:124040:SPELL_HEAL|h|cff82f4ffChi Torpedo|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (35402 Overhealed) ",
							["amount"] = 35402,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 12:08:58|r\n|Hunit:0x03000000074AD62A:Myaruko-Blackrock|hMyaruko-Blackrock|h |Hspell:124040:SPELL_HEAL|h|cff82f4ffChi Torpedo|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (61965 Overhealed) (Critical) ",
							["amount"] = 61965,
						},
						["icon"] = "Interface\\Icons\\ability_monk_quitornado",
					},
					["Holy Prism"] = {
						[-2] = {
							["time"] = "|cffffffff12/24/12 01:02:31|r\n|Hunit:0x0380000004BB3781:Blitznhealz-Jubei'Thos|hBlitznhealz-Jubei'Thos|h |Hspell:114871:SPELL_HEAL|h|cff82f4ffHoly Prism|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff53892|r |cff82f4ffHoly|r. (5533 Overhealed) ",
							["amount"] = 59425,
						},
						[2] = {
							["time"] = "|cffffffff12/24/12 01:01:02|r\n|Hunit:0x0380000004BB3781:Blitznhealz-Jubei'Thos|hBlitznhealz-Jubei'Thos|h |Hspell:114871:SPELL_HEAL|h|cff82f4ffHoly Prism|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (120707 Overhealed) (Critical) ",
							["amount"] = 120707,
						},
						["icon"] = "Interface\\Icons\\spell_paladin_holyprism",
					},
					["Wild Growth"] = {
						[-2] = {
							["time"] = "|cffffffff01/15/13 12:53:37|r\n|Hunit:0x0380000003DC030F:Rarww-Jubei'Thos|hRarww-Jubei'Thos|h |Hspell:48438:SPELL_PERIODIC_HEAL|h|cff82f4ffWild Growth|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff7036|r |cff82f4ffNature|r. ",
							["amount"] = 7036,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 11:04:21|r\n|Hunit:0x0100000000396FF9:Cocha-Spirestone|hCocha-Spirestone|h |Hspell:48438:SPELL_PERIODIC_HEAL|h|cff82f4ffWild Growth|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (14475 Overhealed) (Critical) ",
							["amount"] = 14475,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Flourish",
					},
					["Rapid Renewal"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 12:22:44|r\n|Hunit:0x030000000743A020:Pharmdizzle-Tichondrius|hPharmdizzle-Tichondrius|h |Hspell:63544:SPELL_HEAL|h|cff82f4ffRapid Renewal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff8277|r |cff82f4ffHoly|r. ",
							["amount"] = 8277,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Renew",
					},
					["Ancestral Guidance"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 11:52:40|r\n|Hunit:0x03000000068718E6:Darkcinder-Ner'zhul|hDarkcinder-Ner'zhul|h |Hspell:114911:SPELL_HEAL|h|cff82f4ffAncestral Guidance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff113780|r |cff82f4ffPhysical|r. ",
							["amount"] = 113780,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_shaman_ancestralguidance",
					},
					["Prayer of Healing"] = {
						[-2] = {
							["time"] = "|cffffffff01/04/13 10:11:53|r\n|Hunit:0x03000000001B3877:Zypochondria-Blackrock|hZypochondria-Blackrock|h |Hspell:596:SPELL_HEAL|h|cff82f4ffPrayer of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff52030|r |cff82f4ffHoly|r. ",
							["amount"] = 52030,
						},
						[2] = {
							["time"] = "|cffffffff01/04/13 10:06:07|r\n|Hunit:0x03000000001B3877:Zypochondria-Blackrock|hZypochondria-Blackrock|h |Hspell:596:SPELL_HEAL|h|cff82f4ffPrayer of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff26201|r |cff82f4ffHoly|r. (93558 Overhealed) (Critical) ",
							["amount"] = 119759,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfHealing02",
					},
					["Lifebloom"] = {
						[-2] = {
							["time"] = "|cffffffff01/15/13 12:12:41|r\n|Hunit:0x030000000772E1E2:Bubblers-Tichondrius|hBubblers-Tichondrius|h |Hspell:33778:SPELL_HEAL|h|cff82f4ffLifebloom|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (66375 Overhealed) ",
							["amount"] = 66375,
						},
						[2] = {
							["time"] = "|cffffffff01/17/13 10:12:10|r\n|Hunit:0x0100000004ED47D3:Natronn|hNatronn|h |Hspell:33778:SPELL_HEAL|h|cff82f4ffLifebloom|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (54520 Overhealed) (Critical) ",
							["amount"] = 54520,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingTouch",
					},
					["Lightspring Renew"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 11:52:41|r\n|Hunit:0x03800000012027E1:Reconcile-Chromaggus|hReconcile-Chromaggus|h |Hspell:126154:SPELL_PERIODIC_HEAL|h|cff82f4ffLightspring Renew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff7012|r |cff82f4ffHoly|r. (111032 Overhealed) ",
							["amount"] = 118044,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 11:52:44|r\n|Hunit:0x03800000012027E1:Reconcile-Chromaggus|hReconcile-Chromaggus|h |Hspell:126154:SPELL_PERIODIC_HEAL|h|cff82f4ffLightspring Renew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (236087 Overhealed) (Critical) ",
							["amount"] = 236087,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SummonLightwell",
					},
					["Vampiric Embrace"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 09:24:30|r\n|Hunit:0x03800000057A25F6:Holyhealz-Korgath|hHolyhealz-Korgath|h |Hspell:15290:SPELL_PERIODIC_HEAL|h|cff82f4ffVampiric Embrace|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff23958|r |cff82f4ffShadow|r. (12510 Overhealed) ",
							["amount"] = 36468,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_UnsummonBuilding",
					},
					["Mistweaving"] = {
						[-2] = {
							["time"] = "|cffffffff12/23/12 07:32:53|r\n|Hunit:0xF130FF0F00009365:Mistweaver Nian|hMistweaver Nian|h |Hspell:125125:SPELL_PERIODIC_HEAL|h|cff82f4ffMistweaving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff30027|r |cff82f4ffNature|r. (21842 Overhealed) ",
							["amount"] = 51869,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_soothingmists",
					},
					["Spirit Link"] = {
						[-2] = {
							["time"] = "|cffffffff01/12/13 07:55:33|r\n|Hunit:0xF130CF0E000011A7:Spirit Link Totem|hSpirit Link Totem|h |Hspell:98021:SPELL_HEAL|h|cff82f4ffSpirit Link|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff146630|r |cff82f4ffNature|r. ",
							["amount"] = 146630,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_SpiritLink",
					},
					["Earthliving"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 12:54:00|r\n|Hunit:0x03800000058703CB:Saucylp-Mug'thol|hSaucylp-Mug'thol|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff24828|r |cff82f4ffNature|r. ",
							["amount"] = 24828,
						},
						[2] = {
							["time"] = "|cffffffff01/19/13 12:53:50|r\n|Hunit:0x03800000058703CB:Saucylp-Mug'thol|hSaucylp-Mug'thol|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (46672 Overhealed) (Critical) ",
							["amount"] = 46672,
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_GiftEarthmother",
					},
					["Light of the Ancient Kings"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 10:55:21|r\n|Hunit:0xF130B5A3000003CD:Guardian of Ancient Kings|hGuardian of Ancient Kings|h |Hspell:86678:SPELL_HEAL|h|cff82f4ffLight of the Ancient Kings|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (89720 Overhealed) ",
							["amount"] = 89720,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolyBolt",
					},
					["Renewing Mist"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 10:38:00|r\n|Hunit:0x030000000740DE31:Sunang-Blackrock|hSunang-Blackrock|h |Hspell:119611:SPELL_PERIODIC_HEAL|h|cff82f4ffRenewing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (8020 Overhealed) ",
							["amount"] = 8020,
						},
						[2] = {
							["time"] = "|cffffffff01/08/13 10:38:07|r\n|Hunit:0x030000000740DE31:Sunang-Blackrock|hSunang-Blackrock|h |Hspell:119611:SPELL_PERIODIC_HEAL|h|cff82f4ffRenewing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (16039 Overhealed) (Critical) ",
							["amount"] = 16039,
						},
						["icon"] = "Interface\\Icons\\ability_monk_renewingmists",
					},
					["Battle Insight"] = {
						[-2] = {
							["time"] = "|cffffffff01/31/13 05:22:58|r\n|Hunit:0x0100000004E6CADC:Dankai|hDankai|h |Hspell:123530:SPELL_HEAL|h|cff82f4ffBattle Insight|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff17693|r |cff82f4ffHoly|r. ",
							["amount"] = 17693,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_CircleOfRenewal",
					},
					["Heal"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:50:05|r\n|Hunit:0x0180000001FB95FD:Jen-Stormscale|hJen-Stormscale|h |Hspell:2050:SPELL_HEAL|h|cff82f4ffHeal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff38642|r |cff82f4ffHoly|r. ",
							["amount"] = 38642,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_LesserHeal",
					},
					["Divine Hymn"] = {
						[-2] = {
							["time"] = "|cffffffff12/27/12 12:34:01|r\n|Hunit:0x030000000743A020:Pharmdizzle-Tichondrius|hPharmdizzle-Tichondrius|h |Hspell:64844:SPELL_HEAL|h|cff82f4ffDivine Hymn|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (72202 Overhealed) ",
							["amount"] = 72202,
						},
						[2] = {
							["time"] = "|cffffffff01/19/13 02:06:40|r\n|Hunit:0x0300000005AC8374:Bandayde-Kilrogg|hBandayde-Kilrogg|h |Hspell:64844:SPELL_HEAL|h|cff82f4ffDivine Hymn|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff27186|r |cff82f4ffHoly|r. (126691 Overhealed) (Critical) ",
							["amount"] = 153877,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_DivineProvidence",
					},
					["Holy Light"] = {
						[-2] = {
							["time"] = "|cffffffff12/24/12 01:28:56|r\n|Hunit:0x030000000764FB0B:Bubleahearth-Frostmourne|hBubleahearth-Frostmourne|h |Hspell:635:SPELL_HEAL|h|cff82f4ffHoly Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff50172|r |cff82f4ffHoly|r. ",
							["amount"] = 50172,
						},
						[2] = {
							["time"] = "|cffffffff01/05/13 01:37:16|r\n|Hunit:0x03000000077485E8:Drkpally-Sen'jin|hDrkpally-Sen'jin|h |Hspell:635:SPELL_HEAL|h|cff82f4ffHoly Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (78126 Overhealed) (Critical) ",
							["amount"] = 78126,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolyBolt",
					},
					["Eminence (Statue)"] = {
						[-2] = {
							["time"] = "|cffffffff01/05/13 02:04:40|r\n|Hunit:0x0300000007438535:Bubalicious-Frostmourne|hBubalicious-Frostmourne|h |Hspell:117895:SPELL_HEAL|h|cff82f4ffEminence (Statue)|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff26700|r |cff82f4ffNature|r. (33509 Overhealed) ",
							["amount"] = 60209,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\inv_jewelcrafting_jadeserpent",
					},
					["Lightwell Renew"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 09:10:39|r\n|Hunit:0x03000000077920FF:Dethwhyspur-Proudmoore|hDethwhyspur-Proudmoore|h |Hspell:7001:SPELL_PERIODIC_HEAL|h|cff82f4ffLightwell Renew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (17386 Overhealed) ",
							["amount"] = 17386,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SummonLightwell",
					},
					["Revival"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 10:37:21|r\n|Hunit:0x030000000740DE31:Sunang-Blackrock|hSunang-Blackrock|h |Hspell:115310:SPELL_HEAL|h|cff82f4ffRevival|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff56259|r |cff82f4ffNature|r. (3390 Overhealed) ",
							["amount"] = 59649,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 12:25:47|r\n|Hunit:0x03000000074AD62A:Myaruko-Blackrock|hMyaruko-Blackrock|h |Hspell:115310:SPELL_HEAL|h|cff82f4ffRevival|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff96814|r |cff82f4ffNature|r. (13955 Overhealed) (Critical) ",
							["amount"] = 110769,
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_BlessingOfEternals",
					},
					["Spirit Mend"] = {
						[-2] = {
							["time"] = "|cffffffff01/09/13 08:44:18|r\n|Hunit:0xF140ECE104000057:Brogo|hBrogo|h |Hspell:90361:SPELL_HEAL|h|cff82f4ffSpirit Mend|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff22041|r |cff82f4ffNature|r. ",
							["amount"] = 22041,
						},
						[2] = {
							["time"] = "|cffffffff01/05/13 11:39:53|r\n|Hunit:0xF140CEC1B4000260:Ankha|hAnkha|h |Hspell:90361:SPELL_HEAL|h|cff82f4ffSpirit Mend|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff26875|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 26875,
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_SpiritLink",
					},
				},
				["hit"] = {
					["Holy"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 06:23:49|r\n|Hunit:0x0100000000BFC19F:Cabernet-Spirestone|hCabernet-Spirestone|h |Hspell:53385:SPELL_DAMAGE|h|cffff1313Divine Storm|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffff1313118725|r |cffff1313Holy|r. ",
							["amount"] = 118725,
						},
						[2] = {
							["time"] = "|cffffffff01/08/13 11:42:03|r\n|Hunit:0xF130E95A00000547:Light's Hammer|hLight's Hammer|h |Hspell:114919:SPELL_DAMAGE|h|cff82f4ffArcing Light|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff40059|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 40059,
						},
						["icon"] = "Interface\\Icons\\Ability_Paladin_DivineStorm",
					},
					["Physical"] = {
						[-2] = {
							["time"] = "|cffffffff01/06/13 04:09:40|r\n|Hunit:0xF1310A9F000466BE:Dippy|hDippy|h |Hspell:134537:SPELL_DAMAGE|h|cffff1313Peck|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffff1313374253|r |cffff1313Physical|r. (66867 Absorbed) (452981 Overkill) ",
							["amount"] = 827234,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 07:23:06|r\n|Hunit:0xF130DE4A00044C02:Saboteur Kip'tilak|hSaboteur Kip'tilak|h |Haction:SWING_DAMAGE|h|cffff1313Melee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffff1313125692|r |cffff1313Physical|r. (Critical) ",
							["amount"] = 125692,
						},
						["icon"] = "Interface\\Icons\\INV_Misc_Birdbeck_01",
					},
					["Frost"] = {
						[-2] = {
							["time"] = "|cffffffff01/06/13 08:16:18|r\n|Hunit:0xF13106BF00007550:Darkhatched Lizard-Lord|hDarkhatched Lizard-Lord|h |Hspell:133121:SPELL_DAMAGE|h|cffff1313Water Jets|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffff1313208197|r |cffff1313Frost|r. ",
							["amount"] = 208197,
						},
						[2] = {
							["time"] = "|cffffffff01/08/13 11:42:02|r\n|Hunit:0x03800000048892C7:Xknìght-Jubei'Thos|hXknìght-Jubei'Thos|h |Hspell:49184:SPELL_DAMAGE|h|cff82f4ffHowling Blast|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff122812|r |cff82f4ffFrost|r. (Critical) ",
							["amount"] = 122812,
						},
						["icon"] = "Interface\\Icons\\Spell_Frost_ArcticWinds",
					},
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 09:16:09|r\n|Hicon:32:source|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_6.blp:0|t|h|Hunit:0x0380000005874922:Starmina-KulTiras|hStarmina-KulTiras|h |Hspell:73510:SPELL_DAMAGE|h|cffff1313Mind Spike|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffff131354860|r |cffff1313Shadowfrost|r. ",
							["amount"] = 54860,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 10:26:59|r\n|Hunit:0x0100000000293244:Castro|hCastro|h |Hspell:131081:SPELL_DAMAGE|h|cffff1313Frostfire Bolt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffff131314745|r |cffff1313Frostfire|r. (Critical) ",
							["amount"] = 14745,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_priest_mindspike",
					},
					["Shadow"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 12:16:03|r\n|Hunit:0xF130EE4700000009:Sha of Fear|hSha of Fear|h |Hspell:119775:SPELL_DAMAGE|h|cffff1313Reaching Attack|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffff1313183588|r |cffff1313Shadow|r. (16632 Overkill) ",
							["amount"] = 200220,
						},
						[2] = {
							["time"] = "|cffffffff01/06/13 09:22:48|r\n|Hunit:0x0100000000612307:Skormm-Frostmane|hSkormm-Frostmane|h |Hspell:48181:SPELL_DAMAGE|h|cffff1313Haunt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffff131377783|r |cffff1313Shadow|r. (Critical) ",
							["amount"] = 77783,
						},
						["icon"] = "Interface\\Icons\\Ability_Warlock_Haunt",
					},
					["Fire"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 02:32:24|r\n|Hunit:0x010000000421A806:Cortez|hCortez|h |Hspell:106201:SPELL_DAMAGE|h|cff82f4ffBlood of Deathwing|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff367456|r |cff82f4ffFire|r. (527673 Overkill) ",
							["amount"] = 895129,
						},
						[2] = {
							["time"] = "|cffffffff01/12/13 07:44:12|r\n|Hunit:0x0380000004EAFA13:Kobrakie-Jubei'Thos|hKobrakie-Jubei'Thos|h |Hspell:44461:SPELL_DAMAGE|h|cff82f4ffLiving Bomb|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff94330|r |cff82f4ffFire|r. (Critical) ",
							["amount"] = 94330,
						},
						["icon"] = "Interface\\Icons\\ability_deathwing_bloodcorruption_earth",
					},
					["Arcane"] = {
						[-2] = {
							["time"] = "|cffffffff12/24/12 02:04:45|r\n|Hunit:0xF130EBFA000008A1:Elegon|hElegon|h |Hspell:119722:SPELL_DAMAGE|h|cffff1313Energy Cascade|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffff1313170414|r |cffff1313Arcane|r. ",
							["amount"] = 170414,
						},
						[2] = {
							["time"] = "|cffffffff01/12/13 07:43:43|r\n|Hunit:0x0180000000FC1EA2:Opic-Uldum|hOpic-Uldum|h |Hspell:3044:SPELL_DAMAGE|h|cff82f4ffArcane Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff76407|r |cff82f4ffArcane|r. (Critical) ",
							["amount"] = 76407,
						},
						["icon"] = "Interface\\Icons\\Ability_ImpalingBolt",
					},
					["Nature"] = {
						[-2] = {
							["time"] = "|cffffffff01/17/13 10:40:44|r\n|Hunit:0xF130A136000003AB:Onyxia|hOnyxia|h |Hspell:78999:SPELL_DAMAGE|h|cffff1313Electrical Overload|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cffff1313298756|r |cffff1313Nature|r. (478609 Overkill) ",
							["amount"] = 777365,
						},
						[2] = {
							["time"] = "|cffffffff01/12/13 07:44:00|r\n|Hunit:0x0180000000FC1EA2:Opic-Uldum|hOpic-Uldum|h |Hspell:77767:SPELL_DAMAGE|h|cff82f4ffCobra Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DD3052:Stream|hYou|h |cff82f4ff43930|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 43930,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_LightningOverload",
					},
				},
			},
		},
	},
}
