
FishingBuddy_Player = {
	["MinimapData"] = {
		["minimapPos"] = 154.0707202355207,
		["hide"] = false,
	},
	["Settings"] = {
		["ResetWatcher"] = 1,
	},
	["WasWearing"] = {
	},
	["Outfit"] = {
	},
}
