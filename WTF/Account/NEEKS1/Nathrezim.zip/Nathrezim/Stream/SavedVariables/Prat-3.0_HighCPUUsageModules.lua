
Prat3HighCPUPerCharDB = {
	["time"] = 1361085573,
	["scrollback"] = {
		["ChatFrame1"] = {
			{
				"|cff979797[23:19:33]|r|c00000000|r |Hchannel:channel:2|h[2] |h Joined Channel: |Hchannel:2|h[2. Trade - City]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				70, -- [5]
			}, -- [1]
			{
				"|cff979797[23:19:33]|r|c00000000|r |Hchannel:channel:4|h[4] |h Joined Channel: |Hchannel:4|h[4. LookingForGroup]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				72, -- [5]
			}, -- [2]
			{
				"|cff979797[23:19:33]|r|c00000000|r |Hchannel:channel:5|h[5] |h Joined Channel: |Hchannel:5|h[5. BG]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				73, -- [5]
			}, -- [3]
		},
	},
}
