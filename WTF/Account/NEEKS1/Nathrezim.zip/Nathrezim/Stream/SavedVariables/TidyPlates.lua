
TidyPlatesOptions = {
	["_EnableMiniButton"] = false,
	["EnableCastWatcher"] = 1,
	["FriendlyAutomation"] = "No Automation",
	["EnemyAutomation"] = "No Automation",
	["primary"] = "Neon/|cFFFF4400Damage",
	["WelcomeShown"] = true,
	["secondary"] = "Neon/|cFFFF4400Damage",
}
