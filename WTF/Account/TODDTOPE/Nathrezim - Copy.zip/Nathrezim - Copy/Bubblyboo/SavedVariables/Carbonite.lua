
NxCData = {
	["Version"] = 0.4,
	["Taxi"] = {
	},
}
