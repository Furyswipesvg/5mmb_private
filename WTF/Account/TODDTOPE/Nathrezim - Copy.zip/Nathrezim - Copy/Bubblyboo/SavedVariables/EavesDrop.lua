
EavesDropStatsDB = {
	["profileKeys"] = {
		["Bubblyboo - Nathrezim"] = "Bubblyboo - Nathrezim",
	},
	["profiles"] = {
		["Bubblyboo - Nathrezim"] = {
			{
				["heal"] = {
					["Daybreak"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 09:33:44|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:121129:SPELL_HEAL|h|cffffffffDaybreak|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cffffffff27084|r |cffffffffPhysical|r. ",
							["amount"] = 27084,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_QirajIdol_Sun",
					},
					["Holy Light"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:07:17|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:635:SPELL_HEAL|h|cffffffffHoly Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x03000000056688E1:Jaela-Tichondrius|hJaela-Tichondrius|h |cffffffff30275|r |cffffffffHoly|r. ",
							["amount"] = 30275,
						},
						[2] = {
							["time"] = "|cffffffff01/01/13 09:32:08|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:635:SPELL_HEAL|h|cffffffffHoly Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cffffffff54137|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 54137,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolyBolt",
					},
					["Light of the Ancient Kings"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:04:04|r\n|Hunit:0xF130B5A30000BFB1:Guardian of Ancient Kings|hGuardian of Ancient Kings|h |Hspell:86678:SPELL_HEAL|h|cffffffffLight of the Ancient Kings|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cffffffff0|r |cffffffffHoly|r. (10352 Overhealed) ",
							["amount"] = 10352,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolyBolt",
					},
					["Arcing Light"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 11:13:18|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:119952:SPELL_PERIODIC_HEAL|h|cffffffffArcing Light|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0380000004E1F0F6:Slippie-Saurfang|hSlippie-Saurfang|h |cffffffff21718|r |cffffffffHoly|r. ",
							["amount"] = 21718,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 01:06:40|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:119952:SPELL_PERIODIC_HEAL|h|cffffffffArcing Light|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0380000001A9BD66:Kaay-Mug'thol|hKaay-Mug'thol|h |cffffffff0|r |cffffffffHoly|r. (33971 Overhealed) (Critical) ",
							["amount"] = 33971,
						},
						["icon"] = "Interface\\Icons\\spell_paladin_lightshammer",
					},
					["Beacon of Light"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 09:32:09|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:53652:SPELL_HEAL|h|cffffffffBeacon of Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0180000000982204:Pingofdeath-Crushridge|hPingofdeath-Crushridge|h |cffffffff0|r |cffffffffHoly|r. (54137 Overhealed) ",
							["amount"] = 54137,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Paladin_BeaconofLight",
					},
					["Magnetic Shroud Overload"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 02:38:54|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:107174:SPELL_HEAL|h|cffffffffMagnetic Shroud Overload|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000003CE599E:Klarabelle|hKlarabelle|h |cffffffff34733|r |cffffffffPhysical|r. (6667 Overhealed) ",
							["amount"] = 41400,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Trade_Engineering",
					},
					["Word of Glory"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 11:33:53|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:130551:SPELL_HEAL|h|cffffffffWord of Glory|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cffffffff0|r |cffffffffHoly|r. (132728 Overhealed) ",
							["amount"] = 132728,
						},
						[2] = {
							["time"] = "|cffffffff02/18/13 11:28:58|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:130551:SPELL_HEAL|h|cffffffffWord of Glory|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cffffffff122216|r |cffffffffHoly|r. (74308 Overhealed) (Critical) ",
							["amount"] = 196524,
						},
						["icon"] = "INTERFACE\\ICONS\\inv_helmet_96",
					},
					["Glyph of Protector of the Innocent"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:49:32|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:115536:SPELL_HEAL|h|cffffffffGlyph of Protector of the Innocent|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cffffffff0|r |cffffffffHoly|r. (7393 Overhealed) ",
							["amount"] = 7393,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\ability_paladin_protectoroftheinnocent",
					},
					["Drain Life"] = {
						[-2] = {
							["time"] = "|cffffffff06/29/12 06:42:46|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hBubblyboo's|h |Hspell:109828:SPELL_HEAL|h|cffffffffDrain Life|r|h heals |Hunit:0x010000000352EA3B:Bubblyboo|hBubblyboo|h for |cffffffff6663|r.",
							["amount"] = 6663,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_LifeDrain02",
					},
					["Lay on Hands"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 11:44:32|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:633:SPELL_HEAL|h|cffffffffLay on Hands|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x038000000595C5AB:Flizzarrn-Gundrak|hFlizzarrn-Gundrak|h |cffffffff279654|r |cffffffffHoly|r. (309881 Overhealed) ",
							["amount"] = 589535,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_LayOnHands",
					},
					["Light of Dawn"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:25:10|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:85222:SPELL_HEAL|h|cffffffffLight of Dawn|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0xF140B2566C000226:Smokey|hSmokey|h |cffffffff17771|r |cffffffffHoly|r. ",
							["amount"] = 17771,
						},
						[2] = {
							["time"] = "|cffffffff01/01/13 11:15:34|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:85222:SPELL_HEAL|h|cffffffffLight of Dawn|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x03000000056688E1:Jaela-Tichondrius|hJaela-Tichondrius|h |cffffffff0|r |cffffffffHoly|r. (28737 Overhealed) (Critical) ",
							["amount"] = 28737,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_paladin_lightofdawn",
					},
					["Holy Shock"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:18:22|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:25914:SPELL_HEAL|h|cffffffffHoly Shock|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000051942CA:Slaughtered|hSlaughtered|h |cffffffff0|r |cffffffffHoly|r. (35150 Overhealed) ",
							["amount"] = 35150,
						},
						[2] = {
							["time"] = "|cffffffff01/01/13 11:34:59|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:25914:SPELL_HEAL|h|cffffffffHoly Shock|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000051942CA:Slaughtered|hSlaughtered|h |cffffffff77521|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 77521,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SearingLight",
					},
					["Seal of Insight"] = {
						[-2] = {
							["time"] = "|cffffffff02/18/13 02:17:24|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:20167:SPELL_HEAL|h|cffffffffSeal of Insight|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cffffffff12627|r |cffffffffHoly|r. ",
							["amount"] = 12627,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HealingAura",
					},
					["Flash of Light"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:34:59|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:19750:SPELL_HEAL|h|cffffffffFlash of Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000051942CA:Slaughtered|hSlaughtered|h |cffffffff53375|r |cffffffffHoly|r. ",
							["amount"] = 53375,
						},
						[2] = {
							["time"] = "|cffffffff01/01/13 11:30:56|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:19750:SPELL_HEAL|h|cffffffffFlash of Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000051942CA:Slaughtered|hSlaughtered|h |cffffffff106749|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 106749,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Holy Radiance"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 10:45:16|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:82327:SPELL_HEAL|h|cffffffffHoly Radiance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0380000004AA776D:Kissyface-Eitrigg|hKissyface-Eitrigg|h |cffffffff17580|r |cffffffffHoly|r. ",
							["amount"] = 17580,
						},
						[2] = {
							["time"] = "|cffffffff01/01/13 09:39:53|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:82327:SPELL_HEAL|h|cffffffffHoly Radiance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x03800000059A2950:Cyrrax-Korgath|hCyrrax-Korgath|h |cffffffff41255|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 41255,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_paladin_divinecircle",
					},
					["Ardent Defender"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 11:13:27|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:66235:SPELL_HEAL|h|cffffffffArdent Defender|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cffffffff62232|r |cffffffffHoly|r. ",
							["amount"] = 62232,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolyBolt",
					},
					["Divine Light"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:07:00|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:82326:SPELL_HEAL|h|cffffffffDivine Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000051942CA:Slaughtered|hSlaughtered|h |cffffffff52090|r |cffffffffHoly|r. ",
							["amount"] = 52090,
						},
						[2] = {
							["time"] = "|cffffffff01/01/13 11:18:45|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:82326:SPELL_HEAL|h|cffffffffDivine Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000034F5406:Palia|hPalia|h |cffffffff83987|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 83987,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SurgeOfLight",
					},
				},
				["hit"] = {
					["Exorcism"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 12:28:33|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:879:SPELL_DAMAGE|h|cffffffffExorcism|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530EA43003E6812:Stone Guardian|hStone Guardian|h |cffffffff21683|r |cffffffffHoly|r. ",
							["amount"] = 21683,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Excorcism_02",
					},
					["Seal of Righteousness"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 11:33:17|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:101423:SPELL_DAMAGE|h|cffffffffSeal of Righteousness|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F1050000D54B:Sik'thik Warrior|hSik'thik Warrior|h |cffffffff2460|r |cffffffffHoly|r. ",
							["amount"] = 2460,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 11:31:03|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:101423:SPELL_DAMAGE|h|cffffffffSeal of Righteousness|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F6820000D55E:Sik'thik Swarmer|hSik'thik Swarmer|h |cffffffff4684|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 4684,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_RighteousnessAura",
					},
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 11:34:10|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF130F0C20000D515:Commander Vo'jak|hCommander Vo'jak|h |cffffffff27410|r |cffffffffPhysical|r. ",
							["amount"] = 27410,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 11:32:53|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF130F1050000D54B:Sik'thik Warrior|hSik'thik Warrior|h |cffffffff56614|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 56614,
						},
					},
					["Judgment"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 03:17:07|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:20271:SPELL_DAMAGE|h|cffffffffJudgment|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E7110002FA1F:Rattlegore|hRattlegore|h |cffffffff73837|r |cffffffffHoly|r. ",
							["amount"] = 73837,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 11:33:55|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:20271:SPELL_DAMAGE|h|cffffffffJudgment|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130DD8F0001B115:Sha of Violence|hSha of Violence|h |cffffffff134412|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 134412,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_RighteousFury",
					},
					["Ancient Fury"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 12:47:26|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hBubblyboo's|h |Hspell:86704:SPELL_DAMAGE|h|cffffffffAncient Fury|r|h hits |Hunit:0x01000000005DF800:Gavinrah-Frostmane|hGavinrah-Frostmane|h for |cffffffff1193|r |cffffffffHoly|r.",
							["amount"] = 1193,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Paladin_SanctifiedWrath",
					},
					["Eye for an Eye"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 12:36:36|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hBubblyboo's|h |Hspell:25997:SPELL_DAMAGE|h|cffffffffEye for an Eye|r|h hits |Hunit:0x0100000004D7128A:Liedrel-Dragonmaw|hLiedrel-Dragonmaw|h for |cffffffff1765|r |cffffffffHoly|r.",
							["amount"] = 1765,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 12:47:09|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hBubblyboo's|h |Hspell:25997:SPELL_DAMAGE|h|cffffffffEye for an Eye|r|h hits |Hunit:0x0100000004F4CCEE:Eruken-Frostmane|hEruken-Frostmane|h for |cffffffff1476|r |cffffffffHoly|r.(Critical)",
							["amount"] = 1476,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_EyeforanEye",
					},
					["Holy Shock"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 09:19:01|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:25912:SPELL_DAMAGE|h|cffffffffHoly Shock|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E96800017D2F:Shado-Pan Ambusher|hShado-Pan Ambusher|h |cffffffff13711|r |cffffffffHoly|r. ",
							["amount"] = 13711,
						},
						[2] = {
							["time"] = "|cffffffff01/01/13 09:23:44|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:25912:SPELL_DAMAGE|h|cffffffffHoly Shock|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130FF8600017D40:Ethereal Sha|hEthereal Sha|h |cffffffff26497|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 26497,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SearingLight",
					},
					["Shield of the Righteous"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 11:35:03|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:53600:SPELL_DAMAGE|h|cffffffffShield of the Righteous|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F0C20000D515:Commander Vo'jak|hCommander Vo'jak|h |cffffffff83148|r |cffffffffHoly|r. ",
							["amount"] = 83148,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 01:19:55|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:53600:SPELL_DAMAGE|h|cffffffffShield of the Righteous|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E8DE00038F3B:Bored Student|hBored Student|h |cffffffff127188|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 127188,
						},
						["icon"] = "Interface\\Icons\\Ability_Paladin_ShieldofVengeance",
					},
					["Censure"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 12:28:38|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:31803:SPELL_PERIODIC_DAMAGE|h|cffffffffCensure|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF530EA43003E6812:Stone Guardian|hStone Guardian|h |cffffffff6301|r |cffffffffHoly|r. ",
							["amount"] = 6301,
						},
						[2] = {
							["time"] = "|cffffffff01/19/13 12:28:29|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:31803:SPELL_PERIODIC_DAMAGE|h|cffffffffCensure|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF530EA43003E6812:Stone Guardian|hStone Guardian|h |cffffffff6301|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 6301,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SealOfVengeance",
					},
					["Hammer of the Righteous"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 11:43:14|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:88263:SPELL_DAMAGE|h|cffffffffHammer of the Righteous|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F008000109A2:Sik'thik Soldier|hSik'thik Soldier|h |cffffffff17795|r |cffffffffHoly|r. ",
							["amount"] = 17795,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 11:31:03|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:88263:SPELL_DAMAGE|h|cffffffffHammer of the Righteous|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F6820000D55F:Sik'thik Swarmer|hSik'thik Swarmer|h |cffffffff27954|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 27954,
						},
						["icon"] = "Interface\\Icons\\Ability_Paladin_HammeroftheRighteous",
					},
					["Consecration"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 02:53:21|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:81297:SPELL_DAMAGE|h|cffffffffConsecration|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130DD8F000004B7:Sha of Violence|hSha of Violence|h |cffffffff12673|r |cffffffffHoly|r. ",
							["amount"] = 12673,
						},
						[2] = {
							["time"] = "|cffffffff01/13/13 02:53:20|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:81297:SPELL_DAMAGE|h|cffffffffConsecration|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130DD8F000004B7:Sha of Violence|hSha of Violence|h |cffffffff25637|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 25637,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_InnerFire",
					},
					["Hand of Light"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 12:28:39|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:96172:SPELL_DAMAGE|h|cffffffffHand of Light|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530EA43003E6812:Stone Guardian|hStone Guardian|h |cffffffff9922|r |cffffffffHoly|r. ",
							["amount"] = 9922,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_DivineProvidence",
					},
					["Holy Wrath"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 03:17:11|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:119072:SPELL_DAMAGE|h|cffffffffHoly Wrath|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E7110002FA1F:Rattlegore|hRattlegore|h |cffffffff160761|r |cffffffffHoly|r. ",
							["amount"] = 160761,
						},
						[2] = {
							["time"] = "|cffffffff01/13/13 02:39:34|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:119072:SPELL_DAMAGE|h|cffffffffHoly Wrath|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130DDAB00000514:Gu Cloudstrike|hGu Cloudstrike|h |cffffffff184237|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 184237,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_WeaponMastery",
					},
					["Seals of Command"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 12:47:12|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hBubblyboo's|h |Hspell:20424:SPELL_DAMAGE|h|cffffffffSeals of Command|r|h hits |Hunit:0x01000000005DF800:Gavinrah-Frostmane|hGavinrah-Frostmane|h for |cffffffff445|r |cffffffffHoly|r.",
							["amount"] = 445,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_InnerRage",
					},
					["Stormlash"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 02:56:39|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:120687:SPELL_DAMAGE|h|cffffffffStormlash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130DE3400002F50:Taran Zhu|hTaran Zhu|h |cffffffff11640|r |cffffffffNature|r. ",
							["amount"] = 11640,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 11:27:38|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:120687:SPELL_DAMAGE|h|cffffffffStormlash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150DCDD0001C709:Master Snowdrift|hMaster Snowdrift|h |cffffffff25448|r |cffffffffNature|r. (Critical) ",
							["amount"] = 25448,
						},
						["icon"] = "Interface\\Icons\\Spell_Lightning_LightningBolt01",
					},
					["Drain Life"] = {
						[-2] = {
							["time"] = "|cffffffff06/29/12 06:42:45|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hBubblyboo's|h |Hspell:109828:SPELL_DAMAGE|h|cffffffffDrain Life|r|h hits |Hunit:0xF1306509000078D2:Frozen Core|hFrozen Core|h for |cffffffff3111|r |cffffffffShadow|r.",
							["amount"] = 3111,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_LifeDrain02",
					},
					["Retribution Aura"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 12:47:30|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hBubblyboo's|h |Hspell:7294:DAMAGE_SHIELD|h|cffffffffRetribution Aura|r|h reflects |cffffffff358|r |cffffffffHoly|r damage to |Hunit:0xF130B5AA00000007:Guardian of Ancient Kings|hGuardian of Ancient Kings|h.",
							["amount"] = 358,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_AuraOfLight",
					},
					["Seal of Truth"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 12:28:38|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:42463:SPELL_DAMAGE|h|cffffffffSeal of Truth|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530EA43003E6812:Stone Guardian|hStone Guardian|h |cffffffff3498|r |cffffffffHoly|r. ",
							["amount"] = 3498,
						},
						[2] = {
							["time"] = "|cffffffff01/19/13 12:28:37|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:42463:SPELL_DAMAGE|h|cffffffffSeal of Truth|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF530EA43003E6812:Stone Guardian|hStone Guardian|h |cffffffff7125|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 7125,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SealOfVengeance",
					},
					["Fiery Aura"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 12:24:47|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:23266:DAMAGE_SHIELD|h|cffffffffFiery Aura|r|h |Haction:DAMAGE_SHIELD|hdamages|h |Hunit:0xF130DE5F000026DC:Hozen Party Animal|hHozen Party Animal|h |cffffffff35|r |cffffffffFire|r. ",
							["amount"] = 35,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_LightningShield",
					},
					["Hand of Sacrifice"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 11:35:46|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |Hspell:6940:DAMAGE_SPLIT|h|cffffffffHand of Sacrifice|r|h |Haction:DAMAGE_SPLIT|hshared damage|h |Hunit:0x030000000429F3DE:Althon-Caelestrasz|hAlthon-Caelestrasz|h |cffffffff6010|r |cffffffffPhysical|r. ",
							["amount"] = 6010,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SealOfSacrifice",
					},
					["Avenger's Shield"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 12:27:34|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:31935:SPELL_DAMAGE|h|cffffffffAvenger's Shield|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130DD3D00002649:Ook-Ook|hOok-Ook|h |cffffffff134353|r |cffffffffHoly|r. ",
							["amount"] = 134353,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 11:35:14|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:31935:SPELL_DAMAGE|h|cffffffffAvenger's Shield|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F0C20000D515:Commander Vo'jak|hCommander Vo'jak|h |cffffffff225326|r |cffffffffHoly|r. (Critical) ",
							["amount"] = 225326,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_AvengersShield",
					},
					["Hammer of Wrath"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 03:17:13|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:24275:SPELL_DAMAGE|h|cffffffffHammer of Wrath|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E7110002FA1F:Rattlegore|hRattlegore|h |cffffffff93633|r |cffffffffHoly|r. ",
							["amount"] = 93633,
						},
						[2] = {
							["time"] = "|cffffffff01/13/13 03:17:20|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:24275:SPELL_DAMAGE|h|cffffffffHammer of Wrath|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E7110002FA1F:Rattlegore|hRattlegore|h |cffffffff8490|r |cffffffffHoly|r. (170107 Overkill) (Critical) ",
							["amount"] = 178597,
						},
						["icon"] = "Interface\\Icons\\spell_paladin_hammerofwrath",
					},
					["Crusader Strike"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 11:13:25|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:35395:SPELL_DAMAGE|h|cffffffffCrusader Strike|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E4BB0003CEAA:Scarlet Fanatic|hScarlet Fanatic|h |cffffffff30422|r |cffffffffPhysical|r. ",
							["amount"] = 30422,
						},
						[2] = {
							["time"] = "|cffffffff01/13/13 02:39:38|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:35395:SPELL_DAMAGE|h|cffffffffCrusader Strike|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130DDAB00000514:Gu Cloudstrike|hGu Cloudstrike|h |cffffffff55508|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 55508,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_CrusaderStrike",
					},
					["Templar's Verdict"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 12:36:34|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hBubblyboo's|h |Hspell:85256:SPELL_DAMAGE|h|cffffffffTemplar's Verdict|r|h hits |Hunit:0x0100000004D7128A:Liedrel-Dragonmaw|hLiedrel-Dragonmaw|h for |cffffffff9364|r |cffffffffPhysical|r.",
							["amount"] = 9364,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 12:47:26|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hBubblyboo's|h |Hspell:85256:SPELL_DAMAGE|h|cffffffffTemplar's Verdict|r|h hits |Hunit:0x01000000005DF800:Gavinrah-Frostmane|hGavinrah-Frostmane|h for |cffffffff18975|r |cffffffffPhysical|r.(2788 Absorbed) (Critical)",
							["amount"] = 18975,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_paladin_templarsverdict",
					},
					["Mantid Poison"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:31:55|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:128386:SPELL_PERIODIC_DAMAGE|h|cffffffffMantid Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130F02D0000E01B:General Pa'valak|hGeneral Pa'valak|h |cffffffff7370|r |cffffffffNature|r. ",
							["amount"] = 7370,
						},
						[2] = {
							["time"] = "|cffffffff01/01/13 11:14:18|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hYour|h |Hspell:128386:SPELL_PERIODIC_DAMAGE|h|cffffffffMantid Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130F6820000BF62:Sik'thik Swarmer|hSik'thik Swarmer|h |cffffffff13963|r |cffffffffNature|r. (Critical) ",
							["amount"] = 13963,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_NullifyPoison",
					},
					["Judgement of Truth"] = {
						[-2] = {
							["time"] = "|cffffffff06/29/12 06:42:36|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hBubblyboo's|h |Hspell:31804:SPELL_DAMAGE|h|cffffffffJudgement of Truth|r|h hits |Hunit:0xF1306509000078D2:Frozen Core|hFrozen Core|h for |cffffffff12354|r |cffffffffHoly|r.",
							["amount"] = 12354,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 12:36:55|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hBubblyboo's|h |Hspell:31804:SPELL_DAMAGE|h|cffffffffJudgement of Truth|r|h hits |Hunit:0x0100000004D7128A:Liedrel-Dragonmaw|hLiedrel-Dragonmaw|h for |cffffffff6329|r |cffffffffHoly|r.(Critical)",
							["amount"] = 6329,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SealOfVengeance",
					},
				},
			}, -- [1]
			[-1] = {
				["heal"] = {
					["Renew"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 03:06:24|r\n|Hunit:0x0300000006B03420:Hymns-Kil'jaeden|hHymns-Kil'jaeden|h |Hspell:139:SPELL_PERIODIC_HEAL|h|cff82f4ffRenew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (16989 Overhealed) ",
							["amount"] = 16989,
						},
						[2] = {
							["time"] = "|cffffffff01/13/13 03:13:08|r\n|Hunit:0x0300000006B03420:Hymns-Kil'jaeden|hHymns-Kil'jaeden|h |Hspell:139:SPELL_PERIODIC_HEAL|h|cff82f4ffRenew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff8074|r |cff82f4ffHoly|r. (20478 Overhealed) (Critical) ",
							["amount"] = 28552,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Renew",
					},
					["Swiftmend"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 12:37:23|r\n|Hunit:0x01800000045BFAED:Bobmauly-Stonemaul|hBobmauly-Stonemaul|h |Hspell:18562:SPELL_HEAL|h|cff82f4ffSwiftmend|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff50298|r |cff82f4ffNature|r. ",
							["amount"] = 50298,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 12:43:31|r\n|Hunit:0x01800000045BFAED:Bobmauly-Stonemaul|hBobmauly-Stonemaul|h |Hspell:18562:SPELL_HEAL|h|cff82f4ffSwiftmend|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff44264|r |cff82f4ffNature|r. (56331 Overhealed) (Critical) ",
							["amount"] = 100595,
						},
						["icon"] = "Interface\\Icons\\INV_Relics_IdolofRejuvenation",
					},
					["Healing Surge"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 02:55:36|r\n|Hunit:0x03000000034E801E:Laeya-Thaurissan|hLaeya-Thaurissan|h |Hspell:8004:SPELL_HEAL|h|cff82f4ffHealing Surge|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff185377|r |cff82f4ffNature|r. ",
							["amount"] = 185377,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 11:15:42|r\n|Hunit:0x0380000004E1F0F6:Slippie-Saurfang|hSlippie-Saurfang|h |Hspell:8004:SPELL_HEAL|h|cff82f4ffHealing Surge|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff374533|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 374533,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWay",
					},
					["Glyph of Power Word: Shield"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 03:18:06|r\n|Hunit:0x0300000006B03420:Hymns-Kil'jaeden|hHymns-Kil'jaeden|h |Hspell:56160:SPELL_HEAL|h|cff82f4ffGlyph of Power Word: Shield|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (23421 Overhealed) ",
							["amount"] = 23421,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Prayer of Mending"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 03:19:08|r\n|Hunit:0x0300000006B03420:Hymns-Kil'jaeden|hHymns-Kil'jaeden|h |Hspell:33110:SPELL_HEAL|h|cff82f4ffPrayer of Mending|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff28157|r |cff82f4ffHoly|r. (2433 Overhealed) ",
							["amount"] = 30590,
						},
						[2] = {
							["time"] = "|cffffffff01/13/13 03:26:23|r\n|Hunit:0x0300000006B03420:Hymns-Kil'jaeden|hHymns-Kil'jaeden|h |Hspell:33110:SPELL_HEAL|h|cff82f4ffPrayer of Mending|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (61180 Overhealed) (Critical) ",
							["amount"] = 61180,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfMendingtga",
					},
					["Chi Wave"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 03:12:33|r\n|Hunit:0x0180000004D7CCCB:Sikaliu-Dunemaul|hSikaliu-Dunemaul|h |Hspell:132463:SPELL_HEAL|h|cff82f4ffChi Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff13171|r |cff82f4ffNature|r. ",
							["amount"] = 13171,
						},
						[2] = {
							["time"] = "|cffffffff01/13/13 03:23:58|r\n|Hunit:0x0180000004D7CCCB:Sikaliu-Dunemaul|hSikaliu-Dunemaul|h |Hspell:132463:SPELL_HEAL|h|cff82f4ffChi Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (26314 Overhealed) (Critical) ",
							["amount"] = 26314,
						},
						["icon"] = "Interface\\Icons\\ability_monk_chiwave",
					},
					["Beacon of Light"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 11:21:17|r\n|Hunit:0x030000000429F3DE:Althon-Caelestrasz|hAlthon-Caelestrasz|h |Hspell:53652:SPELL_HEAL|h|cff82f4ffBeacon of Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (94441 Overhealed) ",
							["amount"] = 94441,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Paladin_BeaconofLight",
					},
					["Greater Heal"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 03:17:04|r\n|Hunit:0x0300000006B03420:Hymns-Kil'jaeden|hHymns-Kil'jaeden|h |Hspell:2060:SPELL_HEAL|h|cff82f4ffGreater Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff12888|r |cff82f4ffHoly|r. (96999 Overhealed) ",
							["amount"] = 109887,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 01:01:17|r\n|Hunit:0x03000000070C34D2:Scottdefook-Caelestrasz|hScottdefook-Caelestrasz|h |Hspell:2060:SPELL_HEAL|h|cff82f4ffGreater Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff183960|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 183960,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_GreaterHeal",
					},
					["Blood Burst"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:37:32|r\n|Hunit:0xF1306D710000F07E:Bloodworm|hBloodworm|h |Hspell:81280:SPELL_HEAL|h|cff82f4ffBlood Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffShadow|r. (36119 Overhealed) ",
							["amount"] = 36119,
						},
						[2] = {
							["time"] = "|cffffffff01/01/13 11:25:07|r\n|Hunit:0xF1306D710000DD00:Bloodworm|hBloodworm|h |Hspell:81280:SPELL_HEAL|h|cff82f4ffBlood Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff22536|r |cff82f4ffShadow|r. (30000 Absorbed) (Critical) ",
							["amount"] = 22536,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_BloodNova",
					},
					["Flash Heal"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 03:09:51|r\n|Hunit:0x0300000006B03420:Hymns-Kil'jaeden|hHymns-Kil'jaeden|h |Hspell:2061:SPELL_HEAL|h|cff82f4ffFlash Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff69320|r |cff82f4ffHoly|r. (17525 Overhealed) ",
							["amount"] = 86845,
						},
						[2] = {
							["time"] = "|cffffffff01/13/13 03:18:50|r\n|Hunit:0x0300000006B03420:Hymns-Kil'jaeden|hHymns-Kil'jaeden|h |Hspell:2061:SPELL_HEAL|h|cff82f4ffFlash Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff107343|r |cff82f4ffHoly|r. (89330 Overhealed) (Critical) ",
							["amount"] = 196673,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Halo"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 03:03:26|r\n|Hunit:0x0300000006B03420:Hymns-Kil'jaeden|hHymns-Kil'jaeden|h |Hspell:120692:SPELL_HEAL|h|cff82f4ffHalo|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff3913|r |cff82f4ffHoly|r. (51918 Overhealed) ",
							["amount"] = 55831,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_priest_halo",
					},
					["Eternal Flame"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 11:30:33|r\n|Hunit:0x030000000429F3DE:Althon-Caelestrasz|hAlthon-Caelestrasz|h |Hspell:114163:SPELL_HEAL|h|cff82f4ffEternal Flame|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff87171|r |cff82f4ffHoly|r. ",
							["amount"] = 87171,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 11:36:14|r\n|Hunit:0x030000000429F3DE:Althon-Caelestrasz|hAlthon-Caelestrasz|h |Hspell:114163:SPELL_HEAL|h|cff82f4ffEternal Flame|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff172410|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 172410,
						},
						["icon"] = "Interface\\Icons\\INV_Torch_Thrown",
					},
					["Lay on Hands"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 11:31:43|r\n|Hunit:0x030000000429F3DE:Althon-Caelestrasz|hAlthon-Caelestrasz|h |Hspell:633:SPELL_HEAL|h|cff82f4ffLay on Hands|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff342653|r |cff82f4ffHoly|r. (347404 Overhealed) ",
							["amount"] = 690057,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_LayOnHands",
					},
					["Unleash Life"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 02:45:53|r\n|Hunit:0x03000000034E801E:Laeya-Thaurissan|hLaeya-Thaurissan|h |Hspell:73685:SPELL_HEAL|h|cff82f4ffUnleash Life|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff29725|r |cff82f4ffNature|r. ",
							["amount"] = 29725,
						},
						[2] = {
							["time"] = "|cffffffff01/13/13 02:52:10|r\n|Hunit:0x03000000034E801E:Laeya-Thaurissan|hLaeya-Thaurissan|h |Hspell:73685:SPELL_HEAL|h|cff82f4ffUnleash Life|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff28551|r |cff82f4ffNature|r. (15331 Overhealed) (Critical) ",
							["amount"] = 43882,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_shaman_unleashweapon_life",
					},
					["Light of Dawn"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 11:20:28|r\n|Hunit:0x030000000429F3DE:Althon-Caelestrasz|hAlthon-Caelestrasz|h |Hspell:85222:SPELL_HEAL|h|cff82f4ffLight of Dawn|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (27139 Overhealed) ",
							["amount"] = 27139,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 11:34:01|r\n|Hunit:0x030000000429F3DE:Althon-Caelestrasz|hAlthon-Caelestrasz|h |Hspell:85222:SPELL_HEAL|h|cff82f4ffLight of Dawn|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff55310|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 55310,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_paladin_lightofdawn",
					},
					["Ancestral Awakening"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 11:39:13|r\n|Hunit:0x0180000004DFAAE9:Shocksalot-Bloodscalp|hShocksalot-Bloodscalp|h |Hspell:52752:SPELL_HEAL|h|cff82f4ffAncestral Awakening|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff54302|r |cff82f4ffNature|r. (78542 Overhealed) ",
							["amount"] = 132844,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_AncestralAwakening",
					},
					["Void Shift"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 01:15:50|r\n|Hunit:0x03000000070C34D2:Scottdefook-Caelestrasz|hScottdefook-Caelestrasz|h |Hspell:118594:SPELL_HEAL|h|cff82f4ffVoid Shift|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff228083|r |cff82f4ffShadow|r. ",
							["amount"] = 228083,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\spell_priest_voidshift",
					},
					["Flash of Light"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 09:21:19|r\n|Hunit:0x03000000075F27BE:Albynonurse-Ner'zhul|hAlbynonurse-Ner'zhul|h |Hspell:19750:SPELL_HEAL|h|cff82f4ffFlash of Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff33715|r |cff82f4ffHoly|r. ",
							["amount"] = 33715,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Healing Wave"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 02:49:26|r\n|Hunit:0x03000000034E801E:Laeya-Thaurissan|hLaeya-Thaurissan|h |Hspell:331:SPELL_HEAL|h|cff82f4ffHealing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff95095|r |cff82f4ffNature|r. ",
							["amount"] = 95095,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 11:10:38|r\n|Hunit:0x0380000004E1F0F6:Slippie-Saurfang|hSlippie-Saurfang|h |Hspell:331:SPELL_HEAL|h|cff82f4ffHealing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff95638|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 95638,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_MagicImmunity",
					},
					["Holy Light"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 11:27:59|r\n|Hunit:0x030000000429F3DE:Althon-Caelestrasz|hAlthon-Caelestrasz|h |Hspell:635:SPELL_HEAL|h|cff82f4ffHoly Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (44153 Overhealed) ",
							["amount"] = 44153,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 11:27:52|r\n|Hunit:0x030000000429F3DE:Althon-Caelestrasz|hAlthon-Caelestrasz|h |Hspell:635:SPELL_HEAL|h|cff82f4ffHoly Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (89849 Overhealed) (Critical) ",
							["amount"] = 89849,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolyBolt",
					},
					["Divine Light"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 11:34:08|r\n|Hunit:0x030000000429F3DE:Althon-Caelestrasz|hAlthon-Caelestrasz|h |Hspell:82326:SPELL_HEAL|h|cff82f4ffDivine Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff89221|r |cff82f4ffHoly|r. ",
							["amount"] = 89221,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 11:34:45|r\n|Hunit:0x030000000429F3DE:Althon-Caelestrasz|hAlthon-Caelestrasz|h |Hspell:82326:SPELL_HEAL|h|cff82f4ffDivine Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff33108|r |cff82f4ffHoly|r. (140671 Overhealed) (Critical) ",
							["amount"] = 173779,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SurgeOfLight",
					},
					["Healing Touch"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 12:23:29|r\n|Hunit:0x01800000045BFAED:Bobmauly-Stonemaul|hBobmauly-Stonemaul|h |Hspell:5185:SPELL_HEAL|h|cff82f4ffHealing Touch|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff104199|r |cff82f4ffNature|r. ",
							["amount"] = 104199,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingTouch",
					},
					["Healing Stream Totem"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 02:48:05|r\n|Hunit:0x03000000034E801E:Laeya-Thaurissan|hLaeya-Thaurissan|h |Hspell:52042:SPELL_PERIODIC_HEAL|h|cff82f4ffHealing Stream Totem|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff33652|r |cff82f4ffNature|r. ",
							["amount"] = 33652,
						},
						[2] = {
							["time"] = "|cffffffff01/13/13 02:55:03|r\n|Hunit:0x03000000034E801E:Laeya-Thaurissan|hLaeya-Thaurissan|h |Hspell:52042:SPELL_PERIODIC_HEAL|h|cff82f4ffHealing Stream Totem|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff72177|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 72177,
						},
						["icon"] = "Interface\\Icons\\INV_Spear_04",
					},
					["Chain Heal"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 02:48:26|r\n|Hunit:0x03000000034E801E:Laeya-Thaurissan|hLaeya-Thaurissan|h |Hspell:1064:SPELL_HEAL|h|cff82f4ffChain Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff54801|r |cff82f4ffNature|r. ",
							["amount"] = 54801,
						},
						[2] = {
							["time"] = "|cffffffff01/13/13 02:50:27|r\n|Hunit:0x03000000034E801E:Laeya-Thaurissan|hLaeya-Thaurissan|h |Hspell:1064:SPELL_HEAL|h|cff82f4ffChain Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff131509|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 131509,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWaveGreater",
					},
					["Tranquility"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 12:31:33|r\n|Hunit:0x01800000045BFAED:Bobmauly-Stonemaul|hBobmauly-Stonemaul|h |Hspell:44203:SPELL_HEAL|h|cff82f4ffTranquility|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff2018|r |cff82f4ffNature|r. (30109 Overhealed) ",
							["amount"] = 32127,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 12:31:27|r\n|Hunit:0x01800000045BFAED:Bobmauly-Stonemaul|hBobmauly-Stonemaul|h |Hspell:44203:SPELL_HEAL|h|cff82f4ffTranquility|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff64254|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 64254,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Tranquility",
					},
					["Wild Growth"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 12:36:56|r\n|Hunit:0x01800000045BFAED:Bobmauly-Stonemaul|hBobmauly-Stonemaul|h |Hspell:48438:SPELL_PERIODIC_HEAL|h|cff82f4ffWild Growth|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (4757 Overhealed) ",
							["amount"] = 4757,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 12:36:49|r\n|Hunit:0x01800000045BFAED:Bobmauly-Stonemaul|hBobmauly-Stonemaul|h |Hspell:48438:SPELL_PERIODIC_HEAL|h|cff82f4ffWild Growth|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff9147|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 9147,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Flourish",
					},
					["Nourish"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 12:32:18|r\n|Hunit:0x01800000045BFAED:Bobmauly-Stonemaul|hBobmauly-Stonemaul|h |Hspell:50464:SPELL_HEAL|h|cff82f4ffNourish|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff32260|r |cff82f4ffNature|r. ",
							["amount"] = 32260,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 12:34:00|r\n|Hunit:0x01800000045BFAED:Bobmauly-Stonemaul|hBobmauly-Stonemaul|h |Hspell:50464:SPELL_HEAL|h|cff82f4ffNourish|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (57817 Overhealed) (Critical) ",
							["amount"] = 57817,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Nourish",
					},
					["Binding Heal"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 12:47:13|r\n|Hunit:0x03000000070C34D2:Scottdefook-Caelestrasz|hScottdefook-Caelestrasz|h |Hspell:32546:SPELL_HEAL|h|cff82f4ffBinding Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff42420|r |cff82f4ffHoly|r. ",
							["amount"] = 42420,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 12:54:51|r\n|Hunit:0x03000000070C34D2:Scottdefook-Caelestrasz|hScottdefook-Caelestrasz|h |Hspell:32546:SPELL_HEAL|h|cff82f4ffBinding Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff93087|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 93087,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_BlindingHeal",
					},
					["Living Seed"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 12:43:36|r\n|Hunit:0x01800000045BFAED:Bobmauly-Stonemaul|hBobmauly-Stonemaul|h |Hspell:48503:SPELL_HEAL|h|cff82f4ffLiving Seed|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff24561|r |cff82f4ffNature|r. (10144 Overhealed) ",
							["amount"] = 34705,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_GiftoftheEarthmother",
					},
					["Lifebloom"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 04:32:55|r\n|Hunit:0x030000000777327C:Ihazmilk-Kil'jaeden|hIhazmilk-Kil'jaeden|h |Hspell:33778:SPELL_HEAL|h|cff82f4ffLifebloom|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff12381|r |cff82f4ffNature|r. (96172 Overhealed) ",
							["amount"] = 108553,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 12:37:01|r\n|Hunit:0x01800000045BFAED:Bobmauly-Stonemaul|hBobmauly-Stonemaul|h |Hspell:33763:SPELL_PERIODIC_HEAL|h|cff82f4ffLifebloom|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff15373|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 15373,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingTouch",
					},
					["Divine Star"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 04:33:37|r\n|Hunit:0x03000000062FF5A9:Averline-Khaz'goroth|hAverline-Khaz'goroth|h |Hspell:122128:SPELL_HEAL|h|cff82f4ffDivine Star|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff30458|r |cff82f4ffSpellshadow|r. ",
							["amount"] = 30458,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 06:50:32|r\n|Hunit:0x0100000004E64CFD:Lithindria|hLithindria|h |Hspell:110745:SPELL_HEAL|h|cff82f4ffDivine Star|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffDivine|r. (52189 Overhealed) (Critical) ",
							["amount"] = 52189,
						},
						["icon"] = "Interface\\Icons\\spell_priest_divinestar",
					},
					["Healing Tide"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 11:41:09|r\n|Hunit:0x0180000004DFAAE9:Shocksalot-Bloodscalp|hShocksalot-Bloodscalp|h |Hspell:114942:SPELL_HEAL|h|cff82f4ffHealing Tide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff40133|r |cff82f4ffPhysical|r. ",
							["amount"] = 40133,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 11:41:06|r\n|Hunit:0x0180000004DFAAE9:Shocksalot-Bloodscalp|hShocksalot-Bloodscalp|h |Hspell:114942:SPELL_HEAL|h|cff82f4ffHealing Tide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff69843|r |cff82f4ffPhysical|r. (Critical) ",
							["amount"] = 69843,
						},
						["icon"] = "Interface\\Icons\\ability_shaman_healingtide",
					},
					["Arcing Light"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 11:37:02|r\n|Hunit:0x030000000429F3DE:Althon-Caelestrasz|hAlthon-Caelestrasz|h |Hspell:119952:SPELL_PERIODIC_HEAL|h|cff82f4ffArcing Light|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (21010 Overhealed) ",
							["amount"] = 21010,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 11:37:16|r\n|Hunit:0x030000000429F3DE:Althon-Caelestrasz|hAlthon-Caelestrasz|h |Hspell:119952:SPELL_PERIODIC_HEAL|h|cff82f4ffArcing Light|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff42631|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 42631,
						},
						["icon"] = "Interface\\Icons\\spell_paladin_lightshammer",
					},
					["Daybreak"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 11:28:22|r\n|Hunit:0x030000000429F3DE:Althon-Caelestrasz|hAlthon-Caelestrasz|h |Hspell:121129:SPELL_HEAL|h|cff82f4ffDaybreak|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffPhysical|r. (18994 Overhealed) ",
							["amount"] = 18994,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_QirajIdol_Sun",
					},
					["Healing Rain"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 02:55:01|r\n|Hunit:0x03000000034E801E:Laeya-Thaurissan|hLaeya-Thaurissan|h |Hspell:73921:SPELL_HEAL|h|cff82f4ffHealing Rain|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff18511|r |cff82f4ffNature|r. ",
							["amount"] = 18511,
						},
						[2] = {
							["time"] = "|cffffffff01/13/13 02:53:16|r\n|Hunit:0x03000000034E801E:Laeya-Thaurissan|hLaeya-Thaurissan|h |Hspell:73921:SPELL_HEAL|h|cff82f4ffHealing Rain|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff36977|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 36977,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_GiftoftheWaterSpirit",
					},
					["Ancestral Guidance"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 09:21:17|r\n|Hunit:0x038000000485390B:Heatseeka-KulTiras|hHeatseeka-KulTiras|h |Hspell:114911:SPELL_HEAL|h|cff82f4ffAncestral Guidance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff8552|r |cff82f4ffPhysical|r. ",
							["amount"] = 8552,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_shaman_ancestralguidance",
					},
					["Magnetic Shroud Overload"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 11:20:50|r\n|Hunit:0x0300000006F2C327:Nerrfy-Caelestrasz|hNerrfy-Caelestrasz|h |Hspell:107174:SPELL_HEAL|h|cff82f4ffMagnetic Shroud Overload|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffPhysical|r. (8083 Absorbed) (35042 Overhealed) ",
							["amount"] = 35042,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Trade_Engineering",
					},
					["Vampiric Embrace"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 03:03:43|r\n|Hunit:0x0300000006B03420:Hymns-Kil'jaeden|hHymns-Kil'jaeden|h |Hspell:15290:SPELL_PERIODIC_HEAL|h|cff82f4ffVampiric Embrace|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffShadow|r. (13761 Overhealed) ",
							["amount"] = 13761,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_UnsummonBuilding",
					},
					["Earthliving"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 02:55:35|r\n|Hunit:0x03000000034E801E:Laeya-Thaurissan|hLaeya-Thaurissan|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff6399|r |cff82f4ffNature|r. ",
							["amount"] = 6399,
						},
						[2] = {
							["time"] = "|cffffffff01/13/13 02:53:19|r\n|Hunit:0x03000000034E801E:Laeya-Thaurissan|hLaeya-Thaurissan|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff11770|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 11770,
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_GiftEarthmother",
					},
					["Word of Glory"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 09:21:10|r\n|Hunit:0x03000000075F27BE:Albynonurse-Ner'zhul|hAlbynonurse-Ner'zhul|h |Hspell:130551:SPELL_HEAL|h|cff82f4ffWord of Glory|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff9509|r |cff82f4ffHoly|r. (4332 Absorbed) ",
							["amount"] = 9509,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\inv_helmet_96",
					},
					["Holy Radiance"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 11:28:20|r\n|Hunit:0x030000000429F3DE:Althon-Caelestrasz|hAlthon-Caelestrasz|h |Hspell:82327:SPELL_HEAL|h|cff82f4ffHoly Radiance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff35494|r |cff82f4ffHoly|r. ",
							["amount"] = 35494,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\spell_paladin_divinecircle",
					},
					["Prayer of Healing"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 03:26:27|r\n|Hunit:0x0300000006B03420:Hymns-Kil'jaeden|hHymns-Kil'jaeden|h |Hspell:596:SPELL_HEAL|h|cff82f4ffPrayer of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (45683 Overhealed) ",
							["amount"] = 45683,
						},
						[2] = {
							["time"] = "|cffffffff01/13/13 03:16:25|r\n|Hunit:0x0300000006B03420:Hymns-Kil'jaeden|hHymns-Kil'jaeden|h |Hspell:596:SPELL_HEAL|h|cff82f4ffPrayer of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (90330 Overhealed) (Critical) ",
							["amount"] = 90330,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfHealing02",
					},
					["Cascade"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 03:18:46|r\n|Hunit:0x0300000006B03420:Hymns-Kil'jaeden|hHymns-Kil'jaeden|h |Hspell:121148:SPELL_HEAL|h|cff82f4ffCascade|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff56228|r |cff82f4ffHoly|r. ",
							["amount"] = 56228,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 12:56:15|r\n|Hunit:0x03000000070C34D2:Scottdefook-Caelestrasz|hScottdefook-Caelestrasz|h |Hspell:121148:SPELL_HEAL|h|cff82f4ffCascade|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff100328|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 100328,
						},
						["icon"] = "Interface\\Icons\\ability_priest_cascade",
					},
					["Earth Shield"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 02:55:35|r\n|Hunit:0x03000000034E801E:Laeya-Thaurissan|hLaeya-Thaurissan|h |Hspell:379:SPELL_HEAL|h|cff82f4ffEarth Shield|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff14252|r |cff82f4ffNature|r. ",
							["amount"] = 14252,
						},
						[2] = {
							["time"] = "|cffffffff01/13/13 02:45:53|r\n|Hunit:0x03000000034E801E:Laeya-Thaurissan|hLaeya-Thaurissan|h |Hspell:379:SPELL_HEAL|h|cff82f4ffEarth Shield|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff27997|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 27997,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_SkinofEarth",
					},
					["Holy Prism"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 09:22:21|r\n|Hunit:0x03000000075F27BE:Albynonurse-Ner'zhul|hAlbynonurse-Ner'zhul|h |Hspell:114852:SPELL_HEAL|h|cff82f4ffHoly Prism|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff33958|r |cff82f4ffHoly|r. ",
							["amount"] = 33958,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\spell_paladin_holyprism",
					},
					["Riptide"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 02:52:35|r\n|Hunit:0x03000000034E801E:Laeya-Thaurissan|hLaeya-Thaurissan|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff41426|r |cff82f4ffNature|r. ",
							["amount"] = 41426,
						},
						[2] = {
							["time"] = "|cffffffff01/13/13 02:35:38|r\n|Hunit:0x03000000034E801E:Laeya-Thaurissan|hLaeya-Thaurissan|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (75382 Overhealed) (Critical) ",
							["amount"] = 75382,
						},
						["icon"] = "Interface\\Icons\\spell_nature_riptide",
					},
					["Heal"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 01:18:51|r\n|Hunit:0x03000000070C34D2:Scottdefook-Caelestrasz|hScottdefook-Caelestrasz|h |Hspell:2050:SPELL_HEAL|h|cff82f4ffHeal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff29155|r |cff82f4ffHoly|r. (14041 Overhealed) ",
							["amount"] = 43196,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 01:19:02|r\n|Hunit:0x03000000070C34D2:Scottdefook-Caelestrasz|hScottdefook-Caelestrasz|h |Hspell:2050:SPELL_HEAL|h|cff82f4ffHeal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff25120|r |cff82f4ffHoly|r. (61311 Overhealed) (Critical) ",
							["amount"] = 86431,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_LesserHeal",
					},
					["Penance"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 03:18:52|r\n|Hunit:0x0300000006B03420:Hymns-Kil'jaeden|hHymns-Kil'jaeden|h |Hspell:47750:SPELL_HEAL|h|cff82f4ffPenance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (36796 Overhealed) ",
							["amount"] = 36796,
						},
						[2] = {
							["time"] = "|cffffffff01/13/13 03:26:15|r\n|Hunit:0x0300000006B03420:Hymns-Kil'jaeden|hHymns-Kil'jaeden|h |Hspell:47750:SPELL_HEAL|h|cff82f4ffPenance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (53938 Overhealed) (Critical) ",
							["amount"] = 53938,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Penance",
					},
					["Holy Shock"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 11:37:01|r\n|Hunit:0x030000000429F3DE:Althon-Caelestrasz|hAlthon-Caelestrasz|h |Hspell:25914:SPELL_HEAL|h|cff82f4ffHoly Shock|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff38268|r |cff82f4ffHoly|r. (18250 Overhealed) ",
							["amount"] = 56518,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 11:33:47|r\n|Hunit:0x030000000429F3DE:Althon-Caelestrasz|hAlthon-Caelestrasz|h |Hspell:25914:SPELL_HEAL|h|cff82f4ffHoly Shock|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff101789|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 101789,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SearingLight",
					},
					["Regrowth"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 04:33:28|r\n|Hunit:0x030000000777327C:Ihazmilk-Kil'jaeden|hIhazmilk-Kil'jaeden|h |Hspell:8936:SPELL_HEAL|h|cff82f4ffRegrowth|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff38054|r |cff82f4ffNature|r. ",
							["amount"] = 38054,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 04:33:46|r\n|Hunit:0x030000000777327C:Ihazmilk-Kil'jaeden|hIhazmilk-Kil'jaeden|h |Hspell:8936:SPELL_HEAL|h|cff82f4ffRegrowth|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff88053|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 88053,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_ResistNature",
					},
					["Rejuvenation"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 12:32:20|r\n|Hunit:0x01800000045BFAED:Bobmauly-Stonemaul|hBobmauly-Stonemaul|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cff82f4ffRejuvenation|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff17331|r |cff82f4ffNature|r. ",
							["amount"] = 17331,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 12:32:28|r\n|Hunit:0x01800000045BFAED:Bobmauly-Stonemaul|hBobmauly-Stonemaul|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cff82f4ffRejuvenation|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff13966|r |cff82f4ffNature|r. (20696 Overhealed) (Critical) ",
							["amount"] = 34662,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Rejuvenation",
					},
					["Atonement"] = {
						[-2] = {
							["time"] = "|cffffffff02/16/13 11:02:05|r\n|Hunit:0x0100000004DD3052:Stream|hStream|h |Hspell:81751:SPELL_HEAL|h|cff82f4ffAtonement|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff43584|r |cff82f4ffHoly|r. ",
							["amount"] = 43584,
						},
						[2] = {
							["time"] = "|cffffffff01/02/13 01:17:11|r\n|Hunit:0x03000000070C34D2:Scottdefook-Caelestrasz|hScottdefook-Caelestrasz|h |Hspell:94472:SPELL_HEAL|h|cff82f4ffAtonement|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff6736|r |cff82f4ffHoly|r. (44848 Overhealed) (Critical) ",
							["amount"] = 51584,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_CircleOfRenewal",
					},
					["Greater Healing Wave"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 11:23:59|r\n|Hunit:0x0180000004DFAAE9:Shocksalot-Bloodscalp|hShocksalot-Bloodscalp|h |Hspell:77472:SPELL_HEAL|h|cff82f4ffGreater Healing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff189412|r |cff82f4ffNature|r. (9606 Overhealed) ",
							["amount"] = 199018,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 11:39:11|r\n|Hunit:0x0180000004DFAAE9:Shocksalot-Bloodscalp|hShocksalot-Bloodscalp|h |Hspell:77472:SPELL_HEAL|h|cff82f4ffGreater Healing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff175326|r |cff82f4ffNature|r. (209728 Overhealed) (Critical) ",
							["amount"] = 385054,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWaveLesser",
					},
				},
				["hit"] = {
					["Physical"] = {
						[-2] = {
							["time"] = "|cffffffff01/13/13 03:16:51|r\n|Hunit:0xF130E7110002FA1F:Rattlegore|hRattlegore|h |Haction:SWING_DAMAGE|h|cffff1313Melee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cffff1313118168|r |cffff1313Physical|r. (23432 Absorbed) ",
							["amount"] = 118168,
						},
						[2] = {
							["time"] = "|cffffffff01/01/13 11:34:49|r\n|Hunit:0xF130F4A80000D5CE:Sik'thik Engineer|hSik'thik Engineer|h |Haction:SWING_DAMAGE|h|cffff1313Melee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cffff131349159|r |cffff1313Physical|r. (Critical) ",
							["amount"] = 49159,
						},
					},
					["Holy"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 10:53:22|r\n|Hunit:0xF130E4DE0000F4EE:Scarlet Zealot|hScarlet Zealot|h |Hspell:111010:SPELL_DAMAGE|h|cffff1313Smite|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cffff131333900|r |cffff1313Holy|r. ",
							["amount"] = 33900,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 12:47:29|r\n|Hunit:0x010000000352EA3B:Bubblyboo|hBubblyboo|h suffers |cffff13136383|r |cffff1313Holy|r damage from |Hunit:0x0100000004F4CCEE:Eruken-Frostmane|hEruken-Frostmane's|h |Hspell:31803:SPELL_PERIODIC_DAMAGE|h|cffff1313Censure|r|h.(Critical)",
							["amount"] = 6383,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolySmite",
					},
					["Arcane"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 12:54:58|r\n|Hunit:0xF130E73000038E7E:Jandice Barov|hJandice Barov|h |Hspell:114061:SPELL_DAMAGE|h|cffff1313Wondrous Rapidity|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cffff131363550|r |cffff1313Arcane|r. ",
							["amount"] = 63550,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Arcane_ArcanePotency",
					},
					["Frost"] = {
						[-2] = {
							["time"] = "|cffffffff01/02/13 12:42:33|r\n|Hunit:0xF150E857000052D8:Yan-Zhu the Uncasked|hYan-Zhu the Uncasked|h |Hspell:114548:SPELL_DAMAGE|h|cffff1313Brew Bolt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cffff131368499|r |cffff1313Frost|r. ",
							["amount"] = 68499,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 12:44:01|r\n|Hunit:0x01000000046D67FC:Kachiryoku-Arathor|hKachiryoku-Arathor's|h |Hspell:116:SPELL_DAMAGE|h|cffff1313Frostbolt|r|h hits |Hunit:0x010000000352EA3B:Bubblyboo|hBubblyboo|h for |cffff131337122|r |cffff1313Frost|r.(Critical)",
							["amount"] = 37122,
						},
						["icon"] = "Interface\\Icons\\spell_brew_bolt_medium",
					},
					["Fire"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:26:32|r\n|Hunit:0xF130F00C0000DF2A:Siege Explosives|hSiege Explosives|h |Hspell:119703:SPELL_DAMAGE|h|cff82f4ffDetonate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cff82f4ff187659|r |cff82f4ffFire|r. ",
							["amount"] = 187659,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 12:41:13|r\n|Hunit:0x01000000040C7C7E:Irøh-Bonechewer|hIrøh-Bonechewer's|h |Hspell:60103:SPELL_DAMAGE|h|cffff1313Lava Lash|r|h hits |Hunit:0x010000000352EA3B:Bubblyboo|hBubblyboo|h for |cffff131320752|r |cffff1313Fire|r.(2290 Resisted) (Critical)",
							["amount"] = 20752,
						},
						["icon"] = "Interface\\Icons\\INV_Misc_Bomb_02",
					},
					["Shadow"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 11:33:28|r\n|Hunit:0xF130DD8F0001B115:Sha of Violence|hSha of Violence|h |Hspell:106872:SPELL_DAMAGE|h|cffff1313Disorienting Smash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cffff1313151082|r |cffff1313Shadow|r. ",
							["amount"] = 151082,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_MindSteal",
					},
					["Nature"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:31:27|r\n|Hunit:0xF130F02D0000E01B:General Pa'valak|hGeneral Pa'valak|h |Hspell:119875:SPELL_DAMAGE|h|cffff1313Tempest|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cffff131398242|r |cffff1313Nature|r. ",
							["amount"] = 98242,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 11:30:59|r\n|Hspell:128359:SPELL_DAMAGE|h|cffffffffCaustic Tar|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x010000000352EA3B:Bubblyboo|hYou|h |cffffffff17894|r |cffffffffNature|r. (Critical) ",
							["amount"] = 17894,
						},
						["icon"] = "Interface\\Icons\\INV_Misc_Slime_02",
					},
				},
			},
		},
	},
}
