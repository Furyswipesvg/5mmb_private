
FishingBuddy_Player = {
	["MinimapData"] = {
		["minimapPos"] = 191.6661531239221,
		["hide"] = false,
	},
	["Settings"] = {
		["MinimapButtonPosition"] = -67.35907657992796,
		["ResetWatcher"] = 1,
	},
	["WasWearing"] = {
	},
	["Outfit"] = {
	},
}
