
Prat3CharDB = {
	["history"] = {
	},
}
