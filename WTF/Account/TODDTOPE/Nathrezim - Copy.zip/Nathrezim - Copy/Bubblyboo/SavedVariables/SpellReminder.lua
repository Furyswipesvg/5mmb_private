
SpellReminderDBPerChar = {
	["profileKeys"] = {
		["Bubblyboo - Nathrezim"] = "Default",
	},
}
