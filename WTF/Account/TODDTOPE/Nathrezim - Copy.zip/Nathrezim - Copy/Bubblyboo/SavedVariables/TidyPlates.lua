
TidyPlatesOptions = {
	["FriendlyAutomation"] = "No Automation",
	["_EnableMiniButton"] = false,
	["EnemyAutomation"] = "No Automation",
	["primary"] = "Threat Plates",
	["WelcomeShown"] = true,
	["secondary"] = "Threat Plates",
}
