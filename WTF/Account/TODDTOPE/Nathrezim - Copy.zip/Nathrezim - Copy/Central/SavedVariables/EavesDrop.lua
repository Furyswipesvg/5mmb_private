
EavesDropStatsDB = {
	["profileKeys"] = {
		["Central - Nathrezim"] = "Central - Nathrezim",
	},
	["profiles"] = {
		["Central - Nathrezim"] = {
			{
				["hit"] = {
					["Mantid Poison"] = {
						[-2] = {
							["time"] = "|cffffffff01/10/13 10:05:31|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:128386:SPELL_PERIODIC_DAMAGE|h|cffffffffMantid Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF1310AEE0019FB91:Horde Hunter|hHorde Hunter|h |cffffffff2241|r |cffffffffNature|r. (2657 Overkill) ",
							["amount"] = 4898,
						},
						[2] = {
							["time"] = "|cffffffff01/10/13 10:05:26|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:128386:SPELL_PERIODIC_DAMAGE|h|cffffffffMantid Poison|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF1310AEE0019FB91:Horde Hunter|hHorde Hunter|h |cffffffff9794|r |cffffffffNature|r. (Critical) ",
							["amount"] = 9794,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_NullifyPoison",
					},
					["Frostburn Formula"] = {
						[-2] = {
							["time"] = "|cffffffff02/09/13 07:04:16|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:96331:SPELL_DAMAGE|h|cffffffffFrostburn Formula|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130CEDC0000DD15:Zandalari Juggernaut|hZandalari Juggernaut|h |cffffffff729775|r |cffffffffFrost|r. ",
							["amount"] = 729775,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Mage_DeepFreeze",
					},
					["A Murder of Crows"] = {
						[-2] = {
							["time"] = "|cffffffff02/09/13 07:08:46|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:131900:SPELL_DAMAGE|h|cffffffffA Murder of Crows|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150CBB70000DD6A:Bloodlord Mandokir|hBloodlord Mandokir|h |cffffffff11778|r |cffffffffPhysical|r. ",
							["amount"] = 11778,
						},
						[2] = {
							["time"] = "|cffffffff02/09/13 07:08:47|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:131900:SPELL_DAMAGE|h|cffffffffA Murder of Crows|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150CBB70000DD6A:Bloodlord Mandokir|hBloodlord Mandokir|h |cffffffff24264|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 24264,
						},
						["icon"] = "Interface\\Icons\\ability_hunter_murderofcrows",
					},
					["Auto Shot"] = {
						[-2] = {
							["time"] = "|cffffffff02/09/13 06:17:41|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Haction:RANGE_DAMAGE|h|cffffffffAuto Shot|r|h |Haction:RANGE_DAMAGE|hhit|h |Hunit:0xF150CBB70000E036:Bloodlord Mandokir|hBloodlord Mandokir|h |cffffffff28413|r |cffffffffPhysical|r. ",
							["amount"] = 28413,
						},
						[2] = {
							["time"] = "|cffffffff02/09/13 06:17:36|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Haction:RANGE_DAMAGE|h|cffffffffAuto Shot|r|h |Haction:RANGE_DAMAGE|hhit|h |Hunit:0xF150CBB70000E036:Bloodlord Mandokir|hBloodlord Mandokir|h |cffffffff50591|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 50591,
						},
					},
					["Arcane Shot"] = {
						[-2] = {
							["time"] = "|cffffffff02/09/13 06:17:41|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:3044:SPELL_DAMAGE|h|cffffffffArcane Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150CBB70000E036:Bloodlord Mandokir|hBloodlord Mandokir|h |cffffffff38311|r |cffffffffArcane|r. ",
							["amount"] = 38311,
						},
						[2] = {
							["time"] = "|cffffffff02/09/13 06:25:47|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:3044:SPELL_DAMAGE|h|cffffffffArcane Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150CBB70000F5A6:Bloodlord Mandokir|hBloodlord Mandokir|h |cffffffff73689|r |cffffffffArcane|r. (Critical) ",
							["amount"] = 73689,
						},
						["icon"] = "Interface\\Icons\\Ability_ImpalingBolt",
					},
					["Explosive Shot"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 04:52:43|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:53301:SPELL_DAMAGE|h|cffffffffExplosive Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0xF1308ED500005F37:Apothecary Baxter|hApothecary Baxter|h |cffffffff11175|r |cffffffffFire|r. ",
							["amount"] = 11175,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 04:52:45|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:53301:SPELL_PERIODIC_DAMAGE|h|cffffffffExplosive Shot|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0xF1308ED500005F37:Apothecary Baxter|hApothecary Baxter|h |cffffffff28311|r |cffffffffFire|r. (Critical) ",
							["amount"] = 28311,
						},
						["icon"] = "Interface\\Icons\\Ability_Hunter_ExplosiveShot",
					},
					["Improved Serpent Sting"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 04:52:38|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:83077:SPELL_DAMAGE|h|cffffffffImproved Serpent Sting|r|h |Haction:SPELL_DAMAGE|hhit|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0xF1308ED500005F37:Apothecary Baxter|hApothecary Baxter|h |cffffffff11481|r |cffffffffNature|r. ",
							["amount"] = 11481,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 04:52:27|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:83077:SPELL_DAMAGE|h|cffffffffImproved Serpent Sting|r|h |Haction:SPELL_DAMAGE|hhit|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0xF1308ED500005F37:Apothecary Baxter|hApothecary Baxter|h |cffffffff20166|r |cffffffffNature|r. (Critical) ",
							["amount"] = 20166,
						},
						["icon"] = "Interface\\Icons\\Ability_Hunter_Quickshot",
					},
					["Black Arrow"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 04:51:33|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:3674:SPELL_PERIODIC_DAMAGE|h|cffffffffBlack Arrow|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hicon:128:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8.blp:0|t|h|Hunit:0xF1308DC800005F36:Apothecary Hummel|hApothecary Hummel|h |cffffffff4403|r |cffffffffShadow|r. ",
							["amount"] = 4403,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 04:51:41|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:3674:SPELL_PERIODIC_DAMAGE|h|cffffffffBlack Arrow|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hicon:128:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8.blp:0|t|h|Hunit:0xF1308DC800005F36:Apothecary Hummel|hApothecary Hummel|h |cffffffff9070|r |cffffffffShadow|r. (Critical) ",
							["amount"] = 9070,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_PainSpike",
					},
					["Toxic Link"] = {
						[-2] = {
							["time"] = "|cffffffff02/09/13 06:58:06|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:96478:SPELL_DAMAGE|h|cffffffffToxic Link|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DE8179:Central|hYou|h |cffffffff10890|r |cffffffffNature|r. ",
							["amount"] = 10890,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_PoisonSting",
					},
					["Stormlash"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 12:33:27|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:120687:SPELL_DAMAGE|h|cffffffffStormlash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1308DB00001339B:Apothecary Frye|hApothecary Frye|h |cffffffff7132|r |cffffffffNature|r. ",
							["amount"] = 7132,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Lightning_LightningBolt01",
					},
					["Kill Shot"] = {
						[-2] = {
							["time"] = "|cffffffff02/09/13 07:08:42|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:53351:SPELL_DAMAGE|h|cffffffffKill Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150CBB70000DD6A:Bloodlord Mandokir|hBloodlord Mandokir|h |cffffffff87272|r |cffffffffPhysical|r. ",
							["amount"] = 87272,
						},
						[2] = {
							["time"] = "|cffffffff02/09/13 07:04:02|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:53351:SPELL_DAMAGE|h|cffffffffKill Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130CD7E0000DF17:Gurubashi Warmonger|hGurubashi Warmonger|h |cffffffff131764|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 131764,
						},
						["icon"] = "Interface\\Icons\\Ability_Hunter_Assassinate2",
					},
					["Glaive Toss"] = {
						[-2] = {
							["time"] = "|cffffffff02/09/13 06:59:24|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:121414:SPELL_DAMAGE|h|cffffffffGlaive Toss|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130CC7C0000DE3D:Berserking Boulder Roller|hBerserking Boulder Roller|h |cffffffff30395|r |cffffffffPhysical|r. ",
							["amount"] = 30395,
						},
						[2] = {
							["time"] = "|cffffffff02/09/13 05:41:20|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:120761:SPELL_DAMAGE|h|cffffffffGlaive Toss|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130CD7E00008CFF:Gurubashi Warmonger|hGurubashi Warmonger|h |cffffffff58823|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 58823,
						},
						["icon"] = "Interface\\Icons\\Ability_UpgradeMoonGlaive",
					},
					["Multi-Shot"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 12:30:16|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:2643:SPELL_DAMAGE|h|cffffffffMulti-Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130083E0001330F:Black Rat|hBlack Rat|h |cffffffff1|r |cffffffffPhysical|r. (10748 Overkill) ",
							["amount"] = 10749,
						},
						[2] = {
							["time"] = "|cffffffff02/09/13 07:06:23|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:2643:SPELL_DAMAGE|h|cffffffffMulti-Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150CBB70000DD6A:Bloodlord Mandokir|hBloodlord Mandokir|h |cffffffff22042|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 22042,
						},
						["icon"] = "Interface\\Icons\\Ability_UpgradeMoonGlaive",
					},
					["Explosive Trap"] = {
						[-2] = {
							["time"] = "|cffffffff02/09/13 05:41:19|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:13812:SPELL_PERIODIC_DAMAGE|h|cffffffffExplosive Trap|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130CD7E00008CFF:Gurubashi Warmonger|hGurubashi Warmonger|h |cffffffff2016|r |cffffffffFire|r. ",
							["amount"] = 2016,
						},
						[2] = {
							["time"] = "|cffffffff02/09/13 05:41:17|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:13812:SPELL_DAMAGE|h|cffffffffExplosive Trap|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130CD7E00008CFF:Gurubashi Warmonger|hGurubashi Warmonger|h |cffffffff4213|r |cffffffffFire|r. (Critical) ",
							["amount"] = 4213,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_SelfDestruct",
					},
					["Manipulator's Wrath"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 12:32:04|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:128854:SPELL_DAMAGE|h|cffffffffManipulator's Wrath|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1308DC800013399:Apothecary Hummel|hApothecary Hummel|h |cffffffff5000|r |cffffffffNature|r. ",
							["amount"] = 5000,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_NullifyPoison",
					},
					["Cobra Shot"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 04:52:43|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:77767:SPELL_DAMAGE|h|cffffffffCobra Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0xF1308ED500005F37:Apothecary Baxter|hApothecary Baxter|h |cffffffff15932|r |cffffffffNature|r. ",
							["amount"] = 15932,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 04:53:19|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:77767:SPELL_DAMAGE|h|cffffffffCobra Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hicon:2:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_2.blp:0|t|h|Hunit:0xF1308DB000005F38:Apothecary Frye|hApothecary Frye|h |cffffffff28978|r |cffffffffNature|r. (Critical) ",
							["amount"] = 28978,
						},
						["icon"] = "INTERFACE\\ICONS\\ability_hunter_cobrashot",
					},
					["Serpent Sting"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 04:52:39|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:118253:SPELL_PERIODIC_DAMAGE|h|cffffffffSerpent Sting|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0xF1308ED500005F37:Apothecary Baxter|hApothecary Baxter|h |cffffffff15306|r |cffffffffNature|r. ",
							["amount"] = 15306,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 04:51:47|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:118253:SPELL_PERIODIC_DAMAGE|h|cffffffffSerpent Sting|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hicon:128:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8.blp:0|t|h|Hunit:0xF1308DC800005F36:Apothecary Hummel|hApothecary Hummel|h |cffffffff30028|r |cffffffffNature|r. (Critical) ",
							["amount"] = 30028,
						},
						["icon"] = "Interface\\Icons\\Ability_Hunter_Quickshot",
					},
				},
				["heal"] = {
					["Rallying Cry of King Varian Wrynn"] = {
						[-2] = {
							["time"] = "|cffffffff01/10/13 10:02:12|r\n|Hunit:0xF1310B2F001BB9A3:King Varian Wrynn|hKing Varian Wrynn|h |Hspell:134796:SPELL_HEAL|h|cffffffffRallying Cry of King Varian Wrynn|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DE8179:Central|hYou|h |cffffffff0|r |cffffffffPhysical|r. (87029 Overhealed) ",
							["amount"] = 87029,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Trade_Engineering",
					},
					["Exhilaration"] = {
						[-2] = {
							["time"] = "|cffffffff12/22/12 08:26:55|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:128594:SPELL_HEAL|h|cffffffffExhilaration|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0xF140DB5D69004299:MyBIGassWorm|hMyBIGassWorm|h |cffffffff0|r |cffffffffPhysical|r. (269167 Overhealed) ",
							["amount"] = 269167,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\ability_hunter_onewithnature",
					},
					["Cintron-Infused Bandage"] = {
						[-2] = {
							["time"] = "|cffffffff12/22/12 08:33:59|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:120573:SPELL_PERIODIC_HEAL|h|cffffffffCintron-Infused Bandage|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0xF130F0FC00278861:Injured Gao-Ran Blackguard|hInjured Gao-Ran Blackguard|h |cffffffff39395|r |cffffffffPhysical|r. ",
							["amount"] = 39395,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\inv_misc_bandage_frostweave",
					},
					["Mend Pet"] = {
						[-2] = {
							["time"] = "|cffffffff02/09/13 06:17:22|r\n|Hunit:0x0100000004DE8179:Central|hYour|h |Hspell:136:SPELL_PERIODIC_HEAL|h|cffffffffMend Pet|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0xF140DB5D69000086:MyBIGassWorm|hMyBIGassWorm|h |cffffffff14474|r |cffffffffNature|r. (36941 Overhealed) ",
							["amount"] = 51415,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Hunter_MendPet",
					},
					["Spirit Mend"] = {
						[-2] = {
							["time"] = "|cffffffff12/22/12 08:50:16|r\n|Hunit:0xF140DB5D6B0042C6:Central|hCentral|h |Hspell:90361:SPELL_HEAL|h|cffffffffSpirit Mend|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DE8179:Central|hYou|h |cffffffff10395|r |cffffffffNature|r. ",
							["amount"] = 10395,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_SpiritLink",
					},
				},
			}, -- [1]
			[-1] = {
				["heal"] = {
					["Lightwell Renew"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 04:53:10|r\n|Hunit:0x01800000044CD09B:Mïrror-Draenor|hMïrror-Draenor|h |Hspell:7001:SPELL_PERIODIC_HEAL|h|cff82f4ffLightwell Renew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DE8179:Central|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (21660 Overhealed) ",
							["amount"] = 21660,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SummonLightwell",
					},
					["Prayer of Healing"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 04:52:14|r\n|Hunit:0x01800000044CD09B:Mïrror-Draenor|hMïrror-Draenor|h |Hspell:596:SPELL_HEAL|h|cff82f4ffPrayer of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DE8179:Central|hYou|h |cff82f4ff14968|r |cff82f4ffHoly|r. (22210 Overhealed) ",
							["amount"] = 37178,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfHealing02",
					},
					["Holy Prism"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 04:51:40|r\n|Hunit:0x018000000493F769:Alorrah-Draenor|hAlorrah-Draenor|h |Hspell:114852:SPELL_HEAL|h|cff82f4ffHoly Prism|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DE8179:Central|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (23367 Overhealed) ",
							["amount"] = 23367,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 04:53:44|r\n|Hunit:0x018000000493F769:Alorrah-Draenor|hAlorrah-Draenor|h |Hspell:114852:SPELL_HEAL|h|cff82f4ffHoly Prism|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DE8179:Central|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (50676 Overhealed) (Critical) ",
							["amount"] = 50676,
						},
						["icon"] = "Interface\\Icons\\spell_paladin_holyprism",
					},
					["Cascade"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 04:52:40|r\n|Hunit:0x01800000044CD09B:Mïrror-Draenor|hMïrror-Draenor|h |Hspell:121148:SPELL_HEAL|h|cff82f4ffCascade|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DE8179:Central|hYou|h |cff82f4ff2984|r |cff82f4ffHoly|r. (39377 Overhealed) ",
							["amount"] = 42361,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_priest_cascade",
					},
					["Holy Word: Sanctuary"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 04:51:41|r\n|Hunit:0x01800000044CD09B:Mïrror-Draenor|hMïrror-Draenor|h |Hspell:88686:SPELL_PERIODIC_HEAL|h|cff82f4ffHoly Word: Sanctuary|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DE8179:Central|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (2952 Overhealed) ",
							["amount"] = 2952,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 04:51:40|r\n|Hunit:0x01800000044CD09B:Mïrror-Draenor|hMïrror-Draenor|h |Hspell:88686:SPELL_PERIODIC_HEAL|h|cff82f4ffHoly Word: Sanctuary|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DE8179:Central|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (5975 Overhealed) (Critical) ",
							["amount"] = 5975,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_DivineProvidence",
					},
					["Echo of Light"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 04:52:41|r\n|Hunit:0x01800000044CD09B:Mïrror-Draenor|hMïrror-Draenor|h |Hspell:77489:SPELL_PERIODIC_HEAL|h|cff82f4ffEcho of Light|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000004DE8179:Central|hYou|h |cff82f4ff1246|r |cff82f4ffHoly|r. ",
							["amount"] = 1246,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Aspiration",
					},
					["Prayer of Mending"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 04:51:38|r\n|Hunit:0x01800000044CD09B:Mïrror-Draenor|hMïrror-Draenor|h |Hspell:33110:SPELL_HEAL|h|cff82f4ffPrayer of Mending|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DE8179:Central|hYou|h |cff82f4ff16575|r |cff82f4ffHoly|r. (13676 Overhealed) ",
							["amount"] = 30251,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 04:52:19|r\n|Hunit:0x01800000044CD09B:Mïrror-Draenor|hMïrror-Draenor|h |Hspell:33110:SPELL_HEAL|h|cff82f4ffPrayer of Mending|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000004DE8179:Central|hYou|h |cff82f4ff7085|r |cff82f4ffHoly|r. (53417 Overhealed) (Critical) ",
							["amount"] = 60502,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfMendingtga",
					},
				},
				["hit"] = {
					["Physical"] = {
						[-2] = {
							["time"] = "|cffffffff02/09/13 07:08:12|r\n|Hunit:0xF150CBB70000DD6A:Bloodlord Mandokir|hBloodlord Mandokir|h |Hspell:96684:SPELL_DAMAGE|h|cffff1313Decapitate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DE8179:Central|hYou|h |cffff1313418239|r |cffff1313Physical|r. (18670987 Overkill) ",
							["amount"] = 19089226,
						},
						[2] = {
							["time"] = "|cffffffff02/09/13 05:55:14|r\n|Hunit:0xF130CD7E00008C42:Gurubashi Warmonger|hGurubashi Warmonger|h |Haction:SWING_DAMAGE|h|cffff1313Melee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0x0100000004DE8179:Central|hYou|h |cffff131389598|r |cffff1313Physical|r. (Critical) ",
							["amount"] = 89598,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_BloodBath",
					},
					["Holy"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 04:43:28|r\n|Hunit:0x0100000000BC5033:Xuanzang|hXuanzang|h |Hspell:879:SPELL_DAMAGE|h|cffff1313Exorcism|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DE8179:Central|hYou|h |cffff131316087|r |cffff1313Holy|r. ",
							["amount"] = 16087,
						},
						[2] = {
							["time"] = "|cffffffff02/17/13 04:43:26|r\n|Hunit:0x0100000000BC5033:Xuanzang|hXuanzang|h |Hspell:20271:SPELL_DAMAGE|h|cffff1313Judgment|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DE8179:Central|hYou|h |cffff131325101|r |cffff1313Holy|r. (Critical) ",
							["amount"] = 25101,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Excorcism_02",
					},
					["Arcane"] = {
						[-2] = {
							["time"] = "|cffffffff02/17/13 04:43:39|r\n|Hunit:0x01000000034AE91F:Skroxxar|hSkroxxar|h |Hspell:3044:SPELL_DAMAGE|h|cffff1313Arcane Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DE8179:Central|hYou|h |cffff131316408|r |cffff1313Arcane|r. ",
							["amount"] = 16408,
						},
						[2] = {
							["time"] = "|cffffffff01/15/13 06:35:36|r\n|Hunit:0x0300000005FE0DDF:Hulkandbulk-Kil'jaeden|hHulkandbulk-Kil'jaeden|h |Hspell:3044:SPELL_DAMAGE|h|cffff1313Arcane Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DE8179:Central|hYou|h |cffff131319452|r |cffff1313Arcane|r. (Critical) ",
							["amount"] = 19452,
						},
						["icon"] = "Interface\\Icons\\Ability_ImpalingBolt",
					},
					["Shadow"] = {
						[-2] = {
							["time"] = "|cffffffff02/09/13 06:17:22|r\n|Hunit:0xF150CBB70000E036:Bloodlord Mandokir|hBloodlord Mandokir|h |Hspell:96777:SPELL_DAMAGE|h|cffff1313Bloodletting|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DE8179:Central|hYou|h |cffff1313204937|r |cffff1313Shadow|r. ",
							["amount"] = 204937,
						},
						[2] = {
							["time"] = "|cffffffff12/26/12 05:21:38|r\n|Hunit:0x01000000051942CA:Slaughtered|hSlaughtered|h |Hspell:48721:SPELL_DAMAGE|h|cffff1313Blood Boil|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DE8179:Central|hYou|h |cffff13138909|r |cffff1313Shadow|r. (Critical) ",
							["amount"] = 8909,
						},
						["icon"] = "INTERFACE\\ICONS\\inv_misc_volatilelife",
					},
					["Fire"] = {
						[-2] = {
							["time"] = "|cffffffff12/22/12 08:04:22|r\n|Hspell:124781:SPELL_DAMAGE|h|cff82f4ffMantid Mine|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DE8179:Central|hYou|h |cff82f4ff20583|r |cff82f4ffFire|r. ",
							["amount"] = 20583,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Mage_LivingBomb",
					},
					["Frost"] = {
						[-2] = {
							["time"] = "|cffffffff12/22/12 08:54:41|r\n|Hicon:8:source|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_4.blp:0|t|h|Hunit:0xF130C6540027C125:Eshelon|hEshelon|h |Hspell:124854:SPELL_DAMAGE|h|cffff1313Water Bolt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DE8179:Central|hYou|h |cffff131334592|r |cffff1313Frost|r. ",
							["amount"] = 34592,
						},
						[2] = {
							["time"] = "|cffffffff12/29/12 12:25:13|r\n|Hunit:0x01000000051942CA:Slaughtered|hSlaughtered|h |Hspell:55095:SPELL_PERIODIC_DAMAGE|h|cffff1313Frost Fever|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x0100000004DE8179:Central|hYou|h |cffff13137772|r |cffff1313Frost|r. (Critical) ",
							["amount"] = 7772,
						},
						["icon"] = "Interface\\Icons\\Spell_DeathKnight_FrostFever",
					},
					["Nature"] = {
						[-2] = {
							["time"] = "|cffffffff02/09/13 07:01:34|r\n|Hunit:0xF130CB6C0000DE42:Gurubashi Cauldron-Mixer|hGurubashi Cauldron-Mixer|h |Hspell:96804:SPELL_DAMAGE|h|cffff1313Bubbling Mixture|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DE8179:Central|hYou|h |cffff131326246|r |cffff1313Nature|r. ",
							["amount"] = 26246,
						},
						[2] = {
							["time"] = "|cffffffff12/29/12 12:10:10|r\n|Hunit:0x01000000002AB28D:Peteey|hPeteey|h |Hspell:53209:SPELL_DAMAGE|h|cffff1313Chimera Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000004DE8179:Central|hYou|h |cffff131329679|r |cffff1313Nature|r. (Critical) ",
							["amount"] = 29679,
						},
						["icon"] = "INTERFACE\\ICONS\\creatureportrait_bubble",
					},
				},
			},
		},
	},
}
