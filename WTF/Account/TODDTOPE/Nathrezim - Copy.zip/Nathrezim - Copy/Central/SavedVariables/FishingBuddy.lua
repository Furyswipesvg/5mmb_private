
FishingBuddy_Player = {
	["MinimapData"] = {
		["minimapPos"] = 151.8936569495433,
		["hide"] = false,
	},
	["Settings"] = {
		["ResetWatcher"] = 1,
	},
	["WasWearing"] = {
	},
	["Outfit"] = {
	},
}
