
EavesDropStatsDB = {
	["profileKeys"] = {
		["Dragonstalkr - Nathrezim"] = "Dragonstalkr - Nathrezim",
	},
	["profiles"] = {
		["Dragonstalkr - Nathrezim"] = {
		},
	},
}
