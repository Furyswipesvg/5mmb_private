
TidyPlatesOptions = {
	["FriendlyAutomation"] = "No Automation",
	["EnableCastWatcher"] = false,
	["primary"] = "Threat Plates",
	["_EnableMiniButton"] = false,
	["EnemyAutomation"] = "No Automation",
	["EnableMinimapButton"] = false,
	["WelcomeShown"] = true,
	["secondary"] = "Threat Plates",
}
