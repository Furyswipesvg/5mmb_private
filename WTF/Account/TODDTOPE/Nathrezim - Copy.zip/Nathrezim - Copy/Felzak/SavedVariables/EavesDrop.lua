
EavesDropStatsDB = {
	["profileKeys"] = {
		["Felzak - Nathrezim"] = "Felzak - Nathrezim",
	},
	["profiles"] = {
		["Felzak - Nathrezim"] = {
			{
				["hit"] = {
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:32:41|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h melee swing hits |Hunit:0xF130D87B0004375E:Captain Varo'then|hCaptain Varo'then|h for |cffffffff11441|r |cffffffffPhysical|r.",
							["amount"] = 11441,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:32:17|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h melee swing hits |Hunit:0xF130D87B0004375E:Captain Varo'then|hCaptain Varo'then|h for |cffffffff23602|r |cffffffffPhysical|r.(Critical)",
							["amount"] = 23602,
						},
					},
					["Blood Strike"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 12:45:57|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:45902:SPELL_DAMAGE|h|cffffffffBlood Strike|r|h hits |Hunit:0x01000000032A9FAB:Blackxknight-Dragonmaw|hBlackxknight-Dragonmaw|h for |cffffffff2469|r |cffffffffPhysical|r.",
							["amount"] = 2469,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Deathknight_DeathStrike",
					},
					["Rune Strike"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:32:36|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:56815:SPELL_DAMAGE|h|cffffffffRune Strike|r|h hits |Hunit:0xF130D87B0004375E:Captain Varo'then|hCaptain Varo'then|h for |cffffffff26290|r |cffffffffPhysical|r.",
							["amount"] = 26290,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:25:44|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:56815:SPELL_DAMAGE|h|cffffffffRune Strike|r|h hits |Hicon:128:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8.blp:0|t|h|Hunit:0xF130D6630004374B:Enchanted Magus|hEnchanted Magus|h for |cffffffff54372|r |cffffffffPhysical|r.(Critical)",
							["amount"] = 54372,
						},
						["icon"] = "Interface\\Icons\\Spell_DeathKnight_DarkConviction",
					},
					["Fel Immolation"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:36:45|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:105006:SPELL_DAMAGE|h|cffffffffFel Immolation|r|h hits |Hunit:0xF130E0420004B625:Doomguard Devastator|hDoomguard Devastator|h for |cffffffff30000|r |cffffffffFire|r.",
							["amount"] = 30000,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_FelImmolation",
					},
					["Blood Plague"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:22:56|r\n|Hunit:0xF130DD0300043789:Enchanted Highmistress|hEnchanted Highmistress|h suffers |cffffffff2767|r |cffffffffShadow|r damage from |Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:55078:SPELL_PERIODIC_DAMAGE|h|cffffffffBlood Plague|r|h.",
							["amount"] = 2767,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:22:53|r\n|Hunit:0xF130DD0300043789:Enchanted Highmistress|hEnchanted Highmistress|h suffers |cffffffff5700|r |cffffffffShadow|r damage from |Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:55078:SPELL_PERIODIC_DAMAGE|h|cffffffffBlood Plague|r|h.(Critical)",
							["amount"] = 5700,
						},
						["icon"] = "Interface\\Icons\\Spell_DeathKnight_BloodPlague",
					},
					["Heart Strike"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:21:06|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:55050:SPELL_DAMAGE|h|cffffffffHeart Strike|r|h hits |Hunit:0xF130D55400043793:Eternal Champion|hEternal Champion|h for |cffffffff32344|r |cffffffffPhysical|r.",
							["amount"] = 32344,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:25:58|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:55050:SPELL_DAMAGE|h|cffffffffHeart Strike|r|h hits |Hunit:0xF130D6620004374A:Enchanted Magus|hEnchanted Magus|h for |cffffffff53456|r |cffffffffPhysical|r.(Critical)",
							["amount"] = 53456,
						},
						["icon"] = "Interface\\Icons\\INV_Weapon_Shortblade_40",
					},
					["Death Strike"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:23:03|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:49998:SPELL_DAMAGE|h|cffffffffDeath Strike|r|h hits |Hunit:0xF130DD0300043789:Enchanted Highmistress|hEnchanted Highmistress|h for |cffffffff46352|r |cffffffffPhysical|r.",
							["amount"] = 46352,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:22:59|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:49998:SPELL_DAMAGE|h|cffffffffDeath Strike|r|h hits |Hunit:0xF130DD0300043789:Enchanted Highmistress|hEnchanted Highmistress|h for |cffffffff96033|r |cffffffffPhysical|r.(Critical)",
							["amount"] = 96033,
						},
						["icon"] = "Interface\\Icons\\Spell_DeathKnight_Butcher2",
					},
					["Necrotic Strike"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 12:25:34|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:73975:SPELL_DAMAGE|h|cffffffffNecrotic Strike|r|h hits |Hunit:0x0100000004F58963:Tinkrbells-Shadowsong|hTinkrbells-Shadowsong|h for |cffffffff3382|r |cffffffffPhysical|r.",
							["amount"] = 3382,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 06:13:23|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:73975:SPELL_DAMAGE|h|cffffffffNecrotic Strike|r|h hits |Hunit:0x0100000004EC4FB1:Biocursëd-Smolderthorn|hBiocursëd-Smolderthorn|h for |cffffffff6309|r |cffffffffPhysical|r.(Critical)",
							["amount"] = 6309,
						},
						["icon"] = "INTERFACE\\ICONS\\inv_axe_96",
					},
					["Elune's Wrath"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:32:56|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:103919:SPELL_DAMAGE|h|cffffffffElune's Wrath|r|h hits |Hunit:0xF130D9BB0004A094:Doomguard Devastator|hDoomguard Devastator|h for |cffffffff116235|r |cffffffffArcane|r.(10968 Overkill)",
							["amount"] = 127203,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_StarFall",
					},
					["Whirling Maw"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:21:51|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:109752:SPELL_DAMAGE|h|cffffffffWhirling Maw|r|h hits |Hunit:0xF130D55400043790:Eternal Champion|hEternal Champion|h for |cffffffff29079|r |cffffffffPhysical|r.",
							["amount"] = 29079,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:26:22|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:109752:SPELL_DAMAGE|h|cffffffffWhirling Maw|r|h hits |Hunit:0xF130D6620004374D:Enchanted Magus|hEnchanted Magus|h for |cffffffff55722|r |cffffffffPhysical|r.(Critical)",
							["amount"] = 55722,
						},
						["icon"] = "Interface\\Icons\\Ability_Whirlwind",
					},
					["Magistrike Arc"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:35:43|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:105523:SPELL_DAMAGE|h|cffffffffMagistrike Arc|r|h hits |Hunit:0xF150D6B90004375C:Mannoroth|hMannoroth|h for |cffffffff1208190|r |cffffffffSpellfire|r.",
							["amount"] = 1208190,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\item_sparkofragnoros",
					},
					["Retribution Aura"] = {
						[-2] = {
							["time"] = "|cffffffff06/29/12 06:35:26|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:7294:DAMAGE_SHIELD|h|cffffffffRetribution Aura|r|h reflects |cffffffff135|r |cffffffffHoly|r damage to |Hunit:0xF130649B000071A8:Ahunite Hailstone|hAhunite Hailstone|h.",
							["amount"] = 135,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_AuraOfLight",
					},
					["Blood Boil"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:30:44|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:48721:SPELL_DAMAGE|h|cffffffffBlood Boil|r|h hits |Hunit:0xF130D88200043799:Highguard Elite|hHighguard Elite|h for |cffffffff6850|r |cffffffffShadow|r.",
							["amount"] = 6850,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:23:49|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:48721:SPELL_DAMAGE|h|cffffffffBlood Boil|r|h hits |Hunit:0xF130D5DB00043784:Eye of the Legion|hEye of the Legion|h for |cffffffff14244|r |cffffffffShadow|r.(Critical)",
							["amount"] = 14244,
						},
						["icon"] = "Interface\\Icons\\Spell_DeathKnight_BloodBoil",
					},
					["Bonfire's Blessing"] = {
						[-2] = {
							["time"] = "|cffffffff06/29/12 01:57:49|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:46366:SPELL_DAMAGE|h|cffffffffBonfire's Blessing|r|h hits |Hunit:0xF130BAB40026E34E:Obsidian Viletongue|hObsidian Viletongue|h for |cffffffff850|r |cffffffffFire|r.",
							["amount"] = 850,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_SummerFest_FireSpirit",
					},
					["Frost Fever"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:30:50|r\n|Hunit:0xF130D88200043763:Highguard Elite|hHighguard Elite|h suffers |cffffffff2775|r |cffffffffFrost|r damage from |Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:55095:SPELL_PERIODIC_DAMAGE|h|cffffffffFrost Fever|r|h.",
							["amount"] = 2775,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:22:31|r\n|Hunit:0xF130D5DB0004378D:Eye of the Legion|hEye of the Legion|h suffers |cffffffff4275|r |cffffffffFrost|r damage from |Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:55095:SPELL_PERIODIC_DAMAGE|h|cffffffffFrost Fever|r|h.(1490 Overkill) (Critical)",
							["amount"] = 5765,
						},
						["icon"] = "Interface\\Icons\\Spell_DeathKnight_FrostFever",
					},
					["Death Coil"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 06:47:48|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:47632:SPELL_DAMAGE|h|cffffffffDeath Coil|r|h hits |Hunit:0x01000000042C3F0B:Arrownotix-Silvermoon|hArrownotix-Silvermoon|h for |cffffffff3135|r |cffffffffShadow|r.",
							["amount"] = 3135,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_DeathCoil",
					},
					["Death and Decay"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:25:33|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:52212:SPELL_DAMAGE|h|cffffffffDeath and Decay|r|h hits |Hunit:0xF130D6620004374A:Enchanted Magus|hEnchanted Magus|h for |cffffffff2877|r |cffffffffShadow|r.",
							["amount"] = 2877,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:21:58|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:52212:SPELL_DAMAGE|h|cffffffffDeath and Decay|r|h hits |Hunit:0xF130D55400043790:Eternal Champion|hEternal Champion|h for |cffffffff5987|r |cffffffffShadow|r.(Critical)",
							["amount"] = 5987,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_DeathAndDecay",
					},
				},
				["heal"] = {
					["Rune Tap"] = {
						[-2] = {
							["time"] = "|cffffffff07/04/12 06:34:31|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:48982:SPELL_HEAL|h|cffffffffRune Tap|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffffffff30467|r.",
							["amount"] = 30467,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_DeathKnight_RuneTap",
					},
					["Haunt"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 02:03:47|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:48210:SPELL_HEAL|h|cffffffffHaunt|r|h heals |Hunit:0x0200000006337E9A:Viick-Madoran|hViick-Madoran|h for |cffffffff7084|r.",
							["amount"] = 7084,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Warlock_Haunt",
					},
					["Healthstone"] = {
						[-2] = {
							["time"] = "|cffffffff06/29/12 07:51:31|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:6262:SPELL_HEAL|h|cffffffffHealthstone|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffffffff21479|r.",
							["amount"] = 21479,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Stone_04",
					},
					["Death Strike"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:23:11|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:45470:SPELL_HEAL|h|cffffffffDeath Strike|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffffffff30301|r.(7413 Overhealed)",
							["amount"] = 37714,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_DeathKnight_Butcher2",
					},
					["Death Pact"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 12:25:15|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak's|h |Hspell:48743:SPELL_HEAL|h|cffffffffDeath Pact|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffffffff58905|r.",
							["amount"] = 58905,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_DeathPact",
					},
				},
			}, -- [1]
			[-1] = {
				["hit"] = {
					["Physical"] = {
						[-2] = {
							["time"] = "|cffffffff06/29/12 06:36:39|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak|h falls and loses |cffffffff23253|r health.",
							["amount"] = 23253,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:54:16|r\n|Hunit:0x01000000045D56FD:Flyingpally-Frostmane|hFlyingpally-Frostmane's|h |Hspell:85256:SPELL_DAMAGE|h|cffff1313Templar's Verdict|r|h hits |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffff131312573|r |cffff1313Physical|r.(Critical)",
							["amount"] = 12573,
						},
					},
					["Holy"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:21:46|r\n|Hunit:0xF130D55400043790:Eternal Champion|hEternal Champion's|h |Hspell:102260:SPELL_DAMAGE|h|cffff1313Queen's Blade|r|h hits |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffff131331016|r |cffff1313Holy|r.",
							["amount"] = 31016,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:54:18|r\n|Hunit:0x01000000045D56FD:Flyingpally-Frostmane|hFlyingpally-Frostmane's|h |Hspell:31804:SPELL_DAMAGE|h|cffff1313Judgement of Truth|r|h hits |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffff13138797|r |cffff1313Holy|r.(Critical)",
							["amount"] = 8797,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SealOfVengeance",
					},
					["Frost"] = {
						[-2] = {
							["time"] = "|cffffffff06/29/12 06:36:36|r\n|Hunit:0xF130648C000071A0:Ahune|hAhune's|h |Hspell:46198:SPELL_DAMAGE|h|cffff1313Cold Slap|r|h hits |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffff131356475|r |cffff1313Frost|r.",
							["amount"] = 56475,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 06:25:45|r\n|Hunit:0x0100000004E0BDF4:Venomsburn-Frostmane|hVenomsburn-Frostmane's|h |Hspell:116:SPELL_DAMAGE|h|cffff1313Frostbolt|r|h hits |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffff131328008|r |cffff1313Frost|r.(Critical)",
							["amount"] = 28008,
						},
						["icon"] = "Interface\\Icons\\Spell_Frost_FrostBolt02",
					},
					["Arcane"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:27:00|r\n|Hunit:0xF130D6640004374C:Enchanted Magus|hEnchanted Magus's|h |Hspell:102464:SPELL_DAMAGE|h|cffff1313Arcane Shock|r|h hits |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffff13138515|r |cffff1313Arcane|r.",
							["amount"] = 8515,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:50:47|r\n|Hunit:0x0600000005EE3C24:Achilliess-Lightbringer|hAchilliess-Lightbringer's|h |Hspell:3044:SPELL_DAMAGE|h|cffff1313Arcane Shot|r|h hits |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffff131311544|r |cffff1313Arcane|r.(Critical)",
							["amount"] = 11544,
						},
						["icon"] = "Interface\\Icons\\Ability_ImpalingBolt",
					},
					["Shadow"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 02:03:47|r\n|Hunit:0x0200000006337E9A:Viick-Madoran|hViick-Madoran's|h |Hspell:686:SPELL_DAMAGE|h|cffff1313Shadow Bolt|r|h hits |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffff13139468|r |cffff1313Shadow|r.",
							["amount"] = 9468,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 02:03:53|r\n|Hunit:0x0200000006337E9A:Viick-Madoran|hViick-Madoran's|h |Hspell:109798:SPELL_DAMAGE|h|cffff1313Shadowbolt Volley|r|h hits |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffff131311321|r |cffff1313Shadow|r.(Critical)",
							["amount"] = 11321,
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_ShadowBolt",
					},
					["Fire"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:32:03|r\n|Hunit:0xF130D87B0004375E:Captain Varo'then|hCaptain Varo'then's|h |Hspell:103669:SPELL_DAMAGE|h|cffff1313Magistrike|r|h hits |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffff131324844|r |cffff1313Fire|r.",
							["amount"] = 24844,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 06:25:57|r\n|Hunit:0x0100000004E0BDF4:Venomsburn-Frostmane|hVenomsburn-Frostmane's|h |Hspell:2136:SPELL_DAMAGE|h|cffff1313Fire Blast|r|h hits |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffff13136268|r |cffff1313Fire|r.(Critical)",
							["amount"] = 6268,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_Fireball",
					},
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff06/29/12 07:49:26|r\n|Hunit:0x0100000004D20187:Perfectionn-Gurubashi|hPerfectionn-Gurubashi's|h |Hspell:44614:SPELL_DAMAGE|h|cffff1313Frostfire Bolt|r|h hits |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffff13137071|r |cffff1313Frostfire|r.",
							["amount"] = 7071,
						},
						[2] = {
							["time"] = "|cffffffff07/04/12 06:25:23|r\n|Hunit:0x0100000004E0BDF4:Venomsburn-Frostmane|hVenomsburn-Frostmane's|h |Hspell:84721:SPELL_DAMAGE|h|cffff1313Frostfire Orb|r|h hits |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffff13131844|r |cffff1313Frostfire|r.(Critical)",
							["amount"] = 1844,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_firefrost orb",
					},
					["Nature"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:24:09|r\n|Hunit:0xF130D5750004378F:Royal Handmaiden|hRoyal Handmaiden's|h |Hspell:102233:SPELL_DAMAGE|h|cffff1313Choking Perfume|r|h hits |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffff131320563|r |cffff1313Nature|r.(2642 Resisted)",
							["amount"] = 20563,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:44:44|r\n|Hunit:0x0600000005EE3C24:Achilliess-Lightbringer|hAchilliess-Lightbringer's|h |Hspell:53209:SPELL_DAMAGE|h|cffff1313Chimera Shot|r|h hits |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffff131338120|r |cffff1313Nature|r.(Critical)",
							["amount"] = 38120,
						},
						["icon"] = "Interface\\Icons\\Ability_Hunter_ChimeraShot2",
					},
				},
				["heal"] = {
					["Swiftmend"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:44:45|r\n|Hunit:0x028000000223D51E:Jinjan-Ragnaros|hJinjan-Ragnaros's|h |Hspell:18562:SPELL_HEAL|h|cff82f4ffSwiftmend|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff12471|r.",
							["amount"] = 12471,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:55:09|r\n|Hunit:0x028000000223D51E:Jinjan-Ragnaros|hJinjan-Ragnaros's|h |Hspell:18562:SPELL_HEAL|h|cff82f4ffSwiftmend|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff39390|r.(Critical)",
							["amount"] = 39390,
						},
						["icon"] = "Interface\\Icons\\INV_Relics_IdolofRejuvenation",
					},
					["Rune Tap"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:44:39|r\n|Hunit:0x0600000005E0263A:Chapers-Bladefist|hChapers-Bladefist's|h |Hspell:59754:SPELL_HEAL|h|cff82f4ffRune Tap|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff7107|r.",
							["amount"] = 7107,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_DeathKnight_RuneTap",
					},
					["Healing Wave"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:21:15|r\n|Hunit:0x0300000006F569CF:Møngôôse-Frostmourne|hMøngôôse-Frostmourne's|h |Hspell:331:SPELL_HEAL|h|cff82f4ffHealing Wave|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff12331|r.",
							["amount"] = 12331,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:23:46|r\n|Hunit:0x0300000006F569CF:Møngôôse-Frostmourne|hMøngôôse-Frostmourne's|h |Hspell:331:SPELL_HEAL|h|cff82f4ffHealing Wave|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff24234|r.(Critical)",
							["amount"] = 24234,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_MagicImmunity",
					},
					["Wild Growth"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:44:55|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak|h gains |cff82f4ff0|r Health from |Hunit:0x028000000223D51E:Jinjan-Ragnaros|hJinjan-Ragnaros's|h |Hspell:48438:SPELL_PERIODIC_HEAL|h|cff82f4ffWild Growth|r|h.(1838 Overhealed)",
							["amount"] = 1838,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:55:23|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak|h gains |cff82f4ff968|r Health from |Hunit:0x028000000223D51E:Jinjan-Ragnaros|hJinjan-Ragnaros's|h |Hspell:48438:SPELL_PERIODIC_HEAL|h|cff82f4ffWild Growth|r|h.(1782 Overhealed) (Critical)",
							["amount"] = 2750,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Flourish",
					},
					["Lifebloom"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:44:59|r\n|Hunit:0x028000000223D51E:Jinjan-Ragnaros|hJinjan-Ragnaros's|h |Hspell:33778:SPELL_HEAL|h|cff82f4ffLifebloom|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff3506|r.(16051 Overhealed)",
							["amount"] = 19557,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:45:00|r\n|Hunit:0x0200000005EF28A2:Mooraa-Trollbane|hMooraa-Trollbane's|h |Hspell:33778:SPELL_HEAL|h|cff82f4ffLifebloom|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff2732|r.(34103 Overhealed) (Critical)",
							["amount"] = 36835,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingTouch",
					},
					["Efflorescence"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:55:11|r\n|Hunit:0x028000000223D51E:Jinjan-Ragnaros|hJinjan-Ragnaros's|h |Hspell:81269:SPELL_HEAL|h|cff82f4ffEfflorescence|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff6514|r.",
							["amount"] = 6514,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Misc_Herb_TalandrasRose",
					},
					["Greater Healing Wave"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:22:57|r\n|Hunit:0x0300000006F569CF:Møngôôse-Frostmourne|hMøngôôse-Frostmourne's|h |Hspell:77472:SPELL_HEAL|h|cff82f4ffGreater Healing Wave|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff57496|r.",
							["amount"] = 57496,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:44:05|r\n|Hunit:0x0300000006FF46CF:Kirisute-Caelestrasz|hKirisute-Caelestrasz's|h |Hspell:77472:SPELL_HEAL|h|cff82f4ffGreater Healing Wave|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff35323|r.(Critical)",
							["amount"] = 35323,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWaveLesser",
					},
					["Gift of Sargeras"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:36:51|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak|h gains |cff82f4ff6220|r Health from |Hunit:0xF130D8EC00043759:Illidan Stormrage|hIllidan Stormrage's|h |Hspell:105009:SPELL_PERIODIC_HEAL|h|cff82f4ffGift of Sargeras|r|h.(45070 Overhealed)",
							["amount"] = 51290,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_DemonForm",
					},
					["Divine Storm"] = {
						[-2] = {
							["time"] = "|cffffffff06/29/12 06:35:45|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak|h gains |cff82f4ff7976|r Health from |Hunit:0x03800000045ADD0E:Moomanchu-Rexxar|hMoomanchu-Rexxar's|h |Hspell:54172:SPELL_PERIODIC_HEAL|h|cff82f4ffDivine Storm|r|h.",
							["amount"] = 7976,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Paladin_DivineStorm",
					},
					["Blood Burst"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:52:21|r\n|Hunit:0xF1306D710000009A:Bloodworm|hBloodworm's|h |Hspell:81280:SPELL_HEAL|h|cffff1313Blood Burst|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffff13130|r.(18895 Overhealed)",
							["amount"] = 18895,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:26:10|r\n|Hunit:0xF1306D7100047DF0:Bloodworm|hBloodworm's|h |Hspell:81280:SPELL_HEAL|h|cffff1313Blood Burst|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cffff1313238|r.(27555 Overhealed) (Critical)",
							["amount"] = 27793,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_BloodNova",
					},
					["Unleash Life"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:29:52|r\n|Hunit:0x0300000006F569CF:Møngôôse-Frostmourne|hMøngôôse-Frostmourne's|h |Hspell:73685:SPELL_HEAL|h|cff82f4ffUnleash Life|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff8711|r.",
							["amount"] = 8711,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\spell_shaman_unleashweapon_life",
					},
					["Healing Stream Totem"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:33:13|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak|h gains |cff82f4ff2343|r Health from |Hunit:0xF1300DC7000492AF:Healing Stream Totem|hHealing Stream Totem's|h |Hspell:52042:SPELL_PERIODIC_HEAL|h|cff82f4ffHealing Stream Totem|r|h.",
							["amount"] = 2343,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Stoicism",
					},
					["Earthliving"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:22:55|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak|h gains |cff82f4ff2247|r Health from |Hunit:0x0300000006F569CF:Møngôôse-Frostmourne|hMøngôôse-Frostmourne's|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h.",
							["amount"] = 2247,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:23:06|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak|h gains |cff82f4ff4034|r Health from |Hunit:0x0300000006F569CF:Møngôôse-Frostmourne|hMøngôôse-Frostmourne's|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h.(Critical)",
							["amount"] = 4034,
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_GiftEarthmother",
					},
					["Earth Shield"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:22:32|r\n|Hunit:0x0300000006F569CF:Møngôôse-Frostmourne|hMøngôôse-Frostmourne's|h |Hspell:379:SPELL_HEAL|h|cff82f4ffEarth Shield|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff7294|r.",
							["amount"] = 7294,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:36:30|r\n|Hunit:0x0300000006F569CF:Møngôôse-Frostmourne|hMøngôôse-Frostmourne's|h |Hspell:379:SPELL_HEAL|h|cff82f4ffEarth Shield|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff12021|r.(Critical)",
							["amount"] = 12021,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_SkinofEarth",
					},
					["Healing Rain"] = {
						[-2] = {
							["time"] = "|cffffffff06/29/12 06:35:36|r\n|Hunit:0x018000000487B276:Naughtyria-Bloodscalp|hNaughtyria-Bloodscalp's|h |Hspell:73921:SPELL_HEAL|h|cff82f4ffHealing Rain|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff2839|r.",
							["amount"] = 2839,
						},
						[2] = {
							["time"] = "|cffffffff06/29/12 06:35:38|r\n|Hunit:0x018000000487B276:Naughtyria-Bloodscalp|hNaughtyria-Bloodscalp's|h |Hspell:73921:SPELL_HEAL|h|cff82f4ffHealing Rain|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff5833|r.(Critical)",
							["amount"] = 5833,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_GiftoftheWaterSpirit",
					},
					["Riptide"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:22:57|r\n|Hunit:0x0300000006F569CF:Møngôôse-Frostmourne|hMøngôôse-Frostmourne's|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff14062|r.",
							["amount"] = 14062,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:21:18|r\n|Hunit:0x0300000006F569CF:Møngôôse-Frostmourne|hMøngôôse-Frostmourne's|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff18586|r.(Critical)",
							["amount"] = 18586,
						},
						["icon"] = "Interface\\Icons\\spell_nature_riptide",
					},
					["Cleansing Flames"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:36:26|r\n|Hunit:0x0300000006F569CF:Møngôôse-Frostmourne|hMøngôôse-Frostmourne's|h |Hspell:109847:SPELL_HEAL|h|cff82f4ffCleansing Flames|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff8442|r.",
							["amount"] = 8442,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:22:04|r\n|Hunit:0x0300000006F569CF:Møngôôse-Frostmourne|hMøngôôse-Frostmourne's|h |Hspell:109847:SPELL_HEAL|h|cff82f4ffCleansing Flames|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff11407|r.(Critical)",
							["amount"] = 11407,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_MoltenBlood",
					},
					["Ancestral Awakening"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:23:56|r\n|Hunit:0x0300000006F569CF:Møngôôse-Frostmourne|hMøngôôse-Frostmourne's|h |Hspell:52752:SPELL_HEAL|h|cff82f4ffAncestral Awakening|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff28899|r.",
							["amount"] = 28899,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_AncestralAwakening",
					},
					["Chain Heal"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:22:31|r\n|Hunit:0x0300000006F569CF:Møngôôse-Frostmourne|hMøngôôse-Frostmourne's|h |Hspell:1064:SPELL_HEAL|h|cff82f4ffChain Heal|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff20301|r.",
							["amount"] = 20301,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:27:09|r\n|Hunit:0x0300000006F569CF:Møngôôse-Frostmourne|hMøngôôse-Frostmourne's|h |Hspell:1064:SPELL_HEAL|h|cff82f4ffChain Heal|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff12599|r.(13010 Overhealed) (Critical)",
							["amount"] = 25609,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWaveGreater",
					},
					["Healing Surge"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:28:31|r\n|Hunit:0x0300000006F569CF:Møngôôse-Frostmourne|hMøngôôse-Frostmourne's|h |Hspell:8004:SPELL_HEAL|h|cff82f4ffHealing Surge|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff26994|r.",
							["amount"] = 26994,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:23:01|r\n|Hunit:0x0300000006F569CF:Møngôôse-Frostmourne|hMøngôôse-Frostmourne's|h |Hspell:8004:SPELL_HEAL|h|cff82f4ffHealing Surge|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff38288|r.(Critical)",
							["amount"] = 38288,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWay",
					},
					["Rejuvenation"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 02:03:50|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak|h gains |cff82f4ff5150|r Health from |Hunit:0x028000000223D51E:Jinjan-Ragnaros|hJinjan-Ragnaros's|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cff82f4ffRejuvenation|r|h.",
							["amount"] = 5150,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:44:49|r\n|Hunit:0x0100000004DE83EE:Felzak|hFelzak|h gains |cff82f4ff9327|r Health from |Hunit:0x0200000005EF28A2:Mooraa-Trollbane|hMooraa-Trollbane's|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cff82f4ffRejuvenation|r|h.(Critical)",
							["amount"] = 9327,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Rejuvenation",
					},
					["Regrowth"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:55:11|r\n|Hunit:0x028000000223D51E:Jinjan-Ragnaros|hJinjan-Ragnaros's|h |Hspell:8936:SPELL_HEAL|h|cff82f4ffRegrowth|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff11295|r.",
							["amount"] = 11295,
						},
						[2] = {
							["time"] = "|cffffffff06/23/12 01:55:03|r\n|Hunit:0x028000000223D51E:Jinjan-Ragnaros|hJinjan-Ragnaros's|h |Hspell:8936:SPELL_HEAL|h|cff82f4ffRegrowth|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff29907|r.(Critical)",
							["amount"] = 29907,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_ResistNature",
					},
					["Tranquility"] = {
						[-2] = {
							["time"] = "|cffffffff06/23/12 01:55:25|r\n|Hunit:0x028000000223D51E:Jinjan-Ragnaros|hJinjan-Ragnaros's|h |Hspell:44203:SPELL_HEAL|h|cff82f4ffTranquility|r|h heals |Hunit:0x0100000004DE83EE:Felzak|hFelzak|h for |cff82f4ff9615|r.(3600 Overhealed)",
							["amount"] = 13215,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Tranquility",
					},
				},
			},
		},
	},
}
