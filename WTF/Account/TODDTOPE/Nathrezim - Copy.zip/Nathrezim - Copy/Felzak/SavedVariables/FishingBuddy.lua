
FishingBuddy_Player = {
	["Settings"] = {
		["ResetWatcher"] = 1,
	},
	["Outfit"] = {
	},
	["WasWearing"] = {
	},
}
