
WatchOutDB = {
	["height"] = 35,
	["isLocked"] = false,
	["barWidth"] = 240,
	["width"] = 35,
}
