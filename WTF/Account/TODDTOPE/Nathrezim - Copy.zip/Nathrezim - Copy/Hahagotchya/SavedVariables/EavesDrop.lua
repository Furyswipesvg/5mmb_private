
EavesDropStatsDB = {
	["profileKeys"] = {
		["Hahagotchya - Nathrezim"] = "Hahagotchya - Nathrezim",
	},
	["profiles"] = {
		["Hahagotchya - Nathrezim"] = {
		},
	},
}
