
REFDatabase = {
}
REFSettings = {
	["ArenaSupport"] = true,
	["MiniBarScale"] = 1,
	["MiniBarAnchor"] = "CENTER",
	["OnlyNew"] = false,
	["LastDay"] = "02",
	["LastDayStats"] = {
		["MMR"] = 0,
		["Honor"] = 2,
		["RBG"] = 0,
		["MMRBG"] = 0,
		["5v5"] = 0,
		["CP"] = 0,
		["3v3"] = 0,
		["2v2"] = 0,
	},
	["RBGListFirstTime"] = true,
	["ShowMiniBar"] = false,
	["LDBBGMorph"] = true,
	["UNBGSupport"] = true,
	["LDBShowTotalBG"] = false,
	["RBGSupport"] = true,
	["LDBHK"] = false,
	["MinimapPos"] = 45,
	["MiniBarVisible"] = {
		{
			["HonorKills"] = 1,
			["KillingBlows"] = 1,
			["Healing"] = 2,
			["Damage"] = 2,
		}, -- [1]
		{
			["HonorKills"] = 1,
			["KillingBlows"] = 1,
			["Healing"] = 2,
			["Damage"] = 2,
		}, -- [2]
	},
	["AllowQuery"] = true,
	["ShowDetectedBuilds"] = true,
	["CurrentMMR"] = 0,
	["LDBCPCap"] = true,
	["CurrentMMRBG"] = 0,
	["LDBShowTotalArena"] = false,
	["MiniBarX"] = 0,
	["ArenasListFirstTime"] = true,
	["ShowMinimapButton"] = true,
	["LDBShowQueues"] = true,
	["Version"] = 19,
	["LDBShowPlace"] = false,
	["MiniBarY"] = 0,
	["MiniBarOrder"] = {
		{
			"KillingBlows", -- [1]
			"HonorKills", -- [2]
			"Damage", -- [3]
			"Healing", -- [4]
			"Deaths", -- [5]
			"KDRatio", -- [6]
			"Honor", -- [7]
		}, -- [1]
		{
			"KillingBlows", -- [1]
			"HonorKills", -- [2]
			"Damage", -- [3]
			"Healing", -- [4]
			"Deaths", -- [5]
			"KDRatio", -- [6]
			"Honor", -- [7]
		}, -- [2]
	},
}
REFDatabaseA = {
}
