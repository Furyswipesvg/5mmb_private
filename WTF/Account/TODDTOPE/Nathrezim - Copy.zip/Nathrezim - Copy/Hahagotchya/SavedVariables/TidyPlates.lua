
TidyPlatesOptions = {
	["_EnableMiniButton"] = false,
	["WelcomeShown"] = true,
	["EnableMinimapButton"] = false,
	["FriendlyAutomation"] = "No Automation",
	["EnemyAutomation"] = "No Automation",
	["primary"] = "Neon/|cFFFF4400Damage",
	["EnableCastWatcher"] = false,
	["secondary"] = "Neon/|cFF3782D1Tank",
}
