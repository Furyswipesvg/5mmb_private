
EavesDropStatsDB = {
	["profileKeys"] = {
		["Marinda - Nathrezim"] = "Marinda - Nathrezim",
	},
	["profiles"] = {
		["Marinda - Nathrezim"] = {
		},
	},
}
