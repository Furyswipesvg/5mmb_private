
Prat3HighCPUPerCharDB = {
	["time"] = 1360823552,
	["scrollback"] = {
		["ChatFrame1"] = {
			{
				"|cff979797[22:32:32]|r|c00000000|r |Hchannel:channel:1|h[1] |h Joined Channel: |Hchannel:1|h[1. General - Orgrimmar]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				69, -- [5]
			}, -- [1]
			{
				"|cff979797[22:32:32]|r|c00000000|r |Hchannel:channel:2|h[2] |h Joined Channel: |Hchannel:2|h[2. Trade - City]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				70, -- [5]
			}, -- [2]
			{
				"|cff979797[22:32:32]|r|c00000000|r |Hchannel:channel:3|h[3] |h Joined Channel: |Hchannel:3|h[3. LocalDefense - Orgrimmar]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				71, -- [5]
			}, -- [3]
		},
	},
}
