
SpellReminderDBPerChar = {
	["profileKeys"] = {
		["Marinda - Nathrezim"] = "Default",
	},
}
