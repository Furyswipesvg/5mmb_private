
EavesDropStatsDB = {
	["profileKeys"] = {
		["Mootalia - Nathrezim"] = "Mootalia - Nathrezim",
	},
	["profiles"] = {
		["Mootalia - Nathrezim"] = {
			{
				["heal"] = {
					["Healthstone"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 02:41:01|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:6262:SPELL_HEAL|h|cffffffffHealthstone|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffffffff60734|r |cffffffffPhysical|r. ",
							["amount"] = 60734,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\warlock_ healthstone",
					},
					["Healing Potion"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 03:59:09|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:105708:SPELL_HEAL|h|cffffffffHealing Potion|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffffffff120000|r |cffffffffPhysical|r. ",
							["amount"] = 120000,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\trade_alchemy_potiond3",
					},
					["Blood Craze"] = {
						[-2] = {
							["time"] = "|cffffffff06/20/12 05:53:36|r\n|Hunit:0x0100000000268382:Mootalia|hMootalia|h gains |cffffffff24|r Health from |Hunit:0x0100000000268382:Mootalia|hMootalia's|h |Hspell:16490:SPELL_PERIODIC_HEAL|h|cffffffffBlood Craze|r|h.(723 Overhealed)",
							["amount"] = 747,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_SummonImp",
					},
					["Bloodthirst Heal"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 12:16:22|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:117313:SPELL_HEAL|h|cffffffffBloodthirst Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffffffff5163|r |cffffffffPhysical|r. ",
							["amount"] = 5163,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_BloodLust",
					},
					["Hozenbane"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 04:41:04|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:122373:SPELL_HEAL|h|cffffffffHozenbane|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffffffff0|r |cffffffffPhysical|r. (19373 Overhealed) ",
							["amount"] = 19373,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 04:39:29|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:122373:SPELL_HEAL|h|cffffffffHozenbane|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffffffff39909|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 39909,
						},
						["icon"] = "Interface\\Icons\\Achievement_BG_kill_flag_carrierEOS",
					},
					["Second Wind"] = {
						[-2] = {
							["time"] = "|cffffffff01/05/13 09:41:19|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:16491:SPELL_PERIODIC_HEAL|h|cffffffffSecond Wind|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffffffff14926|r |cffffffffPhysical|r. ",
							["amount"] = 14926,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Hunter_Harass",
					},
					["Victory Rush"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 11:33:03|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:118779:SPELL_HEAL|h|cffffffffVictory Rush|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffffffff174874|r |cffffffffPhysical|r. ",
							["amount"] = 174874,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\spell_impending_victory",
					},
					["First Aid"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 03:59:50|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:102695:SPELL_PERIODIC_HEAL|h|cffffffffFirst Aid|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffffffff19238|r |cffffffffPhysical|r. ",
							["amount"] = 19238,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Heal",
					},
					["Magnetic Shroud Overload"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 03:32:15|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:107174:SPELL_HEAL|h|cffffffffMagnetic Shroud Overload|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x03000000039AB973:Laydgaga-Proudmoore|hLaydgaga-Proudmoore|h |cffffffff21562|r |cffffffffPhysical|r. ",
							["amount"] = 21562,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Trade_Engineering",
					},
				},
				["hit"] = {
					["Shockwave"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 04:42:18|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:46968:SPELL_DAMAGE|h|cffffffffShockwave|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150F40100005C1C:Captain Ook|hCaptain Ook|h |cffffffff85646|r |cffffffffPhysical|r. ",
							["amount"] = 85646,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 02:22:43|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:46968:SPELL_DAMAGE|h|cffffffffShockwave|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13083DB00022E26:Dark Rune Ravager|hDark Rune Ravager|h |cffffffff214623|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 214623,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_Shockwave",
					},
					["Cleave"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 11:32:59|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:845:SPELL_DAMAGE|h|cffffffffCleave|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E3CF00014E37:Lesser Sha|hLesser Sha|h |cffffffff19777|r |cffffffffPhysical|r. ",
							["amount"] = 19777,
						},
						[2] = {
							["time"] = "|cffffffff01/19/13 11:33:11|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:845:SPELL_DAMAGE|h|cffffffffCleave|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130E3CF00014E37:Lesser Sha|hLesser Sha|h |cffffffff45064|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 45064,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_Cleave",
					},
					["Execute"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 04:59:14|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:5308:SPELL_DAMAGE|h|cffffffffExecute|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F8CD00A7A8E4:Sra'thik Swarmlord|hSra'thik Swarmlord|h |cffffffff336172|r |cffffffffPhysical|r. ",
							["amount"] = 336172,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 04:00:07|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:5308:SPELL_DAMAGE|h|cffffffffExecute|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130DD8F000283D7:Sha of Violence|hSha of Violence|h |cffffffff631689|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 631689,
						},
						["icon"] = "Interface\\Icons\\INV_Sword_48",
					},
					["Whirlwind"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 04:46:53|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:1680:SPELL_DAMAGE|h|cffffffffWhirlwind|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F8C000A781E3:Sra'thik Cacophyte|hSra'thik Cacophyte|h |cffffffff29328|r |cffffffffPhysical|r. ",
							["amount"] = 29328,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 03:57:29|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:1680:SPELL_DAMAGE|h|cffffffffWhirlwind|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130DDBD000283D9:Destroying Sha|hDestroying Sha|h |cffffffff73233|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 73233,
						},
						["icon"] = "Interface\\Icons\\Ability_Whirlwind",
					},
					["Malady of the Mind"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 03:06:36|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:63881:SPELL_DAMAGE|h|cffffffffMalady of the Mind|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x050000000571E20A:Muji-Mal'Ganis|hMuji-Mal'Ganis|h |cffffffff5000|r |cffffffffShadow|r. ",
							["amount"] = 5000,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_DeathCoil",
					},
					["Bloodbath"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 12:16:10|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:113344:SPELL_PERIODIC_DAMAGE|h|cffffffffBloodbath|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF1308DC80000184A:Apothecary Hummel|hApothecary Hummel|h |cffffffff14169|r |cffffffffPhysical|r. ",
							["amount"] = 14169,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_BloodBath",
					},
					["Mortal Strike"] = {
						[-2] = {
							["time"] = "|cffffffff06/20/12 06:25:14|r\n|Hunit:0x0100000000268382:Mootalia|hMootalia's|h |Hspell:12294:SPELL_DAMAGE|h|cffffffffMortal Strike|r|h hits |Hunit:0xF3301EB200013A33:Southsea Swashbuckler|hSouthsea Swashbuckler|h for |cffffffff1568|r |cffffffffPhysical|r.(19759 Overkill)",
							["amount"] = 21327,
						},
						[2] = {
							["time"] = "|cffffffff06/20/12 06:13:42|r\n|Hunit:0x0100000000268382:Mootalia|hMootalia's|h |Hspell:12294:SPELL_DAMAGE|h|cffffffffMortal Strike|r|h hits |Hunit:0xF3301EAF00013531:Southsea Pirate|hSouthsea Pirate|h for |cffffffff1556|r |cffffffffPhysical|r.(41659 Overkill) (Critical)",
							["amount"] = 43215,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_SavageBlow",
					},
					["Thunder Clap"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 11:33:20|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:6343:SPELL_DAMAGE|h|cffffffffThunder Clap|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130DF1500014E43:Minion of Doubt|hMinion of Doubt|h |cffffffff27371|r |cffffffffPhysical|r. ",
							["amount"] = 27371,
						},
						[2] = {
							["time"] = "|cffffffff01/19/13 11:33:12|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:6343:SPELL_DAMAGE|h|cffffffffThunder Clap|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130DF1500014E3A:Minion of Doubt|hMinion of Doubt|h |cffffffff52058|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 52058,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_ThunderClap",
					},
					["Scurvy"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 04:39:06|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:121914:SPELL_DAMAGE|h|cffffffffScurvy|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffffffff41486|r |cffffffffNature|r. ",
							["amount"] = 41486,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\inv_misc_food_41",
					},
					["Heroic Strike"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 02:25:48|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:78:SPELL_DAMAGE|h|cffffffffHeroic Strike|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1308061000231A3:Thorim|hThorim|h |cffffffff40565|r |cffffffffPhysical|r. ",
							["amount"] = 40565,
						},
						[2] = {
							["time"] = "|cffffffff02/13/13 10:24:44|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:78:SPELL_DAMAGE|h|cffffffffHeroic Strike|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130CAA7001CF928:Station Guard|hStation Guard|h |cffffffff58725|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 58725,
						},
						["icon"] = "Interface\\Icons\\Ability_Rogue_Ambush",
					},
					["Raging Blow Off-Hand"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 04:59:11|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:85384:SPELL_DAMAGE|h|cffffffffRaging Blow Off-Hand|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F8CD00A7A8E4:Sra'thik Swarmlord|hSra'thik Swarmlord|h |cffffffff68270|r |cffffffffPhysical|r. ",
							["amount"] = 68270,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 02:21:26|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:85384:SPELL_DAMAGE|h|cffffffffRaging Blow Off-Hand|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130804D00022DBA:Hodir|hHodir|h |cffffffff216802|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 216802,
						},
						["icon"] = "Interface\\Icons\\warrior_wild_strike",
					},
					["Raging Blow"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 04:48:07|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:96103:SPELL_DAMAGE|h|cffffffffRaging Blow|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F8C400A6CAD3:Sra'thik Will-Breaker|hSra'thik Will-Breaker|h |cffffffff100409|r |cffffffffPhysical|r. ",
							["amount"] = 100409,
						},
						[2] = {
							["time"] = "|cffffffff01/05/13 09:41:03|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:96103:SPELL_DAMAGE|h|cffffffffRaging Blow|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF131085E000435ED:Dark Summoner|hDark Summoner|h |cffffffff190214|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 190214,
						},
						["icon"] = "Interface\\Icons\\warrior_wild_strike",
					},
					["Whirlwind Off-Hand"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 04:45:20|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:44949:SPELL_DAMAGE|h|cffffffffWhirlwind Off-Hand|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F8C000A776E3:Sra'thik Cacophyte|hSra'thik Cacophyte|h |cffffffff29681|r |cffffffffPhysical|r. ",
							["amount"] = 29681,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 03:57:29|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:44949:SPELL_DAMAGE|h|cffffffffWhirlwind Off-Hand|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130DDBD000283DA:Destroying Sha|hDestroying Sha|h |cffffffff69561|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 69561,
						},
						["icon"] = "Interface\\Icons\\Ability_Whirlwind",
					},
					["Brain Link"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 03:06:25|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:63803:SPELL_DAMAGE|h|cffffffffBrain Link|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x050000000571E20A:Muji-Mal'Ganis|hMuji-Mal'Ganis|h |cffffffff3000|r |cffffffffShadow|r. ",
							["amount"] = 3000,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_MentalQuickness",
					},
					["Voodoo Dolls"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:14:09|r\n|Hicon:64:source|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:116000:SPELL_DAMAGE|h|cffffffffVoodoo Dolls|r|h |Haction:SPELL_DAMAGE|hhit|h |Hicon:32:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_6.blp:0|t|h|Hunit:0x0380000005439C0C:Bushmedicine-Jubei'Thos|hBushmedicine-Jubei'Thos|h |cffffffff89349|r |cffffffffShadow|r. ",
							["amount"] = 89349,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\trade_archaeology_troll_voodoodoll",
					},
					["Victory Rush"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 04:47:18|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:34428:SPELL_DAMAGE|h|cffffffffVictory Rush|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F8C100A78641:Sra'thik Regenerator|hSra'thik Regenerator|h |cffffffff46159|r |cffffffffPhysical|r. ",
							["amount"] = 46159,
						},
						[2] = {
							["time"] = "|cffffffff01/05/13 09:41:05|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:34428:SPELL_DAMAGE|h|cffffffffVictory Rush|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF131085E000435ED:Dark Summoner|hDark Summoner|h |cffffffff173089|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 173089,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_Devastate",
					},
					["Wild Strike"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 04:48:10|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:100130:SPELL_DAMAGE|h|cffffffffWild Strike|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F8C400A6CAD3:Sra'thik Will-Breaker|hSra'thik Will-Breaker|h |cffffffff34198|r |cffffffffPhysical|r. (36467 Overkill) ",
							["amount"] = 70665,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 02:20:57|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:100130:SPELL_DAMAGE|h|cffffffffWild Strike|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130804D00022DBA:Hodir|hHodir|h |cffffffff198011|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 198011,
						},
						["icon"] = "Interface\\Icons\\spell_warrior_wildstrike",
					},
					["Stormlash"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 03:07:28|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:120687:SPELL_DAMAGE|h|cffffffffStormlash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13084620002CEB3:Brain of Yogg-Saron|hBrain of Yogg-Saron|h |cffffffff9691|r |cffffffffNature|r. ",
							["amount"] = 9691,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 03:07:25|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:120687:SPELL_DAMAGE|h|cffffffffStormlash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF13084620002CEB3:Brain of Yogg-Saron|hBrain of Yogg-Saron|h |cffffffff5518|r |cffffffffNature|r. (Critical) ",
							["amount"] = 5518,
						},
						["icon"] = "Interface\\Icons\\Spell_Lightning_LightningBolt01",
					},
					["Shattering Throw"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 02:37:58|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:64382:SPELL_DAMAGE|h|cffffffffShattering Throw|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF15083860002BF28:Aerial Command Unit|hAerial Command Unit|h |cffffffff18682|r |cffffffffPhysical|r. ",
							["amount"] = 18682,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 05:38:52|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:64382:SPELL_DAMAGE|h|cffffffffShattering Throw|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF5310ADE0084DDBD:Dalan Nightbreaker|hDalan Nightbreaker|h |cffffffff34775|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 34775,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_ShatteringThrow",
					},
					["Shield Slam"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:14:40|r\n|Hicon:64:source|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:23922:SPELL_DAMAGE|h|cffffffffShield Slam|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150EAEF00000046:Gara'jal the Spiritbinder|hGara'jal the Spiritbinder|h |cffffffff109452|r |cffffffffPhysical|r. ",
							["amount"] = 109452,
						},
						[2] = {
							["time"] = "|cffffffff01/08/13 11:14:21|r\n|Hicon:64:source|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:23922:SPELL_DAMAGE|h|cffffffffShield Slam|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150EAEF00000046:Gara'jal the Spiritbinder|hGara'jal the Spiritbinder|h |cffffffff205230|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 205230,
						},
						["icon"] = "Interface\\Icons\\INV_Shield_05",
					},
					["Colossus Smash"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 04:47:20|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:86346:SPELL_DAMAGE|h|cffffffffColossus Smash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130F8C100A78641:Sra'thik Regenerator|hSra'thik Regenerator|h |cffffffff64540|r |cffffffffPhysical|r. ",
							["amount"] = 64540,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 02:21:24|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:86346:SPELL_DAMAGE|h|cffffffffColossus Smash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130804D00022DBA:Hodir|hHodir|h |cffffffff130970|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 130970,
						},
						["icon"] = "INTERFACE\\ICONS\\ability_warrior_colossussmash",
					},
					["Bloodthirst"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 03:32:47|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:23881:SPELL_DAMAGE|h|cffffffffBloodthirst|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130DDAB000248BA:Gu Cloudstrike|hGu Cloudstrike|h |cffffffff47163|r |cffffffffPhysical|r. ",
							["amount"] = 47163,
						},
						[2] = {
							["time"] = "|cffffffff01/03/13 10:48:05|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:23881:SPELL_DAMAGE|h|cffffffffBloodthirst|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF131085E00038E08:Dark Summoner|hDark Summoner|h |cffffffff98829|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 98829,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_BloodLust",
					},
					["Dragon Roar"] = {
						[-2] = {
						},
						[2] = {
							["time"] = "|cffffffff02/10/13 12:16:04|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:118000:SPELL_DAMAGE|h|cffffffffDragon Roar|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF1308DC80000184A:Apothecary Hummel|hApothecary Hummel|h |cffffffff237300|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 237300,
						},
						["icon"] = "Interface\\Icons\\ability_warrior_dragonroar",
					},
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 04:59:09|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF130F8CD00A7A8E4:Sra'thik Swarmlord|hSra'thik Swarmlord|h |cffffffff58410|r |cffffffffPhysical|r. ",
							["amount"] = 58410,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 02:21:26|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF130804D00022DBA:Hodir|hHodir|h |cffffffff147495|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 147495,
						},
					},
					["Revenge"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:14:19|r\n|Hicon:64:source|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:6572:SPELL_DAMAGE|h|cffffffffRevenge|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150EAEF00000046:Gara'jal the Spiritbinder|hGara'jal the Spiritbinder|h |cffffffff52503|r |cffffffffPhysical|r. ",
							["amount"] = 52503,
						},
						[2] = {
							["time"] = "|cffffffff01/08/13 11:14:39|r\n|Hicon:64:source|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:6572:SPELL_DAMAGE|h|cffffffffRevenge|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150EAEF00000046:Gara'jal the Spiritbinder|hGara'jal the Spiritbinder|h |cffffffff141309|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 141309,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_Revenge",
					},
					["Deep Wounds"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 04:57:46|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:115767:SPELL_PERIODIC_DAMAGE|h|cffffffffDeep Wounds|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF130F8BE00A7B795:Sra'thik Mutilator|hSra'thik Mutilator|h |cffffffff23502|r |cffffffffPhysical|r. ",
							["amount"] = 23502,
						},
						[2] = {
							["time"] = "|cffffffff01/05/13 09:41:15|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:115767:SPELL_PERIODIC_DAMAGE|h|cffffffffDeep Wounds|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0xF131085E000435ED:Dark Summoner|hDark Summoner|h |cffffffff44733|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 44733,
						},
						["icon"] = "Interface\\Icons\\Ability_BackStab",
					},
					["Heroic Leap"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 03:49:10|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:52174:SPELL_DAMAGE|h|cffffffffHeroic Leap|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF131037900004807:Sha Haunt|hSha Haunt|h |cffffffff40666|r |cffffffffPhysical|r. (8179 Overkill) ",
							["amount"] = 48845,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 03:51:42|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:52174:SPELL_DAMAGE|h|cffffffffHeroic Leap|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF5310379001EE2D5:Sha Haunt|hSha Haunt|h |cffffffff40666|r |cffffffffPhysical|r. (37400 Overkill) (Critical) ",
							["amount"] = 78066,
						},
						["icon"] = "Interface\\Icons\\Ability_HeroicLeap",
					},
					["Devastate"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:14:38|r\n|Hicon:64:source|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:20243:SPELL_DAMAGE|h|cffffffffDevastate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF150EAEF00000046:Gara'jal the Spiritbinder|hGara'jal the Spiritbinder|h |cffffffff47755|r |cffffffffPhysical|r. ",
							["amount"] = 47755,
						},
						[2] = {
							["time"] = "|cffffffff01/19/13 11:33:10|r\n|Hunit:0x0100000000268382:Mootalia|hYour|h |Hspell:20243:SPELL_DAMAGE|h|cffffffffDevastate|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130DF1500014E3A:Minion of Doubt|hMinion of Doubt|h |cffffffff80583|r |cffffffffPhysical|r. (Critical) ",
							["amount"] = 80583,
						},
						["icon"] = "Interface\\Icons\\INV_Sword_11",
					},
					["Heroic Throw"] = {
						[-2] = {
							["time"] = "|cffffffff06/20/12 06:34:19|r\n|Hunit:0x0100000000268382:Mootalia|hMootalia's|h |Hspell:57755:SPELL_DAMAGE|h|cffffffffHeroic Throw|r|h hits |Hunit:0xF3301EB200013E80:Southsea Swashbuckler|hSouthsea Swashbuckler|h for |cffffffff1661|r |cffffffffPhysical|r.(12490 Overkill)",
							["amount"] = 14151,
						},
						[2] = {
							["time"] = "|cffffffff06/20/12 05:54:36|r\n|Hunit:0x0100000000268382:Mootalia|hMootalia's|h |Hspell:57755:SPELL_DAMAGE|h|cffffffffHeroic Throw|r|h hits |Hunit:0xF33096F600012C9F:Covert Ops Hardsuit|hCovert Ops Hardsuit|h for |cffffffff1848|r |cffffffffPhysical|r.(24770 Overkill) (Critical)",
							["amount"] = 26618,
						},
						["icon"] = "Interface\\Icons\\INV_Axe_66",
					},
					["Rend"] = {
						[-2] = {
							["time"] = "|cffffffff06/20/12 06:24:17|r\n|Hunit:0xF3301EB2000139BB:Southsea Swashbuckler|hSouthsea Swashbuckler|h suffers |cffffffff1726|r |cffffffffPhysical|r damage from |Hunit:0x0100000000268382:Mootalia|hMootalia's|h |Hspell:94009:SPELL_PERIODIC_DAMAGE|h|cffffffffRend|r|h.(625 Overkill)",
							["amount"] = 2351,
						},
						[2] = {
							["time"] = "|cffffffff06/20/12 06:24:40|r\n|Hunit:0xF33096F600013A08:Covert Ops Hardsuit|hCovert Ops Hardsuit|h suffers |cffffffff1848|r |cffffffffPhysical|r damage from |Hunit:0x0100000000268382:Mootalia|hMootalia's|h |Hspell:94009:SPELL_PERIODIC_DAMAGE|h|cffffffffRend|r|h.(2580 Overkill) (Critical)",
							["amount"] = 4428,
						},
						["icon"] = "Interface\\Icons\\Ability_Gouge",
					},
				},
			}, -- [1]
			[-1] = {
				["hit"] = {
					["Physical"] = {
						[-2] = {
							["time"] = "|cffffffff01/03/13 10:48:10|r\n|Hunit:0xF131085000038E0D:Tormented Ghost|hTormented Ghost|h |Haction:SWING_DAMAGE|h|cffff1313Melee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffff1313163139|r |cffff1313Physical|r. (360785 Overkill) ",
							["amount"] = 523924,
						},
						[2] = {
							["time"] = "|cffffffff12/27/12 10:14:43|r\n|Hunit:0xF130F1F90000AFD1:Gurthan Iron Maw|hGurthan Iron Maw|h |Haction:SWING_DAMAGE|h|cffff1313Melee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffff1313135730|r |cffff1313Physical|r. (Critical) ",
							["amount"] = 135730,
						},
					},
					["Shadow"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:14:09|r\n|Hunit:0xF150EAEF00000046:Gara'jal the Spiritbinder|hGara'jal the Spiritbinder|h |Hspell:117215:SPELL_DAMAGE|h|cffff1313Right Cross|r|h |Haction:SPELL_DAMAGE|hhit|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYou|h |cffff1313148915|r |cffff1313Shadow|r. ",
							["amount"] = 148915,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 03:09:30|r\n|Hunit:0x0680000004FDAC78:Florencia-Garrosh|hFlorencia-Garrosh|h |Hspell:2944:SPELL_DAMAGE|h|cffff1313Devouring Plague|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffff131397098|r |cffff1313Shadow|r. (Critical) ",
							["amount"] = 97098,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FistOfJustice",
					},
					["Frost"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 11:31:12|r\n|Hunit:0xF130DC8000014E2B:Wise Mari|hWise Mari|h |Hspell:106334:SPELL_DAMAGE|h|cffff1313Wash Away|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffff1313107972|r |cffff1313Frost|r. ",
							["amount"] = 107972,
						},
						[2] = {
							["time"] = "|cffffffff01/01/13 04:37:25|r\n|Hunit:0x05800000082BC68D:Shabibi-Kel'Thuzad|hShabibi-Kel'Thuzad|h |Hspell:113092:SPELL_DAMAGE|h|cffff1313Frost Bomb|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffff131392842|r |cffff1313Frost|r. (Critical) ",
							["amount"] = 92842,
						},
						["icon"] = "Interface\\Icons\\Spell_Frost_SummonWaterElemental",
					},
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 02:30:59|r\n|Hunit:0x018000000491247F:Poltyrgeist-Darkspear|hPoltyrgeist-Darkspear|h |Hspell:73510:SPELL_DAMAGE|h|cffff1313Mind Spike|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffff131328370|r |cffff1313Shadowfrost|r. ",
							["amount"] = 28370,
						},
						[2] = {
							["time"] = "|cffffffff01/01/13 04:43:48|r\n|Hunit:0x038000000107A3F2:Artvandelay-Draka|hArtvandelay-Draka|h |Hspell:44614:SPELL_DAMAGE|h|cffff1313Frostfire Bolt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffff131355955|r |cffff1313Frostfire|r. (Critical) ",
							["amount"] = 55955,
						},
						["icon"] = "Interface\\Icons\\Ability_Mage_FrostFireBolt",
					},
					["Holy"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 05:45:36|r\n|Hunit:0xF5310ADF0084E5A3:Disha Fearwarden|hDisha Fearwarden|h |Hspell:134768:SPELL_DAMAGE|h|cffff1313Wrath of the Light|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffff1313187416|r |cffff1313Holy|r. (40863 Overkill) ",
							["amount"] = 228279,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 07:12:07|r\n|Hunit:0x068000000529BB78:Vaslor-Hydraxis|hVaslor-Hydraxis|h |Hspell:24275:SPELL_DAMAGE|h|cffff1313Hammer of Wrath|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffff131339309|r |cffff1313Holy|r. (29271 Overkill) (Critical) ",
							["amount"] = 68580,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolyProtection",
					},
					["Fire"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 03:40:30|r\n|Hspell:106470:SPELL_DAMAGE|h|cffff1313Ball of Fire|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffff131387696|r |cffff1313Fire|r. ",
							["amount"] = 87696,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 07:07:21|r\n|Hunit:0x020000000128DA43:Crillian-Stormrage|hCrillian-Stormrage|h |Hspell:11366:SPELL_DAMAGE|h|cffff1313Pyroblast|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffff131394404|r |cffff1313Fire|r. (Critical) ",
							["amount"] = 94404,
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_BluePyroblast",
					},
					["Arcane"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 02:45:28|r\n|Hunit:0x03800000056FE00F:Shain-Saurfang|hShain-Saurfang|h |Hspell:3044:SPELL_DAMAGE|h|cffff1313Arcane Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffff131321984|r |cffff1313Arcane|r. ",
							["amount"] = 21984,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 02:45:21|r\n|Hunit:0x03800000056FE00F:Shain-Saurfang|hShain-Saurfang|h |Hspell:3044:SPELL_DAMAGE|h|cffff1313Arcane Shot|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffff131348768|r |cffff1313Arcane|r. (Critical) ",
							["amount"] = 48768,
						},
						["icon"] = "Interface\\Icons\\Ability_ImpalingBolt",
					},
					["Nature"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 02:36:00|r\n|Hunit:0xF150829800022E83:Leviathan Mk II|hLeviathan Mk II|h |Hspell:63631:SPELL_DAMAGE|h|cffff1313Shock Blast|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffff131399000|r |cffff1313Nature|r. ",
							["amount"] = 99000,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 02:38:45|r\n|Hunit:0x048000000426473E:Stormylove-Sargeras|hStormylove-Sargeras|h |Hspell:45284:SPELL_DAMAGE|h|cffff1313Lightning Bolt|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cffff131315653|r |cffff1313Nature|r. (12240 Overkill) (Critical) ",
							["amount"] = 27893,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_GroundingTotem",
					},
				},
				["heal"] = {
					["Daybreak"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 02:55:31|r\n|Hunit:0x0600000003787746:Brutalhealer-Hyjal|hBrutalhealer-Hyjal|h |Hspell:121129:SPELL_HEAL|h|cff82f4ffDaybreak|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff9755|r |cff82f4ffPhysical|r. ",
							["amount"] = 9755,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_QirajIdol_Sun",
					},
					["Swiftmend"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 11:34:33|r\n|Hunit:0x0100000004ED47D3:Natronn|hNatronn|h |Hspell:18562:SPELL_HEAL|h|cff82f4ffSwiftmend|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff23117|r |cff82f4ffNature|r. (38721 Overhealed) ",
							["amount"] = 61838,
						},
						[2] = {
							["time"] = "|cffffffff01/19/13 11:35:03|r\n|Hunit:0x0100000004ED47D3:Natronn|hNatronn|h |Hspell:18562:SPELL_HEAL|h|cff82f4ffSwiftmend|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff940|r |cff82f4ffNature|r. (120705 Overhealed) (Critical) ",
							["amount"] = 121645,
						},
						["icon"] = "Interface\\Icons\\INV_Relics_IdolofRejuvenation",
					},
					["Healing Surge"] = {
						[-2] = {
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 07:04:03|r\n|Hunit:0x0180000004C98F0B:Tuggles-Darkspear|hTuggles-Darkspear|h |Hspell:8004:SPELL_HEAL|h|cff82f4ffHealing Surge|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff123670|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 123670,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWay",
					},
					["Glyph of Power Word: Shield"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 04:12:41|r\n|Hunit:0x0100000003C4594F:Youjizz-Bonechewer|hYoujizz-Bonechewer|h |Hspell:56160:SPELL_HEAL|h|cff82f4ffGlyph of Power Word: Shield|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff17617|r |cff82f4ffHoly|r. ",
							["amount"] = 17617,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Prayer of Mending"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:14:33|r\n|Hunit:0x03000000074C5D45:Shaack-Frostmourne|hShaack-Frostmourne|h |Hspell:33110:SPELL_HEAL|h|cff82f4ffPrayer of Mending|r|h |Haction:SPELL_HEAL|hhealed|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff44689|r |cff82f4ffHoly|r. (13178 Overhealed) ",
							["amount"] = 57867,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 02:04:07|r\n|Hunit:0x05000000057BA988:Tangi-Mal'Ganis|hTangi-Mal'Ganis|h |Hspell:33110:SPELL_HEAL|h|cff82f4ffPrayer of Mending|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff55622|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 55622,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfMendingtga",
					},
					["Circle of Healing"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 02:16:18|r\n|Hunit:0x05000000057BA988:Tangi-Mal'Ganis|hTangi-Mal'Ganis|h |Hspell:34861:SPELL_HEAL|h|cff82f4ffCircle of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff18906|r |cff82f4ffHoly|r. ",
							["amount"] = 18906,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 02:03:46|r\n|Hunit:0x05000000057BA988:Tangi-Mal'Ganis|hTangi-Mal'Ganis|h |Hspell:34861:SPELL_HEAL|h|cff82f4ffCircle of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff36071|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 36071,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_CircleOfRenewal",
					},
					["Chi Wave"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 12:16:30|r\n|Hunit:0x030000000775E7BF:Honchoi-Dreadmaul|hHonchoi-Dreadmaul|h |Hspell:132463:SPELL_HEAL|h|cff82f4ffChi Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff12995|r |cff82f4ffNature|r. ",
							["amount"] = 12995,
						},
						[2] = {
							["time"] = "|cffffffff02/10/13 12:16:31|r\n|Hunit:0x030000000775E7BF:Honchoi-Dreadmaul|hHonchoi-Dreadmaul|h |Hspell:132463:SPELL_HEAL|h|cff82f4ffChi Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff26162|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 26162,
						},
						["icon"] = "Interface\\Icons\\ability_monk_chiwave",
					},
					["Holy Light"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:13:49|r\n|Hunit:0x030000000768DD32:Killoclock-Frostmourne|hKilloclock-Frostmourne|h |Hspell:635:SPELL_HEAL|h|cff82f4ffHoly Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (26150 Overhealed) ",
							["amount"] = 26150,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_HolyBolt",
					},
					["Chain Heal"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 07:04:29|r\n|Hunit:0x0180000004C98F0B:Tuggles-Darkspear|hTuggles-Darkspear|h |Hspell:1064:SPELL_HEAL|h|cff82f4ffChain Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff16477|r |cff82f4ffNature|r. ",
							["amount"] = 16477,
						},
						[2] = {
							["time"] = "|cffffffff01/01/13 11:14:32|r\n|Hunit:0x0100000002992D67:Musicman|hMusicman|h |Hspell:1064:SPELL_HEAL|h|cff82f4ffChain Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff37684|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 37684,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingWaveGreater",
					},
					["Holy Word: Serenity"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 03:37:25|r\n|Hunit:0x03000000039AB973:Laydgaga-Proudmoore|hLaydgaga-Proudmoore|h |Hspell:88684:SPELL_HEAL|h|cff82f4ffHoly Word: Serenity|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff49964|r |cff82f4ffHoly|r. ",
							["amount"] = 49964,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\spell_holy_persuitofjustice",
					},
					["Beacon of Light"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:13:58|r\n|Hunit:0x030000000380062E:Paladumb-Nagrand|hPaladumb-Nagrand|h |Hspell:53652:SPELL_HEAL|h|cff82f4ffBeacon of Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff30742|r |cff82f4ffHoly|r. ",
							["amount"] = 30742,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Paladin_BeaconofLight",
					},
					["Echo of Light"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:14:39|r\n|Hunit:0x03000000074C5D45:Shaack-Frostmourne|hShaack-Frostmourne|h |Hspell:77489:SPELL_PERIODIC_HEAL|h|cff82f4ffEcho of Light|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff7436|r |cff82f4ffHoly|r. ",
							["amount"] = 7436,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Aspiration",
					},
					["Nature's Vigil"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:14:13|r\n|Hunit:0x03000000078067F5:Lipsmaka-Frostmourne|hLipsmaka-Frostmourne|h |Hspell:124988:SPELL_HEAL|h|cff82f4ffNature's Vigil|r|h |Haction:SPELL_HEAL|hhealed|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff19776|r |cff82f4ffNature|r. ",
							["amount"] = 19776,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Achievement_Zone_Feralas",
					},
					["Greater Heal"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:14:38|r\n|Hunit:0x03000000074C5D45:Shaack-Frostmourne|hShaack-Frostmourne|h |Hspell:2060:SPELL_HEAL|h|cff82f4ffGreater Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (90230 Overhealed) ",
							["amount"] = 90230,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 04:10:24|r\n|Hunit:0x0100000003C4594F:Youjizz-Bonechewer|hYoujizz-Bonechewer|h |Hspell:2060:SPELL_HEAL|h|cff82f4ffGreater Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff167992|r |cff82f4ffHoly|r. (16837 Overhealed) (Critical) ",
							["amount"] = 184829,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_GreaterHeal",
					},
					["Blood Burst"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:15:53|r\n|Hunit:0xF5306D7100B56C9C:Bloodworm|hBloodworm|h |Hspell:81280:SPELL_HEAL|h|cff82f4ffBlood Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff42521|r |cff82f4ffShadow|r. ",
							["amount"] = 42521,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 03:57:27|r\n|Hunit:0xF1306D7100028C3B:Bloodworm|hBloodworm|h |Hspell:81280:SPELL_HEAL|h|cff82f4ffBlood Burst|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff48467|r |cff82f4ffShadow|r. (Critical) ",
							["amount"] = 48467,
						},
						["icon"] = "Interface\\Icons\\Ability_Warrior_BloodNova",
					},
					["Flash Heal"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:14:31|r\n|Hunit:0x03000000074C5D45:Shaack-Frostmourne|hShaack-Frostmourne|h |Hspell:2061:SPELL_HEAL|h|cff82f4ffFlash Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (66799 Overhealed) ",
							["amount"] = 66799,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 04:02:42|r\n|Hunit:0x03000000039AB973:Laydgaga-Proudmoore|hLaydgaga-Proudmoore|h |Hspell:2061:SPELL_HEAL|h|cff82f4ffFlash Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff123113|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 123113,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Halo"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 02:02:07|r\n|Hunit:0x05000000057BA988:Tangi-Mal'Ganis|hTangi-Mal'Ganis|h |Hspell:120692:SPELL_HEAL|h|cff82f4ffHalo|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (122636 Overhealed) ",
							["amount"] = 122636,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 03:07:54|r\n|Hunit:0x05000000057BA988:Tangi-Mal'Ganis|hTangi-Mal'Ganis|h |Hspell:120692:SPELL_HEAL|h|cff82f4ffHalo|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff26004|r |cff82f4ffHoly|r. (27432 Overhealed) (Critical) ",
							["amount"] = 53436,
						},
						["icon"] = "Interface\\Icons\\ability_priest_halo",
					},
					["Rejuvenation"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:11:49|r\n|Hunit:0x01000000002707CA:Gurp|hGurp|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cff82f4ffRejuvenation|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff17408|r |cff82f4ffNature|r. (3178 Overhealed) ",
							["amount"] = 20586,
						},
						[2] = {
							["time"] = "|cffffffff01/19/13 11:34:09|r\n|Hunit:0x0100000004ED47D3:Natronn|hNatronn|h |Hspell:774:SPELL_PERIODIC_HEAL|h|cff82f4ffRejuvenation|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (41202 Overhealed) (Critical) ",
							["amount"] = 41202,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Rejuvenation",
					},
					["Eternal Flame"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 03:06:14|r\n|Hunit:0x0200000005F074AD:Fusroduh-Arthas|hFusroduh-Arthas|h |Hspell:114163:SPELL_PERIODIC_HEAL|h|cff82f4ffEternal Flame|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff4461|r |cff82f4ffHoly|r. ",
							["amount"] = 4461,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 03:05:56|r\n|Hunit:0x0200000005F074AD:Fusroduh-Arthas|hFusroduh-Arthas|h |Hspell:114163:SPELL_HEAL|h|cff82f4ffEternal Flame|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff51885|r |cff82f4ffHoly|r. (10340 Overhealed) (Critical) ",
							["amount"] = 62225,
						},
						["icon"] = "Interface\\Icons\\INV_Torch_Thrown",
					},
					["Healing Rain"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:13:04|r\n|Hunit:0x0100000002992D67:Musicman|hMusicman|h |Hspell:73921:SPELL_HEAL|h|cff82f4ffHealing Rain|r|h |Haction:SPELL_HEAL|hhealed|h |Hicon:128:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (12741 Overhealed) ",
							["amount"] = 12741,
						},
						[2] = {
							["time"] = "|cffffffff01/01/13 11:13:27|r\n|Hunit:0x0100000002992D67:Musicman|hMusicman|h |Hspell:73921:SPELL_HEAL|h|cff82f4ffHealing Rain|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (17345 Overhealed) (Critical) ",
							["amount"] = 17345,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_GiftoftheWaterSpirit",
					},
					["Chi Torpedo"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 07:03:51|r\n|Hunit:0x04800000057E5738:Lichkengfu-EmeraldDream|hLichkengfu-EmeraldDream|h |Hspell:124040:SPELL_HEAL|h|cff82f4ffChi Torpedo|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff13978|r |cff82f4ffNature|r. ",
							["amount"] = 13978,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_quitornado",
					},
					["Light of Dawn"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 02:57:42|r\n|Hunit:0x0600000003787746:Brutalhealer-Hyjal|hBrutalhealer-Hyjal|h |Hspell:85222:SPELL_HEAL|h|cff82f4ffLight of Dawn|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff16473|r |cff82f4ffHoly|r. ",
							["amount"] = 16473,
						},
						[2] = {
							["time"] = "|cffffffff01/08/13 11:14:11|r\n|Hunit:0x030000000380062E:Paladumb-Nagrand|hPaladumb-Nagrand|h |Hspell:85222:SPELL_HEAL|h|cff82f4ffLight of Dawn|r|h |Haction:SPELL_HEAL|hhealed|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff21286|r |cff82f4ffHoly|r. (21449 Overhealed) (Critical) ",
							["amount"] = 42735,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_paladin_lightofdawn",
					},
					["Ancestral Awakening"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 07:04:17|r\n|Hunit:0x0180000004C98F0B:Tuggles-Darkspear|hTuggles-Darkspear|h |Hspell:52752:SPELL_HEAL|h|cff82f4ffAncestral Awakening|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff6831|r |cff82f4ffNature|r. ",
							["amount"] = 6831,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_AncestralAwakening",
					},
					["Restorative Mists"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:14:34|r\n|Hunit:0x0100000002992D67:Musicman|hMusicman|h |Hspell:114083:SPELL_HEAL|h|cff82f4ffRestorative Mists|r|h |Haction:SPELL_HEAL|hhealed|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (28372 Overhealed) ",
							["amount"] = 28372,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_TidalWaves",
					},
					["Flash of Light"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 02:55:26|r\n|Hunit:0x0600000003787746:Brutalhealer-Hyjal|hBrutalhealer-Hyjal|h |Hspell:19750:SPELL_HEAL|h|cff82f4ffFlash of Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff46336|r |cff82f4ffHoly|r. ",
							["amount"] = 46336,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 02:55:41|r\n|Hunit:0x0600000003787746:Brutalhealer-Hyjal|hBrutalhealer-Hyjal|h |Hspell:19750:SPELL_HEAL|h|cff82f4ffFlash of Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff67666|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 67666,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					},
					["Aggressive Behavior"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:14:37|r\n|Hicon:8:source|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_4.blp:0|t|h|Hunit:0xF550EC4B00B4C85A:Sha of Anger|hSha of Anger|h |Hspell:119626:SPELL_HEAL|h|cffff1313Aggressive Behavior|r|h |Haction:SPELL_HEAL|hhealed|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYou|h |cffff13130|r |cffff1313Shadow|r. (408720 Overhealed) ",
							["amount"] = 408720,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Misc_EmotionAngry",
					},
					["Tranquility"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 12:16:35|r\n|Hunit:0x0100000005268D5C:Korova-Frostmane|hKorova-Frostmane|h |Hspell:44203:SPELL_HEAL|h|cff82f4ffTranquility|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff39047|r |cff82f4ffNature|r. ",
							["amount"] = 39047,
						},
						[2] = {
							["time"] = "|cffffffff01/08/13 11:14:28|r\n|Hunit:0x0180000004D4E0BC:Eriesel-Boulderfist|hEriesel-Boulderfist|h |Hspell:44203:SPELL_HEAL|h|cff82f4ffTranquility|r|h |Haction:SPELL_HEAL|hhealed|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff34087|r |cff82f4ffNature|r. (40036 Overhealed) (Critical) ",
							["amount"] = 74123,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_Tranquility",
					},
					["Divine Light"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 03:05:36|r\n|Hunit:0x0200000005F074AD:Fusroduh-Arthas|hFusroduh-Arthas|h |Hspell:82326:SPELL_HEAL|h|cff82f4ffDivine Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff35211|r |cff82f4ffHoly|r. ",
							["amount"] = 35211,
						},
						[2] = {
							["time"] = "|cffffffff01/01/13 04:36:05|r\n|Hunit:0x03000000076886CB:Bubblybêar-Kil'jaeden|hBubblybêar-Kil'jaeden|h |Hspell:82326:SPELL_HEAL|h|cff82f4ffDivine Light|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (76386 Overhealed) (Critical) ",
							["amount"] = 76386,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SurgeOfLight",
					},
					["Healing Touch"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:14:40|r\n|Hunit:0x0180000004D4E0BC:Eriesel-Boulderfist|hEriesel-Boulderfist|h |Hspell:5185:SPELL_HEAL|h|cff82f4ffHealing Touch|r|h |Haction:SPELL_HEAL|hhealed|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (124636 Overhealed) ",
							["amount"] = 124636,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingTouch",
					},
					["Penance"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 04:13:08|r\n|Hunit:0x0100000003C4594F:Youjizz-Bonechewer|hYoujizz-Bonechewer|h |Hspell:47750:SPELL_HEAL|h|cff82f4ffPenance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff19506|r |cff82f4ffHoly|r. ",
							["amount"] = 19506,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 04:13:07|r\n|Hunit:0x0100000003C4594F:Youjizz-Bonechewer|hYoujizz-Bonechewer|h |Hspell:47750:SPELL_HEAL|h|cff82f4ffPenance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff37715|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 37715,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Penance",
					},
					["Holy Shock"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 02:57:40|r\n|Hunit:0x0600000003787746:Brutalhealer-Hyjal|hBrutalhealer-Hyjal|h |Hspell:25914:SPELL_HEAL|h|cff82f4ffHoly Shock|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff38826|r |cff82f4ffHoly|r. ",
							["amount"] = 38826,
						},
						[2] = {
							["time"] = "|cffffffff01/01/13 11:12:56|r\n|Hunit:0x01000000013E8DEF:Church|hChurch|h |Hspell:25914:SPELL_HEAL|h|cff82f4ffHoly Shock|r|h |Haction:SPELL_HEAL|hhealed|h |Hicon:128:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff106674|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 106674,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SearingLight",
					},
					["Regrowth"] = {
						[-2] = {
							["time"] = "|cffffffff02/10/13 12:16:31|r\n|Hunit:0x0100000005268D5C:Korova-Frostmane|hKorova-Frostmane|h |Hspell:8936:SPELL_HEAL|h|cff82f4ffRegrowth|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff45380|r |cff82f4ffNature|r. ",
							["amount"] = 45380,
						},
						[2] = {
							["time"] = "|cffffffff02/10/13 12:16:21|r\n|Hunit:0x0100000005268D5C:Korova-Frostmane|hKorova-Frostmane|h |Hspell:8936:SPELL_HEAL|h|cff82f4ffRegrowth|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff97129|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 97129,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_ResistNature",
					},
					["Lifebloom"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:13:56|r\n|Hicon:128:source|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8.blp:0|t|h|Hunit:0x0100000002C34A8B:Muchogrande-Terenas|hMuchogrande-Terenas|h |Hspell:33778:SPELL_HEAL|h|cff82f4ffLifebloom|r|h |Haction:SPELL_HEAL|hhealed|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (91123 Overhealed) ",
							["amount"] = 91123,
						},
						[2] = {
							["time"] = "|cffffffff01/08/13 11:14:56|r\n|Hunit:0x0180000004D4E0BC:Eriesel-Boulderfist|hEriesel-Boulderfist|h |Hspell:33778:SPELL_HEAL|h|cff82f4ffLifebloom|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (138401 Overhealed) (Critical) ",
							["amount"] = 138401,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_HealingTouch",
					},
					["Nourish"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 11:23:19|r\n|Hunit:0x0100000004ED47D3:Natronn|hNatronn|h |Hspell:50464:SPELL_HEAL|h|cff82f4ffNourish|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff41191|r |cff82f4ffNature|r. ",
							["amount"] = 41191,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Nourish",
					},
					["Wild Growth"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 11:36:52|r\n|Hunit:0x0100000004ED47D3:Natronn|hNatronn|h |Hspell:48438:SPELL_PERIODIC_HEAL|h|cff82f4ffWild Growth|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff5326|r |cff82f4ffNature|r. ",
							["amount"] = 5326,
						},
						[2] = {
							["time"] = "|cffffffff01/19/13 11:25:59|r\n|Hunit:0x0100000004ED47D3:Natronn|hNatronn|h |Hspell:48438:SPELL_PERIODIC_HEAL|h|cff82f4ffWild Growth|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff10575|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 10575,
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_Flourish",
					},
					["Living Seed"] = {
						[-2] = {
							["time"] = "|cffffffff01/19/13 11:35:05|r\n|Hunit:0x0100000004ED47D3:Natronn|hNatronn|h |Hspell:48503:SPELL_HEAL|h|cff82f4ffLiving Seed|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff13360|r |cff82f4ffNature|r. (23134 Overhealed) ",
							["amount"] = 36494,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Druid_GiftoftheEarthmother",
					},
					["Stay of Execution"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 02:51:24|r\n|Hunit:0x0600000003787746:Brutalhealer-Hyjal|hBrutalhealer-Hyjal|h |Hspell:114917:SPELL_PERIODIC_HEAL|h|cff82f4ffStay of Execution|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (60139 Overhealed) ",
							["amount"] = 60139,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 02:51:19|r\n|Hunit:0x0600000003787746:Brutalhealer-Hyjal|hBrutalhealer-Hyjal|h |Hspell:114917:SPELL_PERIODIC_HEAL|h|cff82f4ffStay of Execution|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (16431 Overhealed) (Critical) ",
							["amount"] = 16431,
						},
						["icon"] = "Interface\\Icons\\spell_paladin_executionsentence",
					},
					["Rapid Renewal"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 03:40:37|r\n|Hunit:0x03000000039AB973:Laydgaga-Proudmoore|hLaydgaga-Proudmoore|h |Hspell:63544:SPELL_HEAL|h|cff82f4ffRapid Renewal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff6688|r |cff82f4ffHoly|r. ",
							["amount"] = 6688,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Renew",
					},
					["Lightspring Renew"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 03:37:24|r\n|Hunit:0x03000000039AB973:Laydgaga-Proudmoore|hLaydgaga-Proudmoore|h |Hspell:126154:SPELL_PERIODIC_HEAL|h|cff82f4ffLightspring Renew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff16585|r |cff82f4ffHoly|r. ",
							["amount"] = 16585,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 03:37:21|r\n|Hunit:0x03000000039AB973:Laydgaga-Proudmoore|hLaydgaga-Proudmoore|h |Hspell:126154:SPELL_PERIODIC_HEAL|h|cff82f4ffLightspring Renew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff34165|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 34165,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_SummonLightwell",
					},
					["Cascade"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:13:55|r\n|Hunit:0x0100000004DD3052:Stream|hStream|h |Hspell:121148:SPELL_HEAL|h|cff82f4ffCascade|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (46113 Overhealed) ",
							["amount"] = 46113,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 03:53:03|r\n|Hunit:0x03000000039AB973:Laydgaga-Proudmoore|hLaydgaga-Proudmoore|h |Hspell:121148:SPELL_HEAL|h|cff82f4ffCascade|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff71516|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 71516,
						},
						["icon"] = "Interface\\Icons\\ability_priest_cascade",
					},
					["Healing Tide"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 07:17:59|r\n|Hunit:0x0680000002EB5DCA:Botabox-Nordrassil|hBotabox-Nordrassil|h |Hspell:114942:SPELL_HEAL|h|cff82f4ffHealing Tide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffPhysical|r. (28119 Overhealed) ",
							["amount"] = 28119,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 07:17:53|r\n|Hunit:0x0680000002EB5DCA:Botabox-Nordrassil|hBotabox-Nordrassil|h |Hspell:114942:SPELL_HEAL|h|cff82f4ffHealing Tide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffPhysical|r. (51964 Overhealed) (Critical) ",
							["amount"] = 51964,
						},
						["icon"] = "Interface\\Icons\\ability_shaman_healingtide",
					},
					["Renew"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 03:37:26|r\n|Hunit:0x03000000039AB973:Laydgaga-Proudmoore|hLaydgaga-Proudmoore|h |Hspell:139:SPELL_PERIODIC_HEAL|h|cff82f4ffRenew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff14859|r |cff82f4ffHoly|r. ",
							["amount"] = 14859,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 03:42:07|r\n|Hunit:0x03000000039AB973:Laydgaga-Proudmoore|hLaydgaga-Proudmoore|h |Hspell:139:SPELL_PERIODIC_HEAL|h|cff82f4ffRenew|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff30609|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 30609,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_Renew",
					},
					["Ancestral Guidance"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 03:07:26|r\n|Hunit:0x0500000004C1B9C1:Fowshow-Mal'Ganis|hFowshow-Mal'Ganis|h |Hspell:114911:SPELL_HEAL|h|cff82f4ffAncestral Guidance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff16215|r |cff82f4ffPhysical|r. (43824 Overhealed) ",
							["amount"] = 60039,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_shaman_ancestralguidance",
					},
					["Magnetic Shroud Overload"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 03:32:15|r\n|Hunit:0x03000000039AB973:Laydgaga-Proudmoore|hLaydgaga-Proudmoore|h |Hspell:107174:SPELL_HEAL|h|cff82f4ffMagnetic Shroud Overload|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff18750|r |cff82f4ffPhysical|r. ",
							["amount"] = 18750,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Trade_Engineering",
					},
					["Word of Glory"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:13:46|r\n|Hicon:128:source|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8.blp:0|t|h|Hunit:0x030000000380062E:Paladumb-Nagrand|hPaladumb-Nagrand|h |Hspell:130551:SPELL_HEAL|h|cff82f4ffWord of Glory|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff55045|r |cff82f4ffHoly|r. ",
							["amount"] = 55045,
						},
						[2] = {
						},
						["icon"] = "INTERFACE\\ICONS\\inv_helmet_96",
					},
					["Binding Heal"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 03:42:06|r\n|Hunit:0x03000000039AB973:Laydgaga-Proudmoore|hLaydgaga-Proudmoore|h |Hspell:32546:SPELL_HEAL|h|cff82f4ffBinding Heal|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff41177|r |cff82f4ffHoly|r. ",
							["amount"] = 41177,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_BlindingHeal",
					},
					["Prayer of Healing"] = {
						[-2] = {
							["time"] = "|cffffffff01/08/13 11:14:36|r\n|Hunit:0x03000000074C5D45:Shaack-Frostmourne|hShaack-Frostmourne|h |Hspell:596:SPELL_HEAL|h|cff82f4ffPrayer of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hicon:64:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_7.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (42701 Overhealed) ",
							["amount"] = 42701,
						},
						[2] = {
							["time"] = "|cffffffff01/01/13 11:13:01|r\n|Hunit:0x0100000003A59536:Rarebooty|hRarebooty|h |Hspell:596:SPELL_HEAL|h|cff82f4ffPrayer of Healing|r|h |Haction:SPELL_HEAL|hhealed|h |Hicon:128:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff9132|r |cff82f4ffHoly|r. (61629 Overhealed) (Critical) ",
							["amount"] = 70761,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfHealing02",
					},
					["Mistweaving"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 04:32:51|r\n|Hunit:0xF130FABD00000159:Tian Mistweaver|hTian Mistweaver|h |Hspell:125125:SPELL_PERIODIC_HEAL|h|cff82f4ffMistweaving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff19687|r |cff82f4ffNature|r. (38433 Overhealed) ",
							["amount"] = 58120,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_soothingmists",
					},
					["Vampiric Embrace"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 07:23:13|r\n|Hunit:0x0280000000A7F77D:Hephaestion-BurningLegion|hHephaestion-BurningLegion|h |Hspell:15290:SPELL_PERIODIC_HEAL|h|cff82f4ffVampiric Embrace|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff6519|r |cff82f4ffShadow|r. ",
							["amount"] = 6519,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shadow_UnsummonBuilding",
					},
					["Zen Sphere"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 07:03:12|r\n|Hunit:0x04800000057E5738:Lichkengfu-EmeraldDream|hLichkengfu-EmeraldDream|h |Hspell:124081:SPELL_PERIODIC_HEAL|h|cff82f4ffZen Sphere|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff4254|r |cff82f4ffNature|r. ",
							["amount"] = 4254,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 07:03:18|r\n|Hunit:0x04800000057E5738:Lichkengfu-EmeraldDream|hLichkengfu-EmeraldDream|h |Hspell:124081:SPELL_PERIODIC_HEAL|h|cff82f4ffZen Sphere|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff8763|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 8763,
						},
						["icon"] = "Interface\\Icons\\ability_monk_forcesphere",
					},
					["Earthliving"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:08:42|r\n|Hunit:0x0100000002992D67:Musicman|hMusicman|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (4127 Overhealed) ",
							["amount"] = 4127,
						},
						[2] = {
							["time"] = "|cffffffff01/01/13 11:08:48|r\n|Hunit:0x0100000002992D67:Musicman|hMusicman|h |Hspell:51945:SPELL_PERIODIC_HEAL|h|cff82f4ffEarthliving|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (8501 Overhealed) (Critical) ",
							["amount"] = 8501,
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_GiftEarthmother",
					},
					["Arcing Light"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 03:42:47|r\n|Hunit:0x0100000004F45239:Isatanka|hIsatanka|h |Hspell:119952:SPELL_PERIODIC_HEAL|h|cff82f4ffArcing Light|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff13059|r |cff82f4ffHoly|r. ",
							["amount"] = 13059,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 03:42:39|r\n|Hunit:0x0100000004F45239:Isatanka|hIsatanka|h |Hspell:119952:SPELL_PERIODIC_HEAL|h|cff82f4ffArcing Light|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff24097|r |cff82f4ffHoly|r. (Critical) ",
							["amount"] = 24097,
						},
						["icon"] = "Interface\\Icons\\spell_paladin_lightshammer",
					},
					["Riptide"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 07:18:17|r\n|Hunit:0x0680000002EB5DCA:Botabox-Nordrassil|hBotabox-Nordrassil|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff16543|r |cff82f4ffNature|r. ",
							["amount"] = 16543,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 07:04:00|r\n|Hunit:0x0180000004C98F0B:Tuggles-Darkspear|hTuggles-Darkspear|h |Hspell:61295:SPELL_HEAL|h|cff82f4ffRiptide|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff32015|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 32015,
						},
						["icon"] = "Interface\\Icons\\spell_nature_riptide",
					},
					["Lay on Hands"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 02:51:12|r\n|Hunit:0x0600000003787746:Brutalhealer-Hyjal|hBrutalhealer-Hyjal|h |Hspell:633:SPELL_HEAL|h|cff82f4ffLay on Hands|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff280173|r |cff82f4ffHoly|r. (41999 Overhealed) ",
							["amount"] = 322172,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_LayOnHands",
					},
					["Divine Hymn"] = {
						[-2] = {
							["time"] = "|cffffffff12/30/12 02:29:42|r\n|Hunit:0x05000000057BA988:Tangi-Mal'Ganis|hTangi-Mal'Ganis|h |Hspell:64844:SPELL_HEAL|h|cff82f4ffDivine Hymn|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff56578|r |cff82f4ffHoly|r. ",
							["amount"] = 56578,
						},
						[2] = {
							["time"] = "|cffffffff12/30/12 02:29:44|r\n|Hunit:0x05000000057BA988:Tangi-Mal'Ganis|hTangi-Mal'Ganis|h |Hspell:64844:SPELL_HEAL|h|cff82f4ffDivine Hymn|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff43211|r |cff82f4ffHoly|r. (69945 Overhealed) (Critical) ",
							["amount"] = 113156,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_DivineProvidence",
					},
					["Healing Wave"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 07:18:20|r\n|Hunit:0x0680000002EB5DCA:Botabox-Nordrassil|hBotabox-Nordrassil|h |Hspell:331:SPELL_HEAL|h|cff82f4ffHealing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff35573|r |cff82f4ffNature|r. ",
							["amount"] = 35573,
						},
						[2] = {
							["time"] = "|cffffffff11/22/12 07:04:41|r\n|Hunit:0x0180000004C98F0B:Tuggles-Darkspear|hTuggles-Darkspear|h |Hspell:331:SPELL_HEAL|h|cff82f4ffHealing Wave|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff55185|r |cff82f4ffNature|r. (8450 Overhealed) (Critical) ",
							["amount"] = 63635,
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_MagicImmunity",
					},
					["Holy Radiance"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 02:55:29|r\n|Hunit:0x0600000003787746:Brutalhealer-Hyjal|hBrutalhealer-Hyjal|h |Hspell:82327:SPELL_HEAL|h|cff82f4ffHoly Radiance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff13660|r |cff82f4ffHoly|r. ",
							["amount"] = 13660,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 02:51:28|r\n|Hunit:0x0600000003787746:Brutalhealer-Hyjal|hBrutalhealer-Hyjal|h |Hspell:82327:SPELL_HEAL|h|cff82f4ffHoly Radiance|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff0|r |cff82f4ffHoly|r. (23482 Overhealed) (Critical) ",
							["amount"] = 23482,
						},
						["icon"] = "INTERFACE\\ICONS\\spell_paladin_divinecircle",
					},
					["Healing Stream Totem"] = {
						[-2] = {
							["time"] = "|cffffffff11/22/12 07:18:30|r\n|Hunit:0x0680000002EB5DCA:Botabox-Nordrassil|hBotabox-Nordrassil|h |Hspell:52042:SPELL_PERIODIC_HEAL|h|cff82f4ffHealing Stream Totem|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff19578|r |cff82f4ffNature|r. ",
							["amount"] = 19578,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\INV_Spear_04",
					},
					["Atonement"] = {
						[-2] = {
							["time"] = "|cffffffff01/01/13 11:12:55|r\n|Hunit:0x0100000000C70143:Tempestk|hTempestk|h |Hspell:81751:SPELL_HEAL|h|cff82f4ffAtonement|r|h |Haction:SPELL_HEAL|hhealed|h |Hicon:128:dest|h|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_8.blp:0|t|h|Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff42835|r |cff82f4ffHoly|r. ",
							["amount"] = 42835,
						},
						[2] = {
							["time"] = "|cffffffff12/28/12 04:17:23|r\n|Hunit:0x0100000003C4594F:Youjizz-Bonechewer|hYoujizz-Bonechewer|h |Hspell:94472:SPELL_HEAL|h|cff82f4ffAtonement|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff11594|r |cff82f4ffHoly|r. (69335 Overhealed) (Critical) ",
							["amount"] = 80929,
						},
						["icon"] = "Interface\\Icons\\Spell_Holy_CircleOfRenewal",
					},
					["Spirit Mend"] = {
						[-2] = {
							["time"] = "|cffffffff12/28/12 02:51:06|r\n|Hunit:0xF140CC911C000007:Gondria|hGondria|h |Hspell:90361:SPELL_HEAL|h|cff82f4ffSpirit Mend|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x0100000000268382:Mootalia|hYou|h |cff82f4ff9897|r |cff82f4ffNature|r. ",
							["amount"] = 9897,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Shaman_SpiritLink",
					},
				},
			},
		},
	},
}
