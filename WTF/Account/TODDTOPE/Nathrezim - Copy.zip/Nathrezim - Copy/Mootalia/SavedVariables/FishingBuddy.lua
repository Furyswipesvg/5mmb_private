
FishingBuddy_Player = {
	["MinimapData"] = {
		["minimapPos"] = 188.9651586135744,
		["hide"] = false,
	},
	["Settings"] = {
		["TotalTimeFishing"] = 8711.10300000073,
		["ResetWatcher"] = 1,
		["STVPoolsOnly"] = 1,
		["ContestSupport"] = 1,
		["CaughtSoFar"] = 0,
		["WatcherLocation"] = {
			["y"] = -383.9999389648438,
			["x"] = 0,
		},
		["OutfitManager"] = "None",
	},
	["WasWearing"] = {
	},
	["Outfit"] = {
	},
}
