
REFDatabase = {
	{
		["MapInfo"] = "ArathiBasin",
		["HK"] = 44,
		["SpecialFields"] = {
			2, -- [1]
			1, -- [2]
		},
		["HordeNum"] = 15,
		["PlaceKB"] = 8,
		["PlaceFactionDamage"] = 10,
		["MMRChange"] = 0,
		["KB"] = 6,
		["PlaceFactionKB"] = 5,
		["PlaceHonor"] = 6,
		["PlaceFactionHonor"] = 6,
		["AllianceNum"] = 15,
		["PlaceHK"] = 6,
		["DataVersion"] = 18,
		["MapName"] = "Arathi Basin",
		["Honor"] = 173,
		["TalentSet"] = 2,
		["Healing"] = 677309,
		["PlaceDamage"] = 18,
		["PlaceHealing"] = 18,
		["PlaceFactionHealing"] = 9,
		["DurationRaw"] = 1444,
		["PreMMR"] = 0,
		["IsRated"] = false,
		["PlaceFactionHK"] = 6,
		["Winner"] = "Alliance",
		["Damage"] = 3356623,
		["TimeRaw"] = 1353641011,
	}, -- [1]
	{
		["MapInfo"] = "TwinPeaks",
		["HK"] = 4,
		["PlaceFactionKB"] = 1,
		["HordeNum"] = 10,
		["AllianceNum"] = 10,
		["DataVersion"] = 19,
		["MMRChange"] = 0,
		["KB"] = 1,
		["SpecialFields"] = {
			0, -- [1]
			0, -- [2]
		},
		["PlaceHonor"] = 11,
		["PlaceFactionHonor"] = 1,
		["Damage"] = 992885,
		["PlaceDamage"] = 13,
		["PlaceFactionDamage"] = 5,
		["PlaceFactionHK"] = 1,
		["Honor"] = 8,
		["TalentSet"] = 2,
		["Healing"] = 115081,
		["MapName"] = "Twin Peaks",
		["PlaceHealing"] = 15,
		["DurationRaw"] = 687,
		["PlaceFactionHealing"] = 7,
		["PreMMR"] = 0,
		["IsRated"] = false,
		["PlaceHK"] = 11,
		["Winner"] = "Alliance",
		["PlaceKB"] = 9,
		["TimeRaw"] = 1356734060,
	}, -- [2]
	{
		["MapInfo"] = "TempleofKotmogu",
		["HK"] = 44,
		["PlaceFactionKB"] = 5,
		["HordeNum"] = 10,
		["AllianceNum"] = 10,
		["DataVersion"] = 19,
		["MMRChange"] = 0,
		["KB"] = 6,
		["SpecialFields"] = {
		},
		["PlaceHonor"] = 4,
		["PlaceFactionHonor"] = 4,
		["Damage"] = 2478744,
		["PlaceDamage"] = 9,
		["PlaceFactionDamage"] = 5,
		["PlaceFactionHK"] = 5,
		["Honor"] = 127,
		["TalentSet"] = 2,
		["Healing"] = 306415,
		["MapName"] = "Temple of Kotmogu",
		["PlaceHealing"] = 16,
		["DurationRaw"] = 695,
		["PlaceFactionHealing"] = 10,
		["PreMMR"] = 0,
		["IsRated"] = false,
		["PlaceHK"] = 5,
		["Winner"] = "Horde",
		["PlaceKB"] = 5,
		["TimeRaw"] = 1356734781,
	}, -- [3]
	{
		["MapInfo"] = "ArathiBasin",
		["HK"] = 36,
		["PlaceFactionKB"] = 10,
		["HordeNum"] = 15,
		["AllianceNum"] = 15,
		["DataVersion"] = 19,
		["MMRChange"] = 0,
		["KB"] = 2,
		["SpecialFields"] = {
			0, -- [1]
			0, -- [2]
		},
		["PlaceHonor"] = 22,
		["PlaceFactionHonor"] = 9,
		["Damage"] = 3455116,
		["PlaceDamage"] = 15,
		["PlaceFactionDamage"] = 8,
		["PlaceFactionHK"] = 9,
		["Honor"] = 128,
		["TalentSet"] = 2,
		["Healing"] = 363653,
		["MapName"] = "Arathi Basin",
		["PlaceHealing"] = 21,
		["DurationRaw"] = 1446,
		["PlaceFactionHealing"] = 12,
		["PreMMR"] = 0,
		["IsRated"] = false,
		["PlaceHK"] = 22,
		["Winner"] = "Horde",
		["PlaceKB"] = 17,
		["TimeRaw"] = 1356736297,
	}, -- [4]
}
REFSettings = {
	["ArenaSupport"] = true,
	["MiniBarScale"] = 1,
	["MiniBarAnchor"] = "CENTER",
	["MiniBarOrder"] = {
		{
			"KillingBlows", -- [1]
			"HonorKills", -- [2]
			"Damage", -- [3]
			"Healing", -- [4]
			"Deaths", -- [5]
			"KDRatio", -- [6]
			"Honor", -- [7]
		}, -- [1]
		{
			"KillingBlows", -- [1]
			"HonorKills", -- [2]
			"Damage", -- [3]
			"Healing", -- [4]
			"Deaths", -- [5]
			"KDRatio", -- [6]
			"Honor", -- [7]
		}, -- [2]
	},
	["LDBShowPlace"] = false,
	["LastDayStats"] = {
		["2v2"] = 0,
		["3v3"] = 0,
		["RBG"] = 0,
		["Honor"] = 4000,
		["CP"] = 4950,
		["5v5"] = 0,
		["MMRBG"] = 0,
		["MMR"] = 0,
	},
	["RBGListFirstTime"] = true,
	["ShowMiniBar"] = false,
	["LDBBGMorph"] = true,
	["ShowMinimapButton"] = true,
	["MiniBarY"] = 0,
	["UNBGSupport"] = true,
	["LDBShowQueues"] = true,
	["MinimapPos"] = 45,
	["MiniBarVisible"] = {
		{
			["KillingBlows"] = 1,
			["HonorKills"] = 1,
			["Healing"] = 2,
			["Damage"] = 2,
		}, -- [1]
		{
			["KillingBlows"] = 1,
			["HonorKills"] = 1,
			["Healing"] = 2,
			["Damage"] = 2,
		}, -- [2]
	},
	["AllowQuery"] = true,
	["Version"] = 19,
	["LDBShowTotalBG"] = false,
	["LDBCPCap"] = true,
	["CurrentMMRBG"] = 0,
	["ArenasListFirstTime"] = true,
	["MiniBarX"] = 0,
	["LDBShowTotalArena"] = false,
	["ShowDetectedBuilds"] = true,
	["LDBHK"] = false,
	["CurrentMMR"] = 0,
	["RBGSupport"] = true,
	["LastDay"] = "18",
	["OnlyNew"] = false,
}
REFDatabaseA = {
}
