
EavesDropStatsDB = {
	["profileKeys"] = {
		["Pawsnreflect - Nathrezim"] = "Pawsnreflect - Nathrezim",
	},
	["profiles"] = {
		["Pawsnreflect - Nathrezim"] = {
			{
				["heal"] = {
					["Expel Harm"] = {
						[-2] = {
							["time"] = "|cffffffff11/20/12 11:48:54|r\n|Hunit:0x01000000051240AB:Pawsnreflect|hYour|h |Hspell:115072:SPELL_HEAL|h|cffffffffExpel Harm|r|h |Haction:SPELL_HEAL|hhealed|h |Hunit:0x01000000051240AB:Pawsnreflect|hYou|h |cffffffff0|r |cffffffffNature|r. (1596 Overhealed) ",
							["amount"] = 1596,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_expelharm",
					},
					["Zen Sphere"] = {
						[-2] = {
							["time"] = "|cffffffff11/20/12 11:48:36|r\n|Hunit:0x01000000051240AB:Pawsnreflect|hYour|h |Hspell:124081:SPELL_PERIODIC_HEAL|h|cffffffffZen Sphere|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000051240AB:Pawsnreflect|hYou|h |cffffffff0|r |cffffffffNature|r. (332 Overhealed) ",
							["amount"] = 332,
						},
						[2] = {
							["time"] = "|cffffffff11/20/12 11:48:40|r\n|Hunit:0x01000000051240AB:Pawsnreflect|hYour|h |Hspell:124081:SPELL_PERIODIC_HEAL|h|cffffffffZen Sphere|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000051240AB:Pawsnreflect|hYou|h |cffffffff0|r |cffffffffNature|r. (664 Overhealed) (Critical) ",
							["amount"] = 664,
						},
						["icon"] = "Interface\\Icons\\ability_monk_forcesphere",
					},
				},
				["hit"] = {
					["Melee Attack"] = {
						[-2] = {
							["time"] = "|cffffffff11/20/12 11:52:04|r\n|Hunit:0x01000000051240AB:Pawsnreflect|hYour|h |Haction:SWING_DAMAGE|h|cffffffffMelee|r|h |Haction:SWING_DAMAGE|hhit|h |Hunit:0xF130B6370000650C:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (Glancing) (97 Overkill) ",
							["amount"] = 98,
						},
						[2] = {
						},
					},
					["Breath of Fire"] = {
						[-2] = {
							["time"] = "|cffffffff11/20/12 11:48:57|r\n|Hunit:0x01000000051240AB:Pawsnreflect|hYour|h |Hspell:115181:SPELL_DAMAGE|h|cffffffffBreath of Fire|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130B6370000C62F:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffFire|r. (1090 Overkill) ",
							["amount"] = 1091,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_breathoffire",
					},
					["Zen Sphere"] = {
						[-2] = {
							["time"] = "|cffffffff11/20/12 11:48:40|r\n|Hunit:0x01000000051240AB:Pawsnreflect|hYour|h |Hspell:124098:SPELL_DAMAGE|h|cffffffffZen Sphere|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130B6370000C62F:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffNature|r. (123 Overkill) ",
							["amount"] = 124,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_forcesphere",
					},
					["Touch of Death"] = {
						[-2] = {
							["time"] = "|cffffffff11/20/12 11:45:44|r\n|Hunit:0x01000000051240AB:Pawsnreflect|hYour|h |Hspell:115080:SPELL_DAMAGE|h|cffffffffTouch of Death|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130B6370000650C:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (11456 Overkill) ",
							["amount"] = 11457,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_touchofdeath",
					},
					["Stagger"] = {
						[-2] = {
							["time"] = "|cffffffff12/26/12 06:37:46|r\n|Hunit:0x01000000051240AB:Pawsnreflect|hYour|h |Hspell:124255:SPELL_PERIODIC_DAMAGE|h|cffffffffStagger|r|h |Haction:SPELL_PERIODIC_DAMAGE|hdamaged|h |Hunit:0x01000000051240AB:Pawsnreflect|hYou|h |cffffffff246|r |cffffffffPhysical|r. ",
							["amount"] = 246,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Ability_Rogue_CheatDeath",
					},
					["Spinning Crane Kick"] = {
						[-2] = {
							["time"] = "|cffffffff11/20/12 11:49:28|r\n|Hunit:0x01000000051240AB:Pawsnreflect|hYour|h |Hspell:107270:SPELL_DAMAGE|h|cffffffffSpinning Crane Kick|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130B6370000C62F:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (160 Overkill) ",
							["amount"] = 161,
						},
						[2] = {
							["time"] = "|cffffffff11/20/12 11:52:22|r\n|Hunit:0x01000000051240AB:Pawsnreflect|hYour|h |Hspell:107270:SPELL_DAMAGE|h|cffffffffSpinning Crane Kick|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130B6370000A076:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (294 Overkill) (Critical) ",
							["amount"] = 295,
						},
						["icon"] = "Interface\\Icons\\ability_monk_cranekick_new",
					},
					["Keg Smash"] = {
						[-2] = {
							["time"] = "|cffffffff11/20/12 11:52:02|r\n|Hunit:0x01000000051240AB:Pawsnreflect|hYour|h |Hspell:121253:SPELL_DAMAGE|h|cffffffffKeg Smash|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130B6370000C62F:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (1055 Overkill) ",
							["amount"] = 1056,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\achievement_brewery_2",
					},
					["Jab"] = {
						[-2] = {
							["time"] = "|cffffffff11/20/12 11:48:13|r\n|Hunit:0x01000000051240AB:Pawsnreflect|hYour|h |Hspell:108557:SPELL_DAMAGE|h|cffffffffJab|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130B6370000C62F:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (125 Overkill) ",
							["amount"] = 126,
						},
						[2] = {
							["time"] = "|cffffffff11/20/12 11:49:21|r\n|Hunit:0x01000000051240AB:Pawsnreflect|hYour|h |Hspell:108557:SPELL_DAMAGE|h|cffffffffJab|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130B6370000C62F:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (80 Blocked) (186 Overkill) (Critical) ",
							["amount"] = 187,
						},
						["icon"] = "Interface\\Icons\\ability_monk_staffstrike",
					},
					["Tiger Palm"] = {
						[-2] = {
							["time"] = "|cffffffff11/20/12 11:49:21|r\n|Hunit:0x01000000051240AB:Pawsnreflect|hYour|h |Hspell:100787:SPELL_DAMAGE|h|cffffffffTiger Palm|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0xF130B6370000C62F:Training Dummy|hTraining Dummy|h |cffffffff1|r |cffffffffPhysical|r. (266 Overkill) ",
							["amount"] = 267,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\ability_monk_tigerpalm",
					},
				},
			}, -- [1]
			[-1] = {
				["hit"] = {
					["Physical"] = {
						[-2] = {
							["time"] = "|cffffffff11/20/12 11:43:00|r\n|Haction:ENVIRONMENTAL_DAMAGE|h|cffffffffFalling|r|h |Haction:ENVIRONMENTAL_DAMAGE|hdamaged|h |Hunit:0x01000000051240AB:Pawsnreflect|hYou|h |cffffffff5209|r |cffffffffPhysical|r. ",
							["amount"] = 5209,
						},
						[2] = {
						},
					},
					["Fire"] = {
						[-2] = {
							["time"] = "|cffffffff12/26/12 06:38:23|r\n|Hunit:0xF130759F00003EE0:Twilight Worshipper|hTwilight Worshipper|h |Hspell:17290:SPELL_DAMAGE|h|cffff1313Fireball|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000051240AB:Pawsnreflect|hYou|h |cffff13132427|r |cffff1313Fire|r. ",
							["amount"] = 2427,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Fire_FlameBolt",
					},
					["Nature"] = {
						[-2] = {
							["time"] = "|cffffffff12/26/12 06:31:54|r\n|Hunit:0xF130764700003CC1:Deep Crawler|hDeep Crawler|h |Hspell:56580:SPELL_DAMAGE|h|cffff1313Glutinous Poison|r|h |Haction:SPELL_DAMAGE|hhit|h |Hunit:0x01000000051240AB:Pawsnreflect|hYou|h |cffff1313750|r |cffff1313Nature|r. ",
							["amount"] = 750,
						},
						[2] = {
						},
						["icon"] = "Interface\\Icons\\Spell_Nature_ElementalShields",
					},
				},
				["heal"] = {
					["Soothing Mist"] = {
						[-2] = {
							["time"] = "|cffffffff12/26/12 06:38:16|r\n|Hunit:0x010000000513BAA0:Skadooch|hSkadooch|h |Hspell:115175:SPELL_PERIODIC_HEAL|h|cff82f4ffSoothing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000051240AB:Pawsnreflect|hYou|h |cff82f4ff2133|r |cff82f4ffNature|r. ",
							["amount"] = 2133,
						},
						[2] = {
							["time"] = "|cffffffff12/26/12 06:35:03|r\n|Hunit:0x010000000513BAA0:Skadooch|hSkadooch|h |Hspell:125953:SPELL_PERIODIC_HEAL|h|cff82f4ffSoothing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000051240AB:Pawsnreflect|hYou|h |cff82f4ff0|r |cff82f4ffNature|r. (2097 Overhealed) (Critical) ",
							["amount"] = 2097,
						},
						["icon"] = "Interface\\Icons\\ability_monk_soothingmists",
					},
					["Renewing Mist"] = {
						[-2] = {
							["time"] = "|cffffffff12/26/12 06:38:17|r\n|Hunit:0x010000000513BAA0:Skadooch|hSkadooch|h |Hspell:119611:SPELL_PERIODIC_HEAL|h|cff82f4ffRenewing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000051240AB:Pawsnreflect|hYou|h |cff82f4ff1652|r |cff82f4ffNature|r. ",
							["amount"] = 1652,
						},
						[2] = {
							["time"] = "|cffffffff12/26/12 06:38:23|r\n|Hunit:0x010000000513BAA0:Skadooch|hSkadooch|h |Hspell:119611:SPELL_PERIODIC_HEAL|h|cff82f4ffRenewing Mist|r|h |Haction:SPELL_PERIODIC_HEAL|hhealed|h |Hunit:0x01000000051240AB:Pawsnreflect|hYou|h |cff82f4ff3304|r |cff82f4ffNature|r. (Critical) ",
							["amount"] = 3304,
						},
						["icon"] = "Interface\\Icons\\ability_monk_renewingmists",
					},
				},
			},
		},
	},
}
