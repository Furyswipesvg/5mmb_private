
EavesDropStatsDB = {
	["profileKeys"] = {
		["Swingit - Nathrezim"] = "Swingit - Nathrezim",
	},
	["profiles"] = {
		["Swingit - Nathrezim"] = {
		},
	},
}
