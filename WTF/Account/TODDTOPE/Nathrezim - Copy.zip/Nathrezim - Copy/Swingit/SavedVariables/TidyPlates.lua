
TidyPlatesOptions = {
	["FriendlyAutomation"] = "No Automation",
	["EnableCastWatcher"] = false,
	["primary"] = "Neon/|cFFFF4400Damage",
	["_EnableMiniButton"] = false,
	["EnemyAutomation"] = "No Automation",
	["EnableMinimapButton"] = false,
	["WelcomeShown"] = true,
	["secondary"] = "Neon/|cFF3782D1Tank",
}
