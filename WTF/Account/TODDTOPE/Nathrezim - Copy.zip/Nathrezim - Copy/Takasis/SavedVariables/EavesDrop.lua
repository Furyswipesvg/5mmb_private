
EavesDropStatsDB = {
	["profileKeys"] = {
		["Takasis - Nathrezim"] = "Takasis - Nathrezim",
	},
	["profiles"] = {
		["Takasis - Nathrezim"] = {
		},
	},
}
