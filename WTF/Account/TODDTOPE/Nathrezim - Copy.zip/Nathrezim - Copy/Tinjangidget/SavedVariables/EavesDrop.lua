
EavesDropStatsDB = {
	["profileKeys"] = {
		["Tinjangidget - Nathrezim"] = "Tinjangidget - Nathrezim",
	},
	["profiles"] = {
		["Tinjangidget - Nathrezim"] = {
		},
	},
}
