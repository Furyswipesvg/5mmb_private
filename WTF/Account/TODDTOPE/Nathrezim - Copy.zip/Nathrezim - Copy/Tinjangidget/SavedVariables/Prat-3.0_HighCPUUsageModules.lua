
Prat3HighCPUPerCharDB = {
	["time"] = 1359956304,
	["scrollback"] = {
		["ChatFrame1"] = {
			{
				"|cff979797[21:38:24]|r|c00000000|r |Hchannel:channel:1|h[1] |h Joined Channel: |Hchannel:1|h[1. General - Dun Morogh]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				69, -- [5]
			}, -- [1]
			{
				"|cff979797[21:38:24]|r|c00000000|r |Hchannel:channel:3|h[3] |h Joined Channel: |Hchannel:3|h[3. LocalDefense - Dun Morogh]|h", -- [1]
				1, -- [2]
				0.7529412508010864, -- [3]
				0.7529412508010864, -- [4]
				71, -- [5]
			}, -- [2]
		},
	},
}
