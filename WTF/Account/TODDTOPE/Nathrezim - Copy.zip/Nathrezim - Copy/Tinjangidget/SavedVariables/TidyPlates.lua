
TidyPlatesOptions = {
	["_EnableMiniButton"] = false,
	["EnableMinimapButton"] = false,
	["WelcomeShown"] = true,
	["FriendlyAutomation"] = "No Automation",
	["EnemyAutomation"] = "No Automation",
	["primary"] = "Neon/|cFFFF4400Damage",
	["EnableCastWatcher"] = false,
	["secondary"] = "Neon/|cFF3782D1Tank",
}
